package cn.newcapec.foundation.privilege.utils;

import cn.newcapec.framework.core.model.BaseAccount;

public class LoginAccount extends BaseAccount {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6205238154195338091L;
	

}
