package cn.newcapec.foundation.privilege.dao.base;

import cn.newcapec.foundation.privilege.model.Resourcetype;
import cn.newcapec.framework.support.base.AppBaseDAO;

/**
 * 资源类型接口实现类
 * @author andy.li
 *
 */
@SuppressWarnings("all")
public abstract class BaseResourcetypeDAO extends AppBaseDAO<Resourcetype> {


}
