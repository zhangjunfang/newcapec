package cn.newcapec.foundation.privilege.dao.base;

import cn.newcapec.foundation.privilege.model.Menu;
import cn.newcapec.framework.support.base.AppBaseDAO;

/**
 * 菜单接口实现类
 *
 * @author hx
 *
 */

@SuppressWarnings("all")
public abstract class BaseMenuDAO extends AppBaseDAO<Menu> {

}
