package cn.newcapec.function.digitalcampus.common;

public interface SoftFilter extends SoftGod {

}
