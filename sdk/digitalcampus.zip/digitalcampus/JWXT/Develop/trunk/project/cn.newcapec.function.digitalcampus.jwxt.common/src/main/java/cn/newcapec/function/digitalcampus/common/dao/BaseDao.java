package cn.newcapec.function.digitalcampus.common.dao;

import org.springframework.stereotype.Repository;


@Repository
public class BaseDao extends AbstractDao {

}
