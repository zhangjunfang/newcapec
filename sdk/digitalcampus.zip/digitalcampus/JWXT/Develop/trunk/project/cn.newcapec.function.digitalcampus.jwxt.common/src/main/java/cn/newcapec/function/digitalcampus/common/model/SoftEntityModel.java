package cn.newcapec.function.digitalcampus.common.model;

import java.util.Date;

public interface SoftEntityModel extends SoftModel {

	
	String getIds();
	
	void setIds(String ids);
	
}
