/*
 * 该类功能及其特点的描述（例如：该类是用来……）
 *
 * @see（与该类相关联的类）：(XXX.java)
 */
/**
 * 
 */
package cn.newcapec.function.digitalcampus.common.dao;

/**
 * @author Administrator
 *
 */
/** 
 * <p>Title: AbstractDao</p>  
 * <p>Description: </p>  
 * <p>Copyright: Copyright (c) 郑州新开普电子股份有限公司 2013</p>  
 * @author 杨航(Sntey)
 * @version
 * @date 创建日期：2013-7-24
 * 修改日期：
 * 修改人：
 * 复审人：
 */
public class AbstractDao extends AbstractDaoHibernate {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7558442722151861793L;

}

