package cn.newcapec.function.digitalcampus.common;

public interface SoftListener extends SoftGod {

}
