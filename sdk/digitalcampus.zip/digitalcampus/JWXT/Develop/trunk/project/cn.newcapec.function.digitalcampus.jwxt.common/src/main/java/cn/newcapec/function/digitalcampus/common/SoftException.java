package cn.newcapec.function.digitalcampus.common;


public interface SoftException extends SoftGod {

}
