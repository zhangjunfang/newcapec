package cn.newcapec.function.digitalcampus.common;

public interface SoftUtils extends SoftGod {

}
