package cn.newcapec.function.digitalcampus.common;

import java.io.Serializable;

public interface SoftGod extends Serializable {
 
	/**
	 * author Sntey(YangHang)
	 * **/
}
