package cn.newcapec.framework.junit;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath*:config/spring-conf/*.xml"})
@TransactionConfiguration(defaultRollback=true)
public class BaseTestCaseSpringJunit4
{
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.junit.BaseTestCaseSpringJunit4
 * JD-Core Version:    0.6.0
 */