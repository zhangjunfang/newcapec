/*    */ package cn.newcapec.framework.utils.http;
/*    */ 
/*    */ public final class UrlUtil
/*    */ {
/*    */   public static final String trimEndSeparator(String url)
/*    */   {
/* 14 */     StringBuffer sb = new StringBuffer(url);
/* 15 */     for (int i = 0; i < sb.length(); i++)
/* 16 */       if (sb.charAt(i) != '/') {
/* 17 */         sb.delete(0, i);
/* 18 */         break;
/*    */       }
/* 20 */     for (int i = sb.length() - 1; (i >= 0) && (sb.charAt(i) == '/'); i--)
/* 21 */       sb.deleteCharAt(i);
/* 22 */     return sb.toString();
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.http.UrlUtil
 * JD-Core Version:    0.6.0
 */