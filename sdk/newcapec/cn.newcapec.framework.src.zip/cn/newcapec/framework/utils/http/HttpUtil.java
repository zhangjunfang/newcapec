/*      */ package cn.newcapec.framework.utils.http;
/*      */ 
/*      */ import java.io.BufferedReader;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.HttpURLConnection;
/*      */ import java.net.URL;
/*      */ import java.net.URLEncoder;
/*      */ import java.nio.charset.Charset;
/*      */ import java.security.cert.CertificateException;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Executors;
/*      */ import javax.net.ssl.SSLContext;
/*      */ import javax.net.ssl.TrustManager;
/*      */ import javax.net.ssl.X509TrustManager;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ import org.apache.commons.lang.exception.ExceptionUtils;
/*      */ import org.apache.http.Header;
/*      */ import org.apache.http.HeaderElement;
/*      */ import org.apache.http.HttpEntity;
/*      */ import org.apache.http.HttpResponse;
/*      */ import org.apache.http.NameValuePair;
/*      */ import org.apache.http.ParseException;
/*      */ import org.apache.http.StatusLine;
/*      */ import org.apache.http.client.ClientProtocolException;
/*      */ import org.apache.http.client.HttpClient;
/*      */ import org.apache.http.client.entity.UrlEncodedFormEntity;
/*      */ import org.apache.http.client.methods.HttpGet;
/*      */ import org.apache.http.client.methods.HttpPost;
/*      */ import org.apache.http.client.methods.HttpUriRequest;
/*      */ import org.apache.http.client.utils.URLEncodedUtils;
/*      */ import org.apache.http.conn.ClientConnectionManager;
/*      */ import org.apache.http.conn.scheme.Scheme;
/*      */ import org.apache.http.conn.scheme.SchemeRegistry;
/*      */ import org.apache.http.conn.ssl.SSLSocketFactory;
/*      */ import org.apache.http.entity.StringEntity;
/*      */ import org.apache.http.entity.mime.MultipartEntity;
/*      */ import org.apache.http.entity.mime.content.FileBody;
/*      */ import org.apache.http.entity.mime.content.StringBody;
/*      */ import org.apache.http.impl.client.DefaultHttpClient;
/*      */ import org.apache.http.message.BasicNameValuePair;
/*      */ import org.apache.http.util.EntityUtils;
/*      */ import org.apache.log4j.Logger;
/*      */ 
/*      */ public class HttpUtil
/*      */ {
/*   70 */   Logger logger = Logger.getLogger(getClass());
/*      */   private DefaultHttpClient httpClient;
/*      */ 
/*      */   public static HttpUtil getInstall()
/*      */   {
/*   86 */     return INSTALL_HANDLER.INSTALL;
/*      */   }
/*      */ 
/*      */   public static void main(String[] args) {
/*   90 */     String ss = "QQ截图20130611173223.png";
/*   91 */     ss = ss.replaceAll(".[^\\d\\w\\.]*", "");
/*   92 */     System.out.println(ss);
/*      */ 
/*   95 */     String abc = "azAZ09.打";
/*   96 */     for (byte b : abc.getBytes()) {
/*   97 */       System.out.println(b);
/*      */     }
/*      */ 
/*  100 */     System.exit(1);
/*      */ 
/*  102 */     System.out.println("1111111111");
/*      */ 
/*  104 */     DefaultHttpClient client = new DefaultHttpClient();
/*      */ 
/*  106 */     String url = "http://www.baidu.com";
/*  107 */     HttpGet httpGet = new HttpGet(url);
/*      */     try
/*      */     {
/*  110 */       HttpResponse response = client.execute(httpGet);
/*  111 */       String str = EntityUtils.toString(response.getEntity());
/*  112 */       System.out.println(str);
/*      */     } catch (ClientProtocolException e) {
/*  114 */       e.printStackTrace();
/*      */     } catch (IOException e) {
/*  116 */       e.printStackTrace();
/*      */     }
/*      */ 
/*  119 */     HttpUtil util = new HttpUtil();
/*  120 */     util.asyncConnect(url, HttpMethod.GET, new HttpConnectionCallback()
/*      */     {
/*      */       public void execute(String response) {
/*  123 */         System.out.println(response);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public void asyncConnect(String url, HttpMethod method, HttpConnectionCallback callback)
/*      */   {
/*  134 */     asyncConnect(url, null, method, callback);
/*      */   }
/*      */ 
/*      */   public void syncConnect(String url, HttpMethod method, HttpConnectionCallback callback)
/*      */   {
/*  139 */     syncConnect(url, null, method, callback);
/*      */   }
/*      */ 
/*      */   public void asyncConnect(String url, Map<String, String> params, HttpMethod method, HttpConnectionCallback callback)
/*      */   {
/*  146 */     Runnable runnable = new Runnable(url, params, method, callback) {
/*      */       public void run() {
/*  148 */         HttpUtil.this.syncConnect(this.val$url, this.val$params, this.val$method, this.val$callback);
/*      */       }
/*      */     };
/*  152 */     new Thread(runnable).start();
/*      */   }
/*      */ 
/*      */   public void syncConnect(String url, Map<String, String> params, HttpMethod method, HttpConnectionCallback callback)
/*      */   {
/*  158 */     String json = null;
/*  159 */     BufferedReader reader = null;
/*      */     try {
/*  161 */       HttpClient client = getHttpClient();
/*  162 */       HttpUriRequest request = getRequest(url, params, method);
/*  163 */       HttpResponse response = client.execute(request);
/*  164 */       if (response.getStatusLine().getStatusCode() == 200) {
/*  165 */         reader = new BufferedReader(
/*  166 */           new InputStreamReader(response
/*  166 */           .getEntity().getContent()));
/*  167 */         StringBuilder sb = new StringBuilder();
/*  168 */         for (String s = reader.readLine(); s != null; s = reader.readLine()) {
/*  169 */           sb.append(s);
/*      */         }
/*  171 */         json = sb.toString();
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (ClientProtocolException localClientProtocolException)
/*      */     {
/*      */       try
/*      */       {
/*  179 */         if (reader != null)
/*  180 */           reader.close();
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException1)
/*      */     {
/*      */       try
/*      */       {
/*  179 */         if (reader != null)
/*  180 */           reader.close();
/*      */       }
/*      */       catch (IOException localIOException2)
/*      */       {
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/*  179 */         if (reader != null)
/*  180 */           reader.close();
/*      */       }
/*      */       catch (IOException localIOException3) {
/*      */       }
/*      */     }
/*  185 */     callback.execute(json);
/*      */   }
/*      */ 
/*      */   private HttpUriRequest getRequest(String url, Map<String, String> params, HttpMethod method)
/*      */   {
/*  191 */     if (method.equals(HttpMethod.POST)) {
/*  192 */       List listParams = new ArrayList();
/*  193 */       if (params != null) {
/*  194 */         for (String name : params.keySet())
/*  195 */           listParams.add(new BasicNameValuePair(name, (String)params.get(name)));
/*      */       }
/*      */       try
/*      */       {
/*  199 */         UrlEncodedFormEntity entity = new UrlEncodedFormEntity(listParams);
/*  200 */         HttpPost request = new HttpPost(url);
/*  201 */         request.setHeader("Content-Type", "application/x-www-form-urlencoded");
/*  202 */         request.setEntity(entity);
/*  203 */         return request;
/*      */       } catch (UnsupportedEncodingException e) {
/*  205 */         throw new RuntimeException(e.getMessage(), e);
/*      */       }
/*      */     }
/*  208 */     if (url.indexOf("?") < 0) {
/*  209 */       url = url + "?";
/*      */     }
/*  211 */     if (params != null) {
/*  212 */       for (String name : params.keySet()) {
/*  213 */         url = url + "&" + name + "=" + URLEncoder.encode((String)params.get(name));
/*      */       }
/*      */     }
/*  216 */     HttpGet request = new HttpGet(url);
/*  217 */     return request;
/*      */   }
/*      */ 
/*      */   public HttpClient getHttpClient()
/*      */   {
/*  222 */     HttpClient result = new DefaultHttpClient();
/*  223 */     return result;
/*      */   }
/*      */ 
/*      */   public String sendGetRequest(String reqURL, String decodeCharset)
/*      */   {
/*  242 */     long responseLength = 0L;
/*  243 */     String responseContent = null;
/*  244 */     HttpClient httpClient = getHttpClient();
/*  245 */     HttpGet httpGet = new HttpGet(reqURL);
/*      */     try {
/*  247 */       HttpResponse response = httpClient.execute(httpGet);
/*  248 */       HttpEntity entity = response.getEntity();
/*  249 */       if (entity != null) {
/*  250 */         responseLength = entity.getContentLength();
/*  251 */         responseContent = EntityUtils.toString(entity, decodeCharset == null ? "UTF-8" : decodeCharset);
/*  252 */         EntityUtils.consume(entity);
/*      */       }
/*      */ 
/*  255 */       System.out.println("请求地址: " + httpGet.getURI());
/*  256 */       System.out.println("响应状态: " + response.getStatusLine());
/*  257 */       System.out.println("响应长度: " + responseLength);
/*  258 */       System.out.println("响应内容: " + responseContent);
/*      */     }
/*      */     catch (ClientProtocolException e) {
/*  261 */       log("该异常通常是协议错误导致,比如构造HttpGet对象时传入的协议不对(将'http'写成'htp')或者服务器端返回的内容不符合HTTP协议要求等,堆栈信息如下", 
/*  262 */         e);
/*      */     } catch (ParseException e) {
/*  264 */       log(e.getMessage(), e);
/*      */     } catch (IOException e) {
/*  266 */       log("该异常通常是网络原因引起的,如HTTP服务器未启动等,堆栈信息如下", e);
/*      */     } finally {
/*  268 */       httpClient.getConnectionManager().shutdown();
/*      */     }
/*      */ 
/*  271 */     return responseContent;
/*      */   }
/*      */ 
/*      */   public String sendPostRequest(String reqURL, String sendData, boolean isEncoder)
/*      */   {
/*  289 */     return sendPostRequest(reqURL, sendData, isEncoder, null, null);
/*      */   }
/*      */ 
/*      */   public String sendPostRequest(String reqURL, String sendData)
/*      */   {
/*  300 */     String responseContent = null;
/*  301 */     HttpClient httpClient = getHttpClient();
/*      */ 
/*  303 */     return sendPostRequest(reqURL, sendData, null);
/*      */   }
/*      */ 
/*      */   public String sendPostRequest(String reqURL, String sendData, String contentType)
/*      */   {
/*  311 */     String responseContent = null;
/*  312 */     HttpClient httpClient = getHttpClient();
/*      */     try
/*      */     {
/*  317 */       HttpPost httpPost = new HttpPost(reqURL);
/*  318 */       if ((contentType == null) || ("".equals(contentType)))
/*  319 */         httpPost.setHeader("Content-Type", "application/x-www-form-urlencoded");
/*      */       else {
/*  321 */         httpPost.setHeader("Content-Type", contentType);
/*      */       }
/*      */ 
/*  324 */       StringEntity entity = new StringEntity(sendData, "UTF-8");
/*  325 */       httpPost.setEntity(entity);
/*  326 */       HttpResponse response = httpClient.execute(httpPost);
/*  327 */       HttpEntity resEntity = response.getEntity();
/*      */ 
/*  329 */       if (resEntity != null) {
/*  330 */         responseContent = EntityUtils.toString(resEntity);
/*  331 */         EntityUtils.consume(resEntity);
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  335 */       e.printStackTrace();
/*  336 */       return "0";
/*      */     }
/*      */     finally {
/*  339 */       httpClient.getConnectionManager().shutdown();
/*      */     }
/*      */ 
/*  342 */     return responseContent;
/*      */   }
/*      */ 
/*      */   public String sendPostRequest(String reqURL, String sendData, boolean isEncoder, String encodeCharset, String decodeCharset)
/*      */   {
/*  375 */     String responseContent = null;
/*      */ 
/*  377 */     HttpClient httpClient = getHttpClient();
/*      */ 
/*  379 */     HttpPost httpPost = new HttpPost(reqURL);
/*      */ 
/*  383 */     httpPost.setHeader("Content-Type", "application/x-www-form-urlencoded");
/*      */     try
/*      */     {
/*  387 */       if (isEncoder)
/*      */       {
/*  389 */         List formParams = new ArrayList();
/*      */ 
/*  391 */         for (String str : sendData.split("&"))
/*      */         {
/*  393 */           formParams.add(new BasicNameValuePair(str.substring(0, str.indexOf("=")), str.substring(str.indexOf("=") + 1)));
/*      */         }
/*      */ 
/*  397 */         httpPost.setEntity(new StringEntity(URLEncodedUtils.format(formParams, encodeCharset == null ? "UTF-8" : encodeCharset)));
/*      */       }
/*      */       else {
/*  400 */         httpPost.setEntity(new StringEntity(sendData));
/*      */       }
/*      */ 
/*  403 */       HttpResponse response = httpClient.execute(httpPost);
/*  404 */       HttpEntity entity = response.getEntity();
/*      */ 
/*  406 */       if (entity != null) {
/*  407 */         responseContent = EntityUtils.toString(entity, decodeCharset == null ? "UTF-8" : decodeCharset);
/*  408 */         EntityUtils.consume(entity);
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  413 */       log("与[" + reqURL + "]通信过程中发生异常,堆栈信息如下", e);
/*      */     }
/*      */     finally
/*      */     {
/*  417 */       httpClient.getConnectionManager().shutdown();
/*      */     }
/*      */ 
/*  421 */     return responseContent;
/*      */   }
/*      */ 
/*      */   public String sendPostRequest(String reqURL, Map<String, String> params, String encodeCharset, String decodeCharset)
/*      */   {
/*  452 */     String responseContent = null;
/*      */ 
/*  454 */     HttpClient httpClient = getHttpClient();
/*      */ 
/*  456 */     HttpPost httpPost = new HttpPost(reqURL);
/*      */ 
/*  458 */     List formParams = new ArrayList();
/*      */ 
/*  460 */     for (Map.Entry entry : params.entrySet())
/*      */     {
/*  462 */       formParams.add(new BasicNameValuePair((String)entry.getKey(), (String)entry.getValue()));
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  468 */       httpPost.setEntity(
/*  469 */         new UrlEncodedFormEntity(formParams, 
/*  469 */         encodeCharset == null ? "UTF-8" : encodeCharset));
/*      */ 
/*  471 */       HttpResponse response = httpClient.execute(httpPost);
/*      */ 
/*  473 */       HttpEntity entity = response.getEntity();
/*      */ 
/*  475 */       if (entity != null)
/*      */       {
/*  477 */         responseContent = EntityUtils.toString(entity, 
/*  478 */           decodeCharset == null ? "UTF-8" : decodeCharset);
/*      */ 
/*  480 */         EntityUtils.consume(entity);
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  485 */       log("与[" + reqURL + "]通信过程中发生异常,堆栈信息如下", e);
/*      */     } finally {
/*  487 */       httpClient.getConnectionManager().shutdown();
/*      */     }
/*      */ 
/*  490 */     return responseContent;
/*      */   }
/*      */ 
/*      */   public String sendPostSSLRequest(String reqURL, Map<String, String> params)
/*      */   {
/*  508 */     return sendPostSSLRequest(reqURL, params, null, null);
/*      */   }
/*      */ 
/*      */   public String sendPostSSLRequest(String reqURL, Map<String, String> params, String encodeCharset, String decodeCharset)
/*      */   {
/*  539 */     String responseContent = "";
/*      */ 
/*  541 */     HttpClient httpClient = getHttpClient();
/*      */ 
/*  543 */     X509TrustManager xtm = new X509TrustManager()
/*      */     {
/*      */       public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException
/*      */       {
/*      */       }
/*      */ 
/*      */       public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException
/*      */       {
/*      */       }
/*      */ 
/*      */       public X509Certificate[] getAcceptedIssuers() {
/*  554 */         return null;
/*      */       }
/*      */ 
/*      */     };
/*      */     try
/*      */     {
/*  561 */       SSLContext ctx = SSLContext.getInstance("TLS");
/*      */ 
/*  563 */       ctx.init(null, new TrustManager[] { xtm }, null);
/*      */ 
/*  565 */       SSLSocketFactory socketFactory = new SSLSocketFactory(ctx);
/*      */ 
/*  567 */       httpClient.getConnectionManager().getSchemeRegistry()
/*  568 */         .register(new Scheme("https", 443, socketFactory));
/*      */ 
/*  570 */       HttpPost httpPost = new HttpPost(reqURL);
/*      */ 
/*  572 */       List formParams = new ArrayList();
/*      */ 
/*  574 */       for (Map.Entry entry : params.entrySet())
/*      */       {
/*  576 */         formParams.add(
/*  577 */           new BasicNameValuePair((String)entry.getKey(), 
/*  577 */           (String)entry
/*  577 */           .getValue()));
/*      */       }
/*      */ 
/*  581 */       httpPost.setEntity(
/*  582 */         new UrlEncodedFormEntity(formParams, 
/*  582 */         encodeCharset == null ? "UTF-8" : encodeCharset));
/*      */ 
/*  584 */       HttpResponse response = httpClient.execute(httpPost);
/*      */ 
/*  586 */       HttpEntity entity = response.getEntity();
/*      */ 
/*  588 */       if (entity != null)
/*      */       {
/*  590 */         responseContent = EntityUtils.toString(entity, 
/*  591 */           decodeCharset == null ? "UTF-8" : decodeCharset);
/*      */ 
/*  593 */         EntityUtils.consume(entity);
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  599 */       log("与[" + reqURL + "]通信过程中发生异常,堆栈信息为", e);
/*      */     }
/*      */     finally
/*      */     {
/*  603 */       httpClient.getConnectionManager().shutdown();
/*      */     }
/*      */ 
/*  607 */     return responseContent;
/*      */   }
/*      */ 
/*      */   public static String sendPostRequestByJava(String reqURL, Map<String, String> params)
/*      */   {
/*  632 */     StringBuilder sendData = new StringBuilder();
/*      */ 
/*  634 */     for (Map.Entry entry : params.entrySet())
/*      */     {
/*  636 */       sendData.append((String)entry.getKey()).append("=").append((String)entry.getValue()).append("&");
/*      */     }
/*      */ 
/*  639 */     if (sendData.length() > 0) {
/*  640 */       sendData.setLength(sendData.length() - 1);
/*      */     }
/*      */ 
/*  643 */     return sendPostRequestByJava(reqURL, sendData.toString());
/*      */   }
/*      */ 
/*      */   public static String sendPostRequestByJava(String reqURL, String sendData)
/*      */   {
/*  666 */     HttpURLConnection httpURLConnection = null;
/*  667 */     OutputStream out = null;
/*  668 */     InputStream in = null;
/*  669 */     int httpStatusCode = 0;
/*      */     try {
/*  671 */       URL sendUrl = new URL(reqURL);
/*  672 */       httpURLConnection = (HttpURLConnection)sendUrl.openConnection();
/*  673 */       httpURLConnection.setRequestMethod("POST");
/*  674 */       httpURLConnection.setDoOutput(true);
/*  675 */       httpURLConnection.setUseCaches(false);
/*  676 */       httpURLConnection.setConnectTimeout(30000);
/*  677 */       httpURLConnection.setReadTimeout(30000);
/*  678 */       out = httpURLConnection.getOutputStream();
/*  679 */       out.write(sendData.toString().getBytes());
/*      */ 
/*  683 */       out.flush();
/*      */ 
/*  687 */       httpStatusCode = httpURLConnection.getResponseCode();
/*      */ 
/*  710 */       in = httpURLConnection.getInputStream();
/*      */ 
/*  712 */       byte[] byteDatas = new byte[in.available()];
/*      */ 
/*  714 */       in.read(byteDatas);
/*      */ 
/*  716 */       str = new String(byteDatas) + "`" + httpStatusCode;
/*      */       return str;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  720 */       log(e.getMessage(), e);
/*      */ 
/*  722 */       String str = "Failed`" + httpStatusCode;
/*      */       return str;
/*      */     }
/*      */     finally
/*      */     {
/*  726 */       if (out != null)
/*      */       {
/*      */         try
/*      */         {
/*  730 */           out.close();
/*      */         }
/*      */         catch (Exception e) {
/*  733 */           log("关闭输出流时发生异常,堆栈信息如下", e);
/*      */         }
/*      */       }
/*  736 */       if (in != null) {
/*      */         try {
/*  738 */           in.close();
/*      */         } catch (Exception e) {
/*  740 */           log("关闭输入流时发生异常,堆栈信息如下", e);
/*      */         }
/*      */       }
/*  743 */       if (httpURLConnection != null) {
/*  744 */         httpURLConnection.disconnect();
/*  745 */         httpURLConnection = null;
/*      */       }
/*      */     }
/*  747 */     throw localObject;
/*      */   }
/*      */ 
/*      */   public String postFiles(Map<String, File> files, Map<String, String> params, String url)
/*      */   {
/*  762 */     String result = null;
/*      */     try {
/*  764 */       if (StringUtils.isBlank(url)) {
/*  765 */         this.logger.debug("postFiles url is null or empty");
/*  766 */         return result;
/*      */       }
/*      */ 
/*  769 */       HttpClient client = getHttpClient();
/*  770 */       HttpPost httppost = new HttpPost(url);
/*      */ 
/*  772 */       MultipartEntity reqEntity = new MultipartEntity();
/*  773 */       if ((params != null) && (params.size() > 0)) {
/*  774 */         for (Map.Entry entry : params.entrySet()) {
/*  775 */           reqEntity.addPart((String)entry.getKey(), new StringBody((String)entry.getValue(), Charset.forName("utf-8")));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  780 */       if ((files != null) && (files.size() > 0)) {
/*  781 */         for (Map.Entry entry : files.entrySet()) {
/*  782 */           String key = (String)entry.getKey();
/*  783 */           File file = (File)entry.getValue();
/*  784 */           if ((StringUtils.isNotBlank(key)) && (file != null) && (file.exists()) && (file.isFile())) {
/*  785 */             reqEntity.addPart(key, new FileBody(file, getFileNameRcn(file.getName()), "", "utf-8"));
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  790 */       httppost.setEntity(reqEntity);
/*      */ 
/*  793 */       this.logger.debug("执行: " + httppost.getRequestLine());
/*  794 */       HttpResponse response = client.execute(httppost);
/*      */ 
/*  796 */       HttpEntity resEntity = response.getEntity();
/*      */ 
/*  798 */       this.logger.debug("执行结果：" + response.getStatusLine().getStatusCode());
/*  799 */       if (resEntity != null) {
/*  800 */         result = EntityUtils.toString(resEntity, "utf-8");
/*  801 */         this.logger.debug("返回结果:" + result);
/*  802 */         EntityUtils.consume(resEntity);
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  806 */       this.logger.error(ExceptionUtils.getFullStackTrace(e));
/*      */     }
/*      */ 
/*  809 */     return result;
/*      */   }
/*      */ 
/*      */   private static String getFileNameRcn(String str)
/*      */   {
/*  822 */     String result = null;
/*  823 */     result = StringUtils.defaultIfEmpty(str, Math.round(Math.random() * 10000.0D));
/*  824 */     StringBuffer sb = new StringBuffer();
/*      */ 
/*  826 */     for (byte b : result.getBytes()) {
/*  827 */       int i = b;
/*  828 */       if ((i >= 97) && (i <= 122))
/*  829 */         sb.append((char)b);
/*  830 */       else if ((i >= 65) && (i <= 90))
/*  831 */         sb.append((char)b);
/*  832 */       else if ((i >= 48) && (i <= 57))
/*  833 */         sb.append((char)b);
/*  834 */       else if (i == 46) {
/*  835 */         sb.append((char)b);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  850 */     result = sb.toString();
/*  851 */     return result;
/*      */   }
/*      */ 
/*      */   public File download(Map<String, String> params, String url)
/*      */   {
/*  865 */     File result = null;
/*  866 */     HttpClient httpClient = getHttpClient();
/*  867 */     OutputStream out = null;
/*  868 */     InputStream in = null;
/*      */ 
/*  870 */     label594: 
/*      */     try { HttpPost post = new HttpPost(url);
/*  871 */       if ((params != null) && (params.size() > 0)) {
/*  872 */         List listParams = new ArrayList();
/*  873 */         for (Map.Entry entry : params.entrySet()) {
/*  874 */           listParams.add(new BasicNameValuePair((String)entry.getKey(), (String)entry.getValue()));
/*      */         }
/*  876 */         post.setEntity(new UrlEncodedFormEntity(listParams, Charset.forName("utf-8")));
/*  877 */         HttpResponse response = httpClient.execute(post);
/*  878 */         String filename = "";
/*  879 */         if (response.getStatusLine().getStatusCode() != 200) break label594; Header d_header = response.getLastHeader("Content-Disposition");
/*      */ 
/*  882 */         if (d_header != null) {
/*  883 */           HeaderElement[] els = d_header.getElements();
/*  884 */           if ((els != null) && (els.length > 0)) {
/*  885 */             for (HeaderElement headerElement : els) {
/*  886 */               String name = headerElement.getName();
/*  887 */               if ("attachment".equalsIgnoreCase(name)) {
/*  888 */                 NameValuePair[] nameValuepairs = headerElement.getParameters();
/*  889 */                 if ((nameValuepairs != null) && (nameValuepairs.length > 0)) {
/*  890 */                   for (NameValuePair nameValuePair : nameValuepairs) {
/*  891 */                     if ("filename".equalsIgnoreCase(nameValuePair.getName())) {
/*  892 */                       filename = nameValuePair.getValue();
/*  893 */                       filename = new String(filename.getBytes("ISO-8859-1"), "utf-8");
/*  894 */                       break;
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*  903 */         HttpEntity responseEntity = response.getEntity();
/*  904 */         if (responseEntity != null) {
/*  905 */           in = responseEntity.getContent();
/*  906 */           filename = System.getProperty("java.io.tmpdir") + File.separator + StringUtils.defaultIfEmpty(filename, String.valueOf(Math.round(Math.random() * 100000.0D)));
/*  907 */           result = new File(filename);
/*  908 */           out = new FileOutputStream(result);
/*      */ 
/*  910 */           byte[] b = new byte[1024];
/*  911 */           int length = 0;
/*  912 */           while ((length = in.read(b)) != -1) {
/*  913 */             out.write(b, 0, length);
/*      */           }
/*  915 */           out.flush();
/*      */         }
/*      */       }
/*      */     } catch (Exception e)
/*      */     {
/*  920 */       e.printStackTrace();
/*      */       try
/*      */       {
/*  923 */         httpClient.getConnectionManager().shutdown();
/*  924 */         if (in != null) {
/*  925 */           in.close();
/*      */         }
/*  927 */         if (out != null)
/*  928 */           out.close();
/*      */       }
/*      */       catch (IOException e) {
/*  931 */         e.printStackTrace();
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/*  923 */         httpClient.getConnectionManager().shutdown();
/*  924 */         if (in != null) {
/*  925 */           in.close();
/*      */         }
/*  927 */         if (out != null)
/*  928 */           out.close();
/*      */       }
/*      */       catch (IOException e) {
/*  931 */         e.printStackTrace();
/*      */       }
/*      */     }
/*  934 */     return result;
/*      */   }
/*      */ 
/*      */   public String sendJSON(String url, String jsonStr) {
/*  938 */     String result = "";
/*  939 */     HttpClient client = getHttpClient();
/*      */ 
/*  941 */     HttpPost post = new HttpPost(url);
/*  942 */     post.setHeader("Content-Type", "application/json");
/*  943 */     post.setEntity(new StringEntity(jsonStr, Charset.forName("utf-8")));
/*      */     try
/*      */     {
/*  946 */       HttpResponse response = client.execute(post);
/*  947 */       HttpEntity entity = response.getEntity();
/*  948 */       result = EntityUtils.toString(entity);
/*      */     } catch (ClientProtocolException e) {
/*  950 */       e.printStackTrace();
/*      */     } catch (IOException e) {
/*  952 */       e.printStackTrace();
/*      */     }
/*      */ 
/*  955 */     return result;
/*      */   }
/*      */ 
/*      */   public String sendJSON(String url, String jsonStr, boolean asyncFlag)
/*      */   {
/*  971 */     if (asyncFlag) {
/*  972 */       ExecutorService executorService = Executors.newSingleThreadExecutor();
/*      */       try {
/*  974 */         executorService.execute(new Runnable(url, jsonStr)
/*      */         {
/*      */           public void run() {
/*  977 */             if (HttpUtil.this.logger.isDebugEnabled()) {
/*  978 */               HttpUtil.this.logger.debug("sendJSON(url,jsonStr,asycFlag),url=" + this.val$url + ";jsonStr=" + this.val$jsonStr);
/*      */             }
/*  980 */             String result = HttpUtil.this.sendJSON(this.val$url, this.val$jsonStr);
/*  981 */             Logger logger = HttpUtil.this.logger;
/*  982 */             if (logger.isDebugEnabled())
/*  983 */               HttpUtil.this.logger.debug("sendJSON(url,jsonStr,asycFlag) result:" + result);
/*      */           } } );
/*      */       }
/*      */       catch (Exception e) {
/*  988 */         e.printStackTrace();
/*      */       } finally {
/*  990 */         executorService.shutdown();
/*      */       }
/*      */     }
/*      */     else {
/*  994 */       return sendJSON(url, jsonStr);
/*      */     }
/*  996 */     return "";
/*      */   }
/*      */ 
/*      */   public static void log(String str, Exception e)
/*      */   {
/* 1001 */     System.out.println(str);
/*      */   }
/*      */ 
/*      */   public static enum HttpMethod
/*      */   {
/*  129 */     GET, POST;
/*      */   }
/*      */ 
/*      */   private static class INSTALL_HANDLER
/*      */   {
/*   80 */     private static HttpUtil INSTALL = new HttpUtil(null);
/*      */ 
/*   81 */     static { INSTALL.httpClient = new DefaultHttpClient();
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.http.HttpUtil
 * JD-Core Version:    0.6.0
 */