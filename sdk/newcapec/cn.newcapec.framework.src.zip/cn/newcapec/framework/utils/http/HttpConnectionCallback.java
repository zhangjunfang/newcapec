package cn.newcapec.framework.utils.http;

public abstract interface HttpConnectionCallback
{
  public abstract void execute(String paramString);
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.http.HttpConnectionCallback
 * JD-Core Version:    0.6.0
 */