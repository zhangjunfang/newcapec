/*    */ package cn.newcapec.framework.utils.http;
/*    */ 
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.restlet.Client;
/*    */ import org.restlet.data.Form;
/*    */ import org.restlet.data.Method;
/*    */ import org.restlet.data.Protocol;
/*    */ import org.restlet.data.Reference;
/*    */ import org.restlet.data.Request;
/*    */ import org.restlet.data.Response;
/*    */ import org.restlet.resource.Representation;
/*    */ 
/*    */ public class RestClientUtil
/*    */ {
/* 25 */   Logger logger = Logger.getLogger(getClass());
/*    */   private static Client restClient;
/*    */ 
/*    */   public Client getClient()
/*    */   {
/* 41 */     Client result = restClient;
/* 42 */     return result;
/*    */   }
/*    */ 
/*    */   public static RestClientUtil getInstall()
/*    */   {
/* 50 */     return INSTALL_HANDLER.INSTALL;
/*    */   }
/*    */ 
/*    */   public Representation send(String url, Form form, RestMethod method)
/*    */   {
/* 65 */     Representation result = null;
/*    */ 
/* 67 */     if (StringUtils.isBlank(url)) {
/* 68 */       this.logger.error("send url is blank");
/* 69 */       return result;
/*    */     }
/*    */ 
/* 72 */     Client client = getClient();
/* 73 */     Reference itemsUri = new Reference(url);
/* 74 */     if (form == null) {
/* 75 */       form = new Form();
/*    */     }
/* 77 */     Representation rep = form.getWebRepresentation();
/*    */ 
/* 79 */     String methodStr = "GET";
/* 80 */     if (method != null) {
/* 81 */       methodStr = method.toString();
/*    */     }
/*    */ 
/* 84 */     Request requst = new Request(new Method(methodStr), itemsUri);
/* 85 */     requst.setEntity(rep);
/* 86 */     Response response = client.handle(requst);
/* 87 */     result = response.getEntity();
/* 88 */     return result;
/*    */   }
/*    */ 
/*    */   private static class INSTALL_HANDLER
/*    */   {
/* 35 */     private static RestClientUtil INSTALL = new RestClientUtil(null);
/*    */ 
/* 36 */     static { RestClientUtil.restClient = new Client(Protocol.HTTP);
/*    */     }
/*    */   }
/*    */ 
/*    */   public static enum RestMethod
/*    */   {
/* 46 */     GET, POST, DELETE, PUT;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.http.RestClientUtil
 * JD-Core Version:    0.6.0
 */