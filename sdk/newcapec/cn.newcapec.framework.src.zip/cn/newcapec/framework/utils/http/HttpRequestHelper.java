/*     */ package cn.newcapec.framework.utils.http;
/*     */ 
/*     */ import cn.newcapec.framework.base.log.LogEnabled;
/*     */ import cn.newcapec.framework.utils.tools.BeanUtils;
/*     */ import cn.newcapec.framework.utils.variant.VariantSet;
/*     */ import cn.newcapec.framework.utils.variant.VariantUtil;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletRequest;
/*     */ 
/*     */ public class HttpRequestHelper
/*     */   implements LogEnabled
/*     */ {
/*     */   private ServletRequest request;
/*     */ 
/*     */   public static HttpRequestHelper getInstance(ServletRequest request)
/*     */   {
/*  32 */     return new HttpRequestHelper(request);
/*     */   }
/*     */ 
/*     */   protected HttpRequestHelper(ServletRequest request) {
/*  36 */     this.request = request;
/*     */   }
/*     */ 
/*     */   public String getParameter(String name) {
/*  40 */     return this.request.getParameter(name);
/*     */   }
/*     */ 
/*     */   public String getString(String name)
/*     */   {
/*  49 */     String str = getParameter(name);
/*  50 */     if (str == null) {
/*  51 */       str = "";
/*     */     }
/*  53 */     return str;
/*     */   }
/*     */ 
/*     */   public String getString(String name, String defaultValue)
/*     */   {
/*     */     String str;
/*  65 */     if ((str = getParameter(name)) == null)
/*  66 */       return defaultValue;
/*  67 */     return str;
/*     */   }
/*     */ 
/*     */   public BigDecimal getBigdecimal(String name)
/*     */   {
/*  77 */     return VariantUtil.parseBigDecimal(getParameter(name));
/*     */   }
/*     */ 
/*     */   public BigDecimal getBigdecimal(String name, BigDecimal defaultValue)
/*     */   {
/*     */     String str;
/*  90 */     if ((str = getParameter(name)) == null)
/*  91 */       return defaultValue;
/*  92 */     return VariantUtil.parseBigDecimal(str);
/*     */   }
/*     */ 
/*     */   public int getInt(String name)
/*     */   {
/* 102 */     return VariantUtil.parseInt(getParameter(name));
/*     */   }
/*     */ 
/*     */   public int getInt(String name, int defaultValue)
/*     */   {
/*     */     String str;
/* 114 */     if ((str = getParameter(name)) == null)
/* 115 */       return defaultValue;
/* 116 */     return VariantUtil.parseInt(str);
/*     */   }
/*     */ 
/*     */   public long getLong(String name)
/*     */   {
/* 128 */     return VariantUtil.parseLong(getParameter(name));
/*     */   }
/*     */ 
/*     */   public long getLong(String name, long defaultValue)
/*     */   {
/*     */     String str;
/* 140 */     if ((str = getParameter(name)) == null)
/* 141 */       return defaultValue;
/* 142 */     return VariantUtil.parseLong(str);
/*     */   }
/*     */ 
/*     */   public float getFloat(String name)
/*     */   {
/* 153 */     return VariantUtil.parseFloat(getParameter(name));
/*     */   }
/*     */ 
/*     */   public float getFloat(String name, float defaultValue)
/*     */   {
/*     */     String str;
/* 166 */     if ((str = getParameter(name)) == null)
/* 167 */       return defaultValue;
/* 168 */     return VariantUtil.parseFloat(str);
/*     */   }
/*     */ 
/*     */   public double getDouble(String name)
/*     */   {
/* 178 */     return VariantUtil.parseDouble(getParameter(name));
/*     */   }
/*     */ 
/*     */   public double getDouble(String name, double defaultValue)
/*     */   {
/*     */     String str;
/* 190 */     if ((str = getParameter(name)) == null)
/* 191 */       return defaultValue;
/* 192 */     return VariantUtil.parseDouble(str);
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(String name)
/*     */   {
/* 201 */     return VariantUtil.parseBoolean(getParameter(name));
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(String name, boolean defaultValue)
/*     */   {
/*     */     String str;
/* 213 */     if ((str = getParameter(name)) == null)
/* 214 */       return defaultValue;
/* 215 */     return VariantUtil.parseBoolean(str);
/*     */   }
/*     */ 
/*     */   public Date getDate(String name)
/*     */   {
/* 224 */     return VariantUtil.parseDate(getParameter(name));
/*     */   }
/*     */ 
/*     */   public Date getDate(String name, Date defaultValue)
/*     */   {
/*     */     String str;
/* 237 */     if ((str = getParameter(name)) == null) {
/* 238 */       return defaultValue;
/*     */     }
/* 240 */     return VariantUtil.parseDate(str);
/*     */   }
/*     */ 
/*     */   public String[] getStringValues(String name)
/*     */   {
/* 253 */     String[] values = this.request.getParameterValues(name);
/* 254 */     return values;
/*     */   }
/*     */ 
/*     */   public void parametersToDO(Object object)
/*     */   {
/* 264 */     if ((object instanceof Map)) {
/* 265 */       parametersToMap((Map)object);
/* 266 */       return;
/*     */     }
/* 268 */     if ((object instanceof VariantSet)) {
/* 269 */       parametersToVariantSet((VariantSet)object);
/* 270 */       return;
/*     */     }
/* 272 */     parametersToBean(object);
/*     */   }
/*     */ 
/*     */   public Map parametersToMap()
/*     */   {
/* 281 */     HashMap hashMap = new HashMap();
/* 282 */     parametersToMap(hashMap);
/* 283 */     return hashMap;
/*     */   }
/*     */ 
/*     */   protected void parametersToBean(Object object)
/*     */   {
/* 293 */     Enumeration paramNames = this.request.getParameterNames();
/* 294 */     while (paramNames.hasMoreElements()) {
/* 295 */       String name = (String)paramNames.nextElement();
/* 296 */       String value = this.request.getParameter(name);
/* 297 */       BeanUtils.copyProperty(object, name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void parametersToMap(Map map)
/*     */   {
/* 307 */     Enumeration paramNames = this.request.getParameterNames();
/* 308 */     while (paramNames.hasMoreElements()) {
/* 309 */       String name = (String)paramNames.nextElement();
/* 310 */       map.put(name, this.request.getParameter(name));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void parametersToVariantSet(VariantSet variantSet)
/*     */   {
/* 320 */     Enumeration paramNames = this.request.getParameterNames();
/* 321 */     while (paramNames.hasMoreElements()) {
/* 322 */       String name = (String)paramNames.nextElement();
/* 323 */       variantSet.setString(name, this.request.getParameter(name));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void attributiesToDO(Object dest)
/*     */   {
/* 334 */     if ((dest instanceof Map)) {
/* 335 */       attributiesToMap((Map)dest);
/* 336 */       return;
/*     */     }
/* 338 */     if ((dest instanceof VariantSet)) {
/* 339 */       attributiesToVariantSet((VariantSet)dest);
/* 340 */       return;
/*     */     }
/* 342 */     attributiesToBean(dest);
/*     */   }
/*     */ 
/*     */   public Map attributiesToMap()
/*     */   {
/* 351 */     HashMap map = new HashMap();
/* 352 */     attributiesToMap(map);
/* 353 */     return map;
/*     */   }
/*     */ 
/*     */   protected void attributiesToBean(Object dest)
/*     */   {
/* 362 */     Enumeration attributeNames = this.request.getAttributeNames();
/* 363 */     while (attributeNames.hasMoreElements()) {
/* 364 */       String name = (String)attributeNames.nextElement();
/* 365 */       Object value = this.request.getAttribute(name);
/* 366 */       BeanUtils.copyProperty(dest, name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void attributiesToMap(Map map)
/*     */   {
/* 376 */     Enumeration attributes = this.request.getAttributeNames();
/* 377 */     while (attributes.hasMoreElements()) {
/* 378 */       String name = (String)attributes.nextElement();
/* 379 */       map.put(name, this.request.getAttribute(name));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void attributiesToVariantSet(VariantSet variant)
/*     */   {
/* 389 */     Enumeration attributes = this.request.getAttributeNames();
/* 390 */     while (attributes.hasMoreElements()) {
/* 391 */       String name = (String)attributes.nextElement();
/* 392 */       variant.setValue(name, this.request.getAttribute(name));
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.http.HttpRequestHelper
 * JD-Core Version:    0.6.0
 */