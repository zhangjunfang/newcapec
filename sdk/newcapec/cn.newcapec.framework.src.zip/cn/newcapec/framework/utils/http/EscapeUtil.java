/*     */ package cn.newcapec.framework.utils.http;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLDecoder;
/*     */ import java.net.URLEncoder;
/*     */ import org.apache.commons.lang.StringEscapeUtils;
/*     */ 
/*     */ public final class EscapeUtil
/*     */ {
/*     */   private static String toHex(char c)
/*     */   {
/*  17 */     return Integer.toHexString(c).toUpperCase();
/*     */   }
/*     */ 
/*     */   public static final String escape(String plainText)
/*     */   {
/*  28 */     if (plainText == null)
/*  29 */       return "";
/*  30 */     int i = plainText.length();
/*  31 */     StringBuffer result = new StringBuffer(i);
/*  32 */     for (int j = 0; j < i; j++)
/*     */     {
/*     */       char c;
/*  34 */       if ((c = plainText.charAt(j)) > '࿿')
/*  35 */         result.append("%u" + toHex(c));
/*  36 */       else if (c > 'ÿ')
/*  37 */         result.append("%u0" + toHex(c));
/*  38 */       else if (c > '')
/*  39 */         result.append("%u00" + toHex(c));
/*  40 */       else if (((c >= '0') && (c <= '9')) || ((c >= 'A') && (c <= 'Z')) || ((c >= 'a') && (c <= 'z')))
/*  41 */         result.append(c);
/*  42 */       else if (c > '\r')
/*  43 */         result.append("%" + toHex(c));
/*     */       else
/*  45 */         result.append("%0" + toHex(c));
/*     */     }
/*  47 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static String UrlEncode(String str) {
/*  51 */     return UrlEncode(str, "UTF-8");
/*     */   }
/*     */ 
/*     */   public static String UrlEncode(String str, String type)
/*     */   {
/*     */     try
/*     */     {
/*  59 */       return URLEncoder.encode(str, type); } catch (UnsupportedEncodingException ex) {
/*     */     }
/*  61 */     throw new RuntimeException("字符串编码错误", ex);
/*     */   }
/*     */ 
/*     */   public static String UrlDecode(String str)
/*     */   {
/*  66 */     return UrlDecode(str);
/*     */   }
/*     */ 
/*     */   public static String UrlDecode(String str, String type)
/*     */   {
/*     */     try
/*     */     {
/*  74 */       return URLDecoder.decode(str, type); } catch (UnsupportedEncodingException ex) {
/*     */     }
/*  76 */     throw new RuntimeException("字符串解码错误", ex);
/*     */   }
/*     */ 
/*     */   public static final String unescape(String encodedText)
/*     */   {
/*  88 */     if (encodedText == null)
/*  89 */       return "";
/*  90 */     StringBuffer temp = new StringBuffer(4);
/*  91 */     StringBuffer result = new StringBuffer();
/*  92 */     int len = encodedText.length();
/*  93 */     int j = 0;
/*  94 */     int k = 0;
/*  95 */     int l = 0;
/*  96 */     char c1 = '\000';
/*  97 */     for (int i = 0; i < len; i++) {
/*  98 */       char c = encodedText.charAt(i);
/*  99 */       if (k != 0) {
/* 100 */         if (j != 0) {
/* 101 */           j = 0;
/* 102 */           if (c == 'u') {
/* 103 */             l = 1;
/* 104 */             k = 1;
/* 105 */             continue;
/*     */           }
/*     */         }
/* 108 */         temp.append(c);
/* 109 */         if (temp.length() != (l != 0 ? 4 : 2))
/* 110 */           k = 1;
/*     */         else
/*     */           try
/*     */           {
/* 114 */             int i2 = Integer.parseInt(temp.toString(), 16);
/* 115 */             result.append((char)i2);
/* 116 */             temp.setLength(0);
/* 117 */             k = 0;
/* 118 */             l = 0;
/*     */           }
/*     */           catch (NumberFormatException ex) {
/* 121 */             throw new IllegalArgumentException("Unable to parse unicode value: " + temp);
/*     */           }
/*     */       }
/* 124 */       else if ((c == '%') || (c == '$')) {
/* 125 */         j = 1;
/* 126 */         c1 = c;
/* 127 */         k = 1;
/*     */       }
/*     */       else
/*     */       {
/* 132 */         result.append(c);
/*     */       }
/*     */     }
/* 135 */     if (j != 0)
/* 136 */       result.append(c1);
/* 137 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static final String escapeXml(String xml)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 149 */     return StringEscapeUtils.escapeXml(xml);
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.http.EscapeUtil
 * JD-Core Version:    0.6.0
 */