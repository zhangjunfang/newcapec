/*     */ package cn.newcapec.framework.utils.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.zip.GZIPOutputStream;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ public final class ResponseUtil
/*     */ {
/*     */   public static final OutputStream getOutputStream(HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/*  29 */     String str = request.getHeader("Accept-Encoding");
/*     */     OutputStream outputStream;
/*     */     OutputStream outputStream;
/*  31 */     if ((str != null) && (str.indexOf("gzip") != -1)) {
/*  32 */       response.setHeader("Content-Encoding", "gzip");
/*  33 */       outputStream = new GZIPOutputStream(response.getOutputStream());
/*     */     }
/*     */     else
/*     */     {
/*     */       OutputStream outputStream;
/*  34 */       if ((str != null) && (str.indexOf("compress") != -1)) {
/*  35 */         response.setHeader("Content-Encoding", "compress");
/*  36 */         outputStream = new ZipOutputStream(response.getOutputStream());
/*     */       } else {
/*  38 */         outputStream = response.getOutputStream();
/*     */       }
/*     */     }
/*  40 */     return outputStream;
/*     */   }
/*     */ 
/*     */   public static final void output(HttpServletRequest request, HttpServletResponse response, InputStream inputStream)
/*     */     throws IOException
/*     */   {
/*  53 */     OutputStream localOutputStream = getOutputStream(request, response);
/*     */     try { print(inputStream, localOutputStream);
/*     */       return; } finally {
/*  58 */       localOutputStream.close();
/*  59 */     }throw localObject;
/*     */   }
/*     */ 
/*     */   public static final void outputNoCompress(HttpServletRequest request, HttpServletResponse response, InputStream in)
/*     */     throws IOException
/*     */   {
/*  72 */     ServletOutputStream out = response.getOutputStream();
/*     */     try { print(in, out);
/*     */       return; } finally {
/*  77 */       out.close();
/*  78 */     }throw localObject;
/*     */   }
/*     */ 
/*     */   private static void print(InputStream input, OutputStream out)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  94 */       byte[] buffer = new byte[1024];
/*  95 */       for (int i = input.read(buffer); i != -1; i = input.read(buffer))
/*  96 */         out.write(buffer, 0, i);
/*  97 */       out.flush();
/*  98 */       return;
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String filter(String value)
/*     */   {
/* 110 */     if (value == null) {
/* 111 */       return null;
/*     */     }
/* 113 */     char[] content = new char[value.length()];
/* 114 */     value.getChars(0, value.length(), content, 0);
/* 115 */     StringBuffer result = new StringBuffer(content.length + 50);
/* 116 */     for (int i = 0; i < content.length; i++) {
/* 117 */       switch (content[i]) {
/*     */       case '<':
/* 119 */         result.append("&lt;");
/* 120 */         break;
/*     */       case '>':
/* 122 */         result.append("&gt;");
/* 123 */         break;
/*     */       case '&':
/* 125 */         result.append("&amp;");
/* 126 */         break;
/*     */       case '"':
/* 128 */         result.append("&quot;");
/* 129 */         break;
/*     */       case '\'':
/* 131 */         result.append("&#39;");
/* 132 */         break;
/*     */       default:
/* 134 */         result.append(content[i]);
/*     */       }
/*     */     }
/* 137 */     return result.toString();
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.http.ResponseUtil
 * JD-Core Version:    0.6.0
 */