/*     */ package cn.newcapec.framework.utils.variant;
/*     */ 
/*     */ import cn.newcapec.framework.utils.tools.DateUtil;
/*     */ import cn.newcapec.framework.utils.tools.StringUtil;
/*     */ import java.math.BigDecimal;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ 
/*     */ public final class VariantUtil
/*     */ {
/*  18 */   private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
/*     */ 
/*  22 */   private static SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
/*     */ 
/*  26 */   private static SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*     */ 
/*     */   public static final Object toObject(byte value) {
/*  29 */     return new Byte(value);
/*     */   }
/*     */ 
/*     */   public static final Object toObject(short value) {
/*  33 */     return new Short(value);
/*     */   }
/*     */ 
/*     */   public static final Object toObject(int value) {
/*  37 */     return new Integer(value);
/*     */   }
/*     */ 
/*     */   public static final Object toObject(long value) {
/*  41 */     return new Long(value);
/*     */   }
/*     */ 
/*     */   public static final Object toObject(float value) {
/*  45 */     return new Float(value);
/*     */   }
/*     */ 
/*     */   public static final Object toObject(double value) {
/*  49 */     return new Double(value);
/*     */   }
/*     */ 
/*     */   public static final Object toObject(boolean value) {
/*  53 */     return new Boolean(value);
/*     */   }
/*     */ 
/*     */   public static final Object toObject(Date value) {
/*  57 */     return value;
/*     */   }
/*     */ 
/*     */   public static final Object toObject(BigDecimal value) {
/*  61 */     return value;
/*     */   }
/*     */ 
/*     */   public static final Object toObject(String value) {
/*  65 */     return value;
/*     */   }
/*     */ 
/*     */   public static final String parseString(Object value)
/*     */   {
/*  75 */     if (value == null)
/*  76 */       return null;
/*  77 */     if ((value instanceof Date))
/*  78 */       return DateUtil.toDateString((Date)value);
/*  79 */     return value.toString();
/*     */   }
/*     */ 
/*     */   public static final byte parseByte(Object value)
/*     */   {
/*  89 */     if (value == null)
/*  90 */       return 0;
/*  91 */     if ((value instanceof Number))
/*  92 */       return ((Number)value).byteValue();
/*  93 */     if ((value instanceof Boolean))
/*  94 */       return (byte)(((Boolean)value).booleanValue() ? 1 : 0);
/*     */     String str;
/*  95 */     if ((str = value.toString()).equals(""))
/*  96 */       return 0;
/*  97 */     return Byte.parseByte(str);
/*     */   }
/*     */ 
/*     */   public static final short parseShort(Object value)
/*     */   {
/* 107 */     if (value == null)
/* 108 */       return 0;
/* 109 */     if ((value instanceof Number))
/* 110 */       return ((Number)value).shortValue();
/* 111 */     if ((value instanceof Boolean))
/* 112 */       return (short)(((Boolean)value).booleanValue() ? 1 : 0);
/*     */     String str;
/* 113 */     if ((str = value.toString()).equals(""))
/* 114 */       return 0;
/* 115 */     return Short.parseShort(str);
/*     */   }
/*     */ 
/*     */   public static final int parseInt(Object value)
/*     */   {
/* 126 */     if (value == null)
/* 127 */       return 0;
/* 128 */     if ((value instanceof Number))
/* 129 */       return ((Number)value).intValue();
/* 130 */     if ((value instanceof Boolean)) {
/* 131 */       if (((Boolean)value).booleanValue())
/* 132 */         return 1;
/* 133 */       return 0;
/*     */     }
/*     */     String str;
/* 135 */     if ((str = value.toString()).equals(""))
/* 136 */       return 0;
/* 137 */     return Integer.parseInt(str);
/*     */   }
/*     */ 
/*     */   public static final long parseLong(Object value)
/*     */   {
/* 148 */     if (value == null)
/* 149 */       return 0L;
/* 150 */     if ((value instanceof Number))
/* 151 */       return ((Number)value).longValue();
/* 152 */     if ((value instanceof Boolean)) {
/* 153 */       if (((Boolean)value).booleanValue())
/* 154 */         return 1L;
/* 155 */       return 0L;
/*     */     }
/* 157 */     if ((value instanceof Date))
/* 158 */       return ((Date)value).getTime();
/*     */     String str;
/* 159 */     if ((str = value.toString()).equals(""))
/* 160 */       return 0L;
/* 161 */     return Long.parseLong(str);
/*     */   }
/*     */ 
/*     */   public static final float parseFloat(Object value)
/*     */   {
/* 170 */     if (value == null)
/* 171 */       return 0.0F;
/* 172 */     if ((value instanceof Number))
/* 173 */       return ((Number)value).floatValue();
/* 174 */     if ((value instanceof Boolean)) {
/* 175 */       if (((Boolean)value).booleanValue())
/* 176 */         return 1.0F;
/* 177 */       return 0.0F;
/*     */     }
/*     */     String str;
/* 179 */     if ((str = value.toString()).equals(""))
/* 180 */       return 0.0F;
/* 181 */     return Float.parseFloat(str);
/*     */   }
/*     */ 
/*     */   public static final double parseDouble(Object value)
/*     */   {
/* 191 */     if (value == null)
/* 192 */       return 0.0D;
/* 193 */     if ((value instanceof Number))
/* 194 */       return ((Number)value).doubleValue();
/* 195 */     if ((value instanceof Boolean)) {
/* 196 */       if (((Boolean)value).booleanValue())
/* 197 */         return 1.0D;
/* 198 */       return 0.0D;
/*     */     }
/*     */     String str;
/* 200 */     if ((str = value.toString()).equals(""))
/* 201 */       return 0.0D;
/* 202 */     return Double.parseDouble(str);
/*     */   }
/*     */ 
/*     */   public static final BigDecimal parseBigDecimal(Object value)
/*     */   {
/* 212 */     if (value == null)
/* 213 */       return BigDecimal.valueOf(0L);
/* 214 */     if ((value instanceof BigDecimal))
/* 215 */       return (BigDecimal)value;
/* 216 */     if ((value instanceof Number))
/* 217 */       return BigDecimal.valueOf(((Number)value).longValue());
/* 218 */     if ((value instanceof Boolean))
/* 219 */       return BigDecimal.valueOf(((Boolean)value).booleanValue() ? 1L : 
/* 220 */         0L);
/*     */     String str;
/* 221 */     if ((str = value.toString()).equals(""))
/* 222 */       return BigDecimal.valueOf(0L);
/* 223 */     return new BigDecimal(str);
/*     */   }
/*     */ 
/*     */   public static final boolean parseBoolean(String value)
/*     */   {
/* 232 */     if (value == null)
/* 233 */       return false;
/* 234 */     return (value.equalsIgnoreCase("true")) || (value.equals("1")) || (value.equals("-1"));
/*     */   }
/*     */ 
/*     */   public static final boolean parseBoolean(Object value)
/*     */   {
/* 244 */     if (value == null)
/* 245 */       return false;
/* 246 */     if ((value instanceof Boolean))
/* 247 */       return ((Boolean)value).booleanValue();
/* 248 */     return parseBoolean(value.toString());
/*     */   }
/*     */ 
/*     */   private static boolean isNumber(String str)
/*     */   {
/* 257 */     int i = str.length();
/* 258 */     for (int j = 0; j < i; j++)
/*     */     {
/*     */       int k;
/* 260 */       if ((((k = str.charAt(j)) < '0') || (k > 57)) && (k != 46) && (
/* 261 */         (j != 0) || (k != 45)))
/* 262 */         return false;
/*     */     }
/* 264 */     return true;
/*     */   }
/*     */ 
/*     */   public static final Date parseDate(Object value)
/*     */   {
/* 274 */     if (value == null)
/* 275 */       return null;
/* 276 */     if ((value instanceof Date))
/* 277 */       return (Date)value;
/* 278 */     if ((value instanceof Number))
/* 279 */       return new Date(((Number)value).longValue());
/*     */     String str;
/* 280 */     if (StringUtil.isValid(str = String.valueOf(value))) {
/* 281 */       if (isNumber(str)) {
/* 282 */         long l = Long.parseLong(str);
/* 283 */         return new Date(l);
/*     */       }
/* 285 */       int i = str.length();
/*     */       try {
/* 287 */         if (i < 19) {
/* 288 */           if (str.indexOf(":") > 0)
/* 289 */             return timeFormat.parse(str);
/* 290 */           return dateFormat.parse(str);
/*     */         }
/* 292 */         return dateTimeFormat.parse(str);
/*     */       } catch (ParseException ex) {
/* 294 */         ex.printStackTrace();
/* 295 */         return null;
/*     */       }
/*     */     }
/* 298 */     return null;
/*     */   }
/*     */ 
/*     */   public static final Object translate(int dataType, Object obj)
/*     */   {
/* 308 */     if ((obj == null) || (
/* 309 */       ((obj instanceof String)) && 
/* 310 */       (((String)obj)
/* 310 */       .length() == 0))) {
/* 311 */       if (dataType == 1)
/* 312 */         return obj;
/* 313 */       return null;
/*     */     }
/* 315 */     switch (dataType) {
/*     */     case 1:
/* 317 */       return parseString(obj);
/*     */     case 9:
/* 319 */       return toObject(parseBoolean(obj));
/*     */     case 10:
/*     */     case 11:
/*     */     case 12:
/* 323 */       return parseDate(obj);
/*     */     case 4:
/* 325 */       return toObject(parseInt(obj));
/*     */     case 7:
/* 327 */       return toObject(parseDouble(obj));
/*     */     case 5:
/* 329 */       return toObject(parseLong(obj));
/*     */     case 6:
/* 331 */       return toObject(parseFloat(obj));
/*     */     case 8:
/* 333 */       return parseBigDecimal(obj);
/*     */     case 2:
/* 335 */       return toObject(parseByte(obj));
/*     */     case 3:
/* 337 */       return toObject(parseShort(obj));
/*     */     }
/* 339 */     return obj;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.variant.VariantUtil
 * JD-Core Version:    0.6.0
 */