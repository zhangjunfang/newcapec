/*     */ package cn.newcapec.framework.utils.variant;
/*     */ 
/*     */ public final class DataType
/*     */ {
/*     */   public static final String UNKNOWN_NAME = "";
/*     */   public static final int UNKNOWN = 0;
/*     */   public static final String STRING_NAME = "string";
/*     */   public static final int STRING = 1;
/*     */   public static final String BYTE_NAME = "byte";
/*     */   public static final int BYTE = 2;
/*     */   public static final String SHORT_NAME = "short";
/*     */   public static final int SHORT = 3;
/*     */   public static final String INT_NAME = "int";
/*     */   public static final int INT = 4;
/*     */   public static final String LONG_NAME = "long";
/*     */   public static final int LONG = 5;
/*     */   public static final String FLOAT_NAME = "float";
/*     */   public static final int FLOAT = 6;
/*     */   public static final String DOUBLE_NAME = "double";
/*     */   public static final int DOUBLE = 7;
/*     */   public static final String BIGDECIMAL_NAME = "bigdecimal";
/*     */   public static final int BIGDECIMAL = 8;
/*     */   public static final String BOOLEAN_NAME = "boolean";
/*     */   public static final int BOOLEAN = 9;
/*     */   public static final String DATE_NAME = "date";
/*     */   public static final int DATE = 10;
/*     */   public static final String TIME_NAME = "time";
/*     */   public static final int TIME = 11;
/*     */   public static final String DATETIME_NAME = "datetime";
/*     */   public static final int DATETIME = 12;
/*     */   public static final String BINARY_NAME = "binary";
/*     */   public static final int BINARY = 20;
/* 149 */   static Class booleanClazz = getClazz("java.lang.Boolean");
/*     */ 
/* 151 */   static Class byteClazz = getClazz("java.lang.Byte");
/*     */ 
/* 153 */   static Class doubleClazz = getClazz("java.lang.Double");
/*     */ 
/* 155 */   static Class floatClazz = getClazz("java.lang.Float");
/*     */ 
/* 157 */   static Class integerClazz = getClazz("java.lang.Integer");
/*     */ 
/* 159 */   static Class longClazz = getClazz("java.lang.Long");
/*     */ 
/* 161 */   static Class numberClazz = getClazz("java.lang.Number");
/*     */ 
/* 163 */   static Class shortClazz = getClazz("java.lang.Short");
/*     */ 
/* 165 */   static Class stringClazz = getClazz("java.lang.String");
/*     */ 
/* 167 */   static Class bigDecimalClazz = getClazz("java.math.BigDecimal");
/*     */ 
/* 169 */   static Class sqlDateClazz = getClazz("java.sql.Date");
/*     */ 
/* 171 */   static Class timeClazz = getClazz("java.sql.Time");
/*     */ 
/* 173 */   static Class timeStampClazz = getClazz("java.sql.Timestamp");
/*     */ 
/* 175 */   static Class dateClazz = getClazz("java.util.Date");
/*     */ 
/*     */   public static final boolean isNumberType(int dataType)
/*     */   {
/* 183 */     return (2 <= dataType) && (dataType <= 8);
/*     */   }
/*     */ 
/*     */   public static final boolean isDateType(int dataType)
/*     */   {
/* 192 */     return (10 <= dataType) && (dataType <= 12);
/*     */   }
/*     */ 
/*     */   public static final boolean isBaseDataType(Class clazz)
/*     */   {
/* 201 */     if (clazz.isPrimitive()) {
/* 202 */       return true;
/*     */     }
/* 204 */     if (clazz.equals(stringClazz)) {
/* 205 */       return true;
/*     */     }
/* 207 */     if (numberClazz.isAssignableFrom(clazz)) {
/* 208 */       return true;
/*     */     }
/* 210 */     if (booleanClazz.isAssignableFrom(clazz)) {
/* 211 */       return true;
/*     */     }
/* 213 */     return dateClazz.isAssignableFrom(clazz);
/*     */   }
/*     */ 
/*     */   public static final int parse(Class clazz)
/*     */   {
/* 222 */     if (clazz.equals(stringClazz))
/* 223 */       return 1;
/* 224 */     if (clazz.equals(Integer.TYPE))
/* 225 */       return 4;
/* 226 */     if (clazz.equals(Boolean.TYPE))
/* 227 */       return 9;
/* 228 */     if (clazz.equals(Float.TYPE))
/* 229 */       return 6;
/* 230 */     if (clazz.equals(dateClazz))
/* 231 */       return 10;
/* 232 */     if (clazz.equals(sqlDateClazz))
/* 233 */       return 10;
/* 234 */     if (clazz.equals(timeClazz))
/* 235 */       return 11;
/* 236 */     if (clazz.equals(timeStampClazz))
/* 237 */       return 12;
/* 238 */     if (clazz.equals(Long.TYPE))
/* 239 */       return 5;
/* 240 */     if (clazz.equals(Double.TYPE))
/* 241 */       return 7;
/* 242 */     if (clazz.equals(Byte.TYPE))
/* 243 */       return 2;
/* 244 */     if (clazz.equals(Short.TYPE))
/* 245 */       return 3;
/* 246 */     if (clazz.equals(bigDecimalClazz))
/* 247 */       return 8;
/* 248 */     if (clazz.equals(integerClazz))
/* 249 */       return 4;
/* 250 */     if (clazz.equals(booleanClazz))
/* 251 */       return 9;
/* 252 */     if (clazz.equals(floatClazz))
/* 253 */       return 6;
/* 254 */     if (clazz.equals(longClazz))
/* 255 */       return 5;
/* 256 */     if (clazz.equals(doubleClazz))
/* 257 */       return 7;
/* 258 */     if (clazz.equals(byteClazz))
/* 259 */       return 2;
/* 260 */     if (clazz.equals(shortClazz))
/* 261 */       return 3;
/* 262 */     return 1;
/*     */   }
/*     */ 
/*     */   public static final int nameToType(String dataTypeName)
/*     */   {
/* 271 */     if ("string".equals(dataTypeName))
/* 272 */       return 1;
/* 273 */     if ("boolean".equals(dataTypeName))
/* 274 */       return 9;
/* 275 */     if ("int".equals(dataTypeName))
/* 276 */       return 4;
/* 277 */     if ("float".equals(dataTypeName))
/* 278 */       return 6;
/* 279 */     if ("date".equals(dataTypeName))
/* 280 */       return 10;
/* 281 */     if ("time".equals(dataTypeName))
/* 282 */       return 11;
/* 283 */     if ("datetime".equals(dataTypeName))
/* 284 */       return 12;
/* 285 */     if ("double".equals(dataTypeName))
/* 286 */       return 7;
/* 287 */     if ("long".equals(dataTypeName))
/* 288 */       return 5;
/* 289 */     if ("byte".equals(dataTypeName))
/* 290 */       return 2;
/* 291 */     if ("short".equals(dataTypeName))
/* 292 */       return 3;
/* 293 */     if ("bigdecimal".equals(dataTypeName))
/* 294 */       return 8;
/* 295 */     if ("binary".equals(dataTypeName))
/* 296 */       return 20;
/* 297 */     return 0;
/*     */   }
/*     */ 
/*     */   public static final String typeToName(int type)
/*     */   {
/* 306 */     switch (type) {
/*     */     case 1:
/* 308 */       return "string";
/*     */     case 9:
/* 310 */       return "boolean";
/*     */     case 4:
/* 312 */       return "int";
/*     */     case 6:
/* 314 */       return "float";
/*     */     case 10:
/* 316 */       return "date";
/*     */     case 11:
/* 318 */       return "time";
/*     */     case 12:
/* 320 */       return "datetime";
/*     */     case 7:
/* 322 */       return "double";
/*     */     case 5:
/* 324 */       return "long";
/*     */     case 2:
/* 326 */       return "byte";
/*     */     case 3:
/* 328 */       return "short";
/*     */     case 8:
/* 330 */       return "bigdecimal";
/*     */     case 20:
/* 332 */       return "binary";
/*     */     case 13:
/*     */     case 14:
/*     */     case 15:
/*     */     case 16:
/*     */     case 17:
/*     */     case 18:
/* 334 */     case 19: } return "";
/*     */   }
/*     */ 
/*     */   public static final Class typeToClass(int dataType)
/*     */   {
/* 342 */     switch (dataType) {
/*     */     case 1:
/* 344 */       return stringClazz;
/*     */     case 9:
/* 346 */       return booleanClazz;
/*     */     case 4:
/* 348 */       return integerClazz;
/*     */     case 6:
/* 350 */       return floatClazz;
/*     */     case 10:
/*     */     case 11:
/*     */     case 12:
/* 354 */       return dateClazz;
/*     */     case 7:
/* 356 */       return doubleClazz;
/*     */     case 5:
/* 358 */       return longClazz;
/*     */     case 2:
/* 360 */       return byteClazz;
/*     */     case 3:
/* 362 */       return shortClazz;
/*     */     case 8:
/* 364 */       return bigDecimalClazz;
/*     */     case 20:
/* 366 */       return null;
/*     */     case 13:
/*     */     case 14:
/*     */     case 15:
/*     */     case 16:
/*     */     case 17:
/*     */     case 18:
/*     */     case 19:
/*     */     }
/* 375 */     return null;
/*     */   }
/*     */ 
/*     */   static final Class getClazz(String clazzName) {
/*     */     try {
/* 380 */       return Class.forName(clazzName); } catch (ClassNotFoundException ex) {
/*     */     }
/* 382 */     throw new NoClassDefFoundError(ex.getMessage());
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.variant.DataType
 * JD-Core Version:    0.6.0
 */