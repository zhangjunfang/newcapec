/*     */ package cn.newcapec.framework.utils.variant;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ import org.apache.commons.lang.ObjectUtils;
/*     */ 
/*     */ public class Variant
/*     */   implements Serializable, Cloneable
/*     */ {
/*     */   private int dataType;
/*     */   private String name;
/*     */   private Object value;
/*     */ 
/*     */   public Variant()
/*     */   {
/*  28 */     this.dataType = 0;
/*     */   }
/*     */ 
/*     */   public Variant(int dataType)
/*     */   {
/*  35 */     this.dataType = dataType;
/*     */   }
/*     */   public Variant(String name) {
/*  38 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public Variant(String name, int dataType, Object value) {
/*  42 */     this.name = name;
/*  43 */     this.dataType = dataType;
/*  44 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  48 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  52 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public int getDataType()
/*     */   {
/*  61 */     return this.dataType;
/*     */   }
/*     */ 
/*     */   public void setDataType(int dataType) {
/*  65 */     if (this.dataType == dataType)
/*  66 */       return;
/*  67 */     this.dataType = dataType;
/*     */   }
/*     */ 
/*     */   public void setDataType(String dataTypeName) {
/*  71 */     setDataType(DataType.nameToType(dataTypeName));
/*     */   }
/*     */ 
/*     */   public Object getValue() {
/*  75 */     return this.value;
/*     */   }
/*     */ 
/*     */   public void setValue(Object value) {
/*  79 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public String getString()
/*     */   {
/*  88 */     return VariantUtil.parseString(this.value);
/*     */   }
/*     */ 
/*     */   public void setString(String value)
/*     */   {
/*  97 */     if (this.dataType == 0)
/*  98 */       this.dataType = 1;
/*  99 */     Object obj = VariantUtil.toObject(value);
/* 100 */     if (this.dataType == 1) {
/* 101 */       this.value = obj;
/* 102 */       return;
/*     */     }
/* 104 */     this.value = VariantUtil.translate(this.dataType, obj);
/*     */   }
/*     */ 
/*     */   public byte getByte()
/*     */   {
/* 113 */     return VariantUtil.parseByte(this.value);
/*     */   }
/*     */ 
/*     */   public void setByte(byte value)
/*     */   {
/* 122 */     if (this.dataType == 0)
/* 123 */       this.dataType = 2;
/* 124 */     Object obj = VariantUtil.toObject(value);
/* 125 */     if (this.dataType == 2) {
/* 126 */       this.value = obj;
/* 127 */       return;
/*     */     }
/* 129 */     this.value = VariantUtil.translate(this.dataType, obj);
/*     */   }
/*     */ 
/*     */   public short getShort()
/*     */   {
/* 138 */     return VariantUtil.parseShort(this.value);
/*     */   }
/*     */ 
/*     */   public void setShort(short value)
/*     */   {
/* 147 */     if (this.dataType == 0)
/* 148 */       this.dataType = 3;
/* 149 */     Object obj = VariantUtil.toObject(value);
/* 150 */     if (this.dataType == 3) {
/* 151 */       this.value = obj;
/* 152 */       return;
/*     */     }
/* 154 */     this.value = VariantUtil.translate(this.dataType, obj);
/*     */   }
/*     */ 
/*     */   public int getInt()
/*     */   {
/* 163 */     return VariantUtil.parseInt(this.value);
/*     */   }
/*     */ 
/*     */   public void setInt(int value)
/*     */   {
/* 172 */     if (this.dataType == 0)
/* 173 */       this.dataType = 4;
/* 174 */     Object obj = VariantUtil.toObject(value);
/* 175 */     if (this.dataType == 4) {
/* 176 */       this.value = obj;
/* 177 */       return;
/*     */     }
/* 179 */     this.value = VariantUtil.translate(this.dataType, obj);
/*     */   }
/*     */ 
/*     */   public long getLong()
/*     */   {
/* 188 */     return VariantUtil.parseLong(this.value);
/*     */   }
/*     */ 
/*     */   public void setLong(long value)
/*     */   {
/* 197 */     if (this.dataType == 0)
/* 198 */       this.dataType = 5;
/* 199 */     Object obj = VariantUtil.toObject(value);
/* 200 */     if (this.dataType == 5) {
/* 201 */       this.value = obj;
/* 202 */       return;
/*     */     }
/* 204 */     this.value = VariantUtil.translate(this.dataType, obj);
/*     */   }
/*     */ 
/*     */   public float getFloat()
/*     */   {
/* 213 */     return VariantUtil.parseFloat(this.value);
/*     */   }
/*     */ 
/*     */   public void setFloat(float value)
/*     */   {
/* 222 */     if (this.dataType == 0)
/* 223 */       this.dataType = 6;
/* 224 */     Object obj = VariantUtil.toObject(value);
/* 225 */     if (this.dataType == 6) {
/* 226 */       this.value = obj;
/* 227 */       return;
/*     */     }
/* 229 */     this.value = VariantUtil.translate(this.dataType, obj);
/*     */   }
/*     */ 
/*     */   public double getDouble()
/*     */   {
/* 238 */     return VariantUtil.parseDouble(this.value);
/*     */   }
/*     */ 
/*     */   public void setDouble(double value)
/*     */   {
/* 247 */     if (this.dataType == 0)
/* 248 */       this.dataType = 7;
/* 249 */     Object obj = VariantUtil.toObject(value);
/* 250 */     if (this.dataType == 7) {
/* 251 */       this.value = obj;
/* 252 */       return;
/*     */     }
/* 254 */     this.value = VariantUtil.translate(this.dataType, obj);
/*     */   }
/*     */ 
/*     */   public BigDecimal getBigDecimal()
/*     */   {
/* 263 */     return VariantUtil.parseBigDecimal(this.value);
/*     */   }
/*     */ 
/*     */   public void setBigDecimal(BigDecimal value)
/*     */   {
/* 272 */     if (this.dataType == 0)
/* 273 */       this.dataType = 8;
/* 274 */     Object obj = VariantUtil.toObject(value);
/* 275 */     if (this.dataType == 8) {
/* 276 */       this.value = obj;
/* 277 */       return;
/*     */     }
/* 279 */     this.value = VariantUtil.translate(this.dataType, obj);
/*     */   }
/*     */ 
/*     */   public boolean getBoolean()
/*     */   {
/* 288 */     return VariantUtil.parseBoolean(this.value);
/*     */   }
/*     */ 
/*     */   public void setBoolean(boolean value)
/*     */   {
/* 297 */     if (this.dataType == 0)
/* 298 */       this.dataType = 9;
/* 299 */     Object obj = VariantUtil.toObject(value);
/* 300 */     if (this.dataType == 9) {
/* 301 */       this.value = obj;
/* 302 */       return;
/*     */     }
/* 304 */     this.value = VariantUtil.translate(this.dataType, obj);
/*     */   }
/*     */ 
/*     */   public Date getDate()
/*     */   {
/* 313 */     return VariantUtil.parseDate(this.value);
/*     */   }
/*     */ 
/*     */   public void setDate(Date paramDate)
/*     */   {
/* 322 */     if (this.dataType == 0)
/* 323 */       this.dataType = 10;
/* 324 */     Object obj = VariantUtil.toObject(paramDate);
/* 325 */     if ((this.dataType == 10) || (this.dataType == 11) || 
/* 326 */       (this.dataType == 12)) {
/* 327 */       this.value = obj;
/* 328 */       return;
/*     */     }
/* 330 */     this.value = VariantUtil.translate(this.dataType, obj);
/*     */   }
/*     */ 
/*     */   public boolean isNull()
/*     */   {
/* 339 */     return this.value == null;
/*     */   }
/*     */ 
/*     */   public void setNull()
/*     */   {
/* 347 */     this.value = null;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 354 */     if ((obj instanceof Variant))
/* 355 */       return ObjectUtils.equals(this.value, ((Variant)obj).getValue());
/* 356 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 360 */     if (this.value != null)
/* 361 */       return this.value.hashCode();
/* 362 */     return 0;
/*     */   }
/*     */ 
/*     */   protected Object clone()
/*     */     throws CloneNotSupportedException
/*     */   {
/* 369 */     Variant variant = (Variant)super.clone();
/* 370 */     variant.setValue(getValue());
/* 371 */     return variant;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 375 */     if (this.value == null)
/* 376 */       return "Variant {null}";
/* 377 */     return this.value.toString();
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.variant.Variant
 * JD-Core Version:    0.6.0
 */