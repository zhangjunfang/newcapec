/*     */ package cn.newcapec.framework.utils.variant;
/*     */ 
/*     */ import cn.newcapec.framework.base.exception.BaseException;
/*     */ import cn.newcapec.framework.utils.collection.ObjectCollection;
/*     */ import cn.newcapec.framework.utils.collection.ObjectList;
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.ClassUtils;
/*     */ 
/*     */ public class VariantSet
/*     */   implements Serializable, Cloneable
/*     */ {
/*     */   private static final long serialVersionUID = -6329100785977056907L;
/*  23 */   private ObjectCollection data = new ObjectList();
/*     */ 
/*     */   private Variant doGetVariant(String key)
/*     */   {
/*     */     Variant variant;
/*  33 */     if ((variant = getVariant(key)) == null) {
/*  34 */       variant = new Variant(key);
/*  35 */       setVariant(key, variant);
/*     */     }
/*  37 */     return variant;
/*     */   }
/*     */ 
/*     */   private void checkIndexValid(int index)
/*     */   {
/*  46 */     if ((index < 0) || (index >= this.data.size()))
/*  47 */       throw new ArrayIndexOutOfBoundsException(index);
/*     */   }
/*     */ 
/*     */   private void checkKeyValid(String name) {
/*  51 */     if (!exists(name))
/*  52 */       throw new BaseException("Variant '" + name + "' does not exist!");
/*     */   }
/*     */ 
/*     */   public boolean exists(String name)
/*     */   {
/*  62 */     return getVariant(name) != null;
/*     */   }
/*     */ 
/*     */   public void assign(VariantSet variantSet)
/*     */   {
/*  71 */     int j = 0; for (int len = variantSet.count(); j < len; j++) {
/*  72 */       String str = variantSet.indexToName(j);
/*  73 */       if (!exists(str))
/*  74 */         setDataType(str, variantSet.getDataType(j));
/*  75 */       setValue(str, variantSet.getValue(j));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clear() {
/*  80 */     this.data.removeAll();
/*     */   }
/*     */ 
/*     */   public Variant getVariant(int index)
/*     */   {
/*  91 */     return (Variant)this.data.get(index);
/*     */   }
/*     */ 
/*     */   public Variant getVariant(String name)
/*     */   {
/* 101 */     return (Variant)this.data.get(name);
/*     */   }
/*     */ 
/*     */   public int getDataType(int index)
/*     */   {
/* 111 */     checkIndexValid(index);
/* 112 */     return getVariant(index).getDataType();
/*     */   }
/*     */ 
/*     */   public void setDataType(int index, int dataType)
/*     */   {
/* 122 */     checkIndexValid(index);
/* 123 */     getVariant(index).setDataType(dataType);
/*     */   }
/*     */ 
/*     */   public void setDataType(int index, String dataTypeName)
/*     */   {
/* 133 */     checkIndexValid(index);
/* 134 */     getVariant(index).setDataType(dataTypeName);
/*     */   }
/*     */ 
/*     */   public int getDataType(String name)
/*     */   {
/* 144 */     checkKeyValid(name);
/* 145 */     return getVariant(name).getDataType();
/*     */   }
/*     */ 
/*     */   public void setDataType(String name, int dataType)
/*     */   {
/* 155 */     doGetVariant(name).setDataType(dataType);
/*     */   }
/*     */ 
/*     */   public void setDataType(String name, String dataTypeName)
/*     */   {
/* 165 */     doGetVariant(name).setDataType(dataTypeName);
/*     */   }
/*     */ 
/*     */   public Object getValue(int index)
/*     */   {
/*     */     Variant variant;
/* 176 */     if ((variant = getVariant(index)) != null)
/* 177 */       return variant.getValue();
/* 178 */     return null;
/*     */   }
/*     */ 
/*     */   public BigDecimal getBigDecimal(int index)
/*     */   {
/*     */     Variant variant;
/* 190 */     if ((variant = getVariant(index)) != null)
/* 191 */       return variant.getBigDecimal();
/* 192 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(int index)
/*     */   {
/*     */     Variant variant;
/* 204 */     if ((variant = getVariant(index)) != null)
/* 205 */       return variant.getBoolean();
/* 206 */     return false;
/*     */   }
/*     */ 
/*     */   public byte getByte(int index)
/*     */   {
/*     */     Variant variant;
/* 218 */     if ((variant = getVariant(index)) != null)
/* 219 */       return variant.getByte();
/* 220 */     return 0;
/*     */   }
/*     */ 
/*     */   public Date getDate(int index)
/*     */   {
/*     */     Variant variant;
/* 231 */     if ((variant = getVariant(index)) != null)
/* 232 */       return variant.getDate();
/* 233 */     return null;
/*     */   }
/*     */ 
/*     */   public double getDouble(int index)
/*     */   {
/*     */     Variant variant;
/* 245 */     if ((variant = getVariant(index)) != null)
/* 246 */       return variant.getDouble();
/* 247 */     return 0.0D;
/*     */   }
/*     */ 
/*     */   public float getFloat(int index)
/*     */   {
/*     */     Variant variant;
/* 258 */     if ((variant = getVariant(index)) != null)
/* 259 */       return variant.getFloat();
/* 260 */     return 0.0F;
/*     */   }
/*     */ 
/*     */   public int getInt(int index)
/*     */   {
/*     */     Variant variant;
/* 272 */     if ((variant = getVariant(index)) != null)
/* 273 */       return variant.getInt();
/* 274 */     return 0;
/*     */   }
/*     */ 
/*     */   public long getLong(int index)
/*     */   {
/*     */     Variant variant;
/* 285 */     if ((variant = getVariant(index)) != null)
/* 286 */       return variant.getLong();
/* 287 */     return 0L;
/*     */   }
/*     */ 
/*     */   public short getShort(int index)
/*     */   {
/*     */     Variant variant;
/* 299 */     if ((variant = getVariant(index)) != null)
/* 300 */       return variant.getShort();
/* 301 */     return 0;
/*     */   }
/*     */ 
/*     */   public String getString(int index)
/*     */   {
/*     */     Variant variant;
/* 312 */     if ((variant = getVariant(index)) != null)
/* 313 */       return variant.getString();
/* 314 */     return null;
/*     */   }
/*     */ 
/*     */   public void setValue(int index, Object value)
/*     */   {
/* 325 */     checkIndexValid(index);
/* 326 */     getVariant(index).setValue(value);
/*     */   }
/*     */ 
/*     */   public void setBigDecimal(int index, BigDecimal value)
/*     */   {
/* 337 */     checkIndexValid(index);
/* 338 */     getVariant(index).setBigDecimal(value);
/*     */   }
/*     */ 
/*     */   public void setBoolean(int index, boolean value)
/*     */   {
/* 348 */     checkIndexValid(index);
/* 349 */     getVariant(index).setBoolean(value);
/*     */   }
/*     */ 
/*     */   public void setByte(int index, byte value)
/*     */   {
/* 359 */     checkIndexValid(index);
/* 360 */     getVariant(index).setByte(value);
/*     */   }
/*     */ 
/*     */   public void setDate(int index, Date value)
/*     */   {
/* 370 */     checkIndexValid(index);
/* 371 */     getVariant(index).setDate(value);
/*     */   }
/*     */ 
/*     */   public void setDouble(int index, double value)
/*     */   {
/* 381 */     checkIndexValid(index);
/* 382 */     getVariant(index).setDouble(value);
/*     */   }
/*     */ 
/*     */   public void setFloat(int index, float value)
/*     */   {
/* 392 */     checkIndexValid(index);
/* 393 */     getVariant(index).setFloat(value);
/*     */   }
/*     */ 
/*     */   public void setInt(int index, int value)
/*     */   {
/* 403 */     checkIndexValid(index);
/* 404 */     getVariant(index).setInt(value);
/*     */   }
/*     */ 
/*     */   public void setLong(int index, long value)
/*     */   {
/* 414 */     checkIndexValid(index);
/* 415 */     getVariant(index).setLong(value);
/*     */   }
/*     */ 
/*     */   public void setShort(int index, short value)
/*     */   {
/* 425 */     checkIndexValid(index);
/* 426 */     getVariant(index).setShort(value);
/*     */   }
/*     */ 
/*     */   public void setString(int index, String value)
/*     */   {
/* 436 */     checkIndexValid(index);
/* 437 */     getVariant(index).setString(value);
/*     */   }
/*     */ 
/*     */   public Object getValue(String name)
/*     */   {
/*     */     Variant variant;
/* 449 */     if ((variant = getVariant(name)) != null)
/* 450 */       return variant.getValue();
/* 451 */     return null;
/*     */   }
/*     */ 
/*     */   public BigDecimal getBigDecimal(String name)
/*     */   {
/*     */     Variant variant;
/* 462 */     if ((variant = getVariant(name)) != null)
/* 463 */       return variant.getBigDecimal();
/* 464 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(String name)
/*     */   {
/*     */     Variant variant;
/* 475 */     if ((variant = getVariant(name)) != null)
/* 476 */       return variant.getBoolean();
/* 477 */     return false;
/*     */   }
/*     */ 
/*     */   public byte getByte(String name)
/*     */   {
/*     */     Variant variant;
/* 488 */     if ((variant = getVariant(name)) != null)
/* 489 */       return variant.getByte();
/* 490 */     return 0;
/*     */   }
/*     */ 
/*     */   public Date getDate(String name)
/*     */   {
/*     */     Variant variant;
/* 501 */     if ((variant = getVariant(name)) != null)
/* 502 */       return variant.getDate();
/* 503 */     return null;
/*     */   }
/*     */ 
/*     */   public double getDouble(String name)
/*     */   {
/*     */     Variant variant;
/* 514 */     if ((variant = getVariant(name)) != null)
/* 515 */       return variant.getDouble();
/* 516 */     return 0.0D;
/*     */   }
/*     */ 
/*     */   public float getFloat(String name)
/*     */   {
/*     */     Variant variant;
/* 527 */     if ((variant = getVariant(name)) != null)
/* 528 */       return variant.getFloat();
/* 529 */     return 0.0F;
/*     */   }
/*     */ 
/*     */   public int getInt(String name)
/*     */   {
/*     */     Variant variant;
/* 540 */     if ((variant = getVariant(name)) != null)
/* 541 */       return variant.getInt();
/* 542 */     return 0;
/*     */   }
/*     */ 
/*     */   public long getLong(String name)
/*     */   {
/*     */     Variant variant;
/* 553 */     if ((variant = getVariant(name)) != null)
/* 554 */       return variant.getLong();
/* 555 */     return 0L;
/*     */   }
/*     */ 
/*     */   public short getShort(String name)
/*     */   {
/*     */     Variant variant;
/* 566 */     if ((variant = getVariant(name)) != null)
/* 567 */       return variant.getShort();
/* 568 */     return 0;
/*     */   }
/*     */ 
/*     */   public String getString(String name)
/*     */   {
/*     */     Variant variant;
/* 579 */     if ((variant = getVariant(name)) != null)
/* 580 */       return variant.getString();
/* 581 */     return null;
/*     */   }
/*     */ 
/*     */   public void setVariant(String name, Variant variant)
/*     */   {
/* 591 */     this.data.forceAdd(name, variant);
/*     */   }
/*     */ 
/*     */   public void setValue(String name, Object object)
/*     */   {
/* 602 */     doGetVariant(name).setValue(object);
/*     */   }
/*     */ 
/*     */   public void setBigDecimal(String name, BigDecimal value)
/*     */   {
/* 612 */     doGetVariant(name).setBigDecimal(value);
/*     */   }
/*     */ 
/*     */   public void setBoolean(String name, boolean value)
/*     */   {
/* 622 */     doGetVariant(name).setBoolean(value);
/*     */   }
/*     */ 
/*     */   public void setByte(String name, byte value)
/*     */   {
/* 632 */     doGetVariant(name).setByte(value);
/*     */   }
/*     */ 
/*     */   public void setDate(String name, Date date)
/*     */   {
/* 642 */     doGetVariant(name).setDate(date);
/*     */   }
/*     */ 
/*     */   public void setDouble(String name, double value)
/*     */   {
/* 652 */     doGetVariant(name).setDouble(value);
/*     */   }
/*     */ 
/*     */   public void setFloat(String name, float value)
/*     */   {
/* 662 */     doGetVariant(name).setFloat(value);
/*     */   }
/*     */ 
/*     */   public void setInt(String name, int value)
/*     */   {
/* 673 */     doGetVariant(name).setInt(value);
/*     */   }
/*     */ 
/*     */   public void setLong(String name, long value)
/*     */   {
/* 683 */     doGetVariant(name).setLong(value);
/*     */   }
/*     */ 
/*     */   public void setShort(String name, short value)
/*     */   {
/* 693 */     doGetVariant(name).setShort(value);
/*     */   }
/*     */ 
/*     */   public void setString(String name, String value)
/*     */   {
/* 703 */     doGetVariant(name).setString(value);
/*     */   }
/*     */ 
/*     */   public boolean isNull(int index)
/*     */   {
/*     */     Variant variant;
/* 714 */     if ((variant = getVariant(index)) != null)
/* 715 */       return variant.isNull();
/* 716 */     return true;
/*     */   }
/*     */ 
/*     */   public void setNull(int index)
/*     */   {
/* 725 */     checkIndexValid(index);
/* 726 */     getVariant(index).setNull();
/*     */   }
/*     */ 
/*     */   public boolean isNull(String name)
/*     */   {
/*     */     Variant variant;
/* 737 */     if ((variant = getVariant(name)) != null)
/* 738 */       return variant.isNull();
/* 739 */     return true;
/*     */   }
/*     */ 
/*     */   public void setNull(String name)
/*     */   {
/* 748 */     doGetVariant(name).setNull();
/*     */   }
/*     */ 
/*     */   public void remove(int index)
/*     */   {
/* 757 */     this.data.remove(index);
/*     */   }
/*     */ 
/*     */   public void remove(String name)
/*     */   {
/* 766 */     this.data.remove(name);
/*     */   }
/*     */ 
/*     */   public int count()
/*     */   {
/* 775 */     return this.data.size();
/*     */   }
/*     */ 
/*     */   public String indexToName(int index)
/*     */   {
/* 785 */     return (String)this.data.getKey(index);
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */     throws CloneNotSupportedException
/*     */   {
/* 792 */     VariantSet variantSet = (VariantSet)super.clone();
/* 793 */     ObjectList objectList = new ObjectList();
/* 794 */     int i = 0; for (int len = this.data.size(); i < len; i++)
/* 795 */       objectList.add(this.data.getKey(i), ((Variant)this.data.get(i)).clone());
/* 796 */     variantSet.data = objectList;
/* 797 */     return variantSet;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 804 */     if (object == null)
/* 805 */       return false;
/* 806 */     if ((object instanceof VariantSet))
/* 807 */       return this.data.equals(((VariantSet)object).data);
/* 808 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 812 */     return this.data.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 817 */     StringBuffer localStringBuffer = new StringBuffer(ClassUtils.getShortClassName(super.getClass())).append(":").append(
/* 818 */       this.data.toString());
/* 819 */     return localStringBuffer.toString();
/*     */   }
/*     */ 
/*     */   public Object[] keyList()
/*     */   {
/* 828 */     return this.data.keyList().toArray();
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.variant.VariantSet
 * JD-Core Version:    0.6.0
 */