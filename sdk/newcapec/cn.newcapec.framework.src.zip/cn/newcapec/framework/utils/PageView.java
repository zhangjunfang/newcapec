/*     */ package cn.newcapec.framework.utils;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ public class PageView<T>
/*     */ {
/*     */   private List<T> records;
/*     */   private PageIndex pageindex;
/*  12 */   private long totalpage = 1L;
/*     */ 
/*  14 */   private int maxresult = 12;
/*     */ 
/*  16 */   private int currentpage = 1;
/*     */   private long totalrecord;
/*  20 */   private int pagecode = 10;
/*     */ 
/*  22 */   private int begin = 0;
/*     */ 
/*  24 */   private int end = 0;
/*     */   private String jsMethod;
/*     */ 
/*     */   public int getFirstResult()
/*     */   {
/*  32 */     return (this.currentpage - 1) * this.maxresult;
/*     */   }
/*     */   public int getPagecode() {
/*  35 */     return this.pagecode;
/*     */   }
/*     */ 
/*     */   public void setPagecode(int pagecode) {
/*  39 */     this.pagecode = pagecode;
/*     */   }
/*     */ 
/*     */   public PageView(int maxresult, int currentpage) {
/*  43 */     this.maxresult = maxresult;
/*  44 */     if (currentpage <= 0) {
/*  45 */       currentpage = 1;
/*     */     }
/*  47 */     this.currentpage = currentpage;
/*     */   }
/*     */ 
/*     */   public void setQueryResult(Page qr)
/*     */   {
/*  52 */     setTotalrecord(qr.getTotal());
/*  53 */     setRecords(qr.getItems());
/*     */   }
/*     */ 
/*     */   public long getTotalrecord() {
/*  57 */     return this.totalrecord;
/*     */   }
/*     */   public void setTotalrecord(long totalrecord) {
/*  60 */     this.totalrecord = totalrecord;
/*  61 */     setTotalpage(this.totalrecord % this.maxresult == 0L ? this.totalrecord / this.maxresult : this.totalrecord / this.maxresult + 1L);
/*     */   }
/*     */   public List<T> getRecords() {
/*  64 */     return this.records;
/*     */   }
/*     */   public void setRecords(List<T> records) {
/*  67 */     this.records = records;
/*     */   }
/*     */   public PageIndex getPageindex() {
/*  70 */     return this.pageindex;
/*     */   }
/*     */   public long getTotalpage() {
/*  73 */     return this.totalpage;
/*     */   }
/*     */   public void setTotalpage(long totalpage) {
/*  76 */     this.totalpage = totalpage;
/*  77 */     this.pageindex = PageIndex.getPageIndex(this.pagecode, this.currentpage, totalpage);
/*     */   }
/*     */   public int getMaxresult() {
/*  80 */     return this.maxresult;
/*     */   }
/*     */   public int getCurrentpage() {
/*  83 */     return this.currentpage;
/*     */   }
/*     */   public int getBegin() {
/*  86 */     this.begin = ((this.currentpage - 1) * this.maxresult);
/*  87 */     return this.begin;
/*     */   }
/*     */   public void setBegin(int begin) {
/*  90 */     this.begin = begin;
/*     */   }
/*     */   public int getEnd() {
/*  93 */     this.end = (this.currentpage * this.maxresult - 1);
/*  94 */     return this.end;
/*     */   }
/*     */   public void setEnd(int end) {
/*  97 */     this.end = end;
/*     */   }
/*     */ 
/*     */   public String getJsMethod()
/*     */   {
/* 103 */     return this.jsMethod;
/*     */   }
/*     */ 
/*     */   public void setJsMethod(String jsMethod)
/*     */   {
/* 109 */     this.jsMethod = jsMethod;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.PageView
 * JD-Core Version:    0.6.0
 */