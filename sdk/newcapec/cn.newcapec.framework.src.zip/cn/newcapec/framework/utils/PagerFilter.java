/*    */ package cn.newcapec.framework.utils;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpSession;
/*    */ 
/*    */ public class PagerFilter
/*    */   implements Filter
/*    */ {
/*    */   public static final String PAGE_SIZE_NAME = "ps";
/* 16 */   private static String ROOT_PATH = "";
/*    */ 
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException
/*    */   {
/* 24 */     HttpServletRequest httpRequest = (HttpServletRequest)request;
/* 25 */     SystemContext.setOffset(Integer.valueOf(getOffset(httpRequest)));
/* 26 */     SystemContext.setPagesize(Integer.valueOf(getPagesize(httpRequest)));
/*    */     try {
/* 28 */       chain.doFilter(request, response);
/*    */     } finally {
/* 30 */       SystemContext.removeOffset();
/* 31 */       SystemContext.removePagesize();
/*    */     }
/*    */   }
/*    */ 
/*    */   private int getOffset(HttpServletRequest request) {
/* 36 */     int offset = 0;
/*    */     try {
/* 38 */       offset = Integer.parseInt(request.getParameter("offset"));
/*    */     } catch (Exception localException) {
/*    */     }
/* 41 */     return offset;
/*    */   }
/*    */ 
/*    */   private int getPagesize(HttpServletRequest httpRequest) {
/* 45 */     String psvalue = httpRequest.getParameter("limit");
/* 46 */     if ((psvalue != null) && (!psvalue.trim().equals(""))) {
/* 47 */       Integer ps = Integer.valueOf(0);
/*    */       try {
/* 49 */         ps = Integer.valueOf(Integer.parseInt(psvalue));
/*    */       } catch (Exception localException) {
/*    */       }
/* 52 */       if (ps.intValue() != 0) {
/* 53 */         httpRequest.getSession().setAttribute("ps", ps);
/*    */       }
/*    */     }
/*    */ 
/* 57 */     Integer pagesize = (Integer)httpRequest.getSession().getAttribute("ps");
/* 58 */     if (pagesize == null) {
/* 59 */       httpRequest.getSession().setAttribute("ps", Integer.valueOf(10));
/* 60 */       return 10;
/*    */     }
/*    */ 
/* 63 */     return pagesize.intValue();
/*    */   }
/*    */ 
/*    */   public void init(FilterConfig arg0) throws ServletException
/*    */   {
/* 68 */     String rootPath = arg0.getServletContext().getServletContextName();
/* 69 */     if (rootPath == null) {
/* 70 */       rootPath = "/";
/*    */     }
/* 72 */     ROOT_PATH = rootPath;
/*    */   }
/*    */ 
/*    */   public static String getRootPath() {
/* 76 */     return ROOT_PATH;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.PagerFilter
 * JD-Core Version:    0.6.0
 */