/*    */ package cn.newcapec.framework.utils;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.security.MessageDigest;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import java.util.TreeMap;
/*    */ 
/*    */ public class MD5
/*    */ {
/*  9 */   private static final String[] hexDigits = { "0", "1", "2", "3", "4", "5", 
/* 10 */     "6", "7", "8", "9", "a", "b", "c", "d", "e", "f" };
/*    */ 
/*    */   public static String byteArrayToHexString(byte[] b)
/*    */   {
/* 21 */     StringBuffer resultSb = new StringBuffer();
/* 22 */     for (int i = 0; i < b.length; i++) {
/* 23 */       resultSb.append(byteToHexString(b[i]));
/*    */     }
/* 25 */     return resultSb.toString();
/*    */   }
/*    */ 
/*    */   private static String byteToHexString(byte b) {
/* 29 */     int n = b;
/* 30 */     if (n < 0)
/* 31 */       n += 256;
/* 32 */     int d1 = n / 16;
/* 33 */     int d2 = n % 16;
/* 34 */     return hexDigits[d1] + hexDigits[d2];
/*    */   }
/*    */ 
/*    */   public static String map2Str(TreeMap<String, String> params)
/*    */   {
/* 44 */     String ret = "";
/* 45 */     if ((params == null) || (params.isEmpty()))
/* 46 */       return ret;
/* 47 */     Set keySet = params.keySet();
/* 48 */     Iterator iterator = keySet.iterator();
/* 49 */     while (iterator.hasNext()) {
/* 50 */       String key = (String)iterator.next();
/* 51 */       String value = (String)params.get(key);
/* 52 */       ret = ret + key + value;
/*    */     }
/*    */ 
/* 55 */     return ret;
/*    */   }
/*    */ 
/*    */   public static String MD5Encode(String string)
/*    */   {
/* 66 */     char[] hexDigits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 
/* 67 */       'e', 'f' };
/*    */     try {
/* 69 */       byte[] bytes = string.getBytes("UTF-8");
/* 70 */       MessageDigest messageDigest = MessageDigest.getInstance("MD5");
/* 71 */       messageDigest.update(bytes);
/* 72 */       byte[] updateBytes = messageDigest.digest();
/* 73 */       int len = updateBytes.length;
/* 74 */       char[] myChar = new char[len * 2];
/* 75 */       int k = 0;
/* 76 */       for (int i = 0; i < len; i++) {
/* 77 */         byte byte0 = updateBytes[i];
/* 78 */         myChar[(k++)] = hexDigits[(byte0 >>> 4 & 0xF)];
/* 79 */         myChar[(k++)] = hexDigits[(byte0 & 0xF)];
/*    */       }
/* 81 */       return new String(myChar);
/*    */     }
/*    */     catch (Exception localException)
/*    */     {
/*    */     }
/* 86 */     return "";
/*    */   }
/*    */   public static void main(String[] args) {
/* 89 */     System.out.println(MD5Encode("123"));
/* 90 */     System.out.println(MD5Encode("123 "));
/* 91 */     System.out.println(MD5Encode("123  "));
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.MD5
 * JD-Core Version:    0.6.0
 */