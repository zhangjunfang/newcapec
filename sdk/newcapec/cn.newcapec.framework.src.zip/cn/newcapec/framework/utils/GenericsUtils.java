/*    */ package cn.newcapec.framework.utils;
/*    */ 
/*    */ import java.lang.reflect.ParameterizedType;
/*    */ import java.lang.reflect.Type;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class GenericsUtils
/*    */ {
/* 16 */   private static final Log log = LogFactory.getLog(GenericsUtils.class);
/*    */ 
/*    */   public static Class getSuperClassGenricType(Class clazz)
/*    */   {
/* 28 */     return getSuperClassGenricType(clazz, 0);
/*    */   }
/*    */ 
/*    */   public static Class getSuperClassGenricType(Class clazz, int index)
/*    */   {
/* 40 */     Type genType = clazz.getGenericSuperclass();
/*    */ 
/* 42 */     if (!(genType instanceof ParameterizedType)) {
/* 43 */       log.warn(clazz.getSimpleName() + "'s superclass not ParameterizedType");
/* 44 */       return Object.class;
/*    */     }
/*    */ 
/* 47 */     Type[] params = ((ParameterizedType)genType).getActualTypeArguments();
/*    */ 
/* 49 */     if ((index >= params.length) || (index < 0)) {
/* 50 */       log.warn("Index: " + index + ", Size of " + clazz.getSimpleName() + "'s Parameterized Type: " + 
/* 51 */         params.length);
/* 52 */       return Object.class;
/*    */     }
/* 54 */     if (!(params[index] instanceof Class)) {
/* 55 */       log.warn(clazz.getSimpleName() + " not set the actual class on superclass generic parameter");
/* 56 */       return Object.class;
/*    */     }
/* 58 */     return (Class)params[index];
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.GenericsUtils
 * JD-Core Version:    0.6.0
 */