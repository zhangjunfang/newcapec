/*     */ package cn.newcapec.framework.utils.exception;
/*     */ 
/*     */ import cn.newcapec.framework.base.exception.BaseException;
/*     */ import cn.newcapec.framework.base.exception.SysException;
/*     */ import cn.newcapec.framework.base.i18n.LangUtil;
/*     */ import cn.newcapec.framework.base.i18n.Message;
/*     */ import cn.newcapec.framework.base.log.LogEnabled;
/*     */ import cn.newcapec.framework.utils.context.NewcapecContext;
/*     */ import cn.newcapec.framework.utils.tools.StringUtil;
/*     */ import java.sql.SQLException;
/*     */ import org.apache.commons.lang.exception.ExceptionUtils;
/*     */ 
/*     */ public class ExceptionUtil
/*     */   implements LogEnabled
/*     */ {
/*     */   private static final String ERROR_CODE = "err_code";
/*     */ 
/*     */   public static void extractException(Throwable t, String lang, Object[] messageArgs)
/*     */     throws RuntimeException
/*     */   {
/*  42 */     extractException(t, lang, messageArgs, null);
/*     */   }
/*     */ 
/*     */   public static void extractException(Throwable t, String lang, Object[] messageArgs, Object entityObject)
/*     */     throws RuntimeException
/*     */   {
/*  71 */     Throwable t1 = null;
/*     */ 
/*  73 */     if (((t instanceof BaseException)) || ((t instanceof SysException))) {
/*  74 */       t1 = t;
/*     */     }
/*     */     else {
/*  77 */       t1 = getTargetBaseException(t);
/*     */     }
/*  79 */     if (t1 == null) {
/*  80 */       t1 = ExceptionUtils.getRootCause(t);
/*     */     }
/*  82 */     if (t1 == null) {
/*  83 */       t1 = t;
/*     */     }
/*     */ 
/*  87 */     String messageCode = StringUtil.trim(t1.getMessage());
/*  88 */     String errorMessage = null;
/*  89 */     if ((t1 instanceof BaseException))
/*     */     {
/*  91 */       if (messageCode.indexOf("err_code") != -1) {
/*  92 */         errorMessage = Message.getInfo(messageCode, lang, messageArgs, null, entityObject);
/*  93 */         if (StringUtil.isValid(errorMessage)) {
/*  94 */           throw new BaseException(errorMessage, t1);
/*     */         }
/*     */       }
/*  97 */       throw ((BaseException)t1);
/*     */     }
/*  99 */     if ((t1 instanceof SysException)) {
/* 100 */       if (messageCode.indexOf("err_code") != -1) {
/* 101 */         errorMessage = Message.getInfo(messageCode, lang, messageArgs, null, entityObject);
/* 102 */         if (StringUtil.isValid(errorMessage)) {
/* 103 */           throw new BaseException(errorMessage, t1);
/*     */         }
/*     */       }
/* 106 */       throw ((SysException)t);
/*     */     }
/* 108 */     if ((t1 instanceof SQLException))
/*     */     {
/* 111 */       SQLExceptionUtil.translateException(t);
/*     */     }
/*     */     else
/* 114 */       throw new SysException(t1.getMessage(), t1);
/*     */   }
/*     */ 
/*     */   private static Throwable getTargetBaseException(Throwable t)
/*     */   {
/* 127 */     Throwable t1 = null;
/*     */     do {
/* 129 */       t1 = ExceptionUtils.getCause(t);
/* 130 */       if (((t1 instanceof BaseException)) || ((t1 instanceof SysException))) {
/* 131 */         return t1;
/*     */       }
/* 133 */       t = t1;
/* 134 */     }while (t1 != null);
/*     */ 
/* 136 */     return null;
/*     */   }
/*     */ 
/*     */   public static void extractException(Throwable t, String lang)
/*     */     throws RuntimeException
/*     */   {
/* 145 */     extractException(t, lang, null, null);
/*     */   }
/*     */ 
/*     */   public static void extractException(Throwable t)
/*     */     throws RuntimeException
/*     */   {
/* 155 */     String lang = LangUtil.getLang(NewcapecContext.getContext());
/* 156 */     extractException(t, lang);
/*     */   }
/*     */ 
/*     */   public static void extractException(Throwable t, Object[] messageArgs)
/*     */     throws RuntimeException
/*     */   {
/* 165 */     String lang = LangUtil.getLang(NewcapecContext.getContext());
/* 166 */     extractException(t, lang, messageArgs, null);
/*     */   }
/*     */ 
/*     */   public static void extractException(Throwable t, Object[] args, Object entityObject) {
/* 170 */     String lang = LangUtil.getLang(NewcapecContext.getContext());
/* 171 */     extractException(t, lang, args, entityObject);
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.exception.ExceptionUtil
 * JD-Core Version:    0.6.0
 */