/*    */ package cn.newcapec.framework.utils.exception;
/*    */ 
/*    */ import cn.newcapec.framework.base.exception.SysException;
/*    */ import org.apache.commons.lang.exception.ExceptionUtils;
/*    */ 
/*    */ public class SQLExceptionUtil
/*    */ {
/*    */   public static void translateException(Throwable t)
/*    */   {
/* 25 */     Throwable t1 = null;
/* 26 */     Throwable t2 = null;
/*    */ 
/* 29 */     while (t != null) {
/* 30 */       t2 = t1;
/* 31 */       t1 = t;
/* 32 */       t = ExceptionUtils.getCause(t);
/*    */     }
/*    */ 
/* 35 */     throw new SysException(t2.getMessage(), t2);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.exception.SQLExceptionUtil
 * JD-Core Version:    0.6.0
 */