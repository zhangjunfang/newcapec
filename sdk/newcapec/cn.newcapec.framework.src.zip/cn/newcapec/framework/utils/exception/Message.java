/*    */ package cn.newcapec.framework.utils.exception;
/*    */ 
/*    */ public class Message
/*    */ {
/*  9 */   private String msgName = "";
/*    */ 
/* 11 */   private String msgCode = "";
/*    */ 
/* 13 */   private String msgDesc = "";
/*    */ 
/*    */   public Message() {
/*    */   }
/*    */ 
/*    */   public Message(String msgName, String msgDesc) {
/* 19 */     this.msgName = msgName;
/* 20 */     this.msgDesc = msgDesc;
/*    */   }
/*    */   public Message(String msgName, String msgCode, String msgDesc) {
/* 23 */     this.msgName = msgName;
/* 24 */     this.msgCode = msgCode;
/* 25 */     this.msgDesc = msgDesc;
/*    */   }
/*    */ 
/*    */   public String getMsgName() {
/* 29 */     return this.msgName;
/*    */   }
/*    */ 
/*    */   public void setMsgName(String msgName) {
/* 33 */     this.msgName = msgName;
/*    */   }
/*    */ 
/*    */   public String getMsgCode() {
/* 37 */     return this.msgCode;
/*    */   }
/*    */ 
/*    */   public void setMsgCode(String msgCode) {
/* 41 */     this.msgCode = msgCode;
/*    */   }
/*    */ 
/*    */   public String getMsgDesc() {
/* 45 */     return this.msgDesc;
/*    */   }
/*    */ 
/*    */   public void setMsgDesc(String msgDesc) {
/* 49 */     this.msgDesc = msgDesc;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.exception.Message
 * JD-Core Version:    0.6.0
 */