/*     */ package cn.newcapec.framework.utils;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class DateUtil
/*     */ {
/*  17 */   public static String DATETIME_FORMAT = "yyyy-MM-dd HH:mm";
/*  18 */   public static String DATE_FORMAT = "yyyy-MM-dd";
/*  19 */   public static String DATETIME_FORMAT2 = "yyyy-MM-dd HH:mm:ss";
/*     */ 
/*     */   public static Date previous(int days)
/*     */   {
/*  28 */     return new Date(System.currentTimeMillis() - days * 3600000L * 24L);
/*     */   }
/*     */ 
/*     */   public static String formatDateTime(Date d)
/*     */   {
/*  35 */     return new SimpleDateFormat(DATETIME_FORMAT).format(d);
/*     */   }
/*     */ 
/*     */   public static String formatDateTime(long d)
/*     */   {
/*  42 */     return new SimpleDateFormat(DATETIME_FORMAT).format(Long.valueOf(d));
/*     */   }
/*     */ 
/*     */   public static String formatDate(Date d)
/*     */   {
/*  49 */     return new SimpleDateFormat(DATE_FORMAT).format(d);
/*     */   }
/*     */ 
/*     */   public static Date parseDate(String d)
/*     */   {
/*     */     try
/*     */     {
/*  57 */       return new SimpleDateFormat(DATE_FORMAT).parse(d);
/*     */     } catch (Exception localException) {
/*     */     }
/*  60 */     return null;
/*     */   }
/*     */ 
/*     */   public static Date parseDateTime(String dt)
/*     */   {
/*     */     try
/*     */     {
/*  68 */       return new SimpleDateFormat(DATETIME_FORMAT).parse(dt);
/*     */     } catch (Exception localException) {
/*     */     }
/*  71 */     return null;
/*     */   }
/*     */ 
/*     */   public static Date parseDate(String date, String formater) {
/*  75 */     Date result = null;
/*  76 */     formater = StringUtils.defaultIfEmpty(formater, DATETIME_FORMAT2);
/*  77 */     if (StringUtils.isNotBlank(date)) {
/*  78 */       SimpleDateFormat simpleDateFormat = new SimpleDateFormat(formater);
/*     */       try {
/*  80 */         result = simpleDateFormat.parse(date);
/*     */       } catch (ParseException e) {
/*  82 */         e.printStackTrace();
/*     */       }
/*     */     }
/*  85 */     return result;
/*     */   }
/*     */ 
/*     */   public static String getLogDate(Date date) {
/*  89 */     Calendar cal = Calendar.getInstance();
/*  90 */     int year = cal.get(1);
/*  91 */     int month = cal.get(2) + 1;
/*  92 */     int day = cal.get(5);
/*  93 */     String str = year + "年" + month + "月" + day + "日  ";
/*     */ 
/*  95 */     String[] weekDays = { "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六" };
/*  96 */     cal = Calendar.getInstance();
/*  97 */     cal.setTime(date);
/*     */ 
/*  99 */     int w = cal.get(7) - 1;
/* 100 */     if (w < 0) {
/* 101 */       w = 0;
/*     */     }
/* 103 */     return str + weekDays[w];
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.DateUtil
 * JD-Core Version:    0.6.0
 */