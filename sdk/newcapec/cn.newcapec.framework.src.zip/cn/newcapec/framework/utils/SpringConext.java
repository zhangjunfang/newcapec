/*    */ package cn.newcapec.framework.utils;
/*    */ 
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ import org.springframework.stereotype.Component;
/*    */ 
/*    */ @Component
/*    */ public class SpringConext
/*    */   implements ApplicationContextAware
/*    */ {
/*    */   private static ApplicationContext context;
/*    */ 
/*    */   public void setApplicationContext(ApplicationContext acx)
/*    */   {
/* 23 */     context = acx;
/*    */   }
/*    */ 
/*    */   public static ApplicationContext getApplicationContext() {
/* 27 */     return context;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.SpringConext
 * JD-Core Version:    0.6.0
 */