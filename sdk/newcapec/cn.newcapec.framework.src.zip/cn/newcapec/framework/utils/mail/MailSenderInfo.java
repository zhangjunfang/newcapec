/*     */ package cn.newcapec.framework.utils.mail;
/*     */ 
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class MailSenderInfo
/*     */ {
/*  11 */   private String mailServerHost = "smtp.126.com";
/*  12 */   private String mailServerPort = "25";
/*     */ 
/*  14 */   private String fromAddress = "liu381447823@126.com";
/*     */   private String toAddress;
/*  18 */   private String userName = "liu381447823@126.com";
/*  19 */   private String password = "305709174";
/*     */ 
/*  21 */   private boolean validate = true;
/*     */   private String subject;
/*     */   private String content;
/*     */   private String[] attachFileNames;
/*     */ 
/*     */   public Properties getProperties()
/*     */   {
/*  36 */     Properties p = new Properties();
/*  37 */     p.put("mail.smtp.host", this.mailServerHost);
/*  38 */     p.put("mail.smtp.port", this.mailServerPort);
/*  39 */     p.put("mail.smtp.auth", this.validate ? "true" : "false");
/*  40 */     return p;
/*     */   }
/*     */   public String getMailServerHost() {
/*  43 */     return this.mailServerHost;
/*     */   }
/*     */   public void setMailServerHost(String mailServerHost) {
/*  46 */     this.mailServerHost = mailServerHost;
/*     */   }
/*     */   public String getMailServerPort() {
/*  49 */     return this.mailServerPort;
/*     */   }
/*     */   public void setMailServerPort(String mailServerPort) {
/*  52 */     this.mailServerPort = mailServerPort;
/*     */   }
/*     */   public boolean isValidate() {
/*  55 */     return this.validate;
/*     */   }
/*     */   public void setValidate(boolean validate) {
/*  58 */     this.validate = validate;
/*     */   }
/*     */   public String[] getAttachFileNames() {
/*  61 */     return this.attachFileNames;
/*     */   }
/*     */   public void setAttachFileNames(String[] fileNames) {
/*  64 */     this.attachFileNames = fileNames;
/*     */   }
/*     */   public String getFromAddress() {
/*  67 */     return this.fromAddress;
/*     */   }
/*     */   public void setFromAddress(String fromAddress) {
/*  70 */     this.fromAddress = fromAddress;
/*     */   }
/*     */   public String getPassword() {
/*  73 */     return this.password;
/*     */   }
/*     */   public void setPassword(String password) {
/*  76 */     this.password = password;
/*     */   }
/*     */   public String getToAddress() {
/*  79 */     return this.toAddress;
/*     */   }
/*     */   public void setToAddress(String toAddress) {
/*  82 */     this.toAddress = toAddress;
/*     */   }
/*     */   public String getUserName() {
/*  85 */     return this.userName;
/*     */   }
/*     */   public void setUserName(String userName) {
/*  88 */     this.userName = userName;
/*     */   }
/*     */   public String getSubject() {
/*  91 */     return this.subject;
/*     */   }
/*     */   public void setSubject(String subject) {
/*  94 */     this.subject = subject;
/*     */   }
/*     */   public String getContent() {
/*  97 */     return this.content;
/*     */   }
/*     */   public void setContent(String textContent) {
/* 100 */     this.content = textContent;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.mail.MailSenderInfo
 * JD-Core Version:    0.6.0
 */