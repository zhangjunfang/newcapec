/*     */ package cn.newcapec.framework.utils.mail;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.mail.Address;
/*     */ import javax.mail.BodyPart;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.Message.RecipientType;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Multipart;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.Transport;
/*     */ import javax.mail.internet.InternetAddress;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ import javax.mail.util.ByteArrayDataSource;
/*     */ 
/*     */ public class SimpleMailSender
/*     */ {
/*     */   public static boolean sendTextMail(String toAddress, String subject, String content)
/*     */   {
/*  45 */     MailSenderInfo mailInfo = new MailSenderInfo();
/*  46 */     mailInfo.setToAddress(toAddress);
/*  47 */     mailInfo.setSubject(subject);
/*  48 */     mailInfo.setContent(content);
/*     */ 
/*  50 */     MyAuthenticator authenticator = null;
/*  51 */     Properties pro = mailInfo.getProperties();
/*  52 */     if (mailInfo.isValidate())
/*     */     {
/*  54 */       authenticator = new MyAuthenticator(mailInfo.getUserName(), mailInfo.getPassword());
/*     */     }
/*     */ 
/*  57 */     Session sendMailSession = Session.getDefaultInstance(pro, authenticator);
/*     */     try
/*     */     {
/*  60 */       Message mailMessage = new MimeMessage(sendMailSession);
/*     */ 
/*  62 */       Address from = new InternetAddress(mailInfo.getFromAddress());
/*     */ 
/*  64 */       mailMessage.setFrom(from);
/*     */ 
/*  66 */       Address to = new InternetAddress(mailInfo.getToAddress());
/*  67 */       mailMessage.setRecipient(Message.RecipientType.TO, to);
/*     */ 
/*  69 */       mailMessage.setSubject(mailInfo.getSubject());
/*     */ 
/*  71 */       mailMessage.setSentDate(new Date());
/*     */ 
/*  73 */       String mailContent = mailInfo.getContent();
/*  74 */       mailMessage.setText(mailContent);
/*     */ 
/*  76 */       Transport.send(mailMessage);
/*  77 */       return true;
/*     */     } catch (MessagingException ex) {
/*  79 */       ex.printStackTrace();
/*     */     }
/*  81 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean sendHtmlMail(String toAddress, String subject, String content)
/*     */   {
/*  94 */     MailSenderInfo mailInfo = new MailSenderInfo();
/*  95 */     mailInfo.setToAddress(toAddress);
/*  96 */     mailInfo.setSubject(subject);
/*  97 */     mailInfo.setContent(content);
/*     */ 
/* 100 */     MyAuthenticator authenticator = null;
/* 101 */     Properties pro = mailInfo.getProperties();
/*     */ 
/* 103 */     if (mailInfo.isValidate()) {
/* 104 */       authenticator = new MyAuthenticator(mailInfo.getUserName(), mailInfo.getPassword());
/*     */     }
/*     */ 
/* 107 */     Session sendMailSession = Session.getDefaultInstance(pro, authenticator);
/*     */     try
/*     */     {
/* 110 */       Message mailMessage = new MimeMessage(sendMailSession);
/*     */ 
/* 112 */       Address from = new InternetAddress(mailInfo.getFromAddress());
/*     */ 
/* 114 */       mailMessage.setFrom(from);
/*     */ 
/* 116 */       Address to = new InternetAddress(mailInfo.getToAddress());
/*     */ 
/* 118 */       mailMessage.setRecipient(Message.RecipientType.TO, to);
/*     */ 
/* 120 */       mailMessage.setSubject(mailInfo.getSubject());
/*     */ 
/* 122 */       mailMessage.setSentDate(new Date());
/*     */ 
/* 126 */       Multipart mainPart = new MimeMultipart();
/*     */ 
/* 128 */       BodyPart html = new MimeBodyPart();
/*     */ 
/* 130 */       html.setContent(mailInfo.getContent(), "text/html; charset=utf-8");
/*     */ 
/* 132 */       mainPart.addBodyPart(html);
/*     */ 
/* 134 */       mailMessage.setContent(mainPart);
/* 135 */       mailMessage.saveChanges();
/*     */ 
/* 139 */       Transport.send(mailMessage);
/* 140 */       return true;
/*     */     } catch (MessagingException ex) {
/* 142 */       ex.printStackTrace();
/*     */     }
/* 144 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean sendHtmlMailWithImg(String toAddress, String subject, String content, List<File> attachList)
/*     */   {
/* 159 */     MailSenderInfo mailInfo = new MailSenderInfo();
/* 160 */     mailInfo.setToAddress(toAddress);
/* 161 */     mailInfo.setSubject(subject);
/* 162 */     mailInfo.setContent(content);
/*     */ 
/* 165 */     MyAuthenticator authenticator = null;
/* 166 */     Properties pro = mailInfo.getProperties();
/*     */ 
/* 168 */     if (mailInfo.isValidate()) {
/* 169 */       authenticator = new MyAuthenticator(mailInfo.getUserName(), 
/* 170 */         mailInfo.getPassword());
/*     */     }
/*     */ 
/* 173 */     Session sendMailSession = Session.getDefaultInstance(pro, authenticator);
/*     */     try
/*     */     {
/* 176 */       MimeMessage message = new MimeMessage(sendMailSession);
/*     */ 
/* 178 */       Address from = new InternetAddress(mailInfo.getFromAddress());
/*     */ 
/* 180 */       message.setFrom(from);
/*     */ 
/* 182 */       Address to = new InternetAddress(mailInfo.getToAddress());
/*     */ 
/* 184 */       message.setRecipient(Message.RecipientType.TO, to);
/*     */ 
/* 186 */       message.setSubject(mailInfo.getSubject());
/*     */ 
/* 188 */       message.setSentDate(new Date());
/*     */ 
/* 192 */       MimeMultipart mm = new MimeMultipart();
/*     */ 
/* 194 */       BodyPart mdp = new MimeBodyPart();
/*     */ 
/* 196 */       mdp.setContent(content.toString(), "text/html;charset=GBK");
/*     */ 
/* 198 */       mm.setSubType("related");
/*     */ 
/* 200 */       mm.addBodyPart(mdp);
/*     */ 
/* 203 */       for (int i = 0; i < attachList.size(); i++)
/*     */       {
/* 205 */         mdp = new MimeBodyPart();
/*     */ 
/* 207 */         File file = (File)attachList.get(i);
/* 208 */         InputStream in = new FileInputStream(file);
/* 209 */         DataHandler dh = new DataHandler(new ByteArrayDataSource(in, "application/octet-stream"));
/* 210 */         mdp.setDataHandler(dh);
/*     */ 
/* 212 */         mdp.setFileName(i + ".jpg");
/* 213 */         mdp.setHeader("Content-ID", "IMG" + i);
/*     */ 
/* 215 */         mm.addBodyPart(mdp);
/*     */       }
/*     */ 
/* 219 */       message.setContent(mm);
/*     */ 
/* 221 */       message.saveChanges();
/* 222 */       Transport transport = sendMailSession.getTransport("smtp");
/* 223 */       transport.connect(mailInfo.getMailServerHost(), mailInfo.getUserName(), mailInfo.getPassword());
/* 224 */       transport.sendMessage(message, message.getAllRecipients());
/*     */ 
/* 226 */       return true;
/*     */     } catch (MessagingException ex) {
/* 228 */       ex.printStackTrace();
/*     */     }
/*     */     catch (FileNotFoundException e) {
/* 231 */       e.printStackTrace();
/*     */     }
/*     */     catch (IOException e) {
/* 234 */       e.printStackTrace();
/*     */     }
/* 236 */     return false;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 242 */     String toMail = "381447823@qq.com";
/* 243 */     String content = "<html><head></head><body><div align=center>\t<a href=http://fr.tzx.com.cn target=_blank>\t\t<img src=cid:IMG0 width=500 height=400 border=0>\t</a></div></body></html>";
/*     */ 
/* 253 */     String subject = "未来餐厅";
/* 254 */     List attachList = new ArrayList();
/*     */ 
/* 257 */     File file = new File("E:/work/futureRestaurant/workSpace/wlct_web/WebRoot/template/wlct/门票印刷文件-电子券.jpg");
/* 258 */     attachList.add(file);
/*     */ 
/* 261 */     sendHtmlMailWithImg(toMail, subject, content, attachList);
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.mail.SimpleMailSender
 * JD-Core Version:    0.6.0
 */