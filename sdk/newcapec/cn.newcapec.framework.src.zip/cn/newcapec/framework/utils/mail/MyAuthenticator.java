/*    */ package cn.newcapec.framework.utils.mail;
/*    */ 
/*    */ import javax.mail.Authenticator;
/*    */ import javax.mail.PasswordAuthentication;
/*    */ 
/*    */ public class MyAuthenticator extends Authenticator
/*    */ {
/*  7 */   String userName = null;
/*  8 */   String password = null;
/*    */ 
/*    */   public MyAuthenticator() {
/*    */   }
/*    */   public MyAuthenticator(String username, String password) {
/* 13 */     this.userName = username;
/* 14 */     this.password = password;
/*    */   }
/*    */   protected PasswordAuthentication getPasswordAuthentication() {
/* 17 */     return new PasswordAuthentication(this.userName, this.password);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.mail.MyAuthenticator
 * JD-Core Version:    0.6.0
 */