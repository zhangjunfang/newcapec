/*    */ package cn.newcapec.framework.utils;
/*    */ 
/*    */ public class SystemContext
/*    */ {
/*  5 */   private static ThreadLocal offset = new ThreadLocal();
/*  6 */   private static ThreadLocal pagesize = new ThreadLocal();
/*    */ 
/*    */   public static void setOffset(Integer _offset)
/*    */   {
/* 10 */     offset.set(_offset);
/*    */   }
/*    */ 
/*    */   public static Integer getOffset() {
/* 14 */     Integer os = (Integer)offset.get();
/* 15 */     if (os == null) {
/* 16 */       return Integer.valueOf(0);
/*    */     }
/* 18 */     return os;
/*    */   }
/*    */ 
/*    */   public static void removeOffset() {
/* 22 */     offset.remove();
/*    */   }
/*    */ 
/*    */   public static void setPagesize(Integer _pagesize)
/*    */   {
/* 27 */     pagesize.set(_pagesize);
/*    */   }
/*    */ 
/*    */   public static Integer getPagesize() {
/* 31 */     Integer ps = (Integer)pagesize.get();
/* 32 */     if (ps == null) {
/* 33 */       return Integer.valueOf(2147483647);
/*    */     }
/* 35 */     return ps;
/*    */   }
/*    */ 
/*    */   public static void removePagesize() {
/* 39 */     pagesize.remove();
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.SystemContext
 * JD-Core Version:    0.6.0
 */