/*    */ package cn.newcapec.framework.utils;
/*    */ 
/*    */ import java.text.CollationKey;
/*    */ import java.text.Collator;
/*    */ import java.util.Comparator;
/*    */ 
/*    */ public class CollatorComparator
/*    */   implements Comparator
/*    */ {
/* 11 */   Collator collator = Collator.getInstance();
/*    */ 
/*    */   public int compare(Object element1, Object element2)
/*    */   {
/* 15 */     CollationKey key1 = this.collator.getCollationKey(element1.toString());
/*    */ 
/* 17 */     CollationKey key2 = this.collator.getCollationKey(element2.toString());
/*    */ 
/* 19 */     return key1.compareTo(key2);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.CollatorComparator
 * JD-Core Version:    0.6.0
 */