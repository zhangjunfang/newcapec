/*    */ package cn.newcapec.framework.utils.fileloader;
/*    */ 
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.net.URL;
/*    */ 
/*    */ public class DefaultFileLoader extends FileLoader
/*    */ {
/*    */   public static final String CLASSPATH_PREFIX = "classpath:";
/*    */   public static final String FILE_PREFIX1 = "file:";
/*    */   public static final String FILE_PREFIX2 = "file://";
/*    */   private FileLoader resourceFileLoader;
/*    */   private FileLoader pathFileLoader;
/*    */   private FileLoader currFileLoader;
/*    */ 
/*    */   private FileLoader getResourceFileLoader()
/*    */   {
/* 27 */     if (this.resourceFileLoader == null)
/* 28 */       this.resourceFileLoader = new ResourceFileLoader();
/* 29 */     return this.resourceFileLoader;
/*    */   }
/*    */ 
/*    */   private FileLoader getPathFileLoader() {
/* 33 */     if (this.pathFileLoader == null)
/* 34 */       this.pathFileLoader = new PathFileLoader();
/* 35 */     return this.pathFileLoader;
/*    */   }
/*    */ 
/*    */   public DefaultFileLoader() {
/* 39 */     super(null);
/*    */   }
/*    */ 
/*    */   public DefaultFileLoader(String paramString) {
/* 43 */     super(paramString);
/*    */   }
/*    */ 
/*    */   protected void doSetFile(String filePath)
/*    */   {
/* 48 */     if (this.root != null)
/* 49 */       filePath = this.root + filePath;
/*    */     String url;
/*    */     String url;
/* 51 */     if (filePath.startsWith("classpath:")) {
/* 52 */       this.currFileLoader = getResourceFileLoader();
/* 53 */       url = filePath.substring("classpath:".length());
/*    */     }
/*    */     else
/*    */     {
/*    */       String url;
/* 54 */       if (filePath.startsWith("file:")) {
/* 55 */         this.currFileLoader = getPathFileLoader();
/* 56 */         url = filePath.substring("file:".length());
/*    */       }
/*    */       else
/*    */       {
/*    */         String url;
/* 57 */         if (filePath.startsWith("file://")) {
/* 58 */           this.currFileLoader = getPathFileLoader();
/* 59 */           url = filePath.substring("file://".length());
/*    */         } else {
/* 61 */           this.currFileLoader = getResourceFileLoader();
/* 62 */           url = filePath;
/*    */         }
/*    */       }
/*    */     }
/* 64 */     this.currFileLoader.setFile(url);
/*    */   }
/*    */ 
/*    */   public boolean exists() {
/* 68 */     return this.currFileLoader.exists();
/*    */   }
/*    */ 
/*    */   public long getLastModified() throws IOException {
/* 72 */     return this.currFileLoader.getLastModified();
/*    */   }
/*    */ 
/*    */   public InputStream getInputStream() throws IOException {
/* 76 */     return this.currFileLoader.getInputStream();
/*    */   }
/*    */ 
/*    */   public OutputStream getOutputStream() throws IOException {
/* 80 */     return this.currFileLoader.getOutputStream();
/*    */   }
/*    */ 
/*    */   public String getRealPath() {
/* 84 */     return this.currFileLoader.getRealPath();
/*    */   }
/*    */ 
/*    */   public URL getURL() throws FileNotFoundException, IOException {
/* 88 */     return this.currFileLoader.getURL();
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.fileloader.DefaultFileLoader
 * JD-Core Version:    0.6.0
 */