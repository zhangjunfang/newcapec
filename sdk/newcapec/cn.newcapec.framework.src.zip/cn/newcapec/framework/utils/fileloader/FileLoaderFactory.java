/*    */ package cn.newcapec.framework.utils.fileloader;
/*    */ 
/*    */ import cn.newcapec.framework.utils.tools.ClassLoaderUtils;
/*    */ 
/*    */ public final class FileLoaderFactory
/*    */ {
/* 13 */   private static String DEFAULT_FILE_LOADER = "cn.newcapec.framework.utils.fileloader.DefaultFileLoader";
/*    */ 
/*    */   public static FileLoader creatFileLoader(String fileLoaderClazzName, String rootPath)
/*    */   {
/*    */     try
/*    */     {
/* 24 */       return (FileLoader)ClassLoaderUtils.newInstance(fileLoaderClazzName, new Class[] { String.class }, new Object[] { rootPath });
/*    */     } catch (Exception ex) {
/* 26 */       ex.printStackTrace();
/*    */     }
/* 28 */     return null;
/*    */   }
/*    */ 
/*    */   public static FileLoader creatFileLoader(Class fileLoaderClazzName, String rootPath)
/*    */   {
/*    */     try
/*    */     {
/* 40 */       return (FileLoader)ClassLoaderUtils.newInstance(fileLoaderClazzName, new Class[] { String.class }, new Object[] { rootPath });
/*    */     } catch (Exception ex) {
/* 42 */       ex.printStackTrace();
/*    */     }
/* 44 */     return null;
/*    */   }
/*    */ 
/*    */   public static final FileLoader createDefaultFileLoader()
/*    */   {
/* 52 */     return creatFileLoader(DEFAULT_FILE_LOADER, null);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.fileloader.FileLoaderFactory
 * JD-Core Version:    0.6.0
 */