/*    */ package cn.newcapec.framework.utils.fileloader;
/*    */ 
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.net.URL;
/*    */ 
/*    */ public abstract class FileLoader
/*    */ {
/*    */   protected String root;
/*    */   private String filePath;
/*    */ 
/*    */   public FileLoader(String root)
/*    */   {
/* 22 */     if (root == null)
/* 23 */       root = "";
/* 24 */     else if (!root.endsWith("/"))
/* 25 */       root = root + '/';
/* 26 */     this.root = root;
/*    */   }
/*    */ 
/*    */   protected abstract void doSetFile(String paramString);
/*    */ 
/*    */   public void setFile(String filePath)
/*    */   {
/* 39 */     this.filePath = filePath;
/* 40 */     doSetFile(filePath);
/*    */   }
/*    */ 
/*    */   public abstract boolean exists();
/*    */ 
/*    */   public abstract long getLastModified()
/*    */     throws IOException;
/*    */ 
/*    */   public abstract InputStream getInputStream()
/*    */     throws IOException;
/*    */ 
/*    */   public abstract OutputStream getOutputStream()
/*    */     throws IOException;
/*    */ 
/*    */   public String getRoot()
/*    */   {
/* 64 */     return this.root;
/*    */   }
/*    */ 
/*    */   public String getFilePath()
/*    */   {
/* 71 */     return this.filePath;
/*    */   }
/*    */ 
/*    */   public abstract String getRealPath();
/*    */ 
/*    */   public abstract URL getURL()
/*    */     throws FileNotFoundException, IOException;
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.fileloader.FileLoader
 * JD-Core Version:    0.6.0
 */