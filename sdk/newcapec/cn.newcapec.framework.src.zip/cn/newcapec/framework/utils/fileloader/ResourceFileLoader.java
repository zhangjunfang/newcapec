/*    */ package cn.newcapec.framework.utils.fileloader;
/*    */ 
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.net.URL;
/*    */ 
/*    */ public class ResourceFileLoader extends FileLoader
/*    */ {
/*    */   private URL url;
/*    */   private String path;
/*    */ 
/*    */   public ResourceFileLoader()
/*    */   {
/* 18 */     super(null);
/*    */   }
/*    */ 
/*    */   public ResourceFileLoader(String root) {
/* 22 */     super(root);
/*    */   }
/*    */ 
/*    */   protected void doSetFile(String filepath) {
/* 26 */     if (this.root == null)
/* 27 */       this.path = filepath;
/*    */     else
/* 29 */       this.path = (this.root + filepath);
/* 30 */     this.url = null;
/*    */   }
/*    */ 
/*    */   protected URL doGetURL() throws FileNotFoundException, IOException {
/* 34 */     if (this.url == null) {
/* 35 */       this.url = getClass().getResource(this.path);
/* 36 */       if (this.url == null) {
/* 37 */         for (ClassLoader localClassLoader = getClass().getClassLoader(); localClassLoader != null; localClassLoader = localClassLoader
/* 38 */           .getParent())
/*    */         {
/* 39 */           this.url = localClassLoader.getResource(this.path);
/* 40 */           if (this.url != null)
/*    */             break;
/*    */         }
/* 43 */         if (this.url == null)
/* 44 */           this.url = ClassLoader.getSystemResource(this.path);
/*    */       }
/* 46 */       if (this.url == null)
/* 47 */         throw new FileNotFoundException(this.path);
/*    */     }
/* 49 */     return this.url;
/*    */   }
/*    */ 
/*    */   public boolean exists()
/*    */   {
/*    */     try
/*    */     {
/* 56 */       return doGetURL() != null;
/*    */     } catch (Exception localException) {
/*    */     }
/* 59 */     return false;
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public long getLastModified() throws IOException
/*    */   {
/* 66 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public InputStream getInputStream() throws IOException {
/* 70 */     return doGetURL().openStream();
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public OutputStream getOutputStream() throws IOException
/*    */   {
/* 77 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public String getRealPath() {
/* 81 */     return this.path;
/*    */   }
/*    */ 
/*    */   public URL getURL() throws FileNotFoundException, IOException {
/* 85 */     return doGetURL();
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.fileloader.ResourceFileLoader
 * JD-Core Version:    0.6.0
 */