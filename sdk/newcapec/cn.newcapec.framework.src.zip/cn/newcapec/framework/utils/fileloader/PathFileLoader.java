/*    */ package cn.newcapec.framework.utils.fileloader;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ 
/*    */ public class PathFileLoader extends FileLoader
/*    */ {
/*    */   private File file;
/*    */   private String filePath;
/*    */ 
/*    */   public PathFileLoader()
/*    */   {
/* 20 */     super(null);
/*    */   }
/*    */ 
/*    */   public PathFileLoader(String root) {
/* 24 */     super(root);
/*    */   }
/*    */ 
/*    */   protected void doSetFile(String filepath) {
/* 28 */     if (this.root == null)
/* 29 */       this.filePath = filepath;
/*    */     else
/* 31 */       this.filePath = (this.root + filepath);
/* 32 */     this.file = new File(this.filePath);
/*    */   }
/*    */ 
/*    */   public boolean exists()
/*    */   {
/* 38 */     return this.file.exists();
/*    */   }
/*    */ 
/*    */   public long getLastModified()
/*    */     throws IOException
/*    */   {
/* 44 */     return this.file.lastModified();
/*    */   }
/*    */ 
/*    */   public InputStream getInputStream()
/*    */     throws IOException
/*    */   {
/* 50 */     return new FileInputStream(this.file);
/*    */   }
/*    */ 
/*    */   public OutputStream getOutputStream()
/*    */     throws IOException
/*    */   {
/* 56 */     return new FileOutputStream(this.file);
/*    */   }
/*    */ 
/*    */   public String getRealPath()
/*    */   {
/* 62 */     return this.filePath;
/*    */   }
/*    */ 
/*    */   public URL getURL()
/*    */   {
/*    */     try
/*    */     {
/* 69 */       return new URL("file:///" + this.filePath);
/*    */     } catch (MalformedURLException ex) {
/* 71 */       ex.printStackTrace();
/*    */     }
/* 73 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.fileloader.PathFileLoader
 * JD-Core Version:    0.6.0
 */