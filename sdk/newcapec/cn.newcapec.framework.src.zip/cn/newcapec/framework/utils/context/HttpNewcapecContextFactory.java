/*    */ package cn.newcapec.framework.utils.context;
/*    */ 
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
/*    */ public final class HttpNewcapecContextFactory
/*    */ {
/*    */   public static final String ATTRIBUTE_KEY = "cn.newcapec.framework.utils.context.TzxContext";
/*    */ 
/*    */   public static final NewcapecContext getContext(ServletRequest servletrequest)
/*    */   {
/* 24 */     return getContext(servletrequest, true);
/*    */   }
/*    */ 
/*    */   public static final NewcapecContext getContext(ServletRequest servletrequest, boolean flag)
/*    */   {
/*    */     HttpNewcapecContext httpTzxContext;
/* 39 */     if (servletrequest != null)
/*    */     {
/*    */       HttpNewcapecContext httpTzxContext;
/* 40 */       if ((httpTzxContext = (HttpNewcapecContext)servletrequest
/* 41 */         .getAttribute("cn.newcapec.framework.utils.context.TzxContext")) == null) {
/* 42 */         if (!flag) {
/* 43 */           return null;
/*    */         }
/* 45 */         httpTzxContext = new HttpNewcapecContext();
/* 46 */         servletrequest.setAttribute("cn.newcapec.framework.utils.context.TzxContext", httpTzxContext);
/*    */       }
/* 48 */       httpTzxContext.setRequest((HttpServletRequest)servletrequest);
/*    */     } else {
/* 50 */       httpTzxContext = new HttpNewcapecContext();
/*    */     }
/* 52 */     return httpTzxContext;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.context.HttpNewcapecContextFactory
 * JD-Core Version:    0.6.0
 */