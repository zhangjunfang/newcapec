/*    */ package cn.newcapec.framework.utils.context;
/*    */ 
/*    */ public abstract class NewcapecContext
/*    */ {
/*    */   public static final int REQUEST = 1;
/*    */   public static final int SESSION = 5;
/*    */   public static final int APPLICATION = 9;
/* 25 */   private static ThreadLocal cache = new ThreadLocal();
/*    */ 
/*    */   public static void registerContext(NewcapecContext tzxContext)
/*    */   {
/* 31 */     cache.set(tzxContext);
/*    */   }
/*    */ 
/*    */   public static synchronized NewcapecContext getContext()
/*    */   {
/*    */     Object obj;
/* 36 */     if ((obj = (NewcapecContext)cache.get()) == null) {
/* 37 */       registerContext((NewcapecContext)(obj = new DynaNewcapecContext()));
/*    */     }
/* 39 */     return (NewcapecContext)obj;
/*    */   }
/*    */ 
/*    */   public static void unregisterContext()
/*    */   {
/* 46 */     cache.set(null);
/*    */   }
/*    */ 
/*    */   public abstract String getParameter(String paramString);
/*    */ 
/*    */   public abstract String[] getParameters(String paramString);
/*    */ 
/*    */   public abstract Object getAttribute(String paramString);
/*    */ 
/*    */   public abstract Object getAttribute(int paramInt, String paramString);
/*    */ 
/*    */   public abstract void setAttribute(int paramInt, String paramString, Object paramObject);
/*    */ 
/*    */   public abstract void removeAttribute(int paramInt, String paramString);
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.context.NewcapecContext
 * JD-Core Version:    0.6.0
 */