/*    */ package cn.newcapec.framework.utils.context;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class DynaNewcapecContext extends AbstractNewcapecContext
/*    */ {
/*    */   private Map cache;
/*    */ 
/*    */   public DynaNewcapecContext()
/*    */   {
/* 16 */     this.cache = new Hashtable();
/*    */   }
/*    */ 
/*    */   private String a(int i, String s) {
/* 20 */     return "$" + i + "." + s;
/*    */   }
/*    */ 
/*    */   public Object getAttribute(int i, String s) {
/* 24 */     return this.cache.get(a(i, s));
/*    */   }
/*    */ 
/*    */   public String getParameter(String s) {
/* 28 */     return null;
/*    */   }
/*    */ 
/*    */   public String[] getParameters(String s) {
/* 32 */     return null;
/*    */   }
/*    */ 
/*    */   public void removeAttribute(int i, String s) {
/* 36 */     this.cache.remove(a(i, s));
/*    */   }
/*    */ 
/*    */   public void setAttribute(int i, String s, Object obj) {
/* 40 */     this.cache.put(a(i, s), obj);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.context.DynaNewcapecContext
 * JD-Core Version:    0.6.0
 */