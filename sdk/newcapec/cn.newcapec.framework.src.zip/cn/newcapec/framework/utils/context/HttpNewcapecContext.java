/*     */ package cn.newcapec.framework.utils.context;
/*     */ 
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.Stack;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ 
/*     */ public class HttpNewcapecContext extends AbstractNewcapecContext
/*     */ {
/*     */   protected Stack reqeustStack;
/*     */ 
/*     */   HttpNewcapecContext()
/*     */   {
/*  18 */     this.reqeustStack = new Stack();
/*     */   }
/*     */ 
/*     */   public HttpServletRequest getRequest()
/*     */   {
/*  27 */     HttpServletRequest httpservletrequest = null;
/*     */ 
/*  29 */     while (httpservletrequest == null)
/*     */     {
/*  32 */       this.reqeustStack.peek();
/*  33 */       Reference reference = null;
/*  34 */       if ((reference = (Reference)this.reqeustStack.peek()) == null) {
/*     */         break;
/*     */       }
/*  37 */       if ((httpservletrequest = (HttpServletRequest)reference.get()) == null) {
/*  38 */         this.reqeustStack.pop();
/*     */       }
/*     */     }
/*  41 */     return httpservletrequest;
/*     */   }
/*     */ 
/*     */   public void setRequest(HttpServletRequest httpservletrequest)
/*     */   {
/*  51 */     boolean flag = false;
/*  52 */     int i = this.reqeustStack.size();
/*  53 */     int j = 0;
/*     */ 
/*  55 */     while (j < i)
/*     */     {
/*     */       Reference reference;
/*  58 */       if (((reference = (Reference)this.reqeustStack.get(j)) != null) && 
/*  59 */         (reference.get() == httpservletrequest)) {
/*  60 */         flag = true;
/*  61 */         for (int k = i - 1; k > j; k--) {
/*  62 */           this.reqeustStack.remove(k);
/*     */         }
/*  64 */         break;
/*     */       }
/*  66 */       j++;
/*     */     }
/*  68 */     if (!flag)
/*  69 */       this.reqeustStack.push(new WeakReference(httpservletrequest));
/*     */   }
/*     */ 
/*     */   public String getParameter(String s)
/*     */   {
/*  76 */     return getRequest().getParameter(s);
/*     */   }
/*     */ 
/*     */   public String[] getParameters(String s)
/*     */   {
/*  83 */     return getRequest().getParameterValues(s);
/*     */   }
/*     */ 
/*     */   public Object getAttribute(int i, String s)
/*     */   {
/*  90 */     HttpServletRequest httpservletrequest = getRequest();
/*  91 */     switch (i) {
/*     */     case 1:
/*  93 */       return httpservletrequest.getAttribute(s);
/*     */     case 5:
/*  96 */       return httpservletrequest.getSession().getAttribute(s);
/*     */     case 9:
/*  99 */       return httpservletrequest.getSession().getServletContext()
/* 100 */         .getAttribute(s);
/*     */     case 2:
/*     */     case 3:
/*     */     case 4:
/*     */     case 6:
/*     */     case 7:
/*     */     case 8:
/*     */     }
/* 108 */     return null;
/*     */   }
/*     */ 
/*     */   public void setAttribute(int i, String s, Object obj)
/*     */   {
/* 113 */     HttpServletRequest httpservletrequest = getRequest();
/* 114 */     switch (i) {
/*     */     case 1:
/* 116 */       httpservletrequest.setAttribute(s, obj);
/* 117 */       return;
/*     */     case 5:
/* 120 */       httpservletrequest.getSession().setAttribute(s, obj);
/* 121 */       return;
/*     */     case 9:
/* 124 */       httpservletrequest.getSession().getServletContext()
/* 125 */         .setAttribute(s, obj);
/*     */     case 2:
/*     */     case 3:
/*     */     case 4:
/*     */     case 6:
/*     */     case 7:
/*     */     case 8:
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeAttribute(int i, String s)
/*     */   {
/* 143 */     HttpServletRequest httpservletrequest = getRequest();
/* 144 */     switch (i) {
/*     */     case 1:
/* 146 */       httpservletrequest.removeAttribute(s);
/* 147 */       return;
/*     */     case 5:
/* 150 */       httpservletrequest.getSession().removeAttribute(s);
/* 151 */       return;
/*     */     case 9:
/* 154 */       httpservletrequest.getSession().getServletContext()
/* 155 */         .removeAttribute(s);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.context.HttpNewcapecContext
 * JD-Core Version:    0.6.0
 */