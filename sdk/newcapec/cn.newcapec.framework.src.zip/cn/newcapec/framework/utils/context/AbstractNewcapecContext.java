/*    */ package cn.newcapec.framework.utils.context;
/*    */ 
/*    */ public abstract class AbstractNewcapecContext extends NewcapecContext
/*    */ {
/*    */   public Object getAttribute(String s)
/*    */   {
/*    */     Object obj;
/* 18 */     if (((obj = getAttribute(1, s)) == null) && 
/* 19 */       ((obj = getAttribute(2, s)) == null) && 
/* 20 */       ((obj = getAttribute(5, s)) == null))
/* 21 */       obj = getAttribute(9, s);
/* 22 */     return obj;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.context.AbstractNewcapecContext
 * JD-Core Version:    0.6.0
 */