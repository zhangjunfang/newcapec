/*     */ package cn.newcapec.framework.utils.tools;
/*     */ 
/*     */ import cn.newcapec.framework.base.exception.BaseException;
/*     */ import cn.newcapec.framework.utils.variant.VariantSet;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class Record extends VariantSet
/*     */ {
/*     */   private static final long serialVersionUID = -342962586160509258L;
/*  22 */   private Logger logger = Logger.getLogger(getClass().getName());
/*     */   private int state;
/*     */   public static final int ADD = 1;
/*     */   public static final int MODIFY = 2;
/*     */   public static final int DELETE = 3;
/*     */ 
/*     */   public int getState()
/*     */   {
/*  33 */     return this.state;
/*     */   }
/*     */ 
/*     */   public void setState(int state) {
/*  37 */     this.state = state;
/*     */   }
/*     */ 
/*     */   public static Record fromDO(Object object)
/*     */   {
/*  47 */     Record record = null;
/*  48 */     Method[] method = object.getClass().getMethods();
/*  49 */     int i = 0; for (int len = method.length; i < len; i++) {
/*  50 */       if (record == null) {
/*  51 */         record = new Record();
/*     */       }
/*  53 */       Method aMethod = method[i];
/*  54 */       String methodname = aMethod.getName();
/*  55 */       if (methodname.startsWith("set")) {
/*  56 */         String propertyName = methodname.substring(3);
/*  57 */         String s = String.valueOf(propertyName.charAt(0)).toLowerCase();
/*  58 */         propertyName = s + propertyName.substring(1);
/*  59 */         record.setValue(propertyName, 
/*  60 */           BeanUtils.getProperty(object, propertyName));
/*     */       }
/*     */     }
/*     */ 
/*  64 */     return record;
/*     */   }
/*     */ 
/*     */   public void toDO(Object obj)
/*     */   {
/*  74 */     int i = 0; for (int len = count(); i < len; i++) {
/*  75 */       String name = indexToName(i);
/*  76 */       Object value = getValue(i);
/*     */ 
/*  78 */       if (((value instanceof String)) && 
/*  79 */         (StringUtil.isEmpty((String)value)))
/*  80 */         value = null;
/*     */       try
/*     */       {
/*  83 */         BeanUtils.copyProperty(obj, name, value);
/*     */       }
/*     */       catch (Exception ex) {
/*  86 */         this.logger.error(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public <T> T toDO(Class<T> clazz)
/*     */   {
/*     */     try
/*     */     {
/*  99 */       Object object = clazz.newInstance();
/* 100 */       toDO(object);
/* 101 */       return object; } catch (Exception ex) {
/*     */     }
/* 103 */     throw new BaseException("转换DO对象出错！", ex);
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.tools.Record
 * JD-Core Version:    0.6.0
 */