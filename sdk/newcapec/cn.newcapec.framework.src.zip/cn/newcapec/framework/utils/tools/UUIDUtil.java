/*    */ package cn.newcapec.framework.utils.tools;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import java.security.SecureRandom;
/*    */ 
/*    */ public final class UUIDUtil
/*    */ {
/*    */   private static SecureRandom rnd;
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 17 */       rnd = SecureRandom.getInstance("SHA1PRNG");
/*    */     } catch (NoSuchAlgorithmException e) {
/* 19 */       rnd = new SecureRandom();
/*    */     }
/*    */ 
/* 23 */     byte[] seed = rnd.generateSeed(64);
/* 24 */     rnd.setSeed(seed);
/*    */   }
/*    */ 
/*    */   public static String generateFormattedGUID() {
/* 28 */     String guid = generateGUID();
/*    */ 
/* 30 */     return guid.substring(0, 8) + '-' + guid.substring(8, 12) + '-' + 
/* 31 */       guid.substring(12, 16) + '-' + guid.substring(16, 20) + '-' + 
/* 32 */       guid.substring(20);
/*    */   }
/*    */ 
/*    */   public static String generateGUID() {
/* 36 */     return new BigInteger(165, rnd).toString(36).toUpperCase();
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.tools.UUIDUtil
 * JD-Core Version:    0.6.0
 */