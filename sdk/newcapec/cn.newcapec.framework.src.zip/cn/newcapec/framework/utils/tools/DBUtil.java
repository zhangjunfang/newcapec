/*     */ package cn.newcapec.framework.utils.tools;
/*     */ 
/*     */ import cn.newcapec.framework.base.biz.db.DbEngineService;
/*     */ import cn.newcapec.framework.base.dao.db.PagingResultSet;
/*     */ import cn.newcapec.framework.base.dbmeta.Container;
/*     */ import cn.newcapec.framework.base.dbmeta.DBTable;
/*     */ import cn.newcapec.framework.base.exception.BaseException;
/*     */ import cn.newcapec.framework.utils.SpringConext;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ 
/*     */ public class DBUtil
/*     */ {
/*     */   public static final int SQL_SELECT = 1;
/*     */   public static final int SQL_INSERT = 2;
/*     */   public static final int SQL_UPDATE = 3;
/*  27 */   static DbEngineService iDbEngineService = (DbEngineService)SpringConext.getApplicationContext().getBean(DbEngineService.class);
/*     */ 
/*     */   public static List query(String querySQL, Class modelClass, boolean convertFieldName)
/*     */     throws BaseException
/*     */   {
/*  42 */     return iDbEngineService.query(querySQL, modelClass, convertFieldName);
/*     */   }
/*     */ 
/*     */   public static List query(String querySQL, Class modelClass)
/*     */     throws BaseException
/*     */   {
/*  56 */     return query(querySQL, modelClass, true);
/*     */   }
/*     */ 
/*     */   public static List query(StringBuffer querySQL, Class modelClass, boolean convertFieldName)
/*     */     throws BaseException
/*     */   {
/*  74 */     return query(querySQL.toString(), modelClass, convertFieldName);
/*     */   }
/*     */ 
/*     */   public static List query(StringBuffer querySQL, Class modelClass)
/*     */     throws BaseException
/*     */   {
/*  90 */     return query(querySQL.toString(), modelClass, true);
/*     */   }
/*     */ 
/*     */   public static List query(String querySQL, Object[] params, Class modelClass, boolean convertFieldName)
/*     */     throws BaseException
/*     */   {
/* 107 */     return iDbEngineService.query(querySQL, params, modelClass, 
/* 108 */       convertFieldName);
/*     */   }
/*     */ 
/*     */   public static List query(String querySQL, Object[] params, Class modelClass)
/*     */     throws BaseException
/*     */   {
/* 141 */     return query(querySQL, params, modelClass, true);
/*     */   }
/*     */ 
/*     */   public static List query(String querySQL, Object params, Class modelClass, boolean convertFieldName)
/*     */     throws BaseException
/*     */   {
/* 161 */     return query(querySQL, new Object[] { params }, modelClass, 
/* 162 */       convertFieldName);
/*     */   }
/*     */ 
/*     */   public static List query(String querySQL, Object params, Class modelClass)
/*     */     throws BaseException
/*     */   {
/* 180 */     return query(querySQL, new Object[] { params }, modelClass, true);
/*     */   }
/*     */ 
/*     */   public static int execute(String querySQL, Object[] params)
/*     */     throws BaseException
/*     */   {
/* 198 */     return iDbEngineService.execute(querySQL, params);
/*     */   }
/*     */ 
/*     */   public static int execute(String querySQL, Object params)
/*     */     throws BaseException
/*     */   {
/* 216 */     return iDbEngineService.execute(querySQL, new Object[] { params });
/*     */   }
/*     */ 
/*     */   public static int execute(String querySQL)
/*     */     throws BaseException
/*     */   {
/* 231 */     return iDbEngineService.execute(querySQL, null);
/*     */   }
/*     */ 
/*     */   public static List query(StringBuffer querySQL, Object[] params, Class modelClass) throws BaseException
/*     */   {
/* 236 */     return query(querySQL.toString(), params, modelClass, true);
/*     */   }
/*     */ 
/*     */   public static List query(StringBuffer querySQL, Object params, Class modelClass)
/*     */     throws BaseException
/*     */   {
/* 254 */     return query(querySQL.toString(), new Object[] { params }, modelClass, 
/* 255 */       true);
/*     */   }
/*     */ 
/*     */   public static List query(StringBuffer querySQL, Object[] params, Class modelClass, boolean convertFieldName) throws BaseException
/*     */   {
/* 260 */     return query(querySQL.toString(), params, modelClass, convertFieldName);
/*     */   }
/*     */ 
/*     */   public static List query(String querySQL, Object[] params, Class modelClass, int pageSize, int pageIndex)
/*     */     throws BaseException
/*     */   {
/* 279 */     return iDbEngineService.query(querySQL.toString(), params, modelClass, 
/* 280 */       pageSize, pageIndex);
/*     */   }
/*     */ 
/*     */   public static List query(String querySQL, Object params, Class modelClass, int pageSize, int pageIndex)
/*     */     throws BaseException
/*     */   {
/* 299 */     return iDbEngineService.query(querySQL.toString(), 
/* 300 */       new Object[] { params }, modelClass, pageSize, pageIndex);
/*     */   }
/*     */ 
/*     */   public static List query(String querySQL, Class modelClass, int pageSize, int pageIndex)
/*     */     throws BaseException
/*     */   {
/* 319 */     return iDbEngineService.query(querySQL.toString(), null, modelClass, 
/* 320 */       pageSize, pageIndex);
/*     */   }
/*     */ 
/*     */   public static PagingResultSet getPagingResultSet(String querySQL, Object[] params, Class modelClass, int pageSize, int pageIndex)
/*     */     throws BaseException
/*     */   {
/* 342 */     if (pageIndex == 0) {
/* 343 */       pageIndex = 1;
/*     */     }
/* 345 */     return iDbEngineService.getPagingResultSet(querySQL, params, 
/* 346 */       modelClass, pageSize, pageIndex);
/*     */   }
/*     */ 
/*     */   public static PagingResultSet getPagingResultSet(String querySQL, Class modelClass, int pageSize, int pageIndex)
/*     */     throws BaseException
/*     */   {
/* 369 */     return getPagingResultSet(querySQL, null, modelClass, pageSize, 
/* 370 */       pageIndex);
/*     */   }
/*     */ 
/*     */   public static PagingResultSet getPagingResultSet(String querySQL, Object param, Class modelClass, int pageSize, int pageIndex)
/*     */     throws BaseException
/*     */   {
/* 394 */     return getPagingResultSet(querySQL, new Object[] { param }, modelClass, 
/* 395 */       pageSize, pageIndex);
/*     */   }
/*     */ 
/*     */   public static PagingResultSet getPagingResultSet(String querySQL, Object[] params, Class modelClass, int pageSize, String pageIndex)
/*     */     throws BaseException
/*     */   {
/* 418 */     int pageIndexNumber = MathUtil.getInteger(pageIndex).intValue();
/* 419 */     return getPagingResultSet(querySQL, params, modelClass, pageSize, 
/* 420 */       pageIndexNumber);
/*     */   }
/*     */ 
/*     */   public static PagingResultSet getPagingResultSet(String querySQL, Class modelClass, int pageSize, String pageIndex)
/*     */     throws BaseException
/*     */   {
/* 441 */     return getPagingResultSet(querySQL, null, modelClass, pageSize, 
/* 442 */       pageIndex);
/*     */   }
/*     */ 
/*     */   public static PagingResultSet getPagingResultSet(String querySQL, Object param, Class modelClass, int pageSize, String pageIndex)
/*     */     throws BaseException
/*     */   {
/* 465 */     return getPagingResultSet(querySQL, new Object[] { param }, modelClass, 
/* 466 */       pageSize, pageIndex);
/*     */   }
/*     */ 
/*     */   public static boolean checkRecordExist(String tableName, String field, Object value, String extraSql)
/*     */   {
/* 481 */     return iDbEngineService.checkRecordExist(tableName, field, value, 
/* 482 */       extraSql, null);
/*     */   }
/*     */ 
/*     */   public static boolean checkRecordExist(String tableName, String field, Object value, String extraSql, Object[] extraParams)
/*     */   {
/* 499 */     return iDbEngineService.checkRecordExist(tableName, field, value, 
/* 500 */       extraSql, extraParams);
/*     */   }
/*     */ 
/*     */   public static boolean checkRecordExist(String tableName, String field, Object value)
/*     */   {
/* 514 */     return iDbEngineService.checkRecordExist(tableName, field, value, null, 
/* 515 */       null);
/*     */   }
/*     */ 
/*     */   public static boolean checkRecordExist(Class entityClass, String propertyName, Object value, String extraHql, Object[] extraParams)
/*     */   {
/* 534 */     return iDbEngineService.checkRecordExist(entityClass, propertyName, 
/* 535 */       value, extraHql, extraParams);
/*     */   }
/*     */ 
/*     */   public static boolean checkRecordExist(Class entityClass, String propertyName, Object value, String extraHql)
/*     */   {
/* 552 */     return iDbEngineService.checkRecordExist(entityClass, propertyName, 
/* 553 */       value, extraHql, null);
/*     */   }
/*     */ 
/*     */   public static boolean checkRecordExist(Class entityClass, String property, Object value)
/*     */   {
/* 570 */     return iDbEngineService.checkRecordExist(entityClass, property, value, 
/* 571 */       null, null);
/*     */   }
/*     */ 
/*     */   public static Container getDBContainer(String schemaPattern, String tablePattern)
/*     */   {
/* 585 */     return iDbEngineService.getDBContainer(schemaPattern, tablePattern);
/*     */   }
/*     */ 
/*     */   public static List<DBTable> getDBTables(String schemaPattern, String tablePattern)
/*     */   {
/* 598 */     return iDbEngineService.getDBTables(schemaPattern, tablePattern);
/*     */   }
/*     */ 
/*     */   public static DBTable getDBTable(String tableName)
/*     */   {
/* 609 */     return iDbEngineService.getDBTable(tableName);
/*     */   }
/*     */ 
/*     */   public static Set<String> getTableList(String schemaPattern, String tablePattern)
/*     */   {
/* 621 */     return iDbEngineService.getTableList(schemaPattern, tablePattern);
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.tools.DBUtil
 * JD-Core Version:    0.6.0
 */