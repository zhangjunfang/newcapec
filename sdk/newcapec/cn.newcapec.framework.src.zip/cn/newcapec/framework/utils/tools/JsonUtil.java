/*     */ package cn.newcapec.framework.utils.tools;
/*     */ 
/*     */ import cn.newcapec.framework.base.log.LogEnabled;
/*     */ import cn.newcapec.framework.utils.variant.VariantSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import net.sf.json.JSONArray;
/*     */ import net.sf.json.JSONException;
/*     */ import net.sf.json.JSONObject;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class JsonUtil
/*     */   implements LogEnabled
/*     */ {
/*     */   public static JSONArray toJSONArray(List list, String[] names)
/*     */   {
/*  34 */     JSONArray jsonArray = new JSONArray();
/*  35 */     if (!list.isEmpty()) {
/*  36 */       int i = 0; for (int len = list.size(); i < len; i++) {
/*  37 */         jsonArray.add(toJSONObject(list.get(i), names));
/*     */       }
/*     */     }
/*     */ 
/*  41 */     return jsonArray;
/*     */   }
/*     */ 
/*     */   public static JSONArray toJSONArray(List list)
/*     */   {
/*  54 */     JSONArray jsonArray = new JSONArray();
/*  55 */     if (!list.isEmpty()) {
/*  56 */       int i = 0; for (int len = list.size(); i < len; i++) {
/*  57 */         jsonArray.add(toJSONObject(list.get(i), null));
/*     */       }
/*     */     }
/*     */ 
/*  61 */     return jsonArray;
/*     */   }
/*     */ 
/*     */   public static JSONObject toJSONObject(JSONArray jsonArray, int possibleTotalCount)
/*     */   {
/*  77 */     JSONObject jsonObject = new JSONObject();
/*  78 */     put(jsonObject, "total", Integer.valueOf(possibleTotalCount));
/*  79 */     put(jsonObject, "data", jsonArray);
/*  80 */     return jsonObject;
/*     */   }
/*     */ 
/*     */   public static JSONObject toJSONObject(List list, String[] names, int possibleTotalCount)
/*     */   {
/*  99 */     JSONArray jsArray = toJSONArray(list, names);
/* 100 */     return toJSONObject(jsArray, possibleTotalCount);
/*     */   }
/*     */ 
/*     */   public static JSONObject toJSONObject(List list, String[] names)
/*     */   {
/* 115 */     return toJSONObject(list, names, list.size());
/*     */   }
/*     */ 
/*     */   public static JSONObject toJSONObject(List list, int possibleTotalCount)
/*     */   {
/* 131 */     JSONArray jsArray = toJSONArray(list, null);
/* 132 */     return toJSONObject(jsArray, possibleTotalCount);
/*     */   }
/*     */ 
/*     */   public static JSONObject toJSONObject(List list)
/*     */   {
/* 145 */     return toJSONObject(list, list.size());
/*     */   }
/*     */ 
/*     */   public static JSONObject toJSONObject(Object obj, String[] names)
/*     */   {
/* 160 */     if ((obj instanceof Map))
/*     */     {
/* 162 */       return mapToJsonObject((Map)obj, names);
/*     */     }
/* 164 */     if ((obj instanceof VariantSet))
/*     */     {
/* 166 */       return variantSetToJsonObject((VariantSet)obj, names);
/*     */     }
/*     */ 
/* 169 */     return objectToJsonObject(obj, names);
/*     */   }
/*     */ 
/*     */   public static JSONObject toJSONObject(Object obj)
/*     */   {
/* 182 */     return toJSONObject(obj, null);
/*     */   }
/*     */ 
/*     */   private static JSONObject objectToJsonObject(Object obj, String[] names)
/*     */   {
/* 195 */     JSONObject jsonObject = new JSONObject();
/* 196 */     if ((names != null) && (names.length != 0))
/*     */     {
/* 200 */       int i = 0; for (int len = names.length; i < len; i++) {
/*     */         try {
/* 202 */           Class propertyType = PropertyUtils.getPropertyType(obj, 
/* 203 */             names[i]);
/* 204 */           if (propertyType == null) {
/*     */             continue;
/*     */           }
/* 207 */           put(jsonObject, names[i], 
/* 208 */             BeanUtils.getProperty(obj, names[i]));
/*     */         } catch (Exception ex) {
/* 210 */           log.error(ex);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 217 */     return jsonObject;
/*     */   }
/*     */ 
/*     */   public static JSONObject variantSetToJsonObject(VariantSet variantSet, String[] names)
/*     */   {
/* 232 */     JSONObject jObject = new JSONObject();
/*     */ 
/* 234 */     if ((names == null) || (names.length == 0)) {
/* 235 */       int i = 0; for (int len = variantSet.count(); i < len; i++)
/* 236 */         put(jObject, variantSet.indexToName(i), variantSet.getValue(i));
/*     */     }
/*     */     else
/*     */     {
/* 240 */       int i = 0; for (int len = variantSet.count(); i < len; i++) {
/* 241 */         String key = variantSet.indexToName(i);
/* 242 */         if (isExists(names, key)) {
/* 243 */           put(jObject, key, variantSet.getValue(i));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 248 */     return jObject;
/*     */   }
/*     */ 
/*     */   public static JSONObject mapToJsonObject(Map map, String[] names)
/*     */   {
/* 262 */     JSONObject jObject = new JSONObject();
/*     */ 
/* 264 */     if ((names == null) || (names.length == 0)) {
/* 265 */       for (Iterator iterator = map.entrySet().iterator(); iterator
/* 266 */         .hasNext(); )
/*     */       {
/* 267 */         Map.Entry entry = (Map.Entry)iterator.next();
/*     */         try {
/* 269 */           jObject.put(entry.getKey().toString(), entry.getValue());
/*     */         } catch (JSONException ex) {
/* 271 */           log.error(ex);
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 276 */       for (Iterator iterator = map.entrySet().iterator(); iterator
/* 277 */         .hasNext(); )
/*     */       {
/* 278 */         Map.Entry entry = (Map.Entry)iterator.next();
/* 279 */         if (!isExists(names, entry.getKey().toString())) continue;
/*     */         try {
/* 281 */           jObject.put(entry.getKey().toString(), entry.getValue());
/*     */         } catch (JSONException ex) {
/* 283 */           log.error(ex);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 288 */     return jObject;
/*     */   }
/*     */ 
/*     */   private static boolean isExists(String[] names, String name)
/*     */   {
/* 300 */     boolean flag = false;
/* 301 */     int i = 0; for (int len = names.length; i < len; i++) {
/* 302 */       if (name.equals(names[i])) {
/* 303 */         flag = true;
/* 304 */         break;
/*     */       }
/*     */     }
/* 307 */     return flag;
/*     */   }
/*     */ 
/*     */   public static void put(JSONObject jsonObject, String key, Object value)
/*     */   {
/*     */     try
/*     */     {
/* 320 */       if (value == null)
/* 321 */         jsonObject.put(key, "");
/*     */       else
/* 323 */         jsonObject.put(key, value);
/*     */     }
/*     */     catch (JSONException ex)
/*     */     {
/* 327 */       log.error(ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.tools.JsonUtil
 * JD-Core Version:    0.6.0
 */