/*     */ package cn.newcapec.framework.utils.tools;
/*     */ 
/*     */ import cn.newcapec.foundation.utils.WebUtils;
/*     */ import com.sun.image.codec.jpeg.JPEGCodec;
/*     */ import com.sun.image.codec.jpeg.JPEGEncodeParam;
/*     */ import com.sun.image.codec.jpeg.JPEGImageEncoder;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.MediaTracker;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ConvolveOp;
/*     */ import java.awt.image.Kernel;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Iterator;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.imageio.ImageReadParam;
/*     */ import javax.imageio.ImageReader;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import javax.swing.ImageIcon;
/*     */ 
/*     */ public class ImageSizer
/*     */ {
/*  42 */   public static final MediaTracker tracker = new MediaTracker(new Component()
/*     */   {
/*     */     private static final long serialVersionUID = 1234162663955668507L;
/*     */   });
/*     */ 
/*     */   public static void resize(File originalFile, File resizedFile, int width, String format)
/*     */     throws IOException
/*     */   {
/*  53 */     if ((format != null) && ("gif".equals(format.toLowerCase()))) {
/*  54 */       resize(originalFile, resizedFile, width, 1.0F);
/*  55 */       return;
/*     */     }
/*  57 */     FileInputStream fis = new FileInputStream(originalFile);
/*  58 */     ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
/*  59 */     int readLength = -1;
/*  60 */     int bufferSize = 1024;
/*  61 */     byte[] bytes = new byte[bufferSize];
/*  62 */     while ((readLength = fis.read(bytes, 0, bufferSize)) != -1) {
/*  63 */       byteStream.write(bytes, 0, readLength);
/*     */     }
/*  65 */     byte[] in = byteStream.toByteArray();
/*  66 */     fis.close();
/*  67 */     byteStream.close();
/*     */ 
/*  69 */     Image inputImage = Toolkit.getDefaultToolkit().createImage(in);
/*  70 */     waitForImage(inputImage);
/*  71 */     int imageWidth = inputImage.getWidth(null);
/*  72 */     if (imageWidth < 1)
/*  73 */       throw new IllegalArgumentException("image width " + imageWidth + " is out of range");
/*  74 */     int imageHeight = inputImage.getHeight(null);
/*  75 */     if (imageHeight < 1) {
/*  76 */       throw new IllegalArgumentException("image height " + imageHeight + " is out of range");
/*     */     }
/*     */ 
/*  79 */     int height = -1;
/*  80 */     double scaleW = imageWidth / width;
/*  81 */     double scaleY = imageHeight / height;
/*  82 */     if ((scaleW >= 0.0D) && (scaleY >= 0.0D)) {
/*  83 */       if (scaleW > scaleY)
/*  84 */         height = -1;
/*     */       else {
/*  86 */         width = -1;
/*     */       }
/*     */     }
/*  89 */     Image outputImage = inputImage.getScaledInstance(width, height, 1);
/*  90 */     checkImage(outputImage);
/*  91 */     encode(new FileOutputStream(resizedFile), outputImage, format);
/*     */   }
/*     */ 
/*     */   private static void checkImage(Image image)
/*     */   {
/*  96 */     waitForImage(image);
/*  97 */     int imageWidth = image.getWidth(null);
/*  98 */     if (imageWidth < 1)
/*  99 */       throw new IllegalArgumentException("image width " + imageWidth + " is out of range");
/* 100 */     int imageHeight = image.getHeight(null);
/* 101 */     if (imageHeight < 1)
/* 102 */       throw new IllegalArgumentException("image height " + imageHeight + " is out of range");
/*     */   }
/*     */ 
/*     */   private static void waitForImage(Image image)
/*     */   {
/*     */     try {
/* 108 */       tracker.addImage(image, 0);
/* 109 */       tracker.waitForID(0);
/* 110 */       tracker.removeImage(image, 0); } catch (InterruptedException e) {
/* 111 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void encode(OutputStream outputStream, Image outputImage, String format) throws IOException
/*     */   {
/* 117 */     int outputWidth = outputImage.getWidth(null);
/* 118 */     if (outputWidth < 1)
/* 119 */       throw new IllegalArgumentException("output image width " + outputWidth + " is out of range");
/* 120 */     int outputHeight = outputImage.getHeight(null);
/* 121 */     if (outputHeight < 1) {
/* 122 */       throw new IllegalArgumentException("output image height " + outputHeight + " is out of range");
/*     */     }
/*     */ 
/* 125 */     BufferedImage bi = new BufferedImage(outputWidth, outputHeight, 
/* 126 */       1);
/* 127 */     Graphics2D biContext = bi.createGraphics();
/* 128 */     biContext.drawImage(outputImage, 0, 0, null);
/* 129 */     ImageIO.write(bi, format, outputStream);
/* 130 */     outputStream.flush();
/*     */   }
/*     */ 
/*     */   private static void resize(File originalFile, File resizedFile, int newWidth, float quality)
/*     */     throws IOException
/*     */   {
/* 142 */     if ((quality < 0.0F) || (quality > 1.0F)) {
/* 143 */       throw new IllegalArgumentException("Quality has to be between 0 and 1");
/*     */     }
/* 145 */     ImageIcon ii = new ImageIcon(originalFile.getCanonicalPath());
/* 146 */     Image i = ii.getImage();
/* 147 */     Image resizedImage = null;
/* 148 */     int iWidth = i.getWidth(null);
/* 149 */     int iHeight = i.getHeight(null);
/* 150 */     if (iWidth > iHeight)
/* 151 */       resizedImage = i.getScaledInstance(newWidth, newWidth * iHeight / iWidth, 4);
/*     */     else {
/* 153 */       resizedImage = i.getScaledInstance(newWidth * iWidth / iHeight, newWidth, 4);
/*     */     }
/*     */ 
/* 156 */     Image temp = new ImageIcon(resizedImage).getImage();
/*     */ 
/* 158 */     BufferedImage bufferedImage = new BufferedImage(temp.getWidth(null), temp.getHeight(null), 
/* 159 */       1);
/*     */ 
/* 161 */     Graphics g = bufferedImage.createGraphics();
/*     */ 
/* 163 */     g.setColor(Color.white);
/* 164 */     g.fillRect(0, 0, temp.getWidth(null), temp.getHeight(null));
/* 165 */     g.drawImage(temp, 0, 0, null);
/* 166 */     g.dispose();
/*     */ 
/* 168 */     float softenFactor = 0.05F;
/* 169 */     float[] softenArray = { 0.0F, softenFactor, 0.0F, softenFactor, 1.0F - softenFactor * 4.0F, softenFactor, 0.0F, softenFactor, 0.0F };
/* 170 */     Kernel kernel = new Kernel(3, 3, softenArray);
/* 171 */     ConvolveOp cOp = new ConvolveOp(kernel, 1, null);
/* 172 */     bufferedImage = cOp.filter(bufferedImage, null);
/*     */ 
/* 174 */     FileOutputStream out = new FileOutputStream(resizedFile);
/*     */ 
/* 176 */     JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
/* 177 */     JPEGEncodeParam param = encoder.getDefaultJPEGEncodeParam(bufferedImage);
/* 178 */     param.setQuality(quality, true);
/* 179 */     encoder.setJPEGEncodeParam(param);
/* 180 */     encoder.encode(bufferedImage);
/*     */   }
/*     */ 
/*     */   public static void cutImage(File originalFile, File resizedFile, int x1, int y1, int x2, int y2, int bigImgwidth, int bigImgHeight) throws IOException
/*     */   {
/* 185 */     FileInputStream is = null;
/* 186 */     ImageInputStream iis = null;
/*     */     try
/*     */     {
/* 190 */       is = new FileInputStream(originalFile);
/*     */ 
/* 197 */       Iterator it = ImageIO.getImageReadersByFormatName(WebUtils.getExt(originalFile.getName()));
/* 198 */       ImageReader reader = (ImageReader)it.next();
/*     */ 
/* 200 */       iis = ImageIO.createImageInputStream(is);
/*     */ 
/* 207 */       reader.setInput(iis, true);
/*     */ 
/* 215 */       ImageReadParam param = reader.getDefaultReadParam();
/* 216 */       int width = reader.getWidth(0);
/* 217 */       int height = reader.getHeight(0);
/*     */ 
/* 219 */       float scaleX = width * 1.0F / bigImgwidth;
/* 220 */       float scaleY = height * 1.0F / bigImgHeight;
/*     */ 
/* 225 */       Rectangle rect = new Rectangle(Math.round(x1 * scaleX), Math.round(y1 * scaleY), Math.round((x2 - x1) * scaleX), Math.round((y2 - y1) * scaleY));
/*     */ 
/* 229 */       param.setSourceRegion(rect);
/*     */ 
/* 235 */       BufferedImage bi = reader.read(0, param);
/*     */ 
/* 238 */       ImageIO.write(bi, "jpg", resizedFile);
/*     */     } finally {
/* 240 */       if (is != null)
/* 241 */         is.close();
/* 242 */       if (iis != null)
/* 243 */         iis.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.tools.ImageSizer
 * JD-Core Version:    0.6.0
 */