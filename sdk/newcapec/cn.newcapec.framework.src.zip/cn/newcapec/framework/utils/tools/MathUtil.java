/*     */ package cn.newcapec.framework.utils.tools;
/*     */ 
/*     */ import cn.newcapec.framework.base.exception.BaseException;
/*     */ import cn.newcapec.framework.base.log.LogEnabled;
/*     */ import java.io.PrintStream;
/*     */ import java.math.BigDecimal;
/*     */ import org.apache.commons.lang.math.NumberUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class MathUtil
/*     */   implements LogEnabled
/*     */ {
/*     */   private static final String STRING_ZERO = "0.00";
/*  20 */   public static final BigDecimal ZERO = new BigDecimal("0.00");
/*     */   private static final double MIN = 1.0E-007D;
/*     */   private static final int DFT_SCALE = 6;
/*     */ 
/*     */   public static boolean isZero(double d)
/*     */   {
/*  34 */     return Math.abs(d) <= 1.0E-007D;
/*     */   }
/*     */ 
/*     */   public static boolean isZero(float f)
/*     */   {
/*  45 */     return Math.abs(f) <= 1.0E-007D;
/*     */   }
/*     */ 
/*     */   public static boolean isZero(BigDecimal bd)
/*     */   {
/*  56 */     if (bd == null) {
/*  57 */       return true;
/*     */     }
/*     */ 
/*  60 */     return isZero(bd.doubleValue());
/*     */   }
/*     */ 
/*     */   public static boolean isZero(Integer bd)
/*     */   {
/*  71 */     if (bd == null) {
/*  72 */       return true;
/*     */     }
/*     */ 
/*  75 */     return isZero(bd.doubleValue());
/*     */   }
/*     */ 
/*     */   public static BigDecimal getBigDecimal(String s)
/*     */   {
/*  86 */     s = StringUtil.trim(s);
/*  87 */     if (s.length() < 1) {
/*  88 */       return ZERO;
/*     */     }
/*  90 */     return new BigDecimal(s);
/*     */   }
/*     */ 
/*     */   public static BigDecimal getBigDecimal(String s, int scale)
/*     */   {
/* 104 */     return getBigDecimal(getBigDecimal(s), scale);
/*     */   }
/*     */ 
/*     */   public static BigDecimal getBigDecimal(double d)
/*     */   {
/* 115 */     return new BigDecimal(d);
/*     */   }
/*     */ 
/*     */   public static BigDecimal getBigDecimal(double d, int scale)
/*     */   {
/* 128 */     if (scale == 0) {
/* 129 */       d = Math.round(d);
/* 130 */       BigDecimal bd = new BigDecimal(d);
/* 131 */       return bd.setScale(0);
/*     */     }
/* 133 */     BigDecimal bd = new BigDecimal(d);
/* 134 */     bd = bd.setScale(scale, 4);
/* 135 */     return bd;
/*     */   }
/*     */ 
/*     */   public static BigDecimal getBigDecimal(BigDecimal bd, int scale)
/*     */   {
/* 149 */     return getBigDecimal(doubleValue(bd), scale);
/*     */   }
/*     */ 
/*     */   public static String toString(BigDecimal bd)
/*     */   {
/* 160 */     if (bd == null) {
/* 161 */       return "0.00";
/*     */     }
/* 163 */     return bd.toString();
/*     */   }
/*     */ 
/*     */   public static boolean moreThan(BigDecimal bd1, BigDecimal bd2)
/*     */   {
/* 177 */     return moreThan(doubleValue(bd1), doubleValue(bd2));
/*     */   }
/*     */ 
/*     */   public static boolean moreThan(Integer bd1, Integer bd2)
/*     */   {
/* 190 */     return moreThan(doubleValue(bd1), doubleValue(bd2));
/*     */   }
/*     */ 
/*     */   public static boolean lessThan(Integer bd1, Integer bd2)
/*     */   {
/* 203 */     return lessThan(doubleValue(bd1), doubleValue(bd2));
/*     */   }
/*     */ 
/*     */   public static boolean moreThan(double d1, double d2)
/*     */   {
/* 216 */     double d = d1 - d2;
/*     */ 
/* 218 */     return (!isZero(d)) && (d >= 0.0D);
/*     */   }
/*     */ 
/*     */   public static boolean lessThan(BigDecimal bd1, BigDecimal bd2)
/*     */   {
/* 233 */     return lessThan(doubleValue(bd1), doubleValue(bd2));
/*     */   }
/*     */ 
/*     */   public static boolean lessThan(double d1, double d2)
/*     */   {
/* 246 */     double d = d1 - d2;
/*     */ 
/* 248 */     return (!isZero(d)) && (d <= 0.0D);
/*     */   }
/*     */ 
/*     */   public static boolean equals(BigDecimal bd1, BigDecimal bd2)
/*     */   {
/* 263 */     return isZero(doubleValue(bd1) - doubleValue(bd2));
/*     */   }
/*     */ 
/*     */   public static double doubleValue(BigDecimal bd)
/*     */   {
/* 274 */     if (bd == null) {
/* 275 */       return 0.0D;
/*     */     }
/* 277 */     return bd.doubleValue();
/*     */   }
/*     */ 
/*     */   public static double doubleValue(Integer bd)
/*     */   {
/* 288 */     if (bd == null) {
/* 289 */       return 0.0D;
/*     */     }
/* 291 */     return bd.doubleValue();
/*     */   }
/*     */ 
/*     */   public static BigDecimal add(BigDecimal bd1, BigDecimal bd2)
/*     */   {
/* 305 */     int scale = getScale(bd1, bd2);
/*     */ 
/* 307 */     return getBigDecimal(doubleValue(bd1) + doubleValue(bd2), scale);
/*     */   }
/*     */ 
/*     */   private static int getScale(BigDecimal bd1, BigDecimal bd2)
/*     */   {
/* 318 */     int scale1 = 0;
/* 319 */     int scale2 = 0;
/* 320 */     if (bd1 != null) {
/* 321 */       scale1 = bd1.scale();
/*     */     }
/*     */ 
/* 324 */     if (bd2 != null) {
/* 325 */       scale2 = bd2.scale();
/*     */     }
/*     */ 
/* 328 */     return scale1 > scale2 ? scale1 : scale2;
/*     */   }
/*     */ 
/*     */   public static BigDecimal add(BigDecimal bd1, double d)
/*     */   {
/* 341 */     return getBigDecimal(doubleValue(bd1) + d);
/*     */   }
/*     */ 
/*     */   public static BigDecimal add(double d1, double d2)
/*     */   {
/* 354 */     return getBigDecimal(d1 + d2);
/*     */   }
/*     */ 
/*     */   public static BigDecimal subtract(BigDecimal bd1, BigDecimal bd2)
/*     */   {
/* 367 */     int scale = getScale(bd1, bd2);
/*     */ 
/* 369 */     return getBigDecimal(doubleValue(bd1) - doubleValue(bd2), scale);
/*     */   }
/*     */ 
/*     */   public static BigDecimal subtract(BigDecimal bd1, double d)
/*     */   {
/* 382 */     return getBigDecimal(doubleValue(bd1) - d);
/*     */   }
/*     */ 
/*     */   public static BigDecimal subtract(double d1, double d2)
/*     */   {
/* 395 */     return getBigDecimal(d1 - d2);
/*     */   }
/*     */ 
/*     */   public static BigDecimal multiply(BigDecimal bd1, BigDecimal bd2)
/*     */   {
/* 408 */     if ((isZero(bd1)) || (isZero(bd2))) {
/* 409 */       return ZERO;
/*     */     }
/*     */ 
/* 412 */     return bd1.multiply(bd2);
/*     */   }
/*     */ 
/*     */   public static BigDecimal divide(BigDecimal bd1, BigDecimal bd2, int scale)
/*     */   {
/* 425 */     if (isZero(bd1)) {
/* 426 */       return ZERO;
/*     */     }
/*     */ 
/* 429 */     if (isZero(bd2)) {
/* 430 */       throw new BaseException("被除数为零");
/*     */     }
/*     */ 
/* 433 */     return bd1.divide(bd2, scale, 4);
/*     */   }
/*     */ 
/*     */   public static BigDecimal divide(BigDecimal bd1, BigDecimal bd2)
/*     */   {
/* 446 */     return divide(bd1, bd2, 6);
/*     */   }
/*     */ 
/*     */   public static Integer getInteger(String s)
/*     */   {
/*     */     try
/*     */     {
/* 458 */       return Integer.valueOf(s);
/*     */     } catch (Exception e) {
/* 460 */       log.warn("", e);
/* 461 */     }return new Integer(0);
/*     */   }
/*     */ 
/*     */   public static Integer add(Integer a, Integer b)
/*     */   {
/* 475 */     return new Integer(intValue(a) + intValue(b));
/*     */   }
/*     */ 
/*     */   public static Integer add(BigDecimal a, Integer b)
/*     */   {
/* 488 */     return new Integer(intValue(a) + intValue(b));
/*     */   }
/*     */ 
/*     */   public static Integer add(Integer a, BigDecimal b)
/*     */   {
/* 501 */     return new Integer(intValue(b) + intValue(a));
/*     */   }
/*     */ 
/*     */   public static int intValue(Integer a)
/*     */   {
/* 512 */     if (a == null) {
/* 513 */       return 0;
/*     */     }
/*     */ 
/* 516 */     return a.intValue();
/*     */   }
/*     */ 
/*     */   public static int intValue(BigDecimal a)
/*     */   {
/* 527 */     if (a == null) {
/* 528 */       return 0;
/*     */     }
/*     */ 
/* 531 */     return a.intValue();
/*     */   }
/*     */ 
/*     */   public static int roundUp(BigDecimal a)
/*     */   {
/* 542 */     if (isZero(a)) {
/* 543 */       return 0;
/*     */     }
/*     */ 
/* 546 */     int i = a.intValue();
/*     */ 
/* 548 */     double diff = a.doubleValue() - i;
/*     */ 
/* 550 */     if (isZero(diff)) {
/* 551 */       return i;
/*     */     }
/* 553 */     if (a.signum() > 0) {
/* 554 */       return i + 1;
/*     */     }
/* 556 */     return i - 1;
/*     */   }
/*     */ 
/*     */   public static int roundDown(BigDecimal a)
/*     */   {
/* 569 */     if (isZero(a)) {
/* 570 */       return 0;
/*     */     }
/* 572 */     int i = a.intValue();
/* 573 */     return i;
/*     */   }
/*     */ 
/*     */   public static double distanceByLngLat(double lng1, double lat1, double lng2, double lat2)
/*     */   {
/* 589 */     double radLat1 = lat1 * 3.141592653589793D / 180.0D;
/* 590 */     double radLat2 = lat2 * 3.141592653589793D / 180.0D;
/* 591 */     double a = radLat1 - radLat2;
/* 592 */     double b = lng1 * 3.141592653589793D / 180.0D - lng2 * 3.141592653589793D / 180.0D;
/* 593 */     double s = 2.0D * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2.0D), 2.0D) + Math.cos(radLat1) * 
/* 594 */       Math.cos(radLat2) * Math.pow(Math.sin(b / 2.0D), 2.0D)));
/* 595 */     s *= 6378137.0D;
/* 596 */     s = Math.round(s * 10000.0D) / 10000L;
/*     */ 
/* 598 */     return s;
/*     */   }
/*     */ 
/*     */   public static Bounds conversion(Double lat, Double lag, Integer r)
/*     */   {
/* 610 */     String l = String.valueOf(111000);
/* 611 */     String latx = new BigDecimal(String.valueOf(r)).divide(
/* 612 */       new BigDecimal(l), 6, 
/* 613 */       6).toString();
/* 614 */     String lagx = new BigDecimal(latx).divide(
/* 615 */       new BigDecimal(String.valueOf(Math.cos(lat.doubleValue()))), 
/* 616 */       6, 6).toString();
/* 617 */     Double latN = Double.valueOf(lat.doubleValue() + Math.abs(Double.valueOf(latx).doubleValue()));
/* 618 */     Double latS = Double.valueOf(lat.doubleValue() - Math.abs(Double.valueOf(latx).doubleValue()));
/* 619 */     Double lagE = Double.valueOf(lag.doubleValue() + Math.abs(Double.valueOf(lagx).doubleValue()));
/* 620 */     Double lagW = Double.valueOf(lag.doubleValue() - Math.abs(Double.valueOf(lagx).doubleValue()));
/* 621 */     Bounds bounds = new Bounds();
/* 622 */     bounds.setLagE(lagE);
/* 623 */     bounds.setLagW(lagW);
/* 624 */     bounds.setLatN(latN);
/* 625 */     bounds.setLatS(latS);
/* 626 */     return bounds;
/*     */   }
/*     */ 
/*     */   public static double converLat(double r)
/*     */   {
/* 640 */     String l = String.valueOf(111000);
/* 641 */     String latx = new BigDecimal(String.valueOf(r)).divide(
/* 642 */       new BigDecimal(l), 6, 
/* 643 */       6).toString();
/*     */ 
/* 645 */     double result = NumberUtils.toDouble(latx, 0.0D);
/* 646 */     return result;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/* 650 */     Bounds b = conversion(Double.valueOf(500.0D), Double.valueOf(500.0D), Integer.valueOf(1000000));
/* 651 */     System.out.println(b.getLagE());
/* 652 */     System.out.println(b.getLagW());
/* 653 */     System.out.println(b.getLatN());
/* 654 */     System.out.println(b.getLatS());
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.tools.MathUtil
 * JD-Core Version:    0.6.0
 */