/*     */ package cn.newcapec.framework.utils.tools;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.net.URL;
/*     */ 
/*     */ public class ClassLoaderUtils
/*     */ {
/*     */   public static URL getResource(String resourceName, Class callingClass)
/*     */   {
/*  36 */     URL url = Thread.currentThread().getContextClassLoader()
/*  37 */       .getResource(resourceName);
/*     */ 
/*  39 */     if (url == null) {
/*  40 */       url = ClassLoaderUtils.class.getClassLoader().getResource(
/*  41 */         resourceName);
/*     */     }
/*     */ 
/*  44 */     if (url == null) {
/*  45 */       ClassLoader cl = callingClass.getClassLoader();
/*     */ 
/*  47 */       if (cl != null) {
/*  48 */         url = cl.getResource(resourceName);
/*     */       }
/*     */     }
/*  51 */     if (url == null) {
/*  52 */       url = callingClass.getResource(resourceName);
/*     */     }
/*  54 */     if (url == null) {
/*  55 */       url = callingClass.getClass().getResource(resourceName);
/*     */     }
/*     */ 
/*  58 */     if ((url == null) && (resourceName != null) && 
/*  59 */       (resourceName.charAt(0) != '/')) {
/*  60 */       return getResource('/' + resourceName, callingClass);
/*     */     }
/*     */ 
/*  63 */     return url;
/*     */   }
/*     */ 
/*     */   public static InputStream getResourceAsStream(String resourceName, Class callingClass)
/*     */   {
/*  78 */     URL url = getResource(resourceName, callingClass);
/*     */     try
/*     */     {
/*  81 */       return url != null ? url.openStream() : null; } catch (IOException e) {
/*     */     }
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */   public static Class loadClass(String className, Class callingClass)
/*     */     throws ClassNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 108 */       return Thread.currentThread().getContextClassLoader()
/* 109 */         .loadClass(className);
/*     */     } catch (ClassNotFoundException e) {
/*     */       try {
/* 112 */         return Class.forName(className);
/*     */       } catch (ClassNotFoundException ex) {
/*     */         try {
/* 115 */           return ClassLoaderUtils.class.getClassLoader().loadClass(
/* 116 */             className); } catch (ClassNotFoundException exc) {
/*     */         }
/*     */       }
/*     */     }
/* 118 */     return callingClass.getClassLoader().loadClass(className);
/*     */   }
/*     */ 
/*     */   public static final Class parseType(String typeName)
/*     */     throws ClassNotFoundException
/*     */   {
/* 133 */     if (typeName.equals("boolean"))
/* 134 */       return Boolean.TYPE;
/* 135 */     if (typeName.equals("int"))
/* 136 */       return Byte.TYPE;
/* 137 */     if (typeName.equals("long"))
/* 138 */       return Byte.TYPE;
/* 139 */     if (typeName.equals("byte"))
/* 140 */       return Byte.TYPE;
/* 141 */     if (typeName.equals("short"))
/* 142 */       return Short.TYPE;
/* 143 */     if (typeName.equals("float"))
/* 144 */       return Byte.TYPE;
/* 145 */     if (typeName.equals("double"))
/* 146 */       return Byte.TYPE;
/* 147 */     return Class.forName(typeName);
/*     */   }
/*     */ 
/*     */   public static final Object newInstance(String clazzName)
/*     */     throws ClassNotFoundException, IllegalAccessException, InstantiationException
/*     */   {
/* 162 */     return Class.forName(clazzName).newInstance();
/*     */   }
/*     */ 
/*     */   public static final Object newInstance(Class clazzName)
/*     */     throws ClassNotFoundException, IllegalAccessException, InstantiationException
/*     */   {
/* 177 */     return clazzName.newInstance();
/*     */   }
/*     */ 
/*     */   public static final Object newInstance(String clazzName, Class[] paramsType, Object[] constrArgs)
/*     */     throws InvocationTargetException, IllegalArgumentException, IllegalAccessException, InstantiationException, SecurityException, NoSuchMethodException, ClassNotFoundException
/*     */   {
/* 200 */     return newInstance(Class.forName(clazzName), paramsType, constrArgs);
/*     */   }
/*     */ 
/*     */   public static final Object newInstance(Class clazzName, Class[] paramTypes, Object[] constrArgs)
/*     */     throws InvocationTargetException, IllegalArgumentException, IllegalAccessException, InstantiationException, SecurityException, NoSuchMethodException
/*     */   {
/* 221 */     return clazzName.getConstructor(paramTypes).newInstance(constrArgs);
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.tools.ClassLoaderUtils
 * JD-Core Version:    0.6.0
 */