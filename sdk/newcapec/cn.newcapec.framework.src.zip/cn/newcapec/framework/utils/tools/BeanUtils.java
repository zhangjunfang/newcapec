/*     */ package cn.newcapec.framework.utils.tools;
/*     */ 
/*     */ import cn.newcapec.framework.base.exception.BaseException;
/*     */ import cn.newcapec.framework.base.log.LogEnabled;
/*     */ import cn.newcapec.framework.utils.variant.DataType;
/*     */ import cn.newcapec.framework.utils.variant.VariantSet;
/*     */ import cn.newcapec.framework.utils.variant.VariantUtil;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.Clob;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class BeanUtils
/*     */   implements LogEnabled
/*     */ {
/*     */   public static void copyProperties(Object dest, Object orginal)
/*     */   {
/*     */     try
/*     */     {
/*  39 */       org.apache.commons.beanutils.BeanUtils.copyProperties(dest, orginal);
/*     */     } catch (Exception e) {
/*  41 */       log.warn("复制对象所有属性时出错", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static boolean isExists(String[] names, String name)
/*     */   {
/*  52 */     boolean flag = false;
/*  53 */     int i = 0; for (int len = names.length; i < len; i++) {
/*  54 */       if (name.equals(names[i])) {
/*  55 */         flag = true;
/*  56 */         break;
/*     */       }
/*     */     }
/*  59 */     return flag;
/*     */   }
/*     */ 
/*     */   public static void copyProperties(Object dest, Object orginal, String[] excepts)
/*     */   {
/*     */     try
/*     */     {
/*  76 */       PropertyDescriptor[] origDescriptors = 
/*  77 */         PropertyUtils.getPropertyDescriptors(orginal);
/*     */ 
/*  79 */       for (int i = 0; i < origDescriptors.length; i++) {
/*  80 */         String name = origDescriptors[i].getName();
/*     */ 
/*  82 */         if ("class".equals(name)) {
/*     */           continue;
/*     */         }
/*  85 */         if ((excepts != null) && (isExists(excepts, name))) {
/*     */           continue;
/*     */         }
/*  88 */         if ((!PropertyUtils.isReadable(orginal, name)) || 
/*  89 */           (!PropertyUtils.isWriteable(dest, name))) continue;
/*     */         try {
/*  91 */           Object value = PropertyUtils.getProperty(orginal, name);
/*     */ 
/*  93 */           copyProperty(dest, name, value);
/*     */         } catch (NoSuchMethodException e) {
/*  95 */           log.warn("复制对象属性时出错", e);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 102 */       log.warn("复制对象属性时出错", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void copySpecialProperties(Object dest, Object orginal, String[] properties)
/*     */   {
/* 118 */     if (properties == null) {
/* 119 */       throw new BaseException("复制对象属性时出错:传入的属性集合参数不能为空！");
/*     */     }
/* 121 */     for (int i = 0; i < properties.length; i++) {
/* 122 */       String name = properties[i];
/*     */       try {
/* 124 */         if ((!PropertyUtils.isReadable(orginal, name)) || 
/* 125 */           (!PropertyUtils.isWriteable(dest, name))) continue;
/* 126 */         Object value = getProperty(orginal, name);
/* 127 */         copyProperty(dest, name, value);
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 131 */         log.warn("复制对象属性时出错", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void copyProperty(Object bean, String name, Object value)
/*     */   {
/*     */     try
/*     */     {
/* 152 */       Class clazz = PropertyUtils.getPropertyType(bean, name);
/* 153 */       if (clazz == null) {
/* 154 */         return;
/*     */       }
/* 156 */       if ((value == null) || (clazz.equals(value.getClass()))) {
/* 157 */         PropertyUtils.setSimpleProperty(bean, name, value);
/* 158 */         return;
/*     */       }
/*     */ 
/* 161 */       PropertyUtils.setSimpleProperty(bean, name, 
/* 162 */         VariantUtil.translate(DataType.parse(clazz), value));
/*     */     }
/*     */     catch (Exception e) {
/* 165 */       log.warn("复制对象单个属性时出错", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object getProperty(Object o, String name)
/*     */   {
/* 179 */     Object val = null;
/*     */     try {
/* 181 */       val = PropertyUtils.getProperty(o, name);
/*     */     } catch (Exception e) {
/* 183 */       log.warn("使用BeanUtils.getPropertyValue获取对象某个属性值时出错", e);
/*     */     }
/*     */ 
/* 186 */     return val;
/*     */   }
/*     */ 
/*     */   public static Map describe(Object obj)
/*     */   {
/*     */     try
/*     */     {
/* 198 */       return org.apache.commons.beanutils.BeanUtils.describe(obj);
/*     */     } catch (Exception e) {
/* 200 */       log.warn("使用BeanUtils.Map获取对象描述时出错", e);
/* 201 */     }return null;
/*     */   }
/*     */ 
/*     */   public static Object callMethod(Object obj, String methodName, Class[] paramTypes, Object[] paramValues)
/*     */   {
/*     */     try
/*     */     {
/* 223 */       Method method = obj.getClass().getDeclaredMethod(methodName, 
/* 224 */         paramTypes);
/* 225 */       if (method != null)
/* 226 */         return method.invoke(obj, paramValues);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 230 */       log.warn("使用BeanUtils.callMethod调用方式对象时出错", e);
/*     */     }
/*     */ 
/* 233 */     return null;
/*     */   }
/*     */ 
/*     */   public static Object cloneBean(Object obj) {
/* 237 */     Object newObj = null;
/*     */     try {
/* 239 */       newObj = org.apache.commons.beanutils.BeanUtils.cloneBean(obj);
/*     */     } catch (Exception e) {
/* 241 */       log.warn("使用BeanUtils.cloneBean复制对象时出错", e);
/*     */     }
/* 243 */     return newObj;
/*     */   }
/*     */ 
/*     */   public static String getPOFieldName(String fldName)
/*     */   {
/* 255 */     String s = fldName.toLowerCase();
/* 256 */     StringBuffer strBuff = new StringBuffer();
/* 257 */     String findStr = "_";
/* 258 */     int i = 0;
/* 259 */     int len = s.length();
/* 260 */     while (i < len) {
/* 261 */       int j = s.indexOf(findStr, i);
/* 262 */       if (j >= 0) {
/* 263 */         strBuff = strBuff.append(s.substring(i, j));
/* 264 */         strBuff = strBuff
/* 265 */           .append(Character.toUpperCase(s.charAt(j + 1)));
/* 266 */         i = j + 2;
/*     */       }
/*     */       else {
/* 269 */         strBuff = strBuff.append(s.substring(i));
/* 270 */         break;
/*     */       }
/*     */     }
/* 272 */     return strBuff.toString();
/*     */   }
/*     */ 
/*     */   static void resultSetToBean(ResultSet resultSet, Object obj, boolean flag)
/*     */   {
/*     */     try
/*     */     {
/* 286 */       ResultSetMetaData resultMetaData = resultSet.getMetaData();
/* 287 */       int i = 1; for (int len = resultMetaData.getColumnCount(); i <= len; i++)
/*     */         try {
/* 289 */           Object value = resultSet.getObject(i);
/* 290 */           if ((value instanceof Clob)) {
/* 291 */             Clob clob = (Clob)value;
/* 292 */             value = clob != null ? clob.getSubString(1L, 
/* 293 */               (int)clob.length()) : 
/* 293 */               null;
/*     */           }
/* 295 */           else if ((value instanceof Timestamp)) {
/* 296 */             value = Integer.valueOf(((Timestamp)value).getNanos());
/*     */           }
/*     */ 
/* 299 */           String propertyName = resultMetaData.getColumnLabel(i);
/* 300 */           if (flag) {
/* 301 */             propertyName = getPOFieldName(propertyName);
/*     */           }
/* 303 */           Class propertyType = PropertyUtils.getPropertyType(obj, 
/* 304 */             propertyName);
/* 305 */           if (propertyType == null) {
/*     */             continue;
/*     */           }
/* 308 */           copyProperty(obj, propertyName, value);
/*     */         } catch (Exception ex) {
/* 310 */           log.error(ex);
/*     */         }
/*     */     }
/*     */     catch (Exception ex) {
/* 314 */       if ((ex instanceof BaseException)) {
/* 315 */         throw ((BaseException)ex);
/*     */       }
/* 317 */       throw new BaseException("转换result对象到类[" + obj.getClass().getName() + 
/* 318 */         "]出错！", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void resultSetToMap(ResultSet resultSet, Map obj, boolean flag)
/*     */   {
/*     */     try
/*     */     {
/* 336 */       ResultSetMetaData resultMetaData = resultSet.getMetaData();
/* 337 */       int i = 1; for (int len = resultMetaData.getColumnCount(); i <= len; i++)
/*     */         try {
/* 339 */           Object value = resultSet.getObject(i);
/* 340 */           if ((value instanceof Clob)) {
/* 341 */             Clob clob = (Clob)value;
/* 342 */             value = clob != null ? clob.getSubString(1L, 
/* 343 */               (int)clob.length()) : 
/* 343 */               null;
/*     */           }
/* 345 */           else if ((value instanceof Timestamp)) {
/* 346 */             value = Integer.valueOf(((Timestamp)value).getNanos());
/*     */           }
/*     */ 
/* 350 */           String name = resultMetaData.getColumnLabel(i);
/* 351 */           if (flag) {
/* 352 */             name = getPOFieldName(name);
/*     */           }
/*     */ 
/* 355 */           obj.put(name, value);
/*     */         }
/*     */         catch (Exception ex) {
/* 358 */           log.error(ex);
/*     */         }
/*     */     }
/*     */     catch (Exception ex) {
/* 362 */       if ((ex instanceof BaseException)) {
/* 363 */         throw ((BaseException)ex);
/*     */       }
/* 365 */       throw new BaseException("转换result对象到类[" + obj.getClass().getName() + 
/* 366 */         "]出错！", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object resultSetToDO(ResultSet resultSet, Class modelClass, boolean convertFieldName)
/*     */   {
/*     */     try
/*     */     {
/* 384 */       Object object = null;
/* 385 */       if (Map.class.isAssignableFrom(modelClass)) {
/* 386 */         object = new HashMap();
/* 387 */         resultSetToMap(resultSet, (Map)object, convertFieldName);
/* 388 */         return object;
/*     */       }
/* 390 */       if (VariantSet.class.isAssignableFrom(modelClass)) {
/* 391 */         object = new Record();
/* 392 */         resultSetToVariantSet(resultSet, (VariantSet)object, 
/* 393 */           convertFieldName);
/* 394 */         return object;
/*     */       }
/* 396 */       object = ClassLoaderUtils.newInstance(modelClass);
/* 397 */       resultSetToBean(resultSet, object, convertFieldName);
/* 398 */       return object;
/*     */     } catch (Exception ex) {
/* 400 */       if ((ex instanceof BaseException)) {
/* 401 */         throw ((BaseException)ex);
/*     */       }
/*     */     }
/* 404 */     throw new BaseException("转换result对象到类[" + modelClass.getName() + 
/* 405 */       "]出错！", ex);
/*     */   }
/*     */ 
/*     */   static void resultSetToVariantSet(ResultSet resultSet, VariantSet variantSet, boolean flag)
/*     */   {
/*     */     try
/*     */     {
/* 423 */       ResultSetMetaData resultMetaData = resultSet.getMetaData();
/* 424 */       int i = 1; for (int len = resultMetaData.getColumnCount(); i <= len; i++)
/*     */         try {
/* 426 */           Object value = resultSet.getObject(i);
/* 427 */           if ((value instanceof Clob)) {
/* 428 */             Clob clob = (Clob)value;
/* 429 */             value = clob != null ? clob.getSubString(1L, 
/* 430 */               (int)clob.length()) : 
/* 430 */               null;
/*     */           }
/* 432 */           else if ((value instanceof Timestamp)) {
/* 433 */             value = Integer.valueOf(((Timestamp)value).getNanos());
/*     */           }
/*     */ 
/* 437 */           String name = resultMetaData.getColumnLabel(i);
/* 438 */           if (flag) {
/* 439 */             name = getPOFieldName(name);
/*     */           }
/*     */ 
/* 442 */           variantSet.setValue(name, value);
/*     */         }
/*     */         catch (Exception ex) {
/* 445 */           log.error(ex);
/*     */         }
/*     */     }
/*     */     catch (Exception ex) {
/* 449 */       if ((ex instanceof BaseException)) {
/* 450 */         throw ((BaseException)ex);
/*     */       }
/* 452 */       throw new BaseException("转换result对象到类[" + 
/* 453 */         variantSet.getClass().getName() + "]出错！", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static <T> T map2Bean(Map<String, String> map, Class<T> class1)
/*     */   {
/* 466 */     Object bean = null;
/*     */     try {
/* 468 */       bean = class1.newInstance();
/* 469 */       org.apache.commons.beanutils.BeanUtils.populate(bean, map);
/*     */     } catch (InstantiationException e) {
/* 471 */       e.printStackTrace();
/*     */     } catch (IllegalAccessException e) {
/* 473 */       e.printStackTrace();
/*     */     } catch (InvocationTargetException e) {
/* 475 */       e.printStackTrace();
/*     */     }
/* 477 */     return bean;
/*     */   }
/*     */ 
/*     */   public static void copyProperties(Map mapData, Object obj)
/*     */   {
/* 490 */     if ((mapData == null) || (obj == null)) {
/* 491 */       return;
/*     */     }
/*     */ 
/* 494 */     Iterator names = mapData.keySet().iterator();
/* 495 */     while (names.hasNext())
/*     */     {
/* 497 */       String name = (String)names.next();
/* 498 */       if (name == null) {
/*     */         continue;
/*     */       }
/* 501 */       Object value = mapData.get(name);
/*     */       try {
/* 503 */         org.apache.commons.beanutils.BeanUtils.setProperty(obj, name, 
/* 504 */           value);
/*     */       } catch (IllegalAccessException e) {
/* 506 */         e.printStackTrace();
/*     */       } catch (InvocationTargetException e) {
/* 508 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.tools.BeanUtils
 * JD-Core Version:    0.6.0
 */