/*     */ package cn.newcapec.framework.utils.tools;
/*     */ 
/*     */ import cn.newcapec.framework.base.log.LogEnabled;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class DateUtil
/*     */   implements LogEnabled
/*     */ {
/*     */   private static final long ONE_DAY = 86400000L;
/*     */   private static final long ONE_MINUTE = 60000L;
/*  23 */   private static String datePattern = "yyyy-MM-dd";
/*     */ 
/*  25 */   private static String timePattern = "HH:mm:ss";
/*     */ 
/*  27 */   private static SimpleDateFormat dateFormat = new SimpleDateFormat(
/*  28 */     datePattern);
/*     */ 
/*  30 */   private static SimpleDateFormat datetimeFormat = new SimpleDateFormat(
/*  31 */     datePattern + " " + timePattern);
/*     */ 
/*     */   public static String toDateString(Date date)
/*     */   {
/*  41 */     if (date == null) {
/*  42 */       return null;
/*     */     }
/*  44 */     return dateFormat.format(date);
/*     */   }
/*     */ 
/*     */   public static Date toDate(String s)
/*     */   {
/*  55 */     s = StringUtils.trim(s);
/*  56 */     if (s.length() < 1)
/*  57 */       return null;
/*     */     try
/*     */     {
/*  60 */       if (s.length() <= 10) {
/*  61 */         return dateFormat.parse(s);
/*     */       }
/*  63 */       return toDate(Timestamp.valueOf(s));
/*     */     } catch (Exception e) {
/*  65 */       log.warn("解析字符串成日期对象时出错", e);
/*  66 */     }return null;
/*     */   }
/*     */ 
/*     */   public static String toDatetimeString(Date date)
/*     */   {
/*  78 */     if (date == null) {
/*  79 */       return null;
/*     */     }
/*  81 */     return datetimeFormat.format(date);
/*     */   }
/*     */ 
/*     */   public static Date toDatetime(String date)
/*     */   {
/*  92 */     if (date == null)
/*  93 */       return null;
/*     */     try
/*     */     {
/*  96 */       return datetimeFormat.parse(date);
/*     */     }
/*     */     catch (ParseException e) {
/*  99 */       e.printStackTrace();
/* 100 */     }return null;
/*     */   }
/*     */ 
/*     */   public static int computeWeek(Date startDate, Date endDate)
/*     */   {
/* 116 */     int weeks = 0;
/*     */ 
/* 118 */     Calendar beginCalendar = Calendar.getInstance();
/* 119 */     beginCalendar.setTime(startDate);
/*     */ 
/* 121 */     Calendar endCalendar = Calendar.getInstance();
/* 122 */     endCalendar.setTime(endDate);
/*     */ 
/* 124 */     while (beginCalendar.before(endCalendar))
/*     */     {
/* 127 */       if ((beginCalendar.get(1) == endCalendar
/* 128 */         .get(1)) && 
/* 129 */         (beginCalendar.get(2) == endCalendar
/* 130 */         .get(2)) && 
/* 131 */         (beginCalendar.get(8) == endCalendar
/* 132 */         .get(8)))
/*     */       {
/*     */         break;
/*     */       }
/*     */ 
/* 137 */       beginCalendar.add(6, 7);
/* 138 */       weeks++;
/*     */     }
/*     */ 
/* 142 */     return weeks;
/*     */   }
/*     */ 
/*     */   public static String getCurrDateTime()
/*     */   {
/* 151 */     return toDatetimeString(new Date());
/*     */   }
/*     */ 
/*     */   public static String getCurrDate()
/*     */   {
/* 161 */     return toDateString(new Date());
/*     */   }
/*     */ 
/*     */   public static Date toDate(Timestamp timestamp)
/*     */   {
/* 173 */     if (timestamp == null) {
/* 174 */       return null;
/*     */     }
/* 176 */     return new Date(timestamp.getTime());
/*     */   }
/*     */ 
/*     */   public static Timestamp toTimestamp(Date date)
/*     */   {
/* 187 */     if (date == null) {
/* 188 */       return null;
/*     */     }
/*     */ 
/* 191 */     return new Timestamp(date.getTime());
/*     */   }
/*     */ 
/*     */   public static String toDateString(Timestamp t)
/*     */   {
/* 202 */     if (t == null) {
/* 203 */       return null;
/*     */     }
/* 205 */     return toDateString(toDate(t));
/*     */   }
/*     */ 
/*     */   public static String toDatetimeString(Timestamp t)
/*     */   {
/* 216 */     if (t == null) {
/* 217 */       return null;
/*     */     }
/* 219 */     return toDatetimeString(toDate(t));
/*     */   }
/*     */ 
/*     */   public static Timestamp toTimestamp(String s)
/*     */   {
/* 231 */     return toTimestamp(toDate(s));
/*     */   }
/*     */ 
/*     */   public static int getYear(Date d)
/*     */   {
/* 239 */     Calendar c = Calendar.getInstance();
/* 240 */     c.setTime(d);
/* 241 */     return c.get(1);
/*     */   }
/*     */ 
/*     */   public static int getYear() {
/* 245 */     return getYear(new Date());
/*     */   }
/*     */ 
/*     */   public static int getMonth(Date d)
/*     */   {
/* 252 */     Calendar c = Calendar.getInstance();
/* 253 */     c.setTime(d);
/* 254 */     return c.get(2) + 1;
/*     */   }
/*     */ 
/*     */   public static int getMonth() {
/* 258 */     return getMonth(new Date());
/*     */   }
/*     */ 
/*     */   public static final int getQuarter(Date d)
/*     */   {
/* 269 */     return getQuarter(getMonth(d));
/*     */   }
/*     */ 
/*     */   public static final int getQuarter()
/*     */   {
/* 278 */     return getQuarter(getMonth());
/*     */   }
/*     */ 
/*     */   public static final int getQuarter(int num)
/*     */   {
/* 288 */     num = num % 3 == 0 ? num / 3 : num / 3 + 1;
/* 289 */     return num % 4 == 0 ? 4 : num % 4;
/*     */   }
/*     */ 
/*     */   public static int getDay(Date d)
/*     */   {
/* 297 */     Calendar c = Calendar.getInstance();
/* 298 */     c.setTime(d);
/* 299 */     return c.get(5);
/*     */   }
/*     */ 
/*     */   public static Date getFutureDate(Date currDate, long timeDiffInMillis)
/*     */   {
/* 312 */     long l = currDate.getTime();
/*     */ 
/* 314 */     l += timeDiffInMillis;
/* 315 */     return new Date(l);
/*     */   }
/*     */ 
/*     */   public static Date getFutureDate(String currDate, long timeDiffInMillis)
/*     */   {
/* 328 */     return getFutureDate(toDate(currDate), timeDiffInMillis);
/*     */   }
/*     */ 
/*     */   public static Date getFutureDate(Date currDate, int days)
/*     */   {
/* 341 */     long l = currDate.getTime();
/* 342 */     long l1 = days * 86400000L;
/*     */ 
/* 344 */     l += l1;
/* 345 */     return new Date(l);
/*     */   }
/*     */ 
/*     */   public static Date getFutureDate(String currDate, int days)
/*     */   {
/* 358 */     return getFutureDate(toDate(currDate), days);
/*     */   }
/*     */ 
/*     */   public static boolean isDateInRange(String currDate, String[] dateRange)
/*     */   {
/* 371 */     if ((currDate == null) || (dateRange == null) || (dateRange.length < 2)) {
/* 372 */       throw new IllegalArgumentException("传入参数非法");
/*     */     }
/*     */ 
/* 375 */     currDate = getDatePart(currDate);
/*     */ 
/* 377 */     return (currDate.compareTo(dateRange[0]) >= 0) && 
/* 377 */       (currDate
/* 377 */       .compareTo(dateRange[1]) <= 0);
/*     */   }
/*     */ 
/*     */   public static String getDatePart(String currDate)
/*     */   {
/* 388 */     if ((currDate != null) && (currDate.length() > 10)) {
/* 389 */       return currDate.substring(0, 10);
/*     */     }
/*     */ 
/* 392 */     return currDate;
/*     */   }
/*     */ 
/*     */   public static int getDateDiff(String stopDate, String startDate)
/*     */   {
/* 405 */     long t2 = toDate(stopDate).getTime();
/* 406 */     long t1 = toDate(startDate).getTime();
/*     */ 
/* 408 */     int diff = (int)((t2 - t1) / 86400000L);
/*     */ 
/* 410 */     diff += (t2 > t1 + diff * 86400000L ? 1 : 0);
/* 411 */     return diff;
/*     */   }
/*     */ 
/*     */   public static int getMinutesDiff(String stopDate, String startDate)
/*     */   {
/* 424 */     long t2 = toDate(stopDate).getTime();
/* 425 */     long t1 = toDate(startDate).getTime();
/*     */ 
/* 427 */     int diff = (int)((t2 - t1) / 60000L);
/*     */ 
/* 429 */     diff += (t2 > t1 + diff * 60000L ? 1 : 0);
/* 430 */     return diff;
/*     */   }
/*     */ 
/*     */   public static boolean isSameWeekDates(Date date1, Date date2)
/*     */   {
/* 437 */     Calendar cal1 = Calendar.getInstance();
/* 438 */     Calendar cal2 = Calendar.getInstance();
/* 439 */     cal1.setFirstDayOfWeek(2);
/* 440 */     cal2.setFirstDayOfWeek(2);
/* 441 */     cal1.setTime(date1);
/* 442 */     cal2.setTime(date2);
/* 443 */     int subYear = cal1.get(1) - cal2.get(1);
/* 444 */     if (subYear == 0) {
/* 445 */       if (cal1.get(3) == cal2
/* 446 */         .get(3))
/* 447 */         return true;
/* 448 */     } else if ((1 == subYear) && (11 == cal2.get(2)))
/*     */     {
/* 450 */       if (cal1.get(3) == cal2
/* 451 */         .get(3))
/* 452 */         return true;
/* 453 */     } else if ((-1 == subYear) && (11 == cal1.get(2)) && 
/* 454 */       (cal1.get(3) == cal2
/* 455 */       .get(3))) {
/* 456 */       return true;
/*     */     }
/* 458 */     return false;
/*     */   }
/*     */ 
/*     */   public static int getSeqWeekByYear(Date currDate)
/*     */   {
/* 469 */     Calendar c = Calendar.getInstance();
/* 470 */     c.setTime(currDate);
/* 471 */     c.setFirstDayOfWeek(2);
/* 472 */     int weekNo = c.get(3);
/*     */ 
/* 474 */     Calendar lastDate = Calendar.getInstance();
/*     */ 
/* 476 */     if (weekNo == 1)
/*     */     {
/* 478 */       lastDate.setTime(toDate(getFriday(c.getTime())));
/* 479 */       if (c.get(1) != lastDate.get(1)) {
/* 480 */         lastDate.setTime(toDate(getMonday(c.getTime())));
/* 481 */         lastDate.add(5, -1);
/* 482 */         lastDate.setFirstDayOfWeek(2);
/* 483 */         weekNo = lastDate.get(3) + 1;
/*     */       }
/*     */     }
/* 486 */     return weekNo;
/*     */   }
/*     */ 
/*     */   public static int getSeqWeekByMonth(Date currDate)
/*     */   {
/* 497 */     Calendar c = Calendar.getInstance();
/* 498 */     c.setTime(currDate);
/* 499 */     c.setFirstDayOfWeek(2);
/*     */ 
/* 501 */     return c.get(4);
/*     */   }
/*     */ 
/*     */   public static String getMonday(Date date)
/*     */   {
/* 512 */     Calendar c = Calendar.getInstance();
/* 513 */     c.setTime(date);
/* 514 */     c.set(7, 2);
/* 515 */     return new SimpleDateFormat("yyyy-MM-dd").format(c.getTime());
/*     */   }
/*     */ 
/*     */   public static String getMonday(String date)
/*     */   {
/* 525 */     Calendar c = Calendar.getInstance();
/* 526 */     c.setTime(toDate(date));
/* 527 */     c.set(7, 2);
/* 528 */     return new SimpleDateFormat("yyyy-MM-dd").format(c.getTime());
/*     */   }
/*     */ 
/*     */   public static String getFriday(Date date)
/*     */   {
/* 534 */     Calendar c = Calendar.getInstance();
/* 535 */     c.setTime(date);
/* 536 */     c.set(7, 6);
/* 537 */     return new SimpleDateFormat("yyyy-MM-dd").format(c.getTime());
/*     */   }
/*     */ 
/*     */   public static String afterNDay(int n)
/*     */   {
/* 542 */     Calendar c = Calendar.getInstance();
/* 543 */     DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
/* 544 */     c.setTime(new Date());
/* 545 */     c.add(5, n);
/* 546 */     Date d2 = c.getTime();
/* 547 */     String s = df.format(d2);
/* 548 */     return s;
/*     */   }
/*     */ 
/*     */   public static boolean isLeapYear(int yearNum)
/*     */   {
/* 558 */     boolean isLeep = false;
/*     */ 
/* 560 */     if ((yearNum % 4 == 0) && (yearNum % 100 != 0))
/* 561 */       isLeep = true;
/* 562 */     else if (yearNum % 400 == 0)
/* 563 */       isLeep = true;
/*     */     else {
/* 565 */       isLeep = false;
/*     */     }
/* 567 */     return isLeep;
/*     */   }
/*     */ 
/*     */   public static String getYearWeekFirstDay(int yearNum, int weekNum)
/*     */   {
/* 578 */     Calendar cal = Calendar.getInstance();
/* 579 */     cal.setFirstDayOfWeek(2);
/* 580 */     cal.set(1, yearNum);
/* 581 */     cal.set(3, weekNum);
/* 582 */     cal.set(7, 2);
/*     */ 
/* 584 */     String tempYear = Integer.toString(yearNum);
/* 585 */     String tempMonth = Integer.toString(cal.get(2) + 1);
/* 586 */     String tempDay = Integer.toString(cal.get(5));
/* 587 */     String tempDate = tempYear + "-" + tempMonth + "-" + tempDay;
/* 588 */     return SetDateFormat(tempDate, "yyyy-MM-dd");
/*     */   }
/*     */ 
/*     */   public static String SetDateFormat(String myDate, String strFormat)
/*     */   {
/*     */     try
/*     */     {
/* 599 */       SimpleDateFormat sdf = new SimpleDateFormat(strFormat);
/* 600 */       String sDate = sdf.format(sdf.parse(myDate));
/* 601 */       return sDate; } catch (Exception e) {
/*     */     }
/* 603 */     return null;
/*     */   }
/*     */ 
/*     */   public String getYearWeekEndDay(int yearNum, int weekNum)
/*     */   {
/* 615 */     Calendar cal = Calendar.getInstance();
/* 616 */     cal.set(1, yearNum);
/* 617 */     cal.set(3, weekNum + 1);
/* 618 */     cal.set(7, 1);
/*     */ 
/* 620 */     String tempYear = Integer.toString(yearNum);
/* 621 */     String tempMonth = Integer.toString(cal.get(2) + 1);
/* 622 */     String tempDay = Integer.toString(cal.get(5));
/* 623 */     String tempDate = tempYear + "-" + tempMonth + "-" + tempDay;
/* 624 */     return SetDateFormat(tempDate, "yyyy-MM-dd");
/*     */   }
/*     */ 
/*     */   public String getYearMonthFirstDay(int yearNum, int monthNum)
/*     */   {
/* 636 */     String tempYear = Integer.toString(yearNum);
/* 637 */     String tempMonth = Integer.toString(monthNum);
/* 638 */     String tempDay = "1";
/* 639 */     String tempDate = tempYear + "-" + tempMonth + "-" + tempDay;
/* 640 */     return SetDateFormat(tempDate, "yyyy-MM-dd");
/*     */   }
/*     */ 
/*     */   public static String getYearMonthEndDay(int yearNum, int monthNum)
/*     */   {
/* 652 */     String tempYear = Integer.toString(yearNum);
/* 653 */     String tempMonth = Integer.toString(monthNum);
/* 654 */     String tempDay = "31";
/* 655 */     if ((tempMonth.equals("1")) || (tempMonth.equals("3")) || 
/* 656 */       (tempMonth.equals("5")) || (tempMonth.equals("7")) || 
/* 657 */       (tempMonth.equals("8")) || (tempMonth.equals("10")) || 
/* 658 */       (tempMonth.equals("12"))) {
/* 659 */       tempDay = "31";
/*     */     }
/* 661 */     if ((tempMonth.equals("4")) || (tempMonth.equals("6")) || 
/* 662 */       (tempMonth.equals("9")) || (tempMonth.equals("11"))) {
/* 663 */       tempDay = "30";
/*     */     }
/* 665 */     if (tempMonth.equals("2")) {
/* 666 */       if (isLeapYear(yearNum))
/* 667 */         tempDay = "29";
/*     */       else {
/* 669 */         tempDay = "28";
/*     */       }
/*     */     }
/*     */ 
/* 673 */     String tempDate = tempYear + "-" + tempMonth + "-" + tempDay;
/* 674 */     return tempDate;
/*     */   }
/*     */ 
/*     */   public static Date getRelativeDate(Date date, char flag, int intervals)
/*     */   {
/* 687 */     Date currDate = null;
/* 688 */     if (date != null)
/*     */     {
/*     */       Calendar newDate;
/* 690 */       (newDate = Calendar.getInstance()).setTime(date);
/* 691 */       switch (flag) {
/*     */       case 'y':
/* 693 */         newDate.add(1, intervals);
/* 694 */         break;
/*     */       case 'M':
/* 696 */         newDate.add(2, intervals);
/* 697 */         break;
/*     */       case 'd':
/* 699 */         newDate.add(5, intervals);
/* 700 */         break;
/*     */       case 'w':
/* 702 */         newDate.add(3, intervals);
/* 703 */         break;
/*     */       case 'h':
/* 705 */         newDate.add(10, intervals);
/* 706 */         break;
/*     */       case 'm':
/* 708 */         newDate.add(12, intervals);
/* 709 */         break;
/*     */       case 's':
/* 711 */         newDate.add(13, intervals);
/* 712 */         break;
/*     */       case 'S':
/* 714 */         newDate.add(14, intervals);
/*     */       }
/* 716 */       currDate = newDate.getTime();
/*     */     }
/* 718 */     return currDate;
/*     */   }
/*     */ 
/*     */   public static Date getCurrDay()
/*     */   {
/* 727 */     return new Date();
/*     */   }
/*     */ 
/*     */   public static String getAfterWeekFirst()
/*     */   {
/* 734 */     return getMonday(afterNDay(7));
/*     */   }
/*     */ 
/*     */   public static String getAfterMonthFirst(String date, int afterNum)
/*     */   {
/* 743 */     Calendar cal = new GregorianCalendar();
/* 744 */     cal.setTime(toDate(date));
/* 745 */     cal.add(2, afterNum);
/* 746 */     cal.set(5, 1);
/* 747 */     return dateFormat.format(cal.getTime());
/*     */   }
/*     */ 
/*     */   public static String getSundayOfWeek(String date)
/*     */   {
/* 756 */     Calendar cal = new GregorianCalendar();
/* 757 */     cal.setFirstDayOfWeek(2);
/* 758 */     cal.setTime(toDate(date));
/* 759 */     cal.set(7, cal.getFirstDayOfWeek() + 6);
/* 760 */     return dateFormat.format(cal.getTime());
/*     */   }
/*     */ 
/*     */   public static String getAfterQuarterFirst(String date, int afterNum)
/*     */   {
/* 769 */     Calendar cal = new GregorianCalendar();
/* 770 */     cal.setTime(toDate(date));
/* 771 */     int currentMonth = cal.get(2) + 1;
/* 772 */     cal.set(5, 1);
/* 773 */     if ((currentMonth >= 1) && (currentMonth <= 3))
/* 774 */       cal.set(2, 0);
/* 775 */     else if ((currentMonth >= 4) && (currentMonth <= 6))
/* 776 */       cal.set(2, 3);
/* 777 */     else if ((currentMonth >= 7) && (currentMonth <= 9))
/* 778 */       cal.set(2, 6);
/* 779 */     else if ((currentMonth >= 10) && (currentMonth <= 12))
/* 780 */       cal.set(2, 9);
/* 781 */     cal.add(2, afterNum * 3);
/* 782 */     return dateFormat.format(cal.getTime());
/*     */   }
/*     */   public static void main(String[] args) {
/* 785 */     System.out.println(getAfterWeekFirst());
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.tools.DateUtil
 * JD-Core Version:    0.6.0
 */