/*     */ package cn.newcapec.framework.utils.tools;
/*     */ 
/*     */ class Bounds
/*     */ {
/*     */   private Double latN;
/*     */   private Double latS;
/*     */   private Double lagE;
/*     */   private Double lagW;
/*     */ 
/*     */   public Double getLatN()
/*     */   {
/* 677 */     return this.latN;
/*     */   }
/*     */   public void setLatN(Double latN) {
/* 680 */     this.latN = latN;
/*     */   }
/*     */   public Double getLatS() {
/* 683 */     return this.latS;
/*     */   }
/*     */   public void setLatS(Double latS) {
/* 686 */     this.latS = latS;
/*     */   }
/*     */   public Double getLagE() {
/* 689 */     return this.lagE;
/*     */   }
/*     */   public void setLagE(Double lagE) {
/* 692 */     this.lagE = lagE;
/*     */   }
/*     */   public Double getLagW() {
/* 695 */     return this.lagW;
/*     */   }
/*     */   public void setLagW(Double lagW) {
/* 698 */     this.lagW = lagW;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.tools.Bounds
 * JD-Core Version:    0.6.0
 */