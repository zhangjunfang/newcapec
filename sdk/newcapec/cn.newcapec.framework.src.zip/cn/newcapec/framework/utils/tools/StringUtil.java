/*     */ package cn.newcapec.framework.utils.tools;
/*     */ 
/*     */ import cn.newcapec.framework.base.exception.BaseException;
/*     */ import cn.newcapec.framework.base.log.LogEnabled;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class StringUtil
/*     */   implements LogEnabled
/*     */ {
/*     */   public static boolean isEmpty(String string)
/*     */   {
/*  27 */     return string == null;
/*     */   }
/*     */ 
/*     */   public static boolean isNotNull(Object obj)
/*     */   {
/*  36 */     if ((obj == null) || ("null".equals(obj.toString()))) {
/*  37 */       return false;
/*     */     }
/*  39 */     return !isEmpty(obj.toString());
/*     */   }
/*     */ 
/*     */   public static String replace(String oldStr, String findStr, String replStr)
/*     */   {
/*  55 */     return repl(oldStr, findStr, replStr, 0);
/*     */   }
/*     */ 
/*     */   public static String replace(String oldStr, String findStr, String replStr, int times)
/*     */   {
/*  73 */     return repl(oldStr, findStr, replStr, times);
/*     */   }
/*     */ 
/*     */   private static boolean isValid(String oldStr, String findStr, String replStr)
/*     */   {
/*  81 */     return (oldStr != null) && (oldStr.length() >= 1) && (findStr != null) && 
/*  79 */       (findStr.length() >= 1) && (replStr != null) && 
/*  80 */       (!findStr.equals(replStr));
/*     */   }
/*     */ 
/*     */   private static String repl(String oldStr, String findStr, String replStr, int times)
/*     */   {
/*  94 */     if (!isValid(oldStr, findStr, replStr)) {
/*  95 */       return oldStr;
/*     */     }
/*  97 */     StringBuffer strBuff = new StringBuffer();
/*     */ 
/*  99 */     if (times < 1) {
/* 100 */       if ((findStr.length() == 1) && (replStr.length() == 1)) {
/* 101 */         return oldStr.replace(findStr.charAt(0), replStr.charAt(0));
/*     */       }
/* 103 */       int i = 0; for (int len = oldStr.length(); i < len; ) {
/* 104 */         int j = oldStr.indexOf(findStr, i);
/*     */ 
/* 106 */         if (j >= 0) {
/* 107 */           strBuff = strBuff.append(oldStr.substring(i, j));
/* 108 */           strBuff = strBuff.append(replStr);
/* 109 */           i = j + findStr.length();
/*     */         } else {
/* 111 */           strBuff = strBuff.append(oldStr.substring(i));
/* 112 */           break;
/*     */         }
/*     */       }
/* 115 */       return new String(strBuff);
/*     */     }
/*     */ 
/* 118 */     int i = 0;
/* 119 */     int len = oldStr.length();
/*     */ 
/* 121 */     for (int k = 0; (i < len) && (k < times); ) {
/* 122 */       int j = oldStr.indexOf(findStr, i);
/*     */ 
/* 124 */       if (j >= 0) {
/* 125 */         strBuff = strBuff.append(oldStr.substring(i, j));
/* 126 */         strBuff = strBuff.append(replStr);
/* 127 */         i = j + findStr.length();
/* 128 */         k++;
/*     */       } else {
/* 130 */         strBuff = strBuff.append(oldStr.substring(i));
/* 131 */         i = len;
/*     */       }
/*     */     }
/*     */ 
/* 135 */     if (i < len) {
/* 136 */       strBuff = strBuff.append(oldStr.substring(i));
/*     */     }
/*     */ 
/* 139 */     return new String(strBuff);
/*     */   }
/*     */ 
/*     */   public static String deleteString(String oldStr, String beginStr, String endStr, int times)
/*     */   {
/* 163 */     if (times < 1) {
/* 164 */       return oldStr;
/*     */     }
/* 166 */     if (!isValid(oldStr)) {
/* 167 */       return oldStr;
/*     */     }
/* 169 */     String retStr = oldStr;
/* 170 */     String tmpStr = delStr(oldStr, beginStr, endStr);
/* 171 */     while ((times-- > 0) && (!retStr.equals(tmpStr))) {
/* 172 */       retStr = tmpStr;
/* 173 */       tmpStr = delStr(retStr, beginStr, endStr);
/*     */     }
/* 175 */     return retStr;
/*     */   }
/*     */ 
/*     */   public static String deleteString(String oldStr, String beginStr, String endStr)
/*     */   {
/* 196 */     if (!isValid(oldStr)) {
/* 197 */       return oldStr;
/*     */     }
/* 199 */     String retStr = oldStr;
/* 200 */     String tmpStr = delStr(oldStr, beginStr, endStr);
/* 201 */     while (!retStr.equals(tmpStr)) {
/* 202 */       retStr = tmpStr;
/* 203 */       tmpStr = delStr(retStr, beginStr, endStr);
/*     */     }
/* 205 */     return retStr;
/*     */   }
/*     */ 
/*     */   public static String getFileNameNoPath(String fileName)
/*     */   {
/* 216 */     fileName = trim(fileName);
/* 217 */     if (fileName.length() < 1) {
/* 218 */       return fileName;
/*     */     }
/* 220 */     String tmpStr = fileName;
/* 221 */     int idx1 = fileName.lastIndexOf("/");
/* 222 */     int idx2 = fileName.lastIndexOf("\\");
/* 223 */     idx1 = idx1 >= idx2 ? idx1 : idx2;
/* 224 */     tmpStr = fileName.substring(idx1 + 1);
/* 225 */     return tmpStr;
/*     */   }
/*     */ 
/*     */   public static boolean isValid(String str)
/*     */   {
/* 233 */     return (str != null) && (str.trim().length() >= 1);
/*     */   }
/*     */ 
/*     */   private static String delStr(String oldStr, String beginStr, String endStr)
/*     */   {
/* 242 */     if ((oldStr == null) || (oldStr.length() < 1) || (beginStr == null) || 
/* 243 */       (beginStr.length() < 1) || (endStr == null) || 
/* 244 */       (endStr.length() < 1)) {
/* 245 */       return oldStr;
/*     */     }
/* 247 */     String retStr = oldStr;
/*     */ 
/* 249 */     int i = oldStr.indexOf(beginStr);
/* 250 */     if (i >= 0) {
/* 251 */       int j = i + beginStr.length();
/* 252 */       if (j < oldStr.length()) {
/* 253 */         int k = oldStr.indexOf(endStr, j);
/* 254 */         if (k >= 0) {
/* 255 */           k += endStr.length();
/* 256 */           retStr = oldStr.substring(0, i) + oldStr.substring(k);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 261 */     return retStr;
/*     */   }
/*     */ 
/*     */   public static String trim(String s)
/*     */   {
/* 272 */     return s == null ? "" : s.trim();
/*     */   }
/*     */ 
/*     */   public static String[][] replace(String[][] str, int columnIndex, String oldString, String newString)
/*     */   {
/* 297 */     if (str == null) {
/* 298 */       return str;
/*     */     }
/* 300 */     if (str.length < 1) {
/* 301 */       return str;
/*     */     }
/* 303 */     if (str[0].length < columnIndex + 1) {
/* 304 */       return str;
/*     */     }
/* 306 */     for (int i = 0; i < str.length; i++) {
/* 307 */       String replacedString = str[i][columnIndex];
/*     */ 
/* 309 */       int replacedIndex = replacedString.indexOf(oldString) + 1;
/* 310 */       int oldStringLength = oldString.length();
/*     */ 
/* 312 */       if (replacedString.indexOf(oldString) == -1) {
/*     */         continue;
/*     */       }
/* 315 */       String first = replacedString.substring(0, replacedIndex - 1);
/* 316 */       String middle = newString;
/* 317 */       String end = replacedString.substring(replacedIndex - 1 + 
/* 318 */         oldString.length());
/*     */ 
/* 320 */       String newStrings = first + middle + end;
/*     */ 
/* 322 */       str[i][columnIndex] = newStrings;
/*     */     }
/*     */ 
/* 325 */     return str;
/*     */   }
/*     */ 
/*     */   public static String getRelativeDir(String packageName)
/*     */   {
/* 340 */     packageName = packageName == null ? "" : packageName.trim();
/*     */ 
/* 342 */     if (packageName.length() < 1) {
/* 343 */       return null;
/*     */     }
/* 345 */     if (packageName.indexOf(".") >= 0) {
/* 346 */       return replace(packageName, ".", "/");
/*     */     }
/* 348 */     return packageName;
/*     */   }
/*     */ 
/*     */   public static String firstUpperCase(String s)
/*     */   {
/* 358 */     if ((s == null) || (s.length() < 1)) {
/* 359 */       return s;
/*     */     }
/* 361 */     String first = s.substring(0, 1);
/* 362 */     String other = s.substring(1);
/* 363 */     s = first.toUpperCase() + other;
/* 364 */     return s;
/*     */   }
/*     */ 
/*     */   public static String firstUpperCaseOnly(String s)
/*     */   {
/* 375 */     if ((s == null) || (s.length() < 1)) {
/* 376 */       return s;
/*     */     }
/* 378 */     return firstUpperCase(s.toLowerCase());
/*     */   }
/*     */ 
/*     */   public static String firstLowerCase(String s)
/*     */   {
/* 388 */     if ((s != null) && (s.length() > 0)) {
/* 389 */       String first = s.substring(0, 1);
/* 390 */       String other = s.substring(1);
/* 391 */       s = first.toLowerCase() + other;
/*     */     }
/* 393 */     return s;
/*     */   }
/*     */ 
/*     */   public static boolean isJavaIdentifier(String s)
/*     */   {
/* 404 */     if ((s == null) || ("".equals(s)))
/* 405 */       return false;
/* 406 */     char[] arr = s.toCharArray();
/* 407 */     if (!Character.isJavaIdentifierStart(arr[0]))
/* 408 */       return false;
/* 409 */     int i = 1; for (int len = arr.length; i < len; i++) {
/* 410 */       if (!Character.isJavaIdentifierPart(arr[i]))
/* 411 */         return false;
/*     */     }
/* 413 */     return true;
/*     */   }
/*     */ 
/*     */   public static void arrayCopy(String[][] src, int src_position, String[][] dst, int dst_position, int length)
/*     */   {
/* 441 */     System.arraycopy(src, src_position, dst, dst_position, length);
/* 442 */     for (int i = src_position; i < src_position + length; i++) {
/* 443 */       String[] tem = new String[src[i].length];
/* 444 */       System.arraycopy(src[i], 0, tem, 0, tem.length);
/* 445 */       src[i] = tem;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String[][] arrayCopy(String[][] src, int src_position, int length)
/*     */   {
/* 468 */     String[][] dst = new String[length][];
/* 469 */     arrayCopy(src, src_position, dst, 0, length);
/* 470 */     return dst;
/*     */   }
/*     */ 
/*     */   public static String[][] arrayCopy(String[][] src)
/*     */   {
/* 487 */     return arrayCopy(src, 0, src.length);
/*     */   }
/*     */ 
/*     */   public static String[] split(String s, String delimiter)
/*     */   {
/* 497 */     StringTokenizer tokenizer = new StringTokenizer(s, delimiter);
/* 498 */     String[] result = new String[tokenizer.countTokens()];
/* 499 */     int i = 0;
/* 500 */     while (tokenizer.hasMoreTokens())
/* 501 */       result[(i++)] = tokenizer.nextToken();
/* 502 */     return result;
/*     */   }
/*     */ 
/*     */   public static boolean equals(Object s1, Object s2)
/*     */   {
/* 514 */     if (s1 == s2)
/* 515 */       return true;
/* 516 */     if (s1 == null)
/* 517 */       return false;
/* 518 */     return s1.equals(s2);
/*     */   }
/*     */ 
/*     */   public static String[][] arrayCombine(List list)
/*     */   {
/* 529 */     if ((list == null) || (list.size() < 1)) {
/* 530 */       return null;
/*     */     }
/*     */ 
/* 533 */     String[][] str = (String[][])null;
/* 534 */     String[][] ret = (String[][])null;
/*     */ 
/* 537 */     int size = 0;
/* 538 */     for (int i = list.size() - 1; i >= 0; i--) {
/* 539 */       str = (String[][])list.get(i);
/* 540 */       if ((str != null) && (str.length > 0)) {
/* 541 */         size += str.length;
/*     */       }
/*     */     }
/*     */ 
/* 545 */     if (size > 0) {
/* 546 */       int j = 0;
/* 547 */       int k = 0;
/* 548 */       ret = new String[size][];
/* 549 */       int i = 0; for (int len = list.size(); i < len; i++) {
/* 550 */         str = (String[][])list.get(i);
/* 551 */         if ((str != null) && (str.length > 0)) {
/* 552 */           k = str.length;
/* 553 */           arrayCopy(str, 0, ret, j, k);
/* 554 */           j += k;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 559 */     return ret;
/*     */   }
/*     */ 
/*     */   public static void print(Object[][] s)
/*     */   {
/* 569 */     if ((s != null) && (s.length > 0)) {
/* 570 */       log.debug("Below is the contents of Array:");
/* 571 */       int i = 0; for (int len = s.length; i < len; i++) {
/* 572 */         int j = 0; for (int jLen = s[i].length; j < jLen; j++) {
/* 573 */           log.debug("\t" + s[i][j]);
/*     */         }
/* 575 */         log.debug("\n");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String join(String[] arr, String delim)
/*     */   {
/* 593 */     if ((arr == null) || (arr.length < 1)) {
/* 594 */       return null;
/*     */     }
/*     */ 
/* 598 */     delim = trim(delim);
/* 599 */     if (delim.length() < 1) {
/* 600 */       throw new BaseException("参数非法，连接数组时，分隔符不可为null或空串");
/*     */     }
/*     */ 
/* 604 */     int len = arr.length;
/*     */ 
/* 607 */     if (len < 2) {
/* 608 */       return arr[0];
/*     */     }
/*     */ 
/* 612 */     StringBuffer sb = new StringBuffer(trim(arr[0]));
/*     */ 
/* 615 */     for (int i = 1; i < len; i++) {
/* 616 */       sb.append(delim).append(trim(arr[i]));
/*     */     }
/*     */ 
/* 619 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String limitLength(String src, int len)
/*     */   {
/* 630 */     String strOut = "";
/* 631 */     if (src == null) {
/* 632 */       return strOut;
/*     */     }
/* 634 */     if (src.length() > len)
/* 635 */       strOut = src.substring(0, len) + "...";
/*     */     else {
/* 637 */       strOut = src;
/*     */     }
/* 639 */     return strOut;
/*     */   }
/*     */ 
/*     */   public static final String translateFromISO(String str, String charsetName)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 652 */     if (str != null)
/* 653 */       return new String(str.getBytes("ISO8859-1"), charsetName);
/* 654 */     return null;
/*     */   }
/*     */ 
/*     */   public static final String translate(String str, String originCharsetName, String charsetName)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 668 */     if (!originCharsetName.equals(charsetName)) {
/* 669 */       if (str != null)
/* 670 */         return new String(str.getBytes(originCharsetName), charsetName);
/* 671 */       return null;
/*     */     }
/* 673 */     return str;
/*     */   }
/*     */ 
/*     */   public static String leftPad(long val, int size, String ch)
/*     */   {
/* 685 */     String result = String.valueOf(val);
/* 686 */     if (isEmpty(ch)) {
/* 687 */       ch = " ";
/*     */     }
/* 689 */     while (result.length() < size) {
/* 690 */       result = ch + result;
/*     */     }
/* 692 */     return result;
/*     */   }
/*     */ 
/*     */   public static String rightPad(long val, int size, String ch)
/*     */   {
/* 704 */     String result = String.valueOf(val);
/* 705 */     if (isEmpty(ch)) {
/* 706 */       ch = " ";
/*     */     }
/* 708 */     while (result.length() < size) {
/* 709 */       result = result + ch;
/*     */     }
/*     */ 
/* 712 */     return result;
/*     */   }
/*     */ 
/*     */   public static String leftPad(Object val, int size, String ch)
/*     */   {
/* 724 */     String result = String.valueOf(val);
/* 725 */     if (isEmpty(ch)) {
/* 726 */       ch = " ";
/*     */     }
/* 728 */     while (result.length() < size) {
/* 729 */       result = ch + result;
/*     */     }
/* 731 */     return result;
/*     */   }
/*     */ 
/*     */   public static String rightPad(Object val, int size, String ch)
/*     */   {
/* 743 */     String result = String.valueOf(val);
/* 744 */     if (isEmpty(ch)) {
/* 745 */       ch = " ";
/*     */     }
/* 747 */     while (result.length() < size) {
/* 748 */       result = result + ch;
/*     */     }
/*     */ 
/* 751 */     return result;
/*     */   }
/*     */ 
/*     */   public static final String extractNumber(String in)
/*     */   {
/* 761 */     if (in == null) {
/* 762 */       return "0";
/*     */     }
/*     */ 
/* 765 */     StringBuffer result = new StringBuffer();
/* 766 */     boolean seenDot = false;
/* 767 */     boolean seenMinus = false;
/* 768 */     boolean seenNumber = false;
/*     */ 
/* 770 */     for (int i = 0; i < in.length(); i++) {
/* 771 */       char c = in.charAt(i);
/*     */ 
/* 773 */       if (c == '.')
/*     */       {
/* 775 */         if (!seenDot) {
/* 776 */           seenDot = true;
/*     */ 
/* 778 */           if (!seenNumber) {
/* 779 */             result.append('0');
/*     */           }
/*     */ 
/* 782 */           result.append('.');
/*     */         }
/* 784 */       } else if (c == '-')
/*     */       {
/* 786 */         if (!seenMinus) {
/* 787 */           seenMinus = true;
/* 788 */           result.append('-');
/*     */         }
/*     */       } else {
/* 790 */         if ((c != '0') && ((c < '1') || (c > '9')))
/*     */           continue;
/* 792 */         seenNumber = true;
/* 793 */         result.append(c);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 798 */     int length = result.length();
/*     */ 
/* 800 */     if ((length > 0) && (result.charAt(length - 1) == '.')) {
/* 801 */       result.deleteCharAt(length - 1);
/*     */     }
/*     */ 
/* 804 */     return result.length() == 0 ? "0" : result.toString();
/*     */   }
/*     */ 
/*     */   public static final String reverse(String str)
/*     */   {
/* 817 */     if (str == null)
/* 818 */       return str;
/* 819 */     int len = str.length();
/* 820 */     char[] dist = new char[len];
/* 821 */     str.getChars(0, len, dist, 0);
/*     */ 
/* 823 */     for (int i = 0; i < len / 2; i++) {
/* 824 */       char a = dist[i];
/* 825 */       dist[i] = dist[(len - i - 1)];
/* 826 */       dist[(len - i - 1)] = a;
/*     */     }
/* 828 */     return new String(dist);
/*     */   }
/*     */ 
/*     */   public static String[] split(String str, String splite, int max, String defaultEmtype)
/*     */   {
/* 844 */     List resultList = new ArrayList();
/* 845 */     String[] strs = StringUtils.split(str, splite, max);
/* 846 */     defaultEmtype = StringUtils.defaultIfEmpty(defaultEmtype, "");
/* 847 */     for (int i = 0; i < strs.length; i++) {
/* 848 */       resultList.add(strs[i]);
/*     */     }
/*     */ 
/* 851 */     if (resultList.size() < max) {
/* 852 */       for (int i = resultList.size(); i < max; i++) {
/* 853 */         resultList.add(defaultEmtype);
/*     */       }
/*     */     }
/*     */ 
/* 857 */     return (String[])resultList.toArray(new String[0]);
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.tools.StringUtil
 * JD-Core Version:    0.6.0
 */