/*    */ package cn.newcapec.framework.utils.tools;
/*    */ 
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import net.sf.json.JsonConfig;
/*    */ import net.sf.json.processors.JsonValueProcessor;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class JsonDateValueProcessor
/*    */   implements JsonValueProcessor
/*    */ {
/* 12 */   private String format = "yyyy-MM-dd HH:mm:ss";
/*    */ 
/*    */   public JsonDateValueProcessor()
/*    */   {
/*    */   }
/*    */ 
/*    */   public JsonDateValueProcessor(String format) {
/* 19 */     if (StringUtils.isNotBlank(format))
/* 20 */       this.format = format;
/*    */   }
/*    */ 
/*    */   public Object processArrayValue(Object value, JsonConfig jsonConfig)
/*    */   {
/* 25 */     return process(value, jsonConfig);
/*    */   }
/*    */ 
/*    */   public Object processObjectValue(String key, Object value, JsonConfig jsonConfig)
/*    */   {
/* 30 */     return process(value, jsonConfig);
/*    */   }
/*    */ 
/*    */   private Object process(Object value, JsonConfig jsonConfig) {
/* 34 */     if ((value instanceof Date)) {
/* 35 */       String str = new SimpleDateFormat(this.format).format((Date)value);
/* 36 */       return str;
/*    */     }
/* 38 */     return value == null ? "" : value.toString();
/*    */   }
/*    */ 
/*    */   public String getFormat() {
/* 42 */     return this.format;
/*    */   }
/*    */ 
/*    */   public void setFormat(String format) {
/* 46 */     this.format = format;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.tools.JsonDateValueProcessor
 * JD-Core Version:    0.6.0
 */