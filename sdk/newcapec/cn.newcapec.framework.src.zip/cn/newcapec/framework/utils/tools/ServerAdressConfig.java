/*    */ package cn.newcapec.framework.utils.tools;
/*    */ 
/*    */ import java.util.ResourceBundle;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class ServerAdressConfig
/*    */ {
/* 23 */   static ResourceBundle CONFIG = null;
/*    */ 
/* 28 */   static Logger log = Logger.getLogger(ServerAdressConfig.class);
/*    */   private static final String FILE_NAME = "config/serviceProxyAddress";
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 37 */       CONFIG = ResourceBundle.getBundle("config/serviceProxyAddress");
/*    */     }
/*    */     catch (Exception localException)
/*    */     {
/*    */     }
/*    */   }
/*    */ 
/*    */   public static synchronized String getItem(String key)
/*    */   {
/*    */     try
/*    */     {
/* 51 */       String str = CONFIG.getString(key);
/* 52 */       str = StringUtils.defaultIfEmpty(str, "");
/* 53 */       str = str.trim();
/* 54 */       return str;
/*    */     } catch (Exception ex) {
/* 56 */       log.debug(ex);
/*    */     }
/* 58 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.tools.ServerAdressConfig
 * JD-Core Version:    0.6.0
 */