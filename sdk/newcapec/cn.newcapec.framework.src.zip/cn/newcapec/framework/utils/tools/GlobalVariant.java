/*     */ package cn.newcapec.framework.utils.tools;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class GlobalVariant
/*     */ {
/*  14 */   private static Map<String, String> variantMap = new Hashtable();
/*     */ 
/*     */   public static void registerVariant(String name, String value)
/*     */   {
/*  33 */     variantMap.put(name, value);
/*     */   }
/*     */ 
/*     */   public static String getVariant(String name)
/*     */   {
/*  49 */     return (String)variantMap.get(name);
/*     */   }
/*     */ 
/*     */   public static String getVariant(String name, String defaultValue)
/*     */   {
/*  67 */     String value = (String)variantMap.get(name);
/*  68 */     if (StringUtil.isEmpty(value)) {
/*  69 */       return defaultValue;
/*     */     }
/*  71 */     return value;
/*     */   }
/*     */ 
/*     */   public static String removeVariant(String name)
/*     */   {
/*  88 */     return (String)variantMap.remove(name);
/*     */   }
/*     */ 
/*     */   public static void addVariantValue(String name, String newValue)
/*     */   {
/* 106 */     if (variantMap.containsKey(name)) {
/* 107 */       String message = (String)variantMap.get(name);
/* 108 */       message = message + newValue;
/* 109 */       variantMap.remove(name);
/* 110 */       variantMap.put(name, message);
/*     */     } else {
/* 112 */       variantMap.put(name, newValue);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean haveVariant(String name)
/*     */   {
/* 129 */     return variantMap.containsKey(name);
/*     */   }
/*     */ 
/*     */   public static int size()
/*     */   {
/* 143 */     return variantMap.size();
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.tools.GlobalVariant
 * JD-Core Version:    0.6.0
 */