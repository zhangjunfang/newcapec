/*    */ package cn.newcapec.framework.utils;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class Page<T>
/*    */ {
/*    */   public static final int DEFAULT_PAGE_SIZE = 10;
/*    */   private int total;
/*    */   private List<T> items;
/*    */   private int pageIndex;
/*    */   private int pageSize;
/*    */   private int pageCount;
/*    */ 
/*    */   public Page(int pageIndex, int pageSize)
/*    */   {
/* 25 */     if (pageIndex < 1)
/* 26 */       pageIndex = 1;
/* 27 */     if (pageSize < 1)
/* 28 */       pageSize = 1;
/* 29 */     this.pageIndex = pageIndex;
/* 30 */     this.pageSize = pageSize;
/*    */   }
/*    */ 
/*    */   public Page(List items, int totalCount, int pageSize, int pageIndex)
/*    */   {
/* 36 */     if (pageIndex < 1)
/* 37 */       pageIndex = 1;
/* 38 */     if (pageSize < 1)
/* 39 */       pageSize = 1;
/* 40 */     this.total = totalCount;
/* 41 */     this.pageIndex = pageIndex;
/* 42 */     this.pageSize = pageSize;
/* 43 */     this.items = items;
/*    */   }
/*    */ 
/*    */   public Page(int pageIndex) {
/* 47 */     this(pageIndex, 10);
/*    */   }
/*    */   public int getPageIndex() {
/* 50 */     return this.pageIndex;
/*    */   }
/* 52 */   public int getPageSize() { return this.pageSize; } 
/*    */   public int getPageCount() {
/* 54 */     return this.pageCount;
/*    */   }
/* 56 */   public int getTotalCount() { return this.total; } 
/*    */   public int getFirstResult() {
/* 58 */     return (this.pageIndex - 1) * this.pageSize;
/*    */   }
/* 60 */   public boolean getHasPrevious() { return this.pageIndex > 1; } 
/*    */   public boolean getHasNext() {
/* 62 */     return this.pageIndex < this.pageCount;
/*    */   }
/*    */   public void setTotalCount(int total) {
/* 65 */     this.total = total;
/* 66 */     this.pageCount = (total / this.pageSize + (total % this.pageSize == 0 ? 0 : 1));
/*    */ 
/* 68 */     if (total == 0) {
/* 69 */       if (this.pageIndex != 1) {
/* 70 */         throw new IndexOutOfBoundsException("Page index out of range.");
/*    */       }
/*    */     }
/* 73 */     else if (this.pageIndex > this.pageCount)
/* 74 */       throw new IndexOutOfBoundsException("Page index out of range.");
/*    */   }
/*    */ 
/*    */   public boolean isEmpty()
/*    */   {
/* 79 */     return this.total == 0;
/*    */   }
/*    */ 
/*    */   public List<T> getItems()
/*    */   {
/* 84 */     return this.items;
/*    */   }
/*    */ 
/*    */   public void setItems(List<T> items) {
/* 88 */     this.items = items;
/*    */   }
/*    */ 
/*    */   public int getTotal()
/*    */   {
/* 93 */     return this.total;
/*    */   }
/*    */ 
/*    */   public void setTotal(int total)
/*    */   {
/* 99 */     this.total = total;
/*    */   }
/*    */ 
/*    */   public Page()
/*    */   {
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.Page
 * JD-Core Version:    0.6.0
 */