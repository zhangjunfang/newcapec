package cn.newcapec.framework.utils.collection;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

public abstract interface ObjectCollection
{
  public abstract void add(Object paramObject1, Object paramObject2);

  public abstract void forceAdd(Object paramObject1, Object paramObject2);

  public abstract void add(int paramInt, Object paramObject1, Object paramObject2);

  public abstract Object get(Object paramObject);

  public abstract Object get(int paramInt);

  public abstract void set(int paramInt, Object paramObject);

  public abstract int indexOf(Object paramObject);

  public abstract Object getKey(int paramInt);

  public abstract Object remove(Object paramObject);

  public abstract Object remove(int paramInt);

  public abstract void removeAll();

  public abstract int size();

  public abstract List keyList();

  public abstract Map map();

  public abstract Iterator iterator();

  public abstract Object clone()
    throws CloneNotSupportedException;
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.collection.ObjectCollection
 * JD-Core Version:    0.6.0
 */