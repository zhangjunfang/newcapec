/*     */ package cn.newcapec.framework.utils.collection;
/*     */ 
/*     */ import cn.newcapec.framework.utils.tools.JsonDateValueProcessor;
/*     */ import java.util.Date;
/*     */ import net.sf.ezmorph.MorpherRegistry;
/*     */ import net.sf.ezmorph.object.DateMorpher;
/*     */ import net.sf.json.JSONArray;
/*     */ import net.sf.json.JSONObject;
/*     */ import net.sf.json.JsonConfig;
/*     */ import net.sf.json.util.CycleDetectionStrategy;
/*     */ import net.sf.json.util.JSONUtils;
/*     */ import net.sf.json.util.PropertyFilter;
/*     */ import org.apache.commons.lang.BooleanUtils;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.lang.exception.ExceptionUtils;
/*     */ import org.apache.commons.lang.math.NumberUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class JSONTools
/*     */ {
/*  27 */   protected static Logger logger = Logger.getLogger(JSONTools.class);
/*     */ 
/*     */   static {
/*  30 */     String[] dateFormats = { "yyyy-MM-dd HH:mm:ss" };
/*  31 */     JSONUtils.getMorpherRegistry().registerMorpher(new DateMorpher(dateFormats));
/*     */   }
/*     */ 
/*     */   public static final String getString(JSONObject json, String key)
/*     */   {
/*  45 */     String result = "";
/*  46 */     Object obj = getObject(json, key);
/*  47 */     if (obj != null) {
/*  48 */       result = obj.toString();
/*     */     }
/*     */ 
/*  51 */     return result;
/*     */   }
/*     */   public static final int getInt(JSONObject json, String key) {
/*  54 */     int result = 0;
/*  55 */     Object obj = getObject(json, key);
/*  56 */     if (obj != null) {
/*  57 */       result = NumberUtils.toInt(obj.toString(), result);
/*     */     }
/*     */ 
/*  60 */     return result;
/*     */   }
/*     */ 
/*     */   public static final boolean getBoolean(JSONObject json, String key) {
/*  64 */     boolean result = false;
/*  65 */     Object obj = getObject(json, key);
/*  66 */     if (obj != null) {
/*  67 */       result = BooleanUtils.toBoolean(obj.toString());
/*     */     }
/*     */ 
/*  70 */     return result;
/*     */   }
/*     */   public static final Double getDouble(JSONObject json, String key) {
/*  73 */     double result = 0.0D;
/*  74 */     Object obj = getObject(json, key);
/*  75 */     if (obj != null) {
/*  76 */       result = NumberUtils.toDouble(obj.toString(), result);
/*     */     }
/*     */ 
/*  79 */     return Double.valueOf(result);
/*     */   }
/*     */   public static final JSONObject getJSONObject(JSONObject json, String key) {
/*  82 */     JSONObject result = null;
/*  83 */     Object obj = getObject(json, key);
/*  84 */     if ((obj != null) && ((obj instanceof JSONObject))) {
/*  85 */       result = (JSONObject)obj;
/*     */     }
/*     */ 
/*  88 */     return result;
/*     */   }
/*     */ 
/*     */   public static final JSONArray getJSONArray(JSONObject json, String key) {
/*  92 */     JSONArray result = null;
/*  93 */     Object obj = getObject(json, key);
/*  94 */     if ((obj != null) && ((obj instanceof JSONArray))) {
/*  95 */       result = (JSONArray)obj;
/*     */     }
/*     */ 
/*  98 */     return result;
/*     */   }
/*     */ 
/*     */   public static final Object getObject(JSONObject json, String key)
/*     */   {
/* 103 */     Object result = null;
/* 104 */     if ((json != null) && (StringUtils.isNotEmpty(key)) && (json.containsKey(key))) {
/* 105 */       result = json.get(key);
/*     */     }
/* 107 */     return result;
/*     */   }
/*     */ 
/*     */   public static final <T> T JSONToBean(JSONObject jsonData, Class<T> clazz) {
/* 111 */     return JSONToBean(jsonData, clazz, null);
/*     */   }
/*     */ 
/*     */   public static final <T> T JSONToBean(JSONObject jsonData, Class<T> clazz, JsonConfig jsonConfig)
/*     */   {
/* 127 */     Object result = null;
/* 128 */     if ((jsonData == null) || (jsonData.size() == 0) || (clazz == null)) {
/* 129 */       return result;
/*     */     }
/* 131 */     if (jsonConfig == null)
/* 132 */       jsonConfig = getJSConfig(null, null, Boolean.valueOf(false));
/*     */     try
/*     */     {
/* 135 */       result = clazz.newInstance();
/* 136 */       result = JSONObject.toBean(jsonData, result, jsonConfig);
/*     */     } catch (Exception e) {
/* 138 */       e.printStackTrace();
/* 139 */       logger.error(ExceptionUtils.getFullStackTrace(e));
/*     */     }
/* 141 */     return result;
/*     */   }
/*     */ 
/*     */   public static final <T> T JSONToBean(JSONObject jsonData, Class<T> clazz, String[] excludes, String datePattern, Boolean includeNull)
/*     */   {
/* 157 */     JsonConfig jsonConfig = getJSConfig(excludes, datePattern, includeNull);
/* 158 */     return JSONToBean(jsonData, clazz, jsonConfig);
/*     */   }
/*     */ 
/*     */   public static JsonConfig getJSConfig(String[] excludes, String datePattern, Boolean includeNull)
/*     */   {
/* 174 */     JsonConfig result = new JsonConfig();
/* 175 */     if (excludes != null) {
/* 176 */       result.setExcludes(excludes);
/*     */     }
/* 178 */     result.setIgnoreDefaultExcludes(false);
/* 179 */     result.setCycleDetectionStrategy(CycleDetectionStrategy.LENIENT);
/* 180 */     result.registerJsonValueProcessor(Date.class, 
/* 181 */       new JsonDateValueProcessor(datePattern));
/* 182 */     if ((includeNull != null) && (!includeNull.booleanValue()))
/*     */     {
/* 184 */       result.setJsonPropertyFilter(new PropertyFilter()
/*     */       {
/*     */         public boolean apply(Object source, String name, Object value)
/*     */         {
/* 188 */           return value == null;
/*     */         }
/*     */       });
/* 194 */       result.setJavaPropertyFilter(new PropertyFilter()
/*     */       {
/*     */         public boolean apply(Object source, String name, Object value)
/*     */         {
/* 199 */           return (value == null) || (StringUtils.isBlank(value.toString()));
/*     */         }
/*     */ 
/*     */       });
/*     */     }
/*     */ 
/* 205 */     return result;
/*     */   }
/*     */ 
/*     */   public JSONObject strToJSONObject(String str, JSONObject jsonObject) {
/* 209 */     JSONObject result = null;
/* 210 */     return result;
/*     */   }
/*     */ 
/*     */   public static JSONObject parseToJSONObject(String str) {
/* 214 */     JSONObject result = null;
/* 215 */     if ((StringUtils.isNotBlank(str)) && (str.startsWith("{")) && 
/* 216 */       (str.endsWith("}"))) {
/* 217 */       result = JSONObject.fromObject(str);
/*     */     }
/* 219 */     if (result == null) {
/* 220 */       result = new JSONObject();
/*     */     }
/* 222 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.collection.JSONTools
 * JD-Core Version:    0.6.0
 */