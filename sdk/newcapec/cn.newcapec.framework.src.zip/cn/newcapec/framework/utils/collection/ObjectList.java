/*     */ package cn.newcapec.framework.utils.collection;
/*     */ 
/*     */ import cn.newcapec.framework.base.exception.DuplicateKeyException;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.collections.map.LinkedMap;
/*     */ import org.apache.commons.lang.ObjectUtils;
/*     */ 
/*     */ public class ObjectList
/*     */   implements ObjectCollection, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 5149700417023169004L;
/*  26 */   private LinkedMap data = new LinkedMap();
/*     */ 
/*     */   public void add(Object key, Object object)
/*     */   {
/*  32 */     if (this.data.containsKey(key))
/*  33 */       throw new DuplicateKeyException(key);
/*  34 */     this.data.put(key, object);
/*     */   }
/*     */ 
/*     */   public void forceAdd(Object key, Object object)
/*     */   {
/*  41 */     this.data.put(key, object);
/*     */   }
/*     */ 
/*     */   public void add(int index, Object key, Object object)
/*     */   {
/*  75 */     if (this.data.containsKey(key)) {
/*  76 */       throw new DuplicateKeyException(key);
/*     */     }
/*     */ 
/*  79 */     int size = this.data.size();
/*  80 */     if ((size > 0) && (index >= size)) {
/*  81 */       throw new ArrayIndexOutOfBoundsException(index);
/*     */     }
/*  83 */     int i = 0;
/*  84 */     List entryList = new ArrayList();
/*     */ 
/*  86 */     for (Iterator iterator = this.data.entrySet().iterator(); iterator.hasNext(); ) {
/*  87 */       Map.Entry entry = (Map.Entry)iterator.next();
/*  88 */       if (i++ >= index) {
/*  89 */         MapEntry mapEntry = new MapEntry(entry.getKey(), entry.getValue());
/*  90 */         entryList.add(mapEntry);
/*  91 */         iterator.remove();
/*     */       }
/*     */     }
/*  94 */     this.data.put(key, object);
/*     */ 
/*  96 */     for (Iterator iterator = entryList.iterator(); iterator.hasNext(); i++) {
/*  97 */       MapEntry entry = (MapEntry)iterator.next();
/*  98 */       this.data.put(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object get(Object key)
/*     */   {
/* 107 */     return this.data.get(key);
/*     */   }
/*     */ 
/*     */   public Object get(int index)
/*     */   {
/* 114 */     return this.data.getValue(index);
/*     */   }
/*     */ 
/*     */   public void set(int index, Object object)
/*     */   {
/*     */     Object key;
/* 122 */     if ((key = this.data.get(index)) != null) {
/* 123 */       this.data.put(key, object);
/* 124 */       return;
/*     */     }
/* 126 */     throw new ArrayIndexOutOfBoundsException(index);
/*     */   }
/*     */ 
/*     */   public int indexOf(Object key)
/*     */   {
/* 133 */     return this.data.indexOf(key);
/*     */   }
/*     */ 
/*     */   public Object getKey(int index)
/*     */   {
/* 140 */     return this.data.get(index);
/*     */   }
/*     */ 
/*     */   public Object remove(Object key)
/*     */   {
/* 147 */     return this.data.remove(key);
/*     */   }
/*     */ 
/*     */   public Object remove(int index)
/*     */   {
/* 154 */     return this.data.remove(index);
/*     */   }
/*     */ 
/*     */   public void removeAll()
/*     */   {
/* 161 */     this.data.clear();
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 168 */     return this.data.size();
/*     */   }
/*     */ 
/*     */   public List keyList()
/*     */   {
/* 175 */     return this.data.asList();
/*     */   }
/*     */ 
/*     */   public Map map()
/*     */   {
/* 182 */     return this.data;
/*     */   }
/*     */ 
/*     */   public Iterator iterator()
/*     */   {
/* 189 */     return this.data.asList().iterator();
/*     */   }
/*     */ 
/*     */   public Object clone() throws CloneNotSupportedException {
/* 193 */     return super.clone();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj) {
/* 197 */     if ((obj instanceof Serializable)) {
/* 198 */       ObjectCollection objectCollection = (Serializable)obj;
/*     */ 
/* 200 */       if (size() != objectCollection.size())
/* 201 */         return false;
/* 202 */       int j = 0; for (int i = size(); j < i; j++) {
/* 203 */         Object o = getKey(j);
/* 204 */         if (!ObjectUtils.equals(get(o), objectCollection.get(o)))
/* 205 */           return false;
/*     */       }
/* 207 */       return true;
/*     */     }
/* 209 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 213 */     if (this.data.size() == 0)
/* 214 */       return 0;
/* 215 */     return this.data.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 219 */     return this.data.toString();
/*     */   }
/*     */ 
/*     */   private class MapEntry
/*     */   {
/*     */     Object key;
/*     */     Object value;
/*     */ 
/*     */     public MapEntry(Object key, Object value)
/*     */     {
/*  49 */       this.key = key;
/*  50 */       this.value = value;
/*     */     }
/*     */ 
/*     */     public Object getKey() {
/*  54 */       return this.key;
/*     */     }
/*     */ 
/*     */     public void setKey(Object key) {
/*  58 */       this.key = key;
/*     */     }
/*     */ 
/*     */     public Object getValue() {
/*  62 */       return this.value;
/*     */     }
/*     */ 
/*     */     public void setValue(Object value) {
/*  66 */       this.value = value;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.collection.ObjectList
 * JD-Core Version:    0.6.0
 */