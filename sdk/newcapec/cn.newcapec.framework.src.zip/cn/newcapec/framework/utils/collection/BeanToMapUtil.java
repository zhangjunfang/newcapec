/*     */ package cn.newcapec.framework.utils.collection;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class BeanToMapUtil
/*     */ {
/*     */   public static Object convertMap(Class type, Map map)
/*     */   {
/*  33 */     BeanInfo beanInfo = null;
/*     */     try {
/*  35 */       beanInfo = Introspector.getBeanInfo(type);
/*     */     }
/*     */     catch (IntrospectionException e) {
/*  38 */       e.printStackTrace();
/*     */     }
/*  40 */     Object obj = null;
/*     */     try {
/*  42 */       obj = type.newInstance();
/*     */     }
/*     */     catch (InstantiationException e) {
/*  45 */       e.printStackTrace();
/*     */     }
/*     */     catch (IllegalAccessException e) {
/*  48 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  52 */     PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
/*  53 */     for (int i = 0; i < propertyDescriptors.length; i++) {
/*  54 */       PropertyDescriptor descriptor = propertyDescriptors[i];
/*  55 */       String propertyName = descriptor.getName();
/*     */ 
/*  57 */       if ((map == null) || (!map.containsKey(propertyName)))
/*     */         continue;
/*  59 */       Object value = map.get(propertyName);
/*     */ 
/*  61 */       Object[] args = new Object[1];
/*  62 */       args[0] = value;
/*     */       try
/*     */       {
/*  65 */         descriptor.getWriteMethod().invoke(obj, args);
/*     */       }
/*     */       catch (IllegalArgumentException e) {
/*  68 */         e.printStackTrace();
/*     */       }
/*     */       catch (IllegalAccessException e) {
/*  71 */         e.printStackTrace();
/*     */       }
/*     */       catch (InvocationTargetException e) {
/*  74 */         e.printStackTrace();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  79 */     return obj;
/*     */   }
/*     */ 
/*     */   public static Map convertBean(Object bean)
/*     */   {
/*  91 */     Class type = bean.getClass();
/*  92 */     Map returnMap = new HashMap();
/*  93 */     BeanInfo beanInfo = null;
/*     */     try {
/*  95 */       beanInfo = Introspector.getBeanInfo(type);
/*     */     }
/*     */     catch (IntrospectionException e) {
/*  98 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 101 */     PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
/* 102 */     for (int i = 0; i < propertyDescriptors.length; i++) {
/* 103 */       PropertyDescriptor descriptor = propertyDescriptors[i];
/* 104 */       String propertyName = descriptor.getName();
/* 105 */       if (!propertyName.equals("class")) {
/* 106 */         Method readMethod = descriptor.getReadMethod();
/* 107 */         Object result = null;
/*     */         try {
/* 109 */           result = readMethod.invoke(bean, new Object[0]);
/*     */         } catch (IllegalArgumentException e) {
/* 111 */           e.printStackTrace();
/*     */         } catch (IllegalAccessException e) {
/* 113 */           e.printStackTrace();
/*     */         } catch (InvocationTargetException e) {
/* 115 */           e.printStackTrace();
/*     */         }
/* 117 */         if (result != null) {
/* 118 */           returnMap.put(propertyName, result);
/*     */         }
/*     */       }
/*     */     }
/* 122 */     return returnMap;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.collection.BeanToMapUtil
 * JD-Core Version:    0.6.0
 */