/*    */ package cn.newcapec.framework.utils;
/*    */ 
/*    */ public class PageIndex
/*    */ {
/*    */   private long startindex;
/*    */   private long endindex;
/*    */ 
/*    */   public PageIndex(long startindex, long endindex)
/*    */   {
/*  8 */     this.startindex = startindex;
/*  9 */     this.endindex = endindex;
/*    */   }
/*    */   public long getStartindex() {
/* 12 */     return this.startindex;
/*    */   }
/*    */   public void setStartindex(long startindex) {
/* 15 */     this.startindex = startindex;
/*    */   }
/*    */   public long getEndindex() {
/* 18 */     return this.endindex;
/*    */   }
/*    */   public void setEndindex(long endindex) {
/* 21 */     this.endindex = endindex;
/*    */   }
/*    */ 
/*    */   public static PageIndex getPageIndex(long viewpagecount, int currentPage, long totalpage) {
/* 25 */     long startpage = currentPage - (viewpagecount % 2L == 0L ? viewpagecount / 2L - 1L : viewpagecount / 2L);
/* 26 */     long endpage = currentPage + viewpagecount / 2L;
/* 27 */     if (startpage < 1L) {
/* 28 */       startpage = 1L;
/* 29 */       if (totalpage >= viewpagecount) endpage = viewpagecount; else
/* 30 */         endpage = totalpage;
/*    */     }
/* 32 */     if (endpage > totalpage) {
/* 33 */       endpage = totalpage;
/* 34 */       if (endpage - viewpagecount > 0L) startpage = endpage - viewpagecount + 1L; else
/* 35 */         startpage = 1L;
/*    */     }
/* 37 */     return new PageIndex(startpage, endpage);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.PageIndex
 * JD-Core Version:    0.6.0
 */