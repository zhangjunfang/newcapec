/*     */ package cn.newcapec.framework.utils;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.UUID;
/*     */ import sun.misc.BASE64Decoder;
/*     */ import sun.misc.BASE64Encoder;
/*     */ 
/*     */ public class VerifyUtil
/*     */ {
/*     */   public static final long stamp = 1800000L;
/*     */ 
/*     */   public static String getEmailCode(String userId)
/*     */   {
/*  25 */     UUID uuid = UUID.randomUUID();
/*  26 */     String uuidstr = uuid.toString();
/*  27 */     String code = uuidstr.substring(0, 8) + uuidstr.substring(9, 13) + uuidstr.substring(14, 18) + uuidstr.substring(19, 23) + uuidstr.substring(24) + "-" + userId + "-" + System.currentTimeMillis();
/*  28 */     BASE64Encoder baseEncoder = new BASE64Encoder();
/*     */ 
/*  30 */     return baseEncoder.encode(code.getBytes());
/*     */   }
/*     */ 
/*     */   public static String getUUID(String code64)
/*     */   {
/*  40 */     BASE64Decoder baseDecoder = new BASE64Decoder();
/*     */     try {
/*  42 */       byte[] dist = baseDecoder.decodeBuffer(code64);
/*  43 */       String code = new String(dist);
/*  44 */       String[] sr = code.split("-");
/*  45 */       return sr[0];
/*     */     } catch (IOException e) {
/*  47 */       e.printStackTrace();
/*  48 */     }return "";
/*     */   }
/*     */ 
/*     */   public static String getUserId(String code64)
/*     */   {
/*  59 */     BASE64Decoder baseDecoder = new BASE64Decoder();
/*     */     try
/*     */     {
/*  62 */       byte[] dist = baseDecoder.decodeBuffer(code64);
/*  63 */       String code = new String(dist);
/*  64 */       String[] sr = code.split("-");
/*  65 */       return sr[1];
/*     */     } catch (IOException e) {
/*  67 */       e.printStackTrace();
/*  68 */     }return "";
/*     */   }
/*     */ 
/*     */   public static String getTimeStamp(String code64)
/*     */   {
/*  79 */     BASE64Decoder baseDecoder = new BASE64Decoder();
/*     */     try
/*     */     {
/*  82 */       byte[] dist = baseDecoder.decodeBuffer(code64);
/*  83 */       String code = new String(dist);
/*  84 */       String[] sr = code.split("-");
/*  85 */       return sr[2];
/*     */     } catch (IOException e) {
/*  87 */       e.printStackTrace();
/*  88 */     }return "";
/*     */   }
/*     */ 
/*     */   public static boolean verifyTime(String code64)
/*     */   {
/* 100 */     BASE64Decoder baseDecoder = new BASE64Decoder();
/*     */     try {
/* 102 */       byte[] dist = baseDecoder.decodeBuffer(code64);
/* 103 */       String code = new String(dist);
/* 104 */       String[] sr = code.split("-");
/* 105 */       long timeStamp = Long.parseLong(sr[2]);
/*     */ 
/* 107 */       long currentMin = System.currentTimeMillis();
/*     */ 
/* 110 */       return timeStamp + 1800000L > currentMin;
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 115 */       e.printStackTrace();
/* 116 */     }return false;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 128 */     System.out.println(verifyTime("Y2ZiYmQ2NTA2NThmNDMzMzg0Zjc2YTlkM2I4MWEyNDgtbGl1amlubGlhbmctMTM3NDAzMTI4NjM3NQ=="));
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.utils.VerifyUtil
 * JD-Core Version:    0.6.0
 */