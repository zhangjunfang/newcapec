/*    */ package cn.newcapec.framework.base.rest;
/*    */ 
/*    */ import org.json.JSONObject;
/*    */ import org.restlet.data.CharacterSet;
/*    */ import org.restlet.data.Response;
/*    */ import org.restlet.resource.Representation;
/*    */ import org.restlet.resource.StringRepresentation;
/*    */ 
/*    */ public class BaseResponseImpl
/*    */   implements BaseResponse
/*    */ {
/* 16 */   private Response response = null;
/*    */ 
/* 18 */   private static final CharacterSet DEFAULT_CHARSET = CharacterSet.UTF_8;
/*    */ 
/*    */   public BaseResponseImpl(Response response) {
/* 21 */     this.response = response;
/*    */   }
/*    */ 
/*    */   public void print(Representation representation) {
/* 25 */     representation.setCharacterSet(DEFAULT_CHARSET);
/* 26 */     getOrignResponse().setEntity(representation);
/*    */   }
/*    */ 
/*    */   public void print(Representation representation, CharacterSet characterSet) {
/* 30 */     if (!DEFAULT_CHARSET.equals(characterSet)) {
/* 31 */       representation.setCharacterSet(characterSet);
/*    */     }
/*    */ 
/* 34 */     getOrignResponse().setEntity(representation);
/*    */   }
/*    */ 
/*    */   public void print(String str) {
/* 38 */     print(new StringRepresentation(str));
/*    */   }
/*    */ 
/*    */   public void print(JSONObject jsonObj) {
/* 42 */     print(jsonObj.toString());
/*    */   }
/*    */ 
/*    */   public void print(Representation representation, String characterSet) {
/* 46 */     CharacterSet newCharacterSet = new CharacterSet("UTF-8", "");
/* 47 */     if (!DEFAULT_CHARSET.equals(newCharacterSet)) {
/* 48 */       representation.setCharacterSet(newCharacterSet);
/*    */     }
/* 50 */     getOrignResponse().setEntity(representation);
/*    */   }
/*    */ 
/*    */   public Response getOrignResponse() {
/* 54 */     return this.response;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.rest.BaseResponseImpl
 * JD-Core Version:    0.6.0
 */