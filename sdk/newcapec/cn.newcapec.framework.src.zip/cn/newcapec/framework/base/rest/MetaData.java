/*    */ package cn.newcapec.framework.base.rest;
/*    */ 
/*    */ public class MetaData
/*    */ {
/* 10 */   private String messageProperty = "msg";
/*    */ 
/* 12 */   private String successProperty = "success";
/*    */ 
/*    */   public String getMessageProperty()
/*    */   {
/* 18 */     return this.messageProperty;
/*    */   }
/*    */ 
/*    */   public void setMessageProperty(String messageProperty)
/*    */   {
/* 26 */     this.messageProperty = messageProperty;
/*    */   }
/*    */ 
/*    */   public String getSuccessProperty()
/*    */   {
/* 33 */     return this.successProperty;
/*    */   }
/*    */ 
/*    */   public void setSuccessProperty(String successProperty)
/*    */   {
/* 41 */     this.successProperty = successProperty;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.rest.MetaData
 * JD-Core Version:    0.6.0
 */