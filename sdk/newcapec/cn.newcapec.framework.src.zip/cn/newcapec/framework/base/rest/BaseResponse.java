package cn.newcapec.framework.base.rest;

import org.json.JSONObject;
import org.restlet.data.Response;
import org.restlet.resource.Representation;

public abstract interface BaseResponse
{
  public abstract void print(Representation paramRepresentation);

  public abstract void print(String paramString);

  public abstract void print(JSONObject paramJSONObject);

  public abstract Response getOrignResponse();
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.rest.BaseResponse
 * JD-Core Version:    0.6.0
 */