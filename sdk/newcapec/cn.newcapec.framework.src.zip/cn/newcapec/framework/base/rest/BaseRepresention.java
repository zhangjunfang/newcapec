/*     */ package cn.newcapec.framework.base.rest;
/*     */ 
/*     */ import cn.newcapec.framework.utils.variant.Variant;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.json.JSONArray;
/*     */ import org.json.JSONException;
/*     */ import org.restlet.data.CharacterSet;
/*     */ import org.restlet.data.MediaType;
/*     */ import org.restlet.resource.Representation;
/*     */ import org.restlet.resource.StringRepresentation;
/*     */ 
/*     */ public class BaseRepresention extends StringRepresentation
/*     */ {
/*     */   public BaseRepresention(Msg message)
/*     */   {
/*  34 */     super(message.toJSONObject().toString(), MediaType.TEXT_PLAIN, null, 
/*  34 */       CharacterSet.UTF_8);
/*     */   }
/*     */ 
/*     */   public BaseRepresention(boolean flag, String msg)
/*     */   {
/*  45 */     super(new Msg(flag, msg).toJSONObject().toString(), 
/*  45 */       MediaType.TEXT_PLAIN, null, CharacterSet.UTF_8);
/*     */   }
/*     */ 
/*     */   public BaseRepresention(boolean flag, String msg, Object data)
/*     */   {
/*  57 */     super(new Msg(flag, msg, data).toJSONObject().toString(), 
/*  57 */       MediaType.TEXT_PLAIN, null, CharacterSet.UTF_8);
/*     */   }
/*     */ 
/*     */   public BaseRepresention(String msg, Object data)
/*     */   {
/*  70 */     super(new Msg(true, msg).setData(data).toJSONObject().toString(), 
/*  70 */       MediaType.TEXT_PLAIN, null, CharacterSet.UTF_8);
/*     */   }
/*     */ 
/*     */   public BaseRepresention(org.json.JSONObject jsonObject)
/*     */   {
/*  80 */     this(jsonObject.toString());
/*     */   }
/*     */ 
/*     */   public BaseRepresention(Map<Object, Object> map)
/*     */   {
/*  93 */     super(new Msg().setData(map).toJSONObject().toString(), 
/*  93 */       MediaType.TEXT_PLAIN, null, CharacterSet.UTF_8);
/*     */   }
/*     */ 
/*     */   public BaseRepresention(Variant variant)
/*     */   {
/* 105 */     super(new Msg().setData(variant).toJSONObject().toString(), 
/* 105 */       MediaType.TEXT_PLAIN, null, CharacterSet.UTF_8);
/*     */   }
/*     */ 
/*     */   public BaseRepresention(Object data)
/*     */   {
/* 117 */     super(new Msg().setData(data).toJSONObject().toString(), 
/* 117 */       MediaType.TEXT_PLAIN, null, CharacterSet.UTF_8);
/*     */   }
/*     */ 
/*     */   public BaseRepresention(Representation jsonRepresentation)
/*     */     throws IOException
/*     */   {
/* 128 */     this(jsonRepresentation.getText());
/*     */   }
/*     */ 
/*     */   public JSONArray toJsonArray()
/*     */     throws JSONException
/*     */   {
/* 138 */     return new JSONArray(getText());
/*     */   }
/*     */ 
/*     */   public org.json.JSONObject toJsonObject()
/*     */     throws JSONException
/*     */   {
/* 148 */     return new org.json.JSONObject(getText());
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.rest.BaseRepresention
 * JD-Core Version:    0.6.0
 */