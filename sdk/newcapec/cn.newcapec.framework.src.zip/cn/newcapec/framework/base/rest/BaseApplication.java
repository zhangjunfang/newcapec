/*    */ package cn.newcapec.framework.base.rest;
/*    */ 
/*    */ import org.restlet.Application;
/*    */ import org.restlet.Context;
/*    */ import org.restlet.service.TunnelService;
/*    */ 
/*    */ public class BaseApplication extends Application
/*    */ {
/* 13 */   private boolean tunnelServiceExtensionsTunnerl = false;
/*    */ 
/*    */   public BaseApplication(Context context)
/*    */   {
/* 26 */     super(context.createChildContext());
/* 27 */     getTunnelService().setExtensionsTunnel(
/* 28 */       this.tunnelServiceExtensionsTunnerl);
/*    */   }
/*    */ 
/*    */   public boolean isTunnelServiceExtensionsTunnerl()
/*    */   {
/* 42 */     return this.tunnelServiceExtensionsTunnerl;
/*    */   }
/*    */ 
/*    */   public void setTunnelServiceExtensionsTunnerl(boolean tunnelServiceExtensionsTunnerl)
/*    */   {
/* 58 */     this.tunnelServiceExtensionsTunnerl = tunnelServiceExtensionsTunnerl;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.rest.BaseApplication
 * JD-Core Version:    0.6.0
 */