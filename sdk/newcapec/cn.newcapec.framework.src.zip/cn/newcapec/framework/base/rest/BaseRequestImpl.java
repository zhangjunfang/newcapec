/*     */ package cn.newcapec.framework.base.rest;
/*     */ 
/*     */ import cn.newcapec.framework.base.exception.SysException;
/*     */ import cn.newcapec.framework.utils.tools.BeanUtils;
/*     */ import cn.newcapec.framework.utils.tools.StringUtil;
/*     */ import cn.newcapec.framework.utils.variant.VariantSet;
/*     */ import cn.newcapec.framework.utils.variant.VariantUtil;
/*     */ import com.noelios.restlet.ext.servlet.ServletCall;
/*     */ import com.noelios.restlet.http.HttpCall;
/*     */ import com.noelios.restlet.http.HttpRequest;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.fileupload.FileItem;
/*     */ import org.apache.commons.fileupload.FileUploadException;
/*     */ import org.apache.commons.fileupload.disk.DiskFileItemFactory;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ import org.restlet.data.CharacterSet;
/*     */ import org.restlet.data.Form;
/*     */ import org.restlet.data.MediaType;
/*     */ import org.restlet.data.Method;
/*     */ import org.restlet.data.Parameter;
/*     */ import org.restlet.data.Reference;
/*     */ import org.restlet.data.Request;
/*     */ import org.restlet.ext.fileupload.RestletFileUpload;
/*     */ import org.restlet.resource.Representation;
/*     */ 
/*     */ public class BaseRequestImpl
/*     */   implements BaseRequest
/*     */ {
/*  53 */   private Logger log = Logger.getLogger(getClass());
/*     */ 
/*  56 */   Request request = null;
/*     */ 
/*  59 */   private Representation representation = null;
/*     */ 
/*  62 */   Form form = null;
/*     */   private MediaType mediaType;
/*  68 */   JSONObject jsonObject = null;
/*     */   List<FileItem> fileItems;
/*  73 */   HttpServletRequest httpServletRequest = null;
/*  74 */   HttpServletResponse httpServletResponse = null;
/*     */ 
/*     */   public BaseRequestImpl(Request request) {
/*  77 */     this.request = request;
/*  78 */     this.representation = request.getEntity();
/*  79 */     this.mediaType = this.representation.getMediaType();
/*     */ 
/*  81 */     init();
/*     */ 
/*  83 */     if ((this.form != null) && (this.form.size() == 0)) {
/*  84 */       HttpServletRequest httpServletRequest = 
/*  85 */         ServletCall.getRequest(request);
/*     */       try {
/*  87 */         httpServletRequest.setCharacterEncoding("utf-8");
/*  88 */         Enumeration paramNames = httpServletRequest.getParameterNames();
/*  89 */         while (paramNames.hasMoreElements()) {
/*  90 */           String name = (String)paramNames.nextElement();
/*  91 */           String value = httpServletRequest.getParameter(name);
/*  92 */           this.form.add(new Parameter(name, value));
/*     */         }
/*     */       } catch (UnsupportedEncodingException e) {
/*  95 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Representation getRepresentation()
/*     */   {
/* 105 */     return this.representation;
/*     */   }
/*     */ 
/*     */   private void init() {
/* 109 */     HttpCall httpCall = ((HttpRequest)this.request).getHttpCall();
/* 110 */     this.httpServletRequest = ((ServletCall)httpCall).getRequest();
/* 111 */     this.httpServletResponse = ((ServletCall)httpCall).getResponse();
/* 112 */     this.representation.setCharacterSet(CharacterSet.UTF_8);
/* 113 */     if (this.request.getMethod() == Method.GET)
/*     */     {
/* 115 */       this.form = this.request.getResourceRef().getQueryAsForm();
/* 116 */     } else if (this.request.getMethod() == Method.POST)
/*     */     {
/* 118 */       if ((this.representation != null) && 
/* 119 */         (MediaType.MULTIPART_FORM_DATA.equals(this.mediaType, true))) {
/* 120 */         DiskFileItemFactory fileFactory = new DiskFileItemFactory();
/* 121 */         fileFactory.setSizeThreshold(4194304);
/*     */ 
/* 123 */         RestletFileUpload uploadFile = new RestletFileUpload(
/* 124 */           fileFactory);
/* 125 */         uploadFile.setFileSizeMax(20971520L);
/*     */         try
/*     */         {
/* 128 */           this.fileItems = uploadFile.parseRequest(this.request);
/*     */         } catch (FileUploadException e) {
/* 130 */           this.log.error("文件上传失败");
/* 131 */           throw new SysException("文件上传失败", e);
/*     */         }
/* 133 */         return;
/*     */       }
/*     */ 
/* 137 */       if ((this.representation != null) && 
/* 138 */         (MediaType.APPLICATION_JSON.equals(this.mediaType, true))) {
/*     */         try {
/* 140 */           this.representation.setCharacterSet(CharacterSet.UTF_8);
/* 141 */           String jsonData = null;
/* 142 */           if (this.httpServletRequest.getAttribute("APPLICATION_JSON_JSONOBJECT") != null)
/* 143 */             jsonData = this.httpServletRequest.getAttribute("APPLICATION_JSON_JSONOBJECT").toString();
/*     */           else {
/* 145 */             jsonData = this.representation.getText();
/*     */           }
/* 147 */           if (StringUtil.isEmpty(jsonData)) {
/* 148 */             this.log.error("客户端提交的Json数据为空");
/* 149 */             throw new SysException("客户端提交的Json数据为空！");
/*     */           }
/* 151 */           if ((!jsonData.startsWith("{")) || (!jsonData.endsWith("}"))) {
/* 152 */             throw new SysException("客户端拼装的Json格式不对!");
/*     */           }
/* 154 */           this.jsonObject = new JSONObject(jsonData);
/*     */         } catch (IOException e) {
/* 156 */           this.log.error("出现解析IO异常!");
/* 157 */           throw new SysException("出现解析IO异常!");
/*     */         } catch (JSONException e) {
/* 159 */           this.log.error("客户端拼装的Json串格式不对!");
/* 160 */           throw new SysException("客户端拼装的Json串格式不对!");
/*     */         }
/* 162 */         return;
/*     */       }
/*     */ 
/* 165 */       if ((this.representation != null) && 
/* 166 */         (MediaType.APPLICATION_WWW_FORM.equals(this.mediaType, true))) {
/* 167 */         if ((this.httpServletRequest != null) && 
/* 168 */           (this.httpServletRequest.getHeader("Accept") != null) && 
/* 169 */           (this.httpServletRequest.getHeader("Accept").indexOf(
/* 170 */           "application/json") != -1)) {
/*     */           try {
/* 172 */             Map map = this.httpServletRequest.getParameterMap();
/* 173 */             if (!map.isEmpty()) {
/* 174 */               Set keySet = map.keySet();
/* 175 */               for (String key : keySet)
/* 176 */                 if (StringUtils.isNotBlank(key))
/* 177 */                   this.jsonObject = new JSONObject(key);
/*     */             }
/*     */           }
/*     */           catch (JSONException e)
/*     */           {
/* 182 */             this.log.error("客户端拼装的Json串格式不对!");
/* 183 */             throw new SysException("客户端拼装的Json串格式不对!");
/*     */           }
/* 185 */           return;
/*     */         }
/*     */ 
/* 190 */         this.representation.setCharacterSet(CharacterSet.UTF_8);
/*     */ 
/* 192 */         this.form = new Form(this.representation);
/*     */       }
/* 194 */       return;
/*     */     }
/* 196 */     if ((this.representation != null) && 
/* 197 */       (MediaType.TEXT_XML.equals(this.mediaType, true)))
/*     */     {
/* 203 */       return;
/*     */     }
/* 205 */     if ((this.representation != null) && 
/* 206 */       (MediaType.TEXT_PLAIN.equals(this.mediaType, true))) {
/* 207 */       this.representation.setCharacterSet(CharacterSet.UTF_8);
/* 208 */       setJsonObjectValues();
/* 209 */       this.form = new Form(this.representation);
/* 210 */       return;
/*     */     }
/* 212 */     if ((this.representation != null) && 
/* 213 */       (MediaType.TEXT_HTML.equals(this.mediaType, true))) {
/* 214 */       this.representation.setCharacterSet(CharacterSet.UTF_8);
/* 215 */       setJsonObjectValues();
/* 216 */       this.form = new Form(this.representation);
/* 217 */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void setJsonObjectValues()
/*     */   {
/* 225 */     Map map = this.httpServletRequest.getParameterMap();
/* 226 */     if (!map.isEmpty()) {
/* 227 */       Set keySet = map.keySet();
/* 228 */       for (String key : keySet)
/*     */         try {
/* 230 */           if (StringUtils.isNotBlank(key))
/* 231 */             this.jsonObject.put(key, this.httpServletRequest
/* 232 */               .getParameter(key));
/*     */         }
/*     */         catch (JSONException e) {
/* 235 */           this.log.error("客户端拼装的Json串格式不对!");
/* 236 */           throw new SysException("客户端拼装的Json串格式不对!");
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public JSONObject getJSONObject()
/*     */   {
/* 246 */     return this.jsonObject;
/*     */   }
/*     */ 
/*     */   public String getParameter(String paramName) {
/* 250 */     return this.form.getValues(paramName);
/*     */   }
/*     */ 
/*     */   public String[] getParameters(String paramName) {
/* 254 */     return this.form.getValuesArray(paramName);
/*     */   }
/*     */ 
/*     */   public List<FileItem> getUploadFileItems() {
/* 258 */     return this.fileItems;
/*     */   }
/*     */ 
/*     */   public String[] getParamNames()
/*     */   {
/* 265 */     String[] names = (String[])null;
/* 266 */     Object[] params = this.form.getNames().toArray();
/* 267 */     if ((params == null) || (params.length == 0)) {
/* 268 */       return new String[0];
/*     */     }
/* 270 */     names = new String[params.length];
/* 271 */     int i = 0; for (int len = params.length; i < len; i++) {
/* 272 */       names[i] = params[i].toString();
/*     */     }
/* 274 */     return names;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getParamValueMap() {
/* 278 */     if (this.form == null) {
/* 279 */       return null;
/*     */     }
/* 281 */     return this.form.getValuesMap();
/*     */   }
/*     */ 
/*     */   public String getString(String name)
/*     */   {
/* 291 */     String str = getParameter(name);
/* 292 */     if (str == null) {
/* 293 */       str = "";
/*     */     }
/* 295 */     return str;
/*     */   }
/*     */ 
/*     */   public String getString(String name, String defaultValue)
/*     */   {
/*     */     String str;
/* 309 */     if ((str = getParameter(name)) == null)
/* 310 */       return defaultValue;
/* 311 */     return str;
/*     */   }
/*     */ 
/*     */   public BigDecimal getBigdecimal(String name)
/*     */   {
/* 322 */     return VariantUtil.parseBigDecimal(getParameter(name));
/*     */   }
/*     */ 
/*     */   public BigDecimal getBigdecimal(String name, BigDecimal defaultValue)
/*     */   {
/*     */     String str;
/* 337 */     if ((str = getParameter(name)) == null)
/* 338 */       return defaultValue;
/* 339 */     return VariantUtil.parseBigDecimal(str);
/*     */   }
/*     */ 
/*     */   public int getInt(String name)
/*     */   {
/* 349 */     return VariantUtil.parseInt(getParameter(name));
/*     */   }
/*     */ 
/*     */   public int getInt(String name, int defaultValue)
/*     */   {
/*     */     String str;
/* 361 */     if ((str = getParameter(name)) == null)
/* 362 */       return defaultValue;
/* 363 */     return VariantUtil.parseInt(str);
/*     */   }
/*     */ 
/*     */   public long getLong(String name)
/*     */   {
/* 374 */     return VariantUtil.parseLong(getParameter(name));
/*     */   }
/*     */ 
/*     */   public long getLong(String name, long defaultValue)
/*     */   {
/*     */     String str;
/* 386 */     if ((str = getParameter(name)) == null)
/* 387 */       return defaultValue;
/* 388 */     return VariantUtil.parseLong(str);
/*     */   }
/*     */ 
/*     */   public float getFloat(String name)
/*     */   {
/* 399 */     return VariantUtil.parseFloat(getParameter(name));
/*     */   }
/*     */ 
/*     */   public float getFloat(String name, float defaultValue)
/*     */   {
/*     */     String str;
/* 412 */     if ((str = getParameter(name)) == null)
/* 413 */       return defaultValue;
/* 414 */     return VariantUtil.parseFloat(str);
/*     */   }
/*     */ 
/*     */   public double getDouble(String name)
/*     */   {
/* 424 */     return VariantUtil.parseDouble(getParameter(name));
/*     */   }
/*     */ 
/*     */   public double getDouble(String name, double defaultValue)
/*     */   {
/*     */     String str;
/* 436 */     if ((str = getParameter(name)) == null)
/* 437 */       return defaultValue;
/* 438 */     return VariantUtil.parseDouble(str);
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(String name)
/*     */   {
/* 448 */     return VariantUtil.parseBoolean(getParameter(name));
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(String name, boolean defaultValue)
/*     */   {
/*     */     String str;
/* 460 */     if ((str = getParameter(name)) == null)
/* 461 */       return defaultValue;
/* 462 */     return VariantUtil.parseBoolean(str);
/*     */   }
/*     */ 
/*     */   public Date getDate(String name)
/*     */   {
/* 472 */     return VariantUtil.parseDate(getParameter(name));
/*     */   }
/*     */ 
/*     */   public Date getDate(String name, Date defaultValue)
/*     */   {
/*     */     String str;
/* 485 */     if ((str = getParameter(name)) == null) {
/* 486 */       return defaultValue;
/*     */     }
/* 488 */     return VariantUtil.parseDate(str);
/*     */   }
/*     */ 
/*     */   public String[] getStringValues(String name)
/*     */   {
/* 499 */     String[] values = getParameters(name);
/* 500 */     int len = 0;
/* 501 */     if ((values != null) && ((len = values.length) != 0)) {
/* 502 */       for (int i = 0; i < len; i++) {
/* 503 */         if (values[i] == null) {
/* 504 */           values[i] = "";
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 516 */     return values;
/*     */   }
/*     */ 
/*     */   public void parameterToDO(Object object)
/*     */   {
/* 526 */     if ((object instanceof Map)) {
/* 527 */       parametersToMap((Map)object);
/* 528 */       return;
/*     */     }
/* 530 */     if ((object instanceof VariantSet)) {
/* 531 */       parametersToVariantSet((VariantSet)object);
/* 532 */       return;
/*     */     }
/* 534 */     parametersToBean(object);
/*     */   }
/*     */ 
/*     */   public Map parametersToMap()
/*     */   {
/* 543 */     HashMap hashMap = new HashMap();
/* 544 */     parametersToMap(hashMap);
/* 545 */     return hashMap;
/*     */   }
/*     */ 
/*     */   protected void parametersToBean(Object object)
/*     */   {
/* 555 */     String[] paramNames = getParamNames();
/* 556 */     int i = 0; for (int len = paramNames.length; i < len; i++) {
/* 557 */       String name = paramNames[i];
/* 558 */       String value = getParameter(name);
/* 559 */       BeanUtils.copyProperty(object, name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void parametersToMap(Map map)
/*     */   {
/* 571 */     String[] paramNames = getParamNames();
/* 572 */     int i = 0; for (int len = paramNames.length; i < len; i++) {
/* 573 */       String name = paramNames[i];
/* 574 */       String value = getParameter(name);
/* 575 */       map.put(name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void parametersToVariantSet(VariantSet variantSet)
/*     */   {
/* 585 */     String[] paramNames = getParamNames();
/* 586 */     int i = 0; for (int len = paramNames.length; i < len; i++) {
/* 587 */       String name = paramNames[i];
/* 588 */       variantSet.setString(name, getParameter(name));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void attributiesToDO(Object dest)
/*     */   {
/* 599 */     if ((dest instanceof Map)) {
/* 600 */       attributiesToMap((Map)dest);
/* 601 */       return;
/*     */     }
/* 603 */     if ((dest instanceof VariantSet)) {
/* 604 */       attributiesToVariantSet((VariantSet)dest);
/* 605 */       return;
/*     */     }
/* 607 */     attributiesToBean(dest);
/*     */   }
/*     */ 
/*     */   public Map attributiesToMap()
/*     */   {
/* 616 */     HashMap map = new HashMap();
/* 617 */     attributiesToMap(map);
/* 618 */     return map;
/*     */   }
/*     */ 
/*     */   protected void attributiesToBean(Object dest)
/*     */   {
/* 627 */     Map attributeNames = this.request.getAttributes();
/* 628 */     for (Iterator iterator = attributeNames.entrySet().iterator(); iterator
/* 629 */       .hasNext(); )
/*     */     {
/* 630 */       Map.Entry entry = (Map.Entry)iterator.next();
/* 631 */       BeanUtils.copyProperty(dest, (String)entry.getKey(), entry
/* 632 */         .getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void attributiesToMap(Map map)
/*     */   {
/* 642 */     Map attributeNames = this.request.getAttributes();
/* 643 */     for (Iterator iterator = attributeNames.entrySet().iterator(); iterator
/* 644 */       .hasNext(); )
/*     */     {
/* 645 */       Map.Entry entry = (Map.Entry)iterator.next();
/* 646 */       map.put(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void attributiesToVariantSet(VariantSet variant)
/*     */   {
/* 657 */     Map attributeNames = this.request.getAttributes();
/* 658 */     for (Iterator iterator = attributeNames.entrySet().iterator(); iterator
/* 659 */       .hasNext(); )
/*     */     {
/* 660 */       Map.Entry entry = (Map.Entry)iterator.next();
/* 661 */       variant.setValue((String)entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   public Request getOrginRequest()
/*     */   {
/* 670 */     return this.request;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.rest.BaseRequestImpl
 * JD-Core Version:    0.6.0
 */