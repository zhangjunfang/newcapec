/*     */ package cn.newcapec.framework.base.rest;
/*     */ 
/*     */ import cn.newcapec.framework.base.exception.BaseException;
/*     */ import cn.newcapec.framework.base.exception.ExceptionUtil;
/*     */ import cn.newcapec.framework.base.exception.SysException;
/*     */ import cn.newcapec.framework.base.log.LogEnabled;
/*     */ import cn.newcapec.framework.utils.tools.StringUtil;
/*     */ import com.noelios.restlet.ext.servlet.ServletCall;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.restlet.Context;
/*     */ import org.restlet.data.Conditions;
/*     */ import org.restlet.data.Dimension;
/*     */ import org.restlet.data.MediaType;
/*     */ import org.restlet.data.ReferenceList;
/*     */ import org.restlet.data.Request;
/*     */ import org.restlet.data.Response;
/*     */ import org.restlet.data.Status;
/*     */ import org.restlet.resource.Representation;
/*     */ import org.restlet.resource.Resource;
/*     */ import org.restlet.resource.ResourceException;
/*     */ import org.restlet.resource.Variant;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ 
/*     */ public class BaseResource extends Resource
/*     */   implements InitializingBean, BaseResourceHandler, LogEnabled
/*     */ {
/*  41 */   private net.sf.json.JSONObject jsonObject = new net.sf.json.JSONObject();
/*     */ 
/*  43 */   private Map<String, String> params = new HashMap();
/*     */ 
/*  47 */   private static final String[] ALLOWED_METHODS = { "get", "post", "put", "delete" };
/*     */   private boolean canGet;
/*     */   private boolean canPost;
/*     */   private boolean canPut;
/*     */   private boolean canDelete;
/*     */ 
/*     */   public BaseResource()
/*     */   {
/*  56 */     org.apache.log4j.Logger.getLogger(getClass());
/*     */   }
/*     */ 
/*     */   public BaseResource(Context context, Request request, Response response) {
/*  60 */     super(context, request, response);
/*  61 */     org.apache.log4j.Logger.getLogger(getClass());
/*  62 */     getVariants().add(new Variant(MediaType.ALL));
/*  63 */     String callMethod = request.getMethod().getName();
/*  64 */     log.info("method[" + callMethod + "] call!");
/*     */   }
/*     */ 
/*     */   public void init(Context context, Request request, Response response)
/*     */   {
/*  71 */     beforeHandle(context, request, response);
/*     */ 
/*  73 */     super.init(context, request, response);
/*  74 */     getVariants().add(new Variant(MediaType.ALL));
/*  75 */     String callMethod = request.getMethod().getName();
/*     */ 
/*  77 */     log.info("method[" + callMethod + "] call!");
/*     */ 
/*  79 */     afterHandle(context, request, response);
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/*  91 */     for (String method : ALLOWED_METHODS) {
/*  92 */       if ("get".equals(method.toLowerCase())) {
/*  93 */         this.canGet = true;
/*     */       }
/*  96 */       else if ("put".equals(method.toLowerCase())) {
/*  97 */         this.canPut = false;
/*     */       }
/* 100 */       else if ("post".equals(method.toLowerCase())) {
/* 101 */         this.canPost = true;
/*     */       }
/* 104 */       else if ("delete".equals(method.toLowerCase())) {
/* 105 */         this.canDelete = false;
/*     */       }
/*     */     }
/* 108 */     log.debug("support methods:get=" + this.canGet + ";put=" + this.canPut + 
/* 109 */       ";post=" + this.canPost + ";delete=" + this.canDelete);
/*     */   }
/*     */ 
/*     */   public final boolean allowGet() {
/* 113 */     return this.canGet;
/*     */   }
/*     */ 
/*     */   public final boolean allowPost() {
/* 117 */     return this.canPost;
/*     */   }
/*     */ 
/*     */   public final boolean allowPut() {
/* 121 */     return this.canPut;
/*     */   }
/*     */ 
/*     */   public final boolean allowDelete() {
/* 125 */     return this.canDelete;
/*     */   }
/*     */ 
/*     */   public void handleGet()
/*     */   {
/* 130 */     if (!isAvailable()) {
/* 131 */       getResponse().setStatus(Status.CLIENT_ERROR_NOT_FOUND);
/*     */     } else {
/* 133 */       Representation selectedRepresentation = null;
/*     */ 
/* 135 */       List variants = getVariants();
/* 136 */       if ((variants == null) || (variants.isEmpty()))
/*     */       {
/* 138 */         getResponse().setStatus(Status.CLIENT_ERROR_NOT_FOUND);
/* 139 */         getLogger().warning("A resource should normally have at least one variant added by calling getVariants().add() in the constructor. Check your resource \"" + 
/* 140 */           getRequest().getResourceRef() + "\".");
/*     */       }
/*     */       else
/*     */       {
/*     */         Variant variant;
/* 141 */         if (isNegotiateContent()) {
/* 142 */           Variant preferredVariant = getPreferredVariant();
/*     */ 
/* 144 */           if (preferredVariant == null) {
/* 145 */             getResponse().setStatus(Status.CLIENT_ERROR_NOT_ACCEPTABLE);
/*     */ 
/* 147 */             ReferenceList refs = new ReferenceList(
/* 148 */               variants.size());
/* 149 */             for (Iterator localIterator = variants.iterator(); localIterator.hasNext(); ) { variant = (Variant)localIterator.next();
/* 150 */               if (variant.getIdentifier() != null) {
/* 151 */                 refs.add(variant.getIdentifier());
/*     */               }
/*     */             }
/*     */ 
/* 155 */             getResponse().setEntity(refs.getTextRepresentation());
/*     */           } else {
/* 157 */             getResponse().getDimensions().clear();
/* 158 */             getResponse().getDimensions().add(Dimension.CHARACTER_SET);
/* 159 */             getResponse().getDimensions().add(Dimension.ENCODING);
/* 160 */             getResponse().getDimensions().add(Dimension.LANGUAGE);
/* 161 */             getResponse().getDimensions().add(Dimension.MEDIA_TYPE);
/* 162 */             callMethod();
/*     */           }
/*     */ 
/* 165 */           selectedRepresentation = getResponse().getEntity();
/*     */         }
/* 167 */         else if (variants.size() == 1) {
/* 168 */           callMethod();
/* 169 */           selectedRepresentation = getResponse().getEntity();
/*     */         } else {
/* 171 */           ReferenceList variantRefs = new ReferenceList();
/*     */ 
/* 173 */           for (Variant variant : variants) {
/* 174 */             if (variant.getIdentifier() != null)
/* 175 */               variantRefs.add(variant.getIdentifier());
/*     */             else {
/* 177 */               getLogger().warning("A resource with multiple variants should provide an identifier for each variant when content negotiation is turned off");
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 182 */           if (variantRefs.size() > 0) {
/* 183 */             getResponse().setStatus(
/* 184 */               Status.REDIRECTION_MULTIPLE_CHOICES);
/* 185 */             getResponse().setEntity(
/* 186 */               variantRefs.getTextRepresentation());
/*     */           } else {
/* 188 */             getResponse().setStatus(Status.CLIENT_ERROR_NOT_FOUND);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 193 */       if (selectedRepresentation == null) {
/* 194 */         if ((getResponse().getStatus() == null) || (
/* 195 */           (getResponse().getStatus().isSuccess()) && 
/* 196 */           (!Status.SUCCESS_NO_CONTENT
/* 196 */           .equals(getResponse().getStatus())))) {
/* 197 */           getResponse().setStatus(Status.CLIENT_ERROR_NOT_FOUND);
/*     */         }
/*     */ 
/*     */       }
/* 201 */       else if (getRequest().getConditions().hasSome()) {
/* 202 */         Status status = getRequest().getConditions()
/* 203 */           .getStatus(getRequest().getMethod(), 
/* 204 */           selectedRepresentation);
/*     */ 
/* 206 */         if (status != null) {
/* 207 */           log.error(status);
/* 208 */           getResponse().setStatus(status);
/* 209 */           getResponse().setEntity(null);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void storeRepresentation(Representation entity)
/*     */     throws ResourceException
/*     */   {
/* 228 */     callMethod();
/*     */   }
/*     */ 
/*     */   public final void acceptRepresentation(Representation entity)
/*     */     throws ResourceException
/*     */   {
/* 241 */     callMethod();
/*     */   }
/*     */ 
/*     */   public final void removeRepresentations() throws ResourceException
/*     */   {
/* 246 */     callMethod();
/*     */   }
/*     */ 
/*     */   private void callMethod()
/*     */   {
/*     */     try
/*     */     {
/* 256 */       String methodName = String.valueOf(getRequest().getAttributes().get("method"));
/* 257 */       if (StringUtil.isEmpty(methodName)) {
/* 258 */         log.error("URI拼写错误，请按正确的方式拼写：服务/操作");
/* 259 */         throw new SysException("URI拼写错误，请按正确的方式拼写：服务/操作");
/*     */       }
/*     */       try
/*     */       {
/* 263 */         java.lang.reflect.Method callMethod = getClass().getMethod(
/* 264 */           methodName, 
/* 265 */           new Class[] { BaseRequest.class, BaseResponse.class });
/* 266 */         if (callMethod == null) {
/* 267 */           throw new SysException("未找到对应的方法[" + methodName + "]！");
/*     */         }
/*     */ 
/* 270 */         BaseResponse baseResponse = new BaseResponseImpl(getResponse());
/* 271 */         BaseRequest baseRequest = new BaseRequestImpl(getRequest());
/* 272 */         if (baseRequest.getJSONObject() != null) {
/* 273 */           this.jsonObject = net.sf.json.JSONObject.fromObject(baseRequest.getJSONObject().toString());
/* 274 */           HttpServletRequest httpServletRequest = ServletCall.getRequest(getRequest());
/* 275 */           httpServletRequest.setCharacterEncoding("utf-8");
/* 276 */           this.params = httpServletRequest.getParameterMap();
/* 277 */           if (!this.params.isEmpty()) {
/* 278 */             Set keySet = this.params.keySet();
/* 279 */             for (String key : keySet) {
/*     */               try {
/* 281 */                 if (StringUtils.isNotBlank(key))
/* 282 */                   this.jsonObject.put(key, httpServletRequest
/* 283 */                     .getParameter(key));
/*     */               }
/*     */               catch (Exception e) {
/* 286 */                 log.error("客户端拼装的Json串格式不对!");
/* 287 */                 throw new SysException("客户端拼装的Json串格式不对!");
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 294 */           this.params = baseRequest.getParamValueMap();
/* 295 */           this.jsonObject = net.sf.json.JSONObject.fromObject(this.params);
/*     */         }
/* 297 */         callMethod.invoke(this, new Object[] { baseRequest, baseResponse });
/*     */       }
/*     */       catch (NoSuchMethodException e)
/*     */       {
/* 301 */         throw new SysException("未找到对应的方法[" + methodName + "]！");
/*     */       }
/*     */     } catch (Exception ex) {
/*     */       try {
/* 305 */         if ((ex instanceof BaseException))
/*     */         {
/* 307 */           ExceptionUtil.extractException(ex);
/*     */         }
/* 309 */         else if ((ex instanceof SysException))
/* 310 */           ExceptionUtil.extractException(ex);
/*     */         else {
/* 312 */           ExceptionUtil.extractException(ex);
/*     */         }
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 317 */         String errMsg = e.getMessage();
/* 318 */         if (StringUtil.isValid(errMsg))
/* 319 */           getResponse().setEntity(
/* 320 */             new BaseRepresention(false, errMsg));
/*     */         else
/* 322 */           getResponse().setEntity(
/* 323 */             new BaseRepresention(false, "服务端处理发生错误，请尝试重新操作！"));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public net.sf.json.JSONObject getJsonObject()
/*     */   {
/* 331 */     return this.jsonObject;
/*     */   }
/*     */ 
/*     */   public void beforeHandle(Context context, Request request, Response response)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void afterHandle(Context context, Request request, Response response)
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.rest.BaseResource
 * JD-Core Version:    0.6.0
 */