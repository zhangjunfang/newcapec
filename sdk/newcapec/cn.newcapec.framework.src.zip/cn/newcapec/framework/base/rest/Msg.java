/*     */ package cn.newcapec.framework.base.rest;
/*     */ 
/*     */ import cn.newcapec.framework.utils.tools.JsonDateValueProcessor;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import net.sf.json.JSONObject;
/*     */ import net.sf.json.JsonConfig;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.restlet.data.CharacterSet;
/*     */ import org.restlet.data.MediaType;
/*     */ import org.restlet.resource.Representation;
/*     */ import org.restlet.resource.StringRepresentation;
/*     */ 
/*     */ public class Msg
/*     */ {
/*  28 */   protected Logger log = Logger.getLogger(getClass());
/*     */ 
/*  32 */   private boolean success = false;
/*     */   private String msg;
/*     */   private String code;
/*     */   private Object data;
/*     */ 
/*     */   public Msg()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Msg(String msg)
/*     */   {
/*  54 */     this(true, msg);
/*     */   }
/*     */ 
/*     */   public Msg(boolean success, String msg)
/*     */   {
/*  64 */     this(success, msg, null);
/*     */   }
/*     */ 
/*     */   public Msg(String msg, Object data)
/*     */   {
/*  76 */     this(true, msg, null);
/*     */   }
/*     */ 
/*     */   public Msg(boolean success, String msg, Object data)
/*     */   {
/*  87 */     this.msg = msg;
/*  88 */     this.success = success;
/*  89 */     if ((data == null) || ("null".equals(data)))
/*  90 */       this.data = "";
/*     */     else
/*  92 */       this.data = data;
/*     */   }
/*     */ 
/*     */   public Object getData()
/*     */   {
/*  99 */     return this.data;
/*     */   }
/*     */ 
/*     */   public Msg setData(Object data)
/*     */   {
/* 107 */     this.data = data;
/* 108 */     return this;
/*     */   }
/*     */ 
/*     */   public String getMsg()
/*     */   {
/* 115 */     return this.msg;
/*     */   }
/*     */ 
/*     */   public Msg setMsg(String msg)
/*     */   {
/* 123 */     this.msg = msg;
/* 124 */     return this;
/*     */   }
/*     */ 
/*     */   public boolean isSuccess()
/*     */   {
/* 131 */     return this.success;
/*     */   }
/*     */ 
/*     */   public String getCode()
/*     */   {
/* 136 */     return this.code;
/*     */   }
/*     */ 
/*     */   public void setCode(String code) {
/* 140 */     this.code = code;
/*     */   }
/*     */ 
/*     */   public Msg setSuccess(boolean success)
/*     */   {
/* 162 */     this.success = success;
/* 163 */     return this;
/*     */   }
/*     */ 
/*     */   public JSONObject toJSONObject()
/*     */   {
/* 172 */     return toJSONObject(null);
/*     */   }
/*     */ 
/*     */   public JsonConfig getJsonConfig(String dateFormat)
/*     */   {
/* 178 */     JsonConfig config = new JsonConfig();
/* 179 */     SimpleDateFormat format = new SimpleDateFormat(dateFormat);
/*     */ 
/* 181 */     config.registerJsonValueProcessor(Date.class, new JsonDateValueProcessor());
/* 182 */     config.registerJsonValueProcessor(Timestamp.class, new JsonDateValueProcessor());
/* 183 */     return config;
/*     */   }
/*     */ 
/*     */   public JSONObject toJSONObject(String[] names)
/*     */   {
/* 194 */     String format = "yyyy-MM-dd HH:mm:ss";
/* 195 */     JSONObject jsonObject = new JSONObject();
/* 196 */     String newMsg = this.msg == null ? "" : this.msg;
/* 197 */     setMsg(newMsg);
/* 198 */     jsonObject = JSONObject.fromObject(this, getJsonConfig(format));
/* 199 */     return jsonObject;
/*     */   }
/*     */ 
/*     */   public Representation toJSONObjectPresention()
/*     */   {
/* 210 */     return toJSONObjectPresention(null);
/*     */   }
/*     */ 
/*     */   public Representation toJSONObjectPresention(String[] names)
/*     */   {
/* 223 */     return new StringRepresentation(toJSONObject(names).toString().replaceAll("null", "\"\""), 
/* 224 */       MediaType.TEXT_PLAIN, null, CharacterSet.UTF_8);
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.rest.Msg
 * JD-Core Version:    0.6.0
 */