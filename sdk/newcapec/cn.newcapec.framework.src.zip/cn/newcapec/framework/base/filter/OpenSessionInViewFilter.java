/*    */ package cn.newcapec.framework.base.filter;
/*    */ 
/*    */ import org.hibernate.FlushMode;
/*    */ import org.hibernate.Session;
/*    */ import org.hibernate.SessionFactory;
/*    */ import org.hibernate.Transaction;
/*    */ import org.springframework.dao.DataAccessResourceFailureException;
/*    */ import org.springframework.orm.hibernate3.SessionFactoryUtils;
/*    */ 
/*    */ public class OpenSessionInViewFilter extends org.springframework.orm.hibernate3.support.OpenSessionInViewFilter
/*    */ {
/*    */   protected void closeSession(Session session, SessionFactory sessionFactory)
/*    */   {
/* 19 */     session.flush();
/* 20 */     session.getTransaction().commit();
/* 21 */     super.closeSession(session, sessionFactory);
/*    */   }
/*    */ 
/*    */   protected Session getSession(SessionFactory sessionFactory)
/*    */     throws DataAccessResourceFailureException
/*    */   {
/* 27 */     Session session = SessionFactoryUtils.getSession(sessionFactory, true);
/* 28 */     session.beginTransaction();
/* 29 */     FlushMode flushMode = getFlushMode();
/* 30 */     if (flushMode != null) {
/* 31 */       setFlushMode(FlushMode.AUTO);
/*    */     }
/* 33 */     return session;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.filter.OpenSessionInViewFilter
 * JD-Core Version:    0.6.0
 */