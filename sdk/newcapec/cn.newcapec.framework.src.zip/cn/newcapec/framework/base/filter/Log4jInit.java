/*    */ package cn.newcapec.framework.base.filter;
/*    */ 
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.util.Properties;
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import org.apache.log4j.PropertyConfigurator;
/*    */ 
/*    */ public class Log4jInit extends HttpServlet
/*    */ {
/*    */   public void init(ServletConfig config)
/*    */     throws ServletException
/*    */   {
/* 17 */     String prefix = config.getServletContext().getRealPath("/");
/* 18 */     String file = config.getInitParameter("log4j");
/* 19 */     String filePath = prefix + file;
/* 20 */     Properties props = new Properties();
/*    */     try {
/* 22 */       FileInputStream istream = new FileInputStream(filePath);
/* 23 */       props.load(istream);
/* 24 */       istream.close();
/*    */ 
/* 26 */       String logFile = prefix + props.getProperty("log4j.appender.file.File");
/* 27 */       props.setProperty("log4j.appender.file.File", logFile);
/* 28 */       PropertyConfigurator.configure(props);
/*    */     } catch (IOException e) {
/* 30 */       toPrint("Could not read configuration file [" + filePath + "].");
/* 31 */       toPrint("Ignoring configuration file [" + filePath + "].");
/* 32 */       return;
/*    */     }
/*    */   }
/*    */ 
/*    */   public static void toPrint(String content) {
/* 37 */     System.out.println(content);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.filter.Log4jInit
 * JD-Core Version:    0.6.0
 */