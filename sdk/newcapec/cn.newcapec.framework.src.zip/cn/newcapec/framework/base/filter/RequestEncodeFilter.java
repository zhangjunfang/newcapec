/*    */ package cn.newcapec.framework.base.filter;
/*    */ 
/*    */ import cn.newcapec.foundation.utils.WebUtils;
/*    */ import java.io.IOException;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
/*    */ public class RequestEncodeFilter
/*    */   implements Filter
/*    */ {
/*    */   private static final long serialVersionUID = 1530445419380216782L;
/*    */   private String fromChartSet;
/*    */   private String toChartSet;
/*    */ 
/*    */   public RequestEncodeFilter()
/*    */   {
/* 31 */     this.fromChartSet = "iso8859-1";
/*    */ 
/* 33 */     this.toChartSet = "UTF-8";
/*    */   }
/*    */ 
/*    */   public void setFromChartSet(String fromChartSet)
/*    */   {
/* 39 */     this.fromChartSet = fromChartSet;
/*    */   }
/*    */ 
/*    */   public void setToChartSet(String toChartSet)
/*    */   {
/* 44 */     this.toChartSet = toChartSet;
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain arg2)
/*    */     throws IOException, ServletException
/*    */   {
/* 57 */     HttpServletRequest httpServletRequest = (HttpServletRequest)request;
/* 58 */     String method = httpServletRequest.getMethod();
/* 59 */     if (method.equalsIgnoreCase("get"))
/*    */     {
/* 61 */       WebUtils.requestConvertEncode(httpServletRequest, this.fromChartSet, this.toChartSet);
/* 62 */     } else if (method.equalsIgnoreCase("post"))
/*    */     {
/* 64 */       String qs = httpServletRequest.getQueryString();
/* 65 */       if (qs != null)
/*    */       {
/* 67 */         WebUtils.requestConvertPostUrlEncode(httpServletRequest, this.fromChartSet, this.toChartSet, new String(qs.getBytes(this.fromChartSet), this.toChartSet));
/*    */       }
/*    */     }
/* 70 */     arg2.doFilter(request, response);
/*    */   }
/*    */ 
/*    */   public void init(FilterConfig arg0)
/*    */     throws ServletException
/*    */   {
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.filter.RequestEncodeFilter
 * JD-Core Version:    0.6.0
 */