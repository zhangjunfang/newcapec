/*    */ package cn.newcapec.framework.base.filter;
/*    */ 
/*    */ import cn.newcapec.framework.base.log.LogEnabled;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ 
/*    */ public abstract class IFilter
/*    */   implements Filter, LogEnabled
/*    */ {
/* 14 */   protected FilterConfig config = null;
/*    */ 
/*    */   public void init(FilterConfig config)
/*    */     throws ServletException
/*    */   {
/* 22 */     this.config = config;
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/* 31 */     this.config = null;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.filter.IFilter
 * JD-Core Version:    0.6.0
 */