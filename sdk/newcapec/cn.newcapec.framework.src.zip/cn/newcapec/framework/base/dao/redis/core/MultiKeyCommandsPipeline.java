package cn.newcapec.framework.base.dao.redis.core;

import java.util.List;
import java.util.Set;

public abstract interface MultiKeyCommandsPipeline
{
  public abstract Response<Long> del(String[] paramArrayOfString);

  public abstract Response<List<String>> blpop(String[] paramArrayOfString);

  public abstract Response<List<String>> brpop(String[] paramArrayOfString);

  public abstract Response<Set<String>> keys(String paramString);

  public abstract Response<List<String>> mget(String[] paramArrayOfString);

  public abstract Response<String> mset(String[] paramArrayOfString);

  public abstract Response<Long> msetnx(String[] paramArrayOfString);

  public abstract Response<String> rename(String paramString1, String paramString2);

  public abstract Response<Long> renamenx(String paramString1, String paramString2);

  public abstract Response<String> rpoplpush(String paramString1, String paramString2);

  public abstract Response<Set<String>> sdiff(String[] paramArrayOfString);

  public abstract Response<Long> sdiffstore(String paramString, String[] paramArrayOfString);

  public abstract Response<Set<String>> sinter(String[] paramArrayOfString);

  public abstract Response<Long> sinterstore(String paramString, String[] paramArrayOfString);

  public abstract Response<Long> smove(String paramString1, String paramString2, String paramString3);

  public abstract Response<List<String>> sort(String paramString1, SortingParams paramSortingParams, String paramString2);

  public abstract Response<List<String>> sort(String paramString1, String paramString2);

  public abstract Response<Set<String>> sunion(String[] paramArrayOfString);

  public abstract Response<Long> sunionstore(String paramString, String[] paramArrayOfString);

  public abstract Response<String> watch(String[] paramArrayOfString);

  public abstract Response<Long> zinterstore(String paramString, String[] paramArrayOfString);

  public abstract Response<Long> zinterstore(String paramString, ZParams paramZParams, String[] paramArrayOfString);

  public abstract Response<Long> zunionstore(String paramString, String[] paramArrayOfString);

  public abstract Response<Long> zunionstore(String paramString, ZParams paramZParams, String[] paramArrayOfString);

  public abstract Response<String> brpoplpush(String paramString1, String paramString2, int paramInt);

  public abstract Response<Long> publish(String paramString1, String paramString2);

  public abstract Response<String> randomKey();

  public abstract Response<Long> bitop(BitOP paramBitOP, String paramString, String[] paramArrayOfString);
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.MultiKeyCommandsPipeline
 * JD-Core Version:    0.6.0
 */