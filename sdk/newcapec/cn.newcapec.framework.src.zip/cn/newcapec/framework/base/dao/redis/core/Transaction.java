/*    */ package cn.newcapec.framework.base.dao.redis.core;
/*    */ 
/*    */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisDataException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Transaction extends MultiKeyPipelineBase
/*    */ {
/* 13 */   protected boolean inTransaction = true;
/*    */ 
/*    */   protected Transaction()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Transaction(Client client) {
/* 20 */     this.client = client;
/*    */   }
/*    */ 
/*    */   protected Client getClient(String key)
/*    */   {
/* 25 */     return this.client;
/*    */   }
/*    */ 
/*    */   protected Client getClient(byte[] key)
/*    */   {
/* 30 */     return this.client;
/*    */   }
/*    */ 
/*    */   public List<Object> exec() {
/* 34 */     this.client.exec();
/* 35 */     this.client.getAll(1);
/*    */ 
/* 37 */     List unformatted = this.client.getObjectMultiBulkReply();
/* 38 */     if (unformatted == null) {
/* 39 */       return null;
/*    */     }
/* 41 */     List formatted = new ArrayList();
/* 42 */     for (Iterator localIterator = unformatted.iterator(); localIterator.hasNext(); ) { Object o = localIterator.next();
/*    */       try {
/* 44 */         formatted.add(generateResponse(o).get());
/*    */       } catch (JedisDataException e) {
/* 46 */         formatted.add(e);
/*    */       }
/*    */     }
/* 49 */     return formatted;
/*    */   }
/*    */ 
/*    */   public List<Response<?>> execGetResponse() {
/* 53 */     this.client.exec();
/* 54 */     this.client.getAll(1);
/*    */ 
/* 56 */     List unformatted = this.client.getObjectMultiBulkReply();
/* 57 */     if (unformatted == null) {
/* 58 */       return null;
/*    */     }
/* 60 */     List response = new ArrayList();
/* 61 */     for (Iterator localIterator = unformatted.iterator(); localIterator.hasNext(); ) { Object o = localIterator.next();
/* 62 */       response.add(generateResponse(o));
/*    */     }
/* 64 */     return response;
/*    */   }
/*    */ 
/*    */   public String discard() {
/* 68 */     this.client.discard();
/* 69 */     this.client.getAll(1);
/* 70 */     this.inTransaction = false;
/* 71 */     clean();
/* 72 */     return this.client.getStatusCodeReply();
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.Transaction
 * JD-Core Version:    0.6.0
 */