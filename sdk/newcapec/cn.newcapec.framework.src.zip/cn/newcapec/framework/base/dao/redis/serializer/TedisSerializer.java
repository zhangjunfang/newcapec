package cn.newcapec.framework.base.dao.redis.serializer;

import cn.newcapec.framework.base.dao.redis.exception.SerializationException;

public abstract interface TedisSerializer<T>
{
  public abstract byte[] serialize(T paramT)
    throws SerializationException;

  public abstract T deserialize(byte[] paramArrayOfByte)
    throws SerializationException;
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.serializer.TedisSerializer
 * JD-Core Version:    0.6.0
 */