package cn.newcapec.framework.base.dao.redis.core;

import java.util.List;

public abstract interface BinaryScriptingCommands
{
  public abstract Object eval(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[][] paramArrayOfByte);

  public abstract Object eval(byte[] paramArrayOfByte, int paramInt, byte[][] paramArrayOfByte1);

  public abstract Object eval(byte[] paramArrayOfByte, List<byte[]> paramList1, List<byte[]> paramList2);

  public abstract Object eval(byte[] paramArrayOfByte);

  public abstract Object evalsha(byte[] paramArrayOfByte);

  public abstract Object evalsha(byte[] paramArrayOfByte, List<byte[]> paramList1, List<byte[]> paramList2);

  public abstract Object evalsha(byte[] paramArrayOfByte, int paramInt, byte[][] paramArrayOfByte1);

  public abstract List<Long> scriptExists(byte[][] paramArrayOfByte);

  public abstract byte[] scriptLoad(byte[] paramArrayOfByte);

  public abstract String scriptFlush();

  public abstract String scriptKill();
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.BinaryScriptingCommands
 * JD-Core Version:    0.6.0
 */