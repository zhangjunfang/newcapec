/*    */ package cn.newcapec.framework.base.dao.redis.util;
/*    */ 
/*    */ import java.security.MessageDigest;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ 
/*    */ public abstract interface Hashing
/*    */ {
/*  7 */   public static final Hashing MURMUR_HASH = new MurmurHash();
/*  8 */   public static final ThreadLocal<MessageDigest> md5Holder = new ThreadLocal();
/*    */ 
/* 10 */   public static final Hashing MD5 = new Hashing() {
/*    */     public long hash(String key) {
/* 12 */       return hash(SafeEncoder.encode(key));
/*    */     }
/*    */ 
/*    */     public long hash(byte[] key) {
/*    */       try {
/* 17 */         if (md5Holder.get() == null)
/* 18 */           md5Holder.set(MessageDigest.getInstance("MD5"));
/*    */       }
/*    */       catch (NoSuchAlgorithmException e) {
/* 21 */         throw new IllegalStateException("++++ no md5 algorythm found");
/*    */       }
/* 23 */       MessageDigest md5 = (MessageDigest)md5Holder.get();
/*    */ 
/* 25 */       md5.reset();
/* 26 */       md5.update(key);
/* 27 */       byte[] bKey = md5.digest();
/* 28 */       long res = (bKey[3] & 0xFF) << 24 | 
/* 29 */         (bKey[2] & 0xFF) << 16 | 
/* 30 */         (bKey[1] & 0xFF) << 8 | bKey[0] & 0xFF;
/* 31 */       return res;
/*    */     }
/* 10 */   };
/*    */ 
/*    */   public abstract long hash(String paramString);
/*    */ 
/*    */   public abstract long hash(byte[] paramArrayOfByte);
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.util.Hashing
 * JD-Core Version:    0.6.0
 */