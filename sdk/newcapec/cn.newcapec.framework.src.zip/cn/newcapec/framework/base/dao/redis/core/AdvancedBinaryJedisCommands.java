package cn.newcapec.framework.base.dao.redis.core;

import java.util.List;

public abstract interface AdvancedBinaryJedisCommands
{
  public abstract List<byte[]> configGet(byte[] paramArrayOfByte);

  public abstract byte[] configSet(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract String slowlogReset();

  public abstract Long slowlogLen();

  public abstract List<byte[]> slowlogGetBinary();

  public abstract List<byte[]> slowlogGetBinary(long paramLong);

  public abstract Long objectRefcount(byte[] paramArrayOfByte);

  public abstract byte[] objectEncoding(byte[] paramArrayOfByte);

  public abstract Long objectIdletime(byte[] paramArrayOfByte);
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.AdvancedBinaryJedisCommands
 * JD-Core Version:    0.6.0
 */