/*     */ package cn.newcapec.framework.base.dao.db;
/*     */ 
/*     */ import cn.newcapec.framework.base.exception.BaseException;
/*     */ import cn.newcapec.framework.utils.Page;
/*     */ import cn.newcapec.framework.utils.tools.BeanUtils;
/*     */ import cn.newcapec.framework.utils.tools.DBUtil;
/*     */ import cn.newcapec.framework.utils.tools.JsonUtil;
/*     */ import cn.newcapec.framework.utils.tools.MathUtil;
/*     */ import cn.newcapec.framework.utils.tools.StringUtil;
/*     */ import cn.newcapec.framework.utils.variant.VariantSet;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.sf.json.JSONArray;
/*     */ import net.sf.json.JSONException;
/*     */ import net.sf.json.JSONObject;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.restlet.data.CharacterSet;
/*     */ import org.restlet.data.MediaType;
/*     */ import org.restlet.resource.Representation;
/*     */ import org.restlet.resource.StringRepresentation;
/*     */ 
/*     */ public class DbDataset
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -2042432252201796659L;
/* 188 */   private Logger log = Logger.getLogger(getClass());
/*     */ 
/* 192 */   private ParameterSet parameterSet = new ParameterSet();
/*     */ 
/* 194 */   private String sql = null;
/*     */ 
/* 199 */   private boolean supportPaging = true;
/*     */ 
/* 204 */   public static final Class DEFUALT_ENTITY_CLAZZ = Record.class;
/*     */   public static final int DEFAULT_PAGING_SIZE = 20;
/*     */   private Class clazz;
/*     */   private int pageCount;
/*     */   private int currPageRowCount;
/*     */   private int pageIndex;
/* 233 */   private int pageSize = 20;
/*     */   private long possibleRecordCount;
/*     */   private List data;
/*     */ 
/*     */   public DbDataset()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DbDataset(String sql, ParameterSet params, boolean supportPaging, int pageIndex, int pageSize)
/*     */   {
/*  65 */     setSql(sql);
/*  66 */     if (params != null) {
/*  67 */       this.parameterSet = params;
/*     */     }
/*  69 */     setSupportPaging(supportPaging);
/*  70 */     setPageIndex(pageIndex);
/*  71 */     setPageSize(pageSize);
/*     */   }
/*     */ 
/*     */   public DbDataset(String sql, ParameterSet params, boolean supportPaging, String pageIndex, String pageSize)
/*     */   {
/*  91 */     this(sql, params, supportPaging, MathUtil.getInteger(pageIndex)
/*  91 */       .intValue(), MathUtil.getInteger(pageSize).intValue());
/*     */   }
/*     */ 
/*     */   public DbDataset(String sql, ParameterSet params, boolean supportPaging)
/*     */   {
/* 105 */     this(sql, params, supportPaging, 1, 20);
/*     */   }
/*     */ 
/*     */   public DbDataset(String sql, ParameterSet params, int pageIndex, int pageSize)
/*     */   {
/* 123 */     this(sql, params, true, pageIndex, pageSize);
/*     */   }
/*     */ 
/*     */   public DbDataset(String sql, ParameterSet params, String pageIndex, String pageSize)
/*     */   {
/* 141 */     this(sql, params, true, MathUtil.getInteger(pageIndex).intValue(), 
/* 141 */       MathUtil.getInteger(pageSize).intValue());
/*     */   }
/*     */ 
/*     */   public DbDataset(String sql, String pageIndex, String pageSize)
/*     */   {
/* 158 */     this(sql, null, true, MathUtil.getInteger(pageIndex).intValue(), 
/* 158 */       MathUtil.getInteger(pageSize).intValue());
/*     */   }
/*     */ 
/*     */   public DbDataset(String sql, int pageIndex, int pageSize)
/*     */   {
/* 175 */     this(sql, null, true, pageIndex, pageSize);
/*     */   }
/*     */ 
/*     */   public DbDataset(String sql)
/*     */   {
/* 185 */     this(sql, null, true, 1, 20);
/*     */   }
/*     */ 
/*     */   public ParameterSet parameters()
/*     */   {
/* 248 */     if (this.parameterSet == null) {
/* 249 */       this.parameterSet = new ParameterSet();
/*     */     }
/* 251 */     return this.parameterSet;
/*     */   }
/*     */ 
/*     */   public DbDataset setParameter(String name, Object value)
/*     */   {
/* 264 */     parameters().setValue(name, value);
/* 265 */     return this;
/*     */   }
/*     */ 
/*     */   public DbDataset setParameters(Map map, String[] names)
/*     */   {
/* 279 */     if ((map == null) || (map.isEmpty())) {
/* 280 */       return this;
/*     */     }
/*     */ 
/* 283 */     if ((names == null) || (names.length == 0)) {
/* 284 */       for (Iterator iterator = map.entrySet().iterator(); iterator
/* 285 */         .hasNext(); )
/*     */       {
/* 286 */         Map.Entry entry = (Map.Entry)iterator.next();
/* 287 */         parameters().setValue(entry.getKey().toString(), 
/* 288 */           entry.getValue());
/*     */       }
/*     */     }
/*     */     else {
/* 292 */       for (Iterator iterator = map.entrySet().iterator(); iterator
/* 293 */         .hasNext(); )
/*     */       {
/* 294 */         Map.Entry entry = (Map.Entry)iterator.next();
/* 295 */         if (isExists(names, entry.getKey().toString())) {
/* 296 */           parameters().setValue(entry.getKey().toString(), 
/* 297 */             entry.getValue());
/*     */         }
/*     */       }
/*     */     }
/* 301 */     return this;
/*     */   }
/*     */ 
/*     */   public DbDataset setParameters(Map map)
/*     */   {
/* 312 */     return setParameters(map, null);
/*     */   }
/*     */ 
/*     */   public DbDataset setParameters(Object obj)
/*     */   {
/* 322 */     return setParameters(BeanUtils.describe(obj), null);
/*     */   }
/*     */ 
/*     */   public DbDataset setParameters(Object obj, String[] names)
/*     */   {
/* 336 */     return setParameters(BeanUtils.describe(obj), names);
/*     */   }
/*     */ 
/*     */   public DbDataset setParameters(VariantSet variantSet, String[] names)
/*     */   {
/* 349 */     int len = 0;
/* 350 */     if ((variantSet == null) || ((len = variantSet.count()) == 0)) {
/* 351 */       this.log.error("varinatSet 参数 为空！");
/* 352 */       return this;
/*     */     }
/* 354 */     if ((names == null) || (names.length == 0)) {
/* 355 */       for (int i = 0; i < len; i++) {
/* 356 */         parameters().setValue(variantSet.indexToName(i), 
/* 357 */           variantSet.getValue(i));
/*     */       }
/*     */     }
/*     */     else {
/* 361 */       for (int i = 0; i < len; i++) {
/* 362 */         String key = variantSet.indexToName(i);
/* 363 */         if (isExists(names, key)) {
/* 364 */           parameters().setValue(variantSet.indexToName(i), 
/* 365 */             variantSet.getValue(i));
/*     */         }
/*     */       }
/*     */     }
/* 369 */     return this;
/*     */   }
/*     */ 
/*     */   public DbDataset setParameters(VariantSet variantSet)
/*     */   {
/* 382 */     return setParameters(variantSet, null);
/*     */   }
/*     */ 
/*     */   public Object getParameter(String name)
/*     */   {
/* 392 */     return parameters().getValue(name);
/*     */   }
/*     */ 
/*     */   public Class getClazz() {
/* 396 */     return this.clazz;
/*     */   }
/*     */ 
/*     */   public DbDataset setClazz(Class clazz)
/*     */   {
/* 406 */     this.clazz = clazz;
/* 407 */     return this;
/*     */   }
/*     */ 
/*     */   public int getPageCount() {
/* 411 */     return this.pageCount;
/*     */   }
/*     */ 
/*     */   public int getPageIndex() {
/* 415 */     return this.pageIndex;
/*     */   }
/*     */ 
/*     */   public DbDataset loadData()
/*     */   {
/* 426 */     if (StringUtil.isEmpty(this.sql)) {
/* 427 */       throw new BaseException("请设置dataset SQl!");
/*     */     }
/*     */ 
/* 430 */     String parsedSQl = translateSql(this.sql);
/* 431 */     if (StringUtil.isEmpty(parsedSQl)) {
/* 432 */       throw new BaseException("dataset SQl 解析错误!");
/*     */     }
/*     */ 
/* 435 */     String querySQL = doGetSql(parsedSQl);
/*     */ 
/* 437 */     Object[] parameters = doGetSqlParameters(parsedSQl);
/*     */ 
/* 439 */     Class modelClazz = DEFUALT_ENTITY_CLAZZ;
/* 440 */     if (getClazz() != null) {
/* 441 */       modelClazz = getClazz();
/*     */     }
/*     */ 
/* 444 */     if (isSupportPaging())
/*     */     {
/* 446 */       PagingResultSet pagePagingResultSet = DBUtil.getPagingResultSet(
/* 447 */         querySQL, parameters, modelClazz, this.pageSize, this.pageIndex);
/*     */ 
/* 449 */       setData(pagePagingResultSet.getData());
/*     */ 
/* 451 */       setPageCount(pagePagingResultSet.getPageCount());
/*     */ 
/* 453 */       setCurrPageRowCount(getData().size());
/*     */ 
/* 455 */       setPageIndex(pagePagingResultSet.getPageIndex());
/*     */ 
/* 457 */       setPossibleRecordCount(pagePagingResultSet.getRowCount());
/*     */     }
/*     */     else {
/* 460 */       List list = DBUtil.query(querySQL, parameters, modelClazz);
/*     */ 
/* 462 */       setData(list);
/* 463 */       int len = list.size();
/*     */ 
/* 465 */       setPageCount(1);
/*     */ 
/* 467 */       setCurrPageRowCount(len);
/*     */ 
/* 469 */       setPageIndex(1);
/*     */ 
/* 471 */       setPossibleRecordCount(len);
/*     */     }
/* 473 */     return this;
/*     */   }
/*     */ 
/*     */   private String translateSql(String sql)
/*     */   {
/* 483 */     Map params = new HashMap();
/*     */ 
/* 485 */     int i = 0; for (int len = this.parameterSet.count(); i < len; i++) {
/* 486 */       String name = this.parameterSet.indexToName(i);
/* 487 */       Object value = this.parameterSet.getValue(i);
/* 488 */       params.put(name, value);
/*     */     }
/*     */ 
/* 491 */     return sql;
/*     */   }
/*     */ 
/*     */   private String doGetSql(String sql)
/*     */   {
/* 503 */     return sql.replaceAll(":(\\w*)", "?");
/*     */   }
/*     */ 
/*     */   public String getParsedSql()
/*     */   {
/* 515 */     String parsedSQl = translateSql(this.sql);
/* 516 */     if (StringUtil.isEmpty(parsedSQl)) {
/* 517 */       return null;
/*     */     }
/*     */ 
/* 520 */     String querySQL = doGetSql(parsedSQl);
/* 521 */     return querySQL;
/*     */   }
/*     */ 
/*     */   private Object[] doGetSqlParameters(String sql)
/*     */   {
/* 533 */     List list = new ArrayList();
/* 534 */     Pattern patter = Pattern.compile(":(\\w*)", 34);
/*     */ 
/* 536 */     Matcher pMatcher = patter.matcher(sql);
/* 537 */     while (pMatcher.find()) {
/* 538 */       String parameName = StringUtil.trim(pMatcher.group(1));
/* 539 */       if (StringUtil.isValid(parameName)) {
/* 540 */         Object value = this.parameterSet.getValue(parameName);
/* 541 */         if (value != null) (value instanceof String);
/*     */ 
/* 543 */         list.add(value);
/*     */       }
/*     */     }
/* 546 */     if (list.isEmpty())
/* 547 */       return null;
/* 548 */     return list.toArray();
/*     */   }
/*     */ 
/*     */   protected DbDataset setPageIndex(int pageIndex) {
/* 552 */     if (pageIndex <= 0)
/* 553 */       this.pageIndex = 1;
/*     */     else {
/* 555 */       this.pageIndex = pageIndex;
/*     */     }
/*     */ 
/* 559 */     return this;
/*     */   }
/*     */ 
/*     */   public int getPageSize()
/*     */   {
/* 564 */     return this.pageSize;
/*     */   }
/*     */ 
/*     */   public DbDataset setPageSize(int pageSize)
/*     */   {
/* 574 */     if (pageSize <= 0)
/* 575 */       this.pageSize = 20;
/*     */     else {
/* 577 */       this.pageSize = pageSize;
/*     */     }
/*     */ 
/* 580 */     return this;
/*     */   }
/*     */ 
/*     */   public DbDataset setPageSize(String pageSize)
/*     */   {
/* 590 */     return setPageSize(MathUtil.getInteger(pageSize).intValue());
/*     */   }
/*     */ 
/*     */   public long getPossibleRecordCount()
/*     */   {
/* 600 */     return this.possibleRecordCount;
/*     */   }
/*     */ 
/*     */   protected DbDataset setPossibleRecordCount(long possibleRecordCount) {
/* 604 */     this.possibleRecordCount = possibleRecordCount;
/* 605 */     return this;
/*     */   }
/*     */ 
/*     */   public int getCurrPageRowCount()
/*     */   {
/* 614 */     return this.currPageRowCount;
/*     */   }
/*     */ 
/*     */   protected DbDataset setCurrPageRowCount(int currPageRowCount) {
/* 618 */     this.currPageRowCount = currPageRowCount;
/* 619 */     return this;
/*     */   }
/*     */ 
/*     */   public String getSql() {
/* 623 */     return this.sql;
/*     */   }
/*     */ 
/*     */   public DbDataset setSql(String sql)
/*     */   {
/* 632 */     this.sql = sql;
/* 633 */     return this;
/*     */   }
/*     */ 
/*     */   public DbDataset setSql(StringBuffer sql)
/*     */   {
/* 642 */     if (sql != null) {
/* 643 */       this.sql = sql.toString();
/*     */     }
/*     */     else {
/* 646 */       this.sql = null;
/*     */     }
/*     */ 
/* 649 */     return this;
/*     */   }
/*     */ 
/*     */   public String getPagingSql(String sql)
/*     */   {
/* 654 */     return sql;
/*     */   }
/*     */ 
/*     */   public boolean isSupportPaging()
/*     */   {
/* 659 */     return this.supportPaging;
/*     */   }
/*     */ 
/*     */   protected DbDataset setSupportPaging(boolean supportPaging) {
/* 663 */     this.supportPaging = supportPaging;
/* 664 */     return this;
/*     */   }
/*     */ 
/*     */   public List getData()
/*     */   {
/* 673 */     return this.data;
/*     */   }
/*     */ 
/*     */   protected DbDataset setData(List data) {
/* 677 */     this.data = data;
/* 678 */     return this;
/*     */   }
/*     */ 
/*     */   protected DbDataset setPageCount(int pageCount) {
/* 682 */     this.pageCount = pageCount;
/* 683 */     return this;
/*     */   }
/*     */ 
/*     */   public JSONArray toJSONArray()
/*     */   {
/* 692 */     return toJSONArray(null);
/*     */   }
/*     */ 
/*     */   public JSONArray toJSONArray(String[] names)
/*     */   {
/* 704 */     JSONArray jsonArray = new JSONArray();
/* 705 */     if ((this.data != null) && (!this.data.isEmpty())) {
/* 706 */       int i = 0; for (int len = this.data.size(); i < len; i++) {
/* 707 */         jsonArray.add(toJSONObject(i, names));
/*     */       }
/*     */     }
/* 710 */     return jsonArray;
/*     */   }
/*     */ 
/*     */   public JSONObject toJSONObject()
/*     */   {
/* 723 */     return toJSONObject(null);
/*     */   }
/*     */ 
/*     */   public JSONObject toJSONObject(String[] names)
/*     */   {
/* 735 */     JSONObject jsonObject = new JSONObject();
/* 736 */     JsonUtil.put(jsonObject, "total", Long.valueOf(getPossibleRecordCount()));
/* 737 */     JsonUtil.put(jsonObject, "data", toJSONArray(names));
/* 738 */     return jsonObject;
/*     */   }
/*     */ 
/*     */   public JSONObject toSingleJSONObject()
/*     */   {
/* 748 */     return toSingleJSONObject(null);
/*     */   }
/*     */ 
/*     */   public JSONObject toSingleJSONObject(String[] names)
/*     */   {
/* 760 */     JSONObject jsonObject = null;
/* 761 */     if ((this.data == null) || (this.data.isEmpty()))
/* 762 */       jsonObject = new JSONObject();
/*     */     else {
/* 764 */       jsonObject = toJSONObject(0, names);
/*     */     }
/* 766 */     return jsonObject;
/*     */   }
/*     */ 
/*     */   public Representation toJSONObjectPresention()
/*     */   {
/* 778 */     return toJSONObjectPresention(null);
/*     */   }
/*     */ 
/*     */   public Representation toJSONObjectPresention(String[] names)
/*     */   {
/* 791 */     return new StringRepresentation(toJSONObject(names).toString(), 
/* 792 */       MediaType.TEXT_PLAIN, null, CharacterSet.UTF_8);
/*     */   }
/*     */ 
/*     */   public Representation toSingleJSONObjectPresention()
/*     */   {
/* 802 */     return toSingleJSONObjectPresention(null);
/*     */   }
/*     */ 
/*     */   public Representation toSingleJSONObjectPresention(String[] names)
/*     */   {
/* 815 */     return new StringRepresentation(toSingleJSONObject(names).toString(), 
/* 816 */       MediaType.TEXT_PLAIN, null, CharacterSet.UTF_8);
/*     */   }
/*     */ 
/*     */   public Representation toJSONArrayPresention()
/*     */   {
/* 826 */     return toJSONArrayPresention(null);
/*     */   }
/*     */ 
/*     */   public Representation toJSONArrayPresention(String[] names)
/*     */   {
/* 838 */     return new StringRepresentation(toJSONArray(names).toString(), 
/* 839 */       MediaType.TEXT_PLAIN, null, CharacterSet.UTF_8);
/*     */   }
/*     */ 
/*     */   public JSONObject toJSONObject(int index, String[] names)
/*     */   {
/* 852 */     if ((getData() == null) || (this.data.isEmpty())) {
/* 853 */       return new JSONObject();
/*     */     }
/*     */ 
/* 856 */     Object obj = getData().get(index);
/*     */ 
/* 858 */     return JsonUtil.toJSONObject(obj, names);
/*     */   }
/*     */ 
/*     */   private static boolean isExists(String[] names, String name)
/*     */   {
/* 870 */     boolean flag = false;
/* 871 */     int i = 0; for (int len = names.length; i < len; i++) {
/* 872 */       if (name.equals(names[i])) {
/* 873 */         flag = true;
/* 874 */         break;
/*     */       }
/*     */     }
/* 877 */     return flag;
/*     */   }
/*     */ 
/*     */   public Page<List> toPage()
/*     */   {
/* 889 */     Page result = null;
/*     */     try {
/* 891 */       if (this != null) {
/* 892 */         int pageIndex = getPageIndex();
/* 893 */         int pageSize = getPageSize();
/* 894 */         result = new Page(pageIndex, pageSize);
/*     */ 
/* 896 */         JSONObject jsonObj = toJSONObject();
/* 897 */         if (jsonObj != null) {
/* 898 */           int count = jsonObj.getInt("total");
/* 899 */           JSONArray jsonArray = jsonObj.getJSONArray("data");
/*     */ 
/* 901 */           List items = new ArrayList();
/*     */ 
/* 903 */           result.setItems(items);
/* 904 */           result.setTotal(count);
/* 905 */           result.setTotalCount(count);
/* 906 */           if ((jsonArray != null) && (jsonArray.size() > 0)) {
/* 907 */             Map map = null;
/* 908 */             for (int i = 0; i < jsonArray.size(); i++) {
/* 909 */               JSONObject obj = jsonArray.getJSONObject(i);
/* 910 */               if ((obj != null) && (obj.size() > 0)) {
/* 911 */                 map = new HashMap();
/* 912 */                 Iterator iterator = obj.keys();
/* 913 */                 while (iterator.hasNext()) {
/* 914 */                   String key = (String)iterator.next();
/* 915 */                   Object value = obj.get(key);
/* 916 */                   map.put(key, value);
/*     */                 }
/* 918 */                 items.add(map);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (JSONException e) {
/* 925 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 928 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.db.DbDataset
 * JD-Core Version:    0.6.0
 */