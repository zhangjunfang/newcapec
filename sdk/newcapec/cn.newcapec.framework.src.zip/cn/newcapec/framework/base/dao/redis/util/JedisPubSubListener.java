/*    */ package cn.newcapec.framework.base.dao.redis.util;
/*    */ 
/*    */ import cn.newcapec.framework.base.dao.redis.core.JedisPubSub;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class JedisPubSubListener extends JedisPubSub
/*    */ {
/*    */   public void onMessage(String channel, String message)
/*    */   {
/* 13 */     System.out.println(channel + "=" + message);
/*    */   }
/*    */ 
/*    */   public void onSubscribe(String channel, int subscribedChannels)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void onUnsubscribe(String channel, int subscribedChannels)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void onPSubscribe(String pattern, int subscribedChannels)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void onPUnsubscribe(String pattern, int subscribedChannels)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void onPMessage(String pattern, String channel, String message)
/*    */   {
/* 38 */     System.out.println(pattern + "=" + channel + "=" + message);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.util.JedisPubSubListener
 * JD-Core Version:    0.6.0
 */