/*     */ package cn.newcapec.framework.base.dao.db;
/*     */ 
/*     */ import cn.newcapec.framework.utils.tools.MathUtil;
/*     */ import cn.newcapec.framework.utils.variant.VariantSet;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class SqlDataset extends DbDataset
/*     */ {
/*     */   private static final long serialVersionUID = 5599490702037660560L;
/*     */   private int start;
/*     */ 
/*     */   public SqlDataset()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SqlDataset(String sql, ParameterSet params, boolean supportPaging, int start, int pageSize)
/*     */   {
/*  42 */     super(sql, params, supportPaging, 1, pageSize);
/*  43 */     setStart(start);
/*     */   }
/*     */ 
/*     */   public SqlDataset(String sql, ParameterSet params, boolean supportPaging, String start, String pageSize)
/*     */   {
/*  64 */     this(sql, params, supportPaging, MathUtil.getInteger(
/*  63 */       start == null ? "0" : start).intValue(), MathUtil.getInteger(
/*  64 */       pageSize).intValue());
/*     */   }
/*     */ 
/*     */   public SqlDataset(String sql, ParameterSet params, int start, int pageSize)
/*     */   {
/*  81 */     this(sql, params, true, start, pageSize);
/*     */   }
/*     */ 
/*     */   public SqlDataset(String sql, ParameterSet params, boolean supportPaging)
/*     */   {
/*  98 */     this(sql, params, supportPaging, 0, 20);
/*     */   }
/*     */ 
/*     */   public SqlDataset(String sql, ParameterSet params, String start, String pageSize)
/*     */   {
/* 117 */     this(sql, params, true, 
/* 116 */       MathUtil.getInteger(start == null ? "0" : start).intValue(), 
/* 117 */       MathUtil.getInteger(pageSize).intValue());
/*     */   }
/*     */ 
/*     */   public SqlDataset(String sql, String start, String pageSize)
/*     */   {
/* 132 */     this(sql, null, true, MathUtil.getInteger(start == null ? "0" : start)
/* 132 */       .intValue(), MathUtil.getInteger(pageSize).intValue());
/*     */   }
/*     */ 
/*     */   public SqlDataset(String sql, int start, int pageSize)
/*     */   {
/* 147 */     this(sql, null, true, start, pageSize);
/*     */   }
/*     */ 
/*     */   public SqlDataset(String sql, ParameterSet params, int start)
/*     */   {
/* 162 */     this(sql, params, true, start, 20);
/*     */   }
/*     */ 
/*     */   public SqlDataset(String sql, ParameterSet params, String start)
/*     */   {
/* 179 */     this(sql, params, true, 
/* 178 */       MathUtil.getInteger(start == null ? "0" : start).intValue(), 
/* 179 */       20);
/*     */   }
/*     */ 
/*     */   public SqlDataset(String sql, int start)
/*     */   {
/* 192 */     this(sql, null, true, start, 20);
/*     */   }
/*     */ 
/*     */   public SqlDataset(String sql, String start)
/*     */   {
/* 205 */     this(sql, null, true, MathUtil.getInteger(start == null ? "0" : start)
/* 205 */       .intValue(), 20);
/*     */   }
/*     */ 
/*     */   public SqlDataset(String sql)
/*     */   {
/* 215 */     this(sql, null, true, 0, 20);
/*     */   }
/*     */ 
/*     */   public SqlDataset(StringBuffer sql)
/*     */   {
/* 225 */     this(sql.toString());
/*     */   }
/*     */ 
/*     */   public int getStart()
/*     */   {
/* 231 */     return this.start;
/*     */   }
/*     */ 
/*     */   public SqlDataset setStart(int start)
/*     */   {
/* 240 */     this.start = start;
/* 241 */     return this;
/*     */   }
/*     */ 
/*     */   public SqlDataset setStart(String start)
/*     */   {
/* 250 */     if (start == null) {
/* 251 */       setStart(0);
/* 252 */       return this;
/*     */     }
/* 254 */     setStart(MathUtil.getInteger(start).intValue());
/* 255 */     return this;
/*     */   }
/*     */ 
/*     */   public SqlDataset loadData()
/*     */   {
/* 270 */     if (getPageSize() == 0) {
/* 271 */       setPageSize(20);
/*     */     }
/*     */ 
/* 274 */     setPageIndex(getStart() / getPageSize() + 1);
/*     */ 
/* 276 */     return (SqlDataset)super.loadData();
/*     */   }
/*     */ 
/*     */   public SqlDataset setPageSize(int pageSize)
/*     */   {
/* 291 */     return (SqlDataset)super.setPageSize(pageSize);
/*     */   }
/*     */ 
/*     */   public SqlDataset setPageSize(String pageSize)
/*     */   {
/* 306 */     return (SqlDataset)super.setPageSize(pageSize);
/*     */   }
/*     */ 
/*     */   public SqlDataset setParameter(String name, Object value)
/*     */   {
/* 324 */     return (SqlDataset)super.setParameter(name, value);
/*     */   }
/*     */ 
/*     */   public SqlDataset setSql(String sql)
/*     */   {
/* 339 */     return (SqlDataset)super.setSql(sql);
/*     */   }
/*     */ 
/*     */   public SqlDataset setSql(StringBuffer sql)
/*     */   {
/* 354 */     return (SqlDataset)super.setSql(sql);
/*     */   }
/*     */ 
/*     */   public SqlDataset setParameters(Map map, String[] names)
/*     */   {
/* 372 */     return (SqlDataset)super.setParameters(map, names);
/*     */   }
/*     */ 
/*     */   public SqlDataset setParameters(Map map)
/*     */   {
/* 387 */     return (SqlDataset)super.setParameters(map);
/*     */   }
/*     */ 
/*     */   public SqlDataset setParameters(Object obj, String[] names)
/*     */   {
/* 405 */     return (SqlDataset)super.setParameters(obj, names);
/*     */   }
/*     */ 
/*     */   public SqlDataset setParameters(Object obj)
/*     */   {
/* 420 */     return (SqlDataset)super.setParameters(obj);
/*     */   }
/*     */ 
/*     */   public SqlDataset setParameters(VariantSet variantSet, String[] names)
/*     */   {
/* 439 */     return (SqlDataset)super.setParameters(variantSet, names);
/*     */   }
/*     */ 
/*     */   public SqlDataset setParameters(VariantSet variantSet)
/*     */   {
/* 456 */     return (SqlDataset)super.setParameters(variantSet);
/*     */   }
/*     */ 
/*     */   public SqlDataset setClazz(Class clazz)
/*     */   {
/* 471 */     return (SqlDataset)super.setClazz(clazz);
/*     */   }
/*     */ 
/*     */   public SqlDataset setSupportPaging(boolean supportPaging)
/*     */   {
/* 486 */     return (SqlDataset)super.setSupportPaging(supportPaging);
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.db.SqlDataset
 * JD-Core Version:    0.6.0
 */