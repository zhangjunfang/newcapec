/*     */ package cn.newcapec.framework.base.dao.redis.core;
/*     */ 
/*     */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisConnectionException;
/*     */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisDataException;
/*     */ import cn.newcapec.framework.base.dao.redis.util.RedisInputStream;
/*     */ import cn.newcapec.framework.base.dao.redis.util.RedisOutputStream;
/*     */ import cn.newcapec.framework.base.dao.redis.util.SafeEncoder;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public final class Protocol
/*     */ {
/*     */   public static final int DEFAULT_PORT = 6379;
/*     */   public static final int DEFAULT_TIMEOUT = 2000;
/*     */   public static final int DEFAULT_DATABASE = 0;
/*     */   public static final String CHARSET = "UTF-8";
/*     */   public static final byte DOLLAR_BYTE = 36;
/*     */   public static final byte ASTERISK_BYTE = 42;
/*     */   public static final byte PLUS_BYTE = 43;
/*     */   public static final byte MINUS_BYTE = 45;
/*     */   public static final byte COLON_BYTE = 58;
/*     */   public static final String SENTINEL_MASTERS = "masters";
/*     */   public static final String SENTINEL_GET_MASTER_ADDR_BY_NAME = "get-master-addr-by-name";
/*     */   public static final String SENTINEL_RESET = "reset";
/*     */   public static final String SENTINEL_SLAVES = "slaves";
/*     */   public static final String SENTINEL_IS_MASTER_DOWN_BY_ADDR = "is-master-down-by-addr";
/*     */ 
/*     */   public static void sendCommand(RedisOutputStream os, Command command, byte[][] args)
/*     */   {
/*  39 */     sendCommand(os, command.raw, args);
/*     */   }
/*     */ 
/*     */   private static void sendCommand(RedisOutputStream os, byte[] command, byte[][] args)
/*     */   {
/*     */     try {
/*  45 */       os.write(42);
/*  46 */       os.writeIntCrLf(args.length + 1);
/*  47 */       os.write(36);
/*  48 */       os.writeIntCrLf(command.length);
/*  49 */       os.write(command);
/*  50 */       os.writeCrLf();
/*     */ 
/*  52 */       for (byte[] arg : args) {
/*  53 */         os.write(36);
/*  54 */         os.writeIntCrLf(arg.length);
/*  55 */         os.write(arg);
/*  56 */         os.writeCrLf();
/*     */       }
/*     */     } catch (IOException e) {
/*  59 */       throw new JedisConnectionException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void processError(RedisInputStream is) {
/*  64 */     String message = is.readLine();
/*  65 */     throw new JedisDataException(message);
/*     */   }
/*     */ 
/*     */   private static Object process(RedisInputStream is) {
/*     */     try {
/*  70 */       byte b = is.readByte();
/*  71 */       if (b == 45) {
/*  72 */         processError(is); } else {
/*  73 */         if (b == 42)
/*  74 */           return processMultiBulkReply(is);
/*  75 */         if (b == 58)
/*  76 */           return processInteger(is);
/*  77 */         if (b == 36)
/*  78 */           return processBulkReply(is);
/*  79 */         if (b == 43) {
/*  80 */           return processStatusCodeReply(is);
/*     */         }
/*  82 */         throw new JedisConnectionException("Unknown reply: " + (char)b);
/*     */       }
/*     */     } catch (IOException e) {
/*  85 */       throw new JedisConnectionException(e);
/*     */     }
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */   private static byte[] processStatusCodeReply(RedisInputStream is) {
/*  91 */     return SafeEncoder.encode(is.readLine());
/*     */   }
/*     */ 
/*     */   private static byte[] processBulkReply(RedisInputStream is) {
/*  95 */     int len = Integer.parseInt(is.readLine());
/*  96 */     if (len == -1) {
/*  97 */       return null;
/*     */     }
/*  99 */     byte[] read = new byte[len];
/* 100 */     int offset = 0;
/*     */     try {
/* 102 */       while (offset < len) {
/* 103 */         offset += is.read(read, offset, len - offset);
/*     */       }
/*     */ 
/* 106 */       is.readByte();
/* 107 */       is.readByte();
/*     */     } catch (IOException e) {
/* 109 */       throw new JedisConnectionException(e);
/*     */     }
/*     */ 
/* 112 */     return read;
/*     */   }
/*     */ 
/*     */   private static Long processInteger(RedisInputStream is) {
/* 116 */     String num = is.readLine();
/* 117 */     return Long.valueOf(num);
/*     */   }
/*     */ 
/*     */   private static List<Object> processMultiBulkReply(RedisInputStream is) {
/* 121 */     int num = Integer.parseInt(is.readLine());
/* 122 */     if (num == -1) {
/* 123 */       return null;
/*     */     }
/* 125 */     List ret = new ArrayList(num);
/* 126 */     for (int i = 0; i < num; i++) {
/*     */       try {
/* 128 */         ret.add(process(is));
/*     */       } catch (JedisDataException e) {
/* 130 */         ret.add(e);
/*     */       }
/*     */     }
/* 133 */     return ret;
/*     */   }
/*     */ 
/*     */   public static Object read(RedisInputStream is) {
/* 137 */     return process(is);
/*     */   }
/*     */ 
/*     */   public static final byte[] toByteArray(boolean value) {
/* 141 */     return toByteArray(value ? 1 : 0);
/*     */   }
/*     */ 
/*     */   public static final byte[] toByteArray(int value) {
/* 145 */     return SafeEncoder.encode(String.valueOf(value));
/*     */   }
/*     */ 
/*     */   public static final byte[] toByteArray(long value) {
/* 149 */     return SafeEncoder.encode(String.valueOf(value));
/*     */   }
/*     */ 
/*     */   public static final byte[] toByteArray(double value) {
/* 153 */     return SafeEncoder.encode(String.valueOf(value));
/*     */   }
/*     */ 
/*     */   public static enum Command {
/* 157 */     PING, SET, GET, QUIT, EXISTS, DEL, TYPE, FLUSHDB, KEYS, RANDOMKEY, RENAME, RENAMENX, RENAMEX, DBSIZE, EXPIRE, EXPIREAT, TTL, SELECT, MOVE, FLUSHALL, GETSET, MGET, SETNX, SETEX, MSET, MSETNX, DECRBY, DECR, INCRBY, INCR, APPEND, SUBSTR, HSET, HGET, HSETNX, HMSET, HMGET, HINCRBY, HEXISTS, HDEL, HLEN, HKEYS, HVALS, HGETALL, RPUSH, LPUSH, LLEN, LRANGE, LTRIM, LINDEX, LSET, LREM, LPOP, RPOP, RPOPLPUSH, SADD, SMEMBERS, SREM, SPOP, SMOVE, SCARD, SISMEMBER, SINTER, SINTERSTORE, SUNION, SUNIONSTORE, SDIFF, SDIFFSTORE, SRANDMEMBER, ZADD, ZRANGE, ZREM, ZINCRBY, ZRANK, ZREVRANK, ZREVRANGE, ZCARD, ZSCORE, MULTI, DISCARD, EXEC, WATCH, UNWATCH, SORT, BLPOP, BRPOP, AUTH, SUBSCRIBE, PUBLISH, UNSUBSCRIBE, PSUBSCRIBE, PUNSUBSCRIBE, ZCOUNT, ZRANGEBYSCORE, ZREVRANGEBYSCORE, ZREMRANGEBYRANK, ZREMRANGEBYSCORE, ZUNIONSTORE, ZINTERSTORE, SAVE, BGSAVE, BGREWRITEAOF, LASTSAVE, SHUTDOWN, INFO, MONITOR, SLAVEOF, CONFIG, STRLEN, SYNC, LPUSHX, PERSIST, RPUSHX, ECHO, LINSERT, DEBUG, BRPOPLPUSH, SETBIT, GETBIT, SETRANGE, GETRANGE, EVAL, EVALSHA, SCRIPT, SLOWLOG, OBJECT, BITCOUNT, BITOP, SENTINEL;
/*     */ 
/*     */     public final byte[] raw;
/*     */ 
/* 162 */     private Command() { this.raw = SafeEncoder.encode(name()); }
/*     */   }
/*     */ 
/*     */   public static enum Keyword
/*     */   {
/* 167 */     AGGREGATE, ALPHA, ASC, BY, DESC, GET, LIMIT, MESSAGE, NO, NOSORT, PMESSAGE, PSUBSCRIBE, PUNSUBSCRIBE, OK, ONE, QUEUED, SET, STORE, SUBSCRIBE, UNSUBSCRIBE, WEIGHTS, WITHSCORES, RESETSTAT, RESET, FLUSH, EXISTS, LOAD, KILL, LEN, REFCOUNT, ENCODING, IDLETIME, AND, OR, XOR, NOT;
/*     */ 
/*     */     public final byte[] raw;
/*     */ 
/* 171 */     private Keyword() { this.raw = SafeEncoder.encode(name().toLowerCase());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.Protocol
 * JD-Core Version:    0.6.0
 */