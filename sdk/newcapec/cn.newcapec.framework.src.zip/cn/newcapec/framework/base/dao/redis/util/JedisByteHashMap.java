/*     */ package cn.newcapec.framework.base.dao.redis.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class JedisByteHashMap
/*     */   implements Map<byte[], byte[]>, Cloneable, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -6971431362627219416L;
/*  15 */   private Map<ByteArrayWrapper, byte[]> internalMap = new HashMap();
/*     */ 
/*     */   public void clear() {
/*  18 */     this.internalMap.clear();
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key) {
/*  22 */     if ((key instanceof byte[]))
/*  23 */       return this.internalMap.containsKey(new ByteArrayWrapper((byte[])key));
/*  24 */     return this.internalMap.containsKey(key);
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value) {
/*  28 */     return this.internalMap.containsValue(value);
/*     */   }
/*     */ 
/*     */   public Set<Map.Entry<byte[], byte[]>> entrySet() {
/*  32 */     Iterator iterator = this.internalMap
/*  33 */       .entrySet().iterator();
/*  34 */     HashSet hashSet = new HashSet();
/*  35 */     while (iterator.hasNext()) {
/*  36 */       Map.Entry entry = (Map.Entry)iterator.next();
/*  37 */       hashSet.add(
/*  38 */         new JedisByteEntry(((ByteArrayWrapper)entry.getKey()).data, 
/*  38 */         (byte[])entry
/*  38 */         .getValue()));
/*     */     }
/*  40 */     return hashSet;
/*     */   }
/*     */ 
/*     */   public byte[] get(Object key) {
/*  44 */     if ((key instanceof byte[]))
/*  45 */       return (byte[])this.internalMap.get(new ByteArrayWrapper((byte[])key));
/*  46 */     return (byte[])this.internalMap.get(key);
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/*  50 */     return this.internalMap.isEmpty();
/*     */   }
/*     */ 
/*     */   public Set<byte[]> keySet() {
/*  54 */     Set keySet = new HashSet();
/*  55 */     Iterator iterator = this.internalMap.keySet().iterator();
/*  56 */     while (iterator.hasNext()) {
/*  57 */       keySet.add(((ByteArrayWrapper)iterator.next()).data);
/*     */     }
/*  59 */     return keySet;
/*     */   }
/*     */ 
/*     */   public byte[] put(byte[] key, byte[] value) {
/*  63 */     return (byte[])this.internalMap.put(new ByteArrayWrapper(key), value);
/*     */   }
/*     */ 
/*     */   public void putAll(Map<? extends byte[], ? extends byte[]> m)
/*     */   {
/*  68 */     Iterator iterator = m.entrySet().iterator();
/*  69 */     while (iterator.hasNext()) {
/*  70 */       Map.Entry next = 
/*  71 */         (Map.Entry)iterator
/*  71 */         .next();
/*  72 */       this.internalMap.put(new ByteArrayWrapper((byte[])next.getKey()), 
/*  73 */         (byte[])next
/*  73 */         .getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   public byte[] remove(Object key) {
/*  78 */     if ((key instanceof byte[]))
/*  79 */       return (byte[])this.internalMap.remove(new ByteArrayWrapper((byte[])key));
/*  80 */     return (byte[])this.internalMap.remove(key);
/*     */   }
/*     */ 
/*     */   public int size() {
/*  84 */     return this.internalMap.size();
/*     */   }
/*     */ 
/*     */   public Collection<byte[]> values() {
/*  88 */     return this.internalMap.values();
/*     */   }
/*     */   private static final class ByteArrayWrapper {
/*     */     private final byte[] data;
/*     */ 
/*     */     public ByteArrayWrapper(byte[] data) {
/*  95 */       if (data == null) {
/*  96 */         throw new NullPointerException();
/*     */       }
/*  98 */       this.data = data;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other) {
/* 102 */       if (!(other instanceof ByteArrayWrapper)) {
/* 103 */         return false;
/*     */       }
/* 105 */       return Arrays.equals(this.data, ((ByteArrayWrapper)other).data);
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 109 */       return Arrays.hashCode(this.data);
/*     */     }
/*     */   }
/*     */   private static final class JedisByteEntry implements Map.Entry<byte[], byte[]> {
/*     */     private byte[] value;
/*     */     private byte[] key;
/*     */ 
/*     */     public JedisByteEntry(byte[] key, byte[] value) {
/* 118 */       this.key = key;
/* 119 */       this.value = value;
/*     */     }
/*     */ 
/*     */     public byte[] getKey() {
/* 123 */       return this.key;
/*     */     }
/*     */ 
/*     */     public byte[] getValue() {
/* 127 */       return this.value;
/*     */     }
/*     */ 
/*     */     public byte[] setValue(byte[] value) {
/* 131 */       this.value = value;
/* 132 */       return value;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.util.JedisByteHashMap
 * JD-Core Version:    0.6.0
 */