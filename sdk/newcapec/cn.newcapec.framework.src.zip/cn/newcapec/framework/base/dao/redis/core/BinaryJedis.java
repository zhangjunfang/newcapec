/*      */ package cn.newcapec.framework.base.dao.redis.core;
/*      */ 
/*      */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisDataException;
/*      */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisException;
/*      */ import cn.newcapec.framework.base.dao.redis.util.JedisByteHashMap;
/*      */ import cn.newcapec.framework.base.dao.redis.util.SafeEncoder;
/*      */ import java.net.URI;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ 
/*      */ public class BinaryJedis
/*      */   implements BasicCommands, BinaryJedisCommands, MultiKeyBinaryCommands, AdvancedBinaryJedisCommands, BinaryScriptingCommands
/*      */ {
/*   21 */   protected Client client = null;
/*      */ 
/*      */   public BinaryJedis(String host) {
/*   24 */     URI uri = URI.create(host);
/*   25 */     if ((uri.getScheme() != null) && (uri.getScheme().equals("redis"))) {
/*   26 */       this.client = new Client(uri.getHost(), uri.getPort());
/*   27 */       this.client.auth(uri.getUserInfo().split(":", 2)[1]);
/*   28 */       this.client.getStatusCodeReply();
/*   29 */       this.client.select(Integer.parseInt(uri.getPath().split("/", 2)[1]));
/*   30 */       this.client.getStatusCodeReply();
/*      */     } else {
/*   32 */       this.client = new Client(host);
/*      */     }
/*      */   }
/*      */ 
/*      */   public BinaryJedis(String host, int port) {
/*   37 */     this.client = new Client(host, port);
/*      */   }
/*      */ 
/*      */   public BinaryJedis(String host, int port, int timeout) {
/*   41 */     this.client = new Client(host, port);
/*   42 */     this.client.setTimeout(timeout);
/*      */   }
/*      */ 
/*      */   public BinaryJedis(JedisShardInfo shardInfo) {
/*   46 */     this.client = new Client(shardInfo.getHost(), shardInfo.getPort());
/*   47 */     this.client.setTimeout(shardInfo.getTimeout());
/*   48 */     this.client.setPassword(shardInfo.getPassword());
/*      */   }
/*      */ 
/*      */   public BinaryJedis(URI uri) {
/*   52 */     this.client = new Client(uri.getHost(), uri.getPort());
/*   53 */     this.client.auth(uri.getUserInfo().split(":", 2)[1]);
/*   54 */     this.client.getStatusCodeReply();
/*   55 */     this.client.select(Integer.parseInt(uri.getPath().split("/", 2)[1]));
/*   56 */     this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public String ping() {
/*   60 */     checkIsInMulti();
/*   61 */     this.client.ping();
/*   62 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public String set(byte[] key, byte[] value)
/*      */   {
/*   76 */     checkIsInMulti();
/*   77 */     this.client.set(key, value);
/*   78 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public byte[] get(byte[] key)
/*      */   {
/*   92 */     checkIsInMulti();
/*   93 */     this.client.get(key);
/*   94 */     return this.client.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   public String quit()
/*      */   {
/*  101 */     checkIsInMulti();
/*  102 */     this.client.quit();
/*  103 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public Boolean exists(byte[] key)
/*      */   {
/*  117 */     checkIsInMulti();
/*  118 */     this.client.exists(key);
/*  119 */     if (this.client.getIntegerReply().longValue() == 1L) return Boolean.valueOf(true); return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   public Long del(byte[][] keys)
/*      */   {
/*  133 */     checkIsInMulti();
/*  134 */     this.client.del(keys);
/*  135 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long del(byte[] key) {
/*  139 */     checkIsInMulti();
/*  140 */     this.client.del(new byte[][] { key });
/*  141 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String type(byte[] key)
/*      */   {
/*  159 */     checkIsInMulti();
/*  160 */     this.client.type(key);
/*  161 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public String flushDB()
/*      */   {
/*  171 */     checkIsInMulti();
/*  172 */     this.client.flushDB();
/*  173 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public Set<byte[]> keys(byte[] pattern)
/*      */   {
/*  208 */     checkIsInMulti();
/*  209 */     this.client.keys(pattern);
/*  210 */     HashSet keySet = new HashSet(
/*  211 */       this.client.getBinaryMultiBulkReply());
/*  212 */     return keySet;
/*      */   }
/*      */ 
/*      */   public byte[] randomBinaryKey()
/*      */   {
/*  224 */     checkIsInMulti();
/*  225 */     this.client.randomKey();
/*  226 */     return this.client.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   public String rename(byte[] oldkey, byte[] newkey)
/*      */   {
/*  241 */     checkIsInMulti();
/*  242 */     this.client.rename(oldkey, newkey);
/*  243 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public Long renamenx(byte[] oldkey, byte[] newkey)
/*      */   {
/*  258 */     checkIsInMulti();
/*  259 */     this.client.renamenx(oldkey, newkey);
/*  260 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long dbSize()
/*      */   {
/*  269 */     checkIsInMulti();
/*  270 */     this.client.dbSize();
/*  271 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long expire(byte[] key, int seconds)
/*      */   {
/*  303 */     checkIsInMulti();
/*  304 */     this.client.expire(key, seconds);
/*  305 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long expireAt(byte[] key, long unixTime)
/*      */   {
/*  339 */     checkIsInMulti();
/*  340 */     this.client.expireAt(key, unixTime);
/*  341 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long ttl(byte[] key)
/*      */   {
/*  356 */     checkIsInMulti();
/*  357 */     this.client.ttl(key);
/*  358 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String select(int index)
/*      */   {
/*  369 */     checkIsInMulti();
/*  370 */     this.client.select(index);
/*  371 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public Long move(byte[] key, int dbIndex)
/*      */   {
/*  388 */     checkIsInMulti();
/*  389 */     this.client.move(key, dbIndex);
/*  390 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String flushAll()
/*      */   {
/*  400 */     checkIsInMulti();
/*  401 */     this.client.flushAll();
/*  402 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public byte[] getSet(byte[] key, byte[] value)
/*      */   {
/*  417 */     checkIsInMulti();
/*  418 */     this.client.getSet(key, value);
/*  419 */     return this.client.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   public List<byte[]> mget(byte[][] keys)
/*      */   {
/*  433 */     checkIsInMulti();
/*  434 */     this.client.mget(keys);
/*  435 */     return this.client.getBinaryMultiBulkReply();
/*      */   }
/*      */ 
/*      */   public Long setnx(byte[] key, byte[] value)
/*      */   {
/*  451 */     checkIsInMulti();
/*  452 */     this.client.setnx(key, value);
/*  453 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String setex(byte[] key, int seconds, byte[] value)
/*      */   {
/*  469 */     checkIsInMulti();
/*  470 */     this.client.setex(key, seconds, value);
/*  471 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public String mset(byte[][] keysvalues)
/*      */   {
/*  495 */     checkIsInMulti();
/*  496 */     this.client.mset(keysvalues);
/*  497 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public Long msetnx(byte[][] keysvalues)
/*      */   {
/*  522 */     checkIsInMulti();
/*  523 */     this.client.msetnx(keysvalues);
/*  524 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long decrBy(byte[] key, long integer)
/*      */   {
/*  550 */     checkIsInMulti();
/*  551 */     this.client.decrBy(key, integer);
/*  552 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long decr(byte[] key)
/*      */   {
/*  578 */     checkIsInMulti();
/*  579 */     this.client.decr(key);
/*  580 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long incrBy(byte[] key, long integer)
/*      */   {
/*  606 */     checkIsInMulti();
/*  607 */     this.client.incrBy(key, integer);
/*  608 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long incr(byte[] key)
/*      */   {
/*  634 */     checkIsInMulti();
/*  635 */     this.client.incr(key);
/*  636 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long append(byte[] key, byte[] value)
/*      */   {
/*  656 */     checkIsInMulti();
/*  657 */     this.client.append(key, value);
/*  658 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public byte[] substr(byte[] key, int start, int end)
/*      */   {
/*  680 */     checkIsInMulti();
/*  681 */     this.client.substr(key, start, end);
/*  682 */     return this.client.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   public Long hset(byte[] key, byte[] field, byte[] value)
/*      */   {
/*  701 */     checkIsInMulti();
/*  702 */     this.client.hset(key, field, value);
/*  703 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public byte[] hget(byte[] key, byte[] field)
/*      */   {
/*  720 */     checkIsInMulti();
/*  721 */     this.client.hget(key, field);
/*  722 */     return this.client.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   public Long hsetnx(byte[] key, byte[] field, byte[] value)
/*      */   {
/*  737 */     checkIsInMulti();
/*  738 */     this.client.hsetnx(key, field, value);
/*  739 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String hmset(byte[] key, Map<byte[], byte[]> hash)
/*      */   {
/*  755 */     checkIsInMulti();
/*  756 */     this.client.hmset(key, hash);
/*  757 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public List<byte[]> hmget(byte[] key, byte[][] fields)
/*      */   {
/*  774 */     checkIsInMulti();
/*  775 */     this.client.hmget(key, fields);
/*  776 */     return this.client.getBinaryMultiBulkReply();
/*      */   }
/*      */ 
/*      */   public Long hincrBy(byte[] key, byte[] field, long value)
/*      */   {
/*  798 */     checkIsInMulti();
/*  799 */     this.client.hincrBy(key, field, value);
/*  800 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Boolean hexists(byte[] key, byte[] field)
/*      */   {
/*  814 */     checkIsInMulti();
/*  815 */     this.client.hexists(key, field);
/*  816 */     if (this.client.getIntegerReply().longValue() == 1L) return Boolean.valueOf(true); return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   public Long hdel(byte[] key, byte[][] fields)
/*      */   {
/*  830 */     checkIsInMulti();
/*  831 */     this.client.hdel(key, fields);
/*  832 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long hlen(byte[] key)
/*      */   {
/*  846 */     checkIsInMulti();
/*  847 */     this.client.hlen(key);
/*  848 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Set<byte[]> hkeys(byte[] key)
/*      */   {
/*  860 */     checkIsInMulti();
/*  861 */     this.client.hkeys(key);
/*  862 */     List lresult = this.client.getBinaryMultiBulkReply();
/*  863 */     return new HashSet(lresult);
/*      */   }
/*      */ 
/*      */   public List<byte[]> hvals(byte[] key)
/*      */   {
/*  875 */     checkIsInMulti();
/*  876 */     this.client.hvals(key);
/*  877 */     List lresult = this.client.getBinaryMultiBulkReply();
/*  878 */     return lresult;
/*      */   }
/*      */ 
/*      */   public Map<byte[], byte[]> hgetAll(byte[] key)
/*      */   {
/*  890 */     checkIsInMulti();
/*  891 */     this.client.hgetAll(key);
/*  892 */     List flatHash = this.client.getBinaryMultiBulkReply();
/*  893 */     Map hash = new JedisByteHashMap();
/*  894 */     Iterator iterator = flatHash.iterator();
/*  895 */     while (iterator.hasNext()) {
/*  896 */       hash.put((byte[])iterator.next(), (byte[])iterator.next());
/*      */     }
/*      */ 
/*  899 */     return hash;
/*      */   }
/*      */ 
/*      */   public Long rpush(byte[] key, byte[][] strings)
/*      */   {
/*  918 */     checkIsInMulti();
/*  919 */     this.client.rpush(key, strings);
/*  920 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long lpush(byte[] key, byte[][] strings)
/*      */   {
/*  939 */     checkIsInMulti();
/*  940 */     this.client.lpush(key, strings);
/*  941 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long llen(byte[] key)
/*      */   {
/*  955 */     checkIsInMulti();
/*  956 */     this.client.llen(key);
/*  957 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public List<byte[]> lrange(byte[] key, long start, long end)
/*      */   {
/*  999 */     checkIsInMulti();
/* 1000 */     this.client.lrange(key, start, end);
/* 1001 */     return this.client.getBinaryMultiBulkReply();
/*      */   }
/*      */ 
/*      */   public String ltrim(byte[] key, long start, long end)
/*      */   {
/* 1039 */     checkIsInMulti();
/* 1040 */     this.client.ltrim(key, start, end);
/* 1041 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public byte[] lindex(byte[] key, long index)
/*      */   {
/* 1063 */     checkIsInMulti();
/* 1064 */     this.client.lindex(key, index);
/* 1065 */     return this.client.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   public String lset(byte[] key, long index, byte[] value)
/*      */   {
/* 1090 */     checkIsInMulti();
/* 1091 */     this.client.lset(key, index, value);
/* 1092 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public Long lrem(byte[] key, long count, byte[] value)
/*      */   {
/* 1115 */     checkIsInMulti();
/* 1116 */     this.client.lrem(key, count, value);
/* 1117 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public byte[] lpop(byte[] key)
/*      */   {
/* 1134 */     checkIsInMulti();
/* 1135 */     this.client.lpop(key);
/* 1136 */     return this.client.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   public byte[] rpop(byte[] key)
/*      */   {
/* 1153 */     checkIsInMulti();
/* 1154 */     this.client.rpop(key);
/* 1155 */     return this.client.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   public byte[] rpoplpush(byte[] srckey, byte[] dstkey)
/*      */   {
/* 1177 */     checkIsInMulti();
/* 1178 */     this.client.rpoplpush(srckey, dstkey);
/* 1179 */     return this.client.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   public Long sadd(byte[] key, byte[][] members)
/*      */   {
/* 1196 */     checkIsInMulti();
/* 1197 */     this.client.sadd(key, members);
/* 1198 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Set<byte[]> smembers(byte[] key)
/*      */   {
/* 1211 */     checkIsInMulti();
/* 1212 */     this.client.smembers(key);
/* 1213 */     List members = this.client.getBinaryMultiBulkReply();
/* 1214 */     return new HashSet(members);
/*      */   }
/*      */ 
/*      */   public Long srem(byte[] key, byte[][] member)
/*      */   {
/* 1230 */     checkIsInMulti();
/* 1231 */     this.client.srem(key, member);
/* 1232 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public byte[] spop(byte[] key)
/*      */   {
/* 1248 */     checkIsInMulti();
/* 1249 */     this.client.spop(key);
/* 1250 */     return this.client.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   public Long smove(byte[] srckey, byte[] dstkey, byte[] member)
/*      */   {
/* 1278 */     checkIsInMulti();
/* 1279 */     this.client.smove(srckey, dstkey, member);
/* 1280 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long scard(byte[] key)
/*      */   {
/* 1292 */     checkIsInMulti();
/* 1293 */     this.client.scard(key);
/* 1294 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Boolean sismember(byte[] key, byte[] member)
/*      */   {
/* 1310 */     checkIsInMulti();
/* 1311 */     this.client.sismember(key, member);
/* 1312 */     if (this.client.getIntegerReply().longValue() == 1L) return Boolean.valueOf(true); return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   public Set<byte[]> sinter(byte[][] keys)
/*      */   {
/* 1335 */     checkIsInMulti();
/* 1336 */     this.client.sinter(keys);
/* 1337 */     List members = this.client.getBinaryMultiBulkReply();
/* 1338 */     return new HashSet(members);
/*      */   }
/*      */ 
/*      */   public Long sinterstore(byte[] dstkey, byte[][] keys)
/*      */   {
/* 1353 */     checkIsInMulti();
/* 1354 */     this.client.sinterstore(dstkey, keys);
/* 1355 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Set<byte[]> sunion(byte[][] keys)
/*      */   {
/* 1375 */     checkIsInMulti();
/* 1376 */     this.client.sunion(keys);
/* 1377 */     List members = this.client.getBinaryMultiBulkReply();
/* 1378 */     return new HashSet(members);
/*      */   }
/*      */ 
/*      */   public Long sunionstore(byte[] dstkey, byte[][] keys)
/*      */   {
/* 1394 */     checkIsInMulti();
/* 1395 */     this.client.sunionstore(dstkey, keys);
/* 1396 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Set<byte[]> sdiff(byte[][] keys)
/*      */   {
/* 1423 */     checkIsInMulti();
/* 1424 */     this.client.sdiff(keys);
/* 1425 */     List members = this.client.getBinaryMultiBulkReply();
/* 1426 */     return new HashSet(members);
/*      */   }
/*      */ 
/*      */   public Long sdiffstore(byte[] dstkey, byte[][] keys)
/*      */   {
/* 1438 */     checkIsInMulti();
/* 1439 */     this.client.sdiffstore(dstkey, keys);
/* 1440 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public byte[] srandmember(byte[] key)
/*      */   {
/* 1456 */     checkIsInMulti();
/* 1457 */     this.client.srandmember(key);
/* 1458 */     return this.client.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   public Long zadd(byte[] key, double score, byte[] member)
/*      */   {
/* 1483 */     checkIsInMulti();
/* 1484 */     this.client.zadd(key, score, member);
/* 1485 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long zadd(byte[] key, Map<Double, byte[]> scoreMembers) {
/* 1489 */     checkIsInMulti();
/* 1490 */     this.client.zaddBinary(key, scoreMembers);
/* 1491 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Set<byte[]> zrange(byte[] key, long start, long end) {
/* 1495 */     checkIsInMulti();
/* 1496 */     this.client.zrange(key, start, end);
/* 1497 */     List members = this.client.getBinaryMultiBulkReply();
/* 1498 */     return new LinkedHashSet(members);
/*      */   }
/*      */ 
/*      */   public Long zrem(byte[] key, byte[][] members)
/*      */   {
/* 1517 */     checkIsInMulti();
/* 1518 */     this.client.zrem(key, members);
/* 1519 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Double zincrby(byte[] key, double score, byte[] member)
/*      */   {
/* 1548 */     checkIsInMulti();
/* 1549 */     this.client.zincrby(key, score, member);
/* 1550 */     String newscore = this.client.getBulkReply();
/* 1551 */     return Double.valueOf(newscore);
/*      */   }
/*      */ 
/*      */   public Long zrank(byte[] key, byte[] member)
/*      */   {
/* 1575 */     checkIsInMulti();
/* 1576 */     this.client.zrank(key, member);
/* 1577 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long zrevrank(byte[] key, byte[] member)
/*      */   {
/* 1601 */     checkIsInMulti();
/* 1602 */     this.client.zrevrank(key, member);
/* 1603 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Set<byte[]> zrevrange(byte[] key, long start, long end)
/*      */   {
/* 1608 */     checkIsInMulti();
/* 1609 */     this.client.zrevrange(key, start, end);
/* 1610 */     List members = this.client.getBinaryMultiBulkReply();
/* 1611 */     return new LinkedHashSet(members);
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrangeWithScores(byte[] key, long start, long end)
/*      */   {
/* 1616 */     checkIsInMulti();
/* 1617 */     this.client.zrangeWithScores(key, start, end);
/* 1618 */     Set set = getBinaryTupledSet();
/* 1619 */     return set;
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrevrangeWithScores(byte[] key, long start, long end)
/*      */   {
/* 1624 */     checkIsInMulti();
/* 1625 */     this.client.zrevrangeWithScores(key, start, end);
/* 1626 */     Set set = getBinaryTupledSet();
/* 1627 */     return set;
/*      */   }
/*      */ 
/*      */   public Long zcard(byte[] key)
/*      */   {
/* 1640 */     checkIsInMulti();
/* 1641 */     this.client.zcard(key);
/* 1642 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Double zscore(byte[] key, byte[] member)
/*      */   {
/* 1657 */     checkIsInMulti();
/* 1658 */     this.client.zscore(key, member);
/* 1659 */     String score = this.client.getBulkReply();
/* 1660 */     return score != null ? new Double(score) : null;
/*      */   }
/*      */ 
/*      */   public Transaction multi() {
/* 1664 */     this.client.multi();
/* 1665 */     return new Transaction(this.client);
/*      */   }
/*      */ 
/*      */   public List<Object> multi(TransactionBlock jedisTransaction) {
/* 1669 */     List results = null;
/* 1670 */     jedisTransaction.setClient(this.client);
/*      */     try {
/* 1672 */       this.client.multi();
/* 1673 */       jedisTransaction.execute();
/* 1674 */       results = jedisTransaction.exec();
/*      */     } catch (Exception ex) {
/* 1676 */       jedisTransaction.discard();
/*      */     }
/* 1678 */     return results;
/*      */   }
/*      */ 
/*      */   protected void checkIsInMulti() {
/* 1682 */     if (this.client.isInMulti())
/* 1683 */       throw new JedisDataException(
/* 1684 */         "Cannot use Jedis when in Multi. Please use JedisTransaction instead.");
/*      */   }
/*      */ 
/*      */   public void connect()
/*      */   {
/* 1689 */     this.client.connect();
/*      */   }
/*      */ 
/*      */   public void disconnect() {
/* 1693 */     this.client.disconnect();
/*      */   }
/*      */ 
/*      */   public String watch(byte[][] keys) {
/* 1697 */     this.client.watch(keys);
/* 1698 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public String unwatch() {
/* 1702 */     this.client.unwatch();
/* 1703 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public List<byte[]> sort(byte[] key)
/*      */   {
/* 1724 */     checkIsInMulti();
/* 1725 */     this.client.sort(key);
/* 1726 */     return this.client.getBinaryMultiBulkReply();
/*      */   }
/*      */ 
/*      */   public List<byte[]> sort(byte[] key, SortingParams sortingParameters)
/*      */   {
/* 1807 */     checkIsInMulti();
/* 1808 */     this.client.sort(key, sortingParameters);
/* 1809 */     return this.client.getBinaryMultiBulkReply();
/*      */   }
/*      */ 
/*      */   public List<byte[]> blpop(int timeout, byte[][] keys)
/*      */   {
/* 1885 */     checkIsInMulti();
/* 1886 */     List args = new ArrayList();
/* 1887 */     for (byte[] arg : keys) {
/* 1888 */       args.add(arg);
/*      */     }
/* 1890 */     args.add(Protocol.toByteArray(timeout));
/*      */ 
/* 1892 */     this.client.blpop((byte[][])args.toArray(new byte[args.size()][]));
/* 1893 */     this.client.setTimeoutInfinite();
/* 1894 */     List multiBulkReply = this.client.getBinaryMultiBulkReply();
/* 1895 */     this.client.rollbackTimeout();
/* 1896 */     return multiBulkReply;
/*      */   }
/*      */ 
/*      */   public Long sort(byte[] key, SortingParams sortingParameters, byte[] dstkey)
/*      */   {
/* 1914 */     checkIsInMulti();
/* 1915 */     this.client.sort(key, sortingParameters, dstkey);
/* 1916 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long sort(byte[] key, byte[] dstkey)
/*      */   {
/* 1936 */     checkIsInMulti();
/* 1937 */     this.client.sort(key, dstkey);
/* 1938 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public List<byte[]> brpop(int timeout, byte[][] keys)
/*      */   {
/* 2014 */     checkIsInMulti();
/* 2015 */     List args = new ArrayList();
/* 2016 */     for (byte[] arg : keys) {
/* 2017 */       args.add(arg);
/*      */     }
/* 2019 */     args.add(Protocol.toByteArray(timeout));
/*      */ 
/* 2021 */     this.client.brpop((byte[][])args.toArray(new byte[args.size()][]));
/* 2022 */     this.client.setTimeoutInfinite();
/* 2023 */     List multiBulkReply = this.client.getBinaryMultiBulkReply();
/* 2024 */     this.client.rollbackTimeout();
/*      */ 
/* 2026 */     return multiBulkReply;
/*      */   }
/*      */ 
/*      */   public List<byte[]> blpop(byte[] arg) {
/* 2030 */     checkIsInMulti();
/* 2031 */     byte[][] args = new byte[1][];
/* 2032 */     args[0] = arg;
/* 2033 */     this.client.blpop(args);
/* 2034 */     this.client.setTimeoutInfinite();
/* 2035 */     List multiBulkReply = this.client.getBinaryMultiBulkReply();
/* 2036 */     this.client.rollbackTimeout();
/* 2037 */     return multiBulkReply;
/*      */   }
/*      */ 
/*      */   public List<byte[]> brpop(byte[] arg) {
/* 2041 */     checkIsInMulti();
/* 2042 */     byte[][] args = new byte[1][];
/* 2043 */     args[0] = arg;
/* 2044 */     this.client.brpop(args);
/* 2045 */     this.client.setTimeoutInfinite();
/* 2046 */     List multiBulkReply = this.client.getBinaryMultiBulkReply();
/* 2047 */     this.client.rollbackTimeout();
/* 2048 */     return multiBulkReply;
/*      */   }
/*      */ 
/*      */   public List<byte[]> blpop(byte[][] args) {
/* 2052 */     checkIsInMulti();
/* 2053 */     this.client.blpop(args);
/* 2054 */     this.client.setTimeoutInfinite();
/* 2055 */     List multiBulkReply = this.client.getBinaryMultiBulkReply();
/* 2056 */     this.client.rollbackTimeout();
/* 2057 */     return multiBulkReply;
/*      */   }
/*      */ 
/*      */   public List<byte[]> brpop(byte[][] args) {
/* 2061 */     checkIsInMulti();
/* 2062 */     this.client.brpop(args);
/* 2063 */     this.client.setTimeoutInfinite();
/* 2064 */     List multiBulkReply = this.client.getBinaryMultiBulkReply();
/* 2065 */     this.client.rollbackTimeout();
/* 2066 */     return multiBulkReply;
/*      */   }
/*      */ 
/*      */   public String auth(String password)
/*      */   {
/* 2085 */     checkIsInMulti();
/* 2086 */     this.client.auth(password);
/* 2087 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public List<Object> pipelined(PipelineBlock jedisPipeline)
/*      */   {
/* 2100 */     jedisPipeline.setClient(this.client);
/* 2101 */     jedisPipeline.execute();
/* 2102 */     return jedisPipeline.syncAndReturnAll();
/*      */   }
/*      */ 
/*      */   public Pipeline pipelined() {
/* 2106 */     Pipeline pipeline = new Pipeline();
/* 2107 */     pipeline.setClient(this.client);
/* 2108 */     return pipeline;
/*      */   }
/*      */ 
/*      */   public Long zcount(byte[] key, double min, double max) {
/* 2112 */     return zcount(key, Protocol.toByteArray(min), Protocol.toByteArray(max));
/*      */   }
/*      */ 
/*      */   public Long zcount(byte[] key, byte[] min, byte[] max) {
/* 2116 */     checkIsInMulti();
/* 2117 */     this.client.zcount(key, min, max);
/* 2118 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Set<byte[]> zrangeByScore(byte[] key, double min, double max)
/*      */   {
/* 2179 */     return zrangeByScore(key, Protocol.toByteArray(min), Protocol.toByteArray(max));
/*      */   }
/*      */ 
/*      */   public Set<byte[]> zrangeByScore(byte[] key, byte[] min, byte[] max)
/*      */   {
/* 2184 */     checkIsInMulti();
/* 2185 */     this.client.zrangeByScore(key, min, max);
/* 2186 */     return new LinkedHashSet(this.client.getBinaryMultiBulkReply());
/*      */   }
/*      */ 
/*      */   public Set<byte[]> zrangeByScore(byte[] key, double min, double max, int offset, int count)
/*      */   {
/* 2247 */     return zrangeByScore(key, Protocol.toByteArray(min), Protocol.toByteArray(max), offset, count);
/*      */   }
/*      */ 
/*      */   public Set<byte[]> zrangeByScore(byte[] key, byte[] min, byte[] max, int offset, int count)
/*      */   {
/* 2252 */     checkIsInMulti();
/* 2253 */     this.client.zrangeByScore(key, min, max, offset, count);
/* 2254 */     return new LinkedHashSet(this.client.getBinaryMultiBulkReply());
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrangeByScoreWithScores(byte[] key, double min, double max)
/*      */   {
/* 2315 */     return zrangeByScoreWithScores(key, Protocol.toByteArray(min), Protocol.toByteArray(max));
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrangeByScoreWithScores(byte[] key, byte[] min, byte[] max)
/*      */   {
/* 2320 */     checkIsInMulti();
/* 2321 */     this.client.zrangeByScoreWithScores(key, min, max);
/* 2322 */     Set set = getBinaryTupledSet();
/* 2323 */     return set;
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrangeByScoreWithScores(byte[] key, double min, double max, int offset, int count)
/*      */   {
/* 2385 */     return zrangeByScoreWithScores(key, Protocol.toByteArray(min), Protocol.toByteArray(max), offset, count);
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrangeByScoreWithScores(byte[] key, byte[] min, byte[] max, int offset, int count)
/*      */   {
/* 2391 */     checkIsInMulti();
/* 2392 */     this.client.zrangeByScoreWithScores(key, min, max, offset, count);
/* 2393 */     Set set = getBinaryTupledSet();
/* 2394 */     return set;
/*      */   }
/*      */ 
/*      */   private Set<Tuple> getBinaryTupledSet() {
/* 2398 */     checkIsInMulti();
/* 2399 */     List membersWithScores = this.client.getBinaryMultiBulkReply();
/* 2400 */     Set set = new LinkedHashSet();
/* 2401 */     Iterator iterator = membersWithScores.iterator();
/* 2402 */     while (iterator.hasNext()) {
/* 2403 */       set.add(new Tuple((byte[])iterator.next(), Double.valueOf(
/* 2404 */         SafeEncoder.encode((byte[])iterator.next()))));
/*      */     }
/* 2406 */     return set;
/*      */   }
/*      */ 
/*      */   public Set<byte[]> zrevrangeByScore(byte[] key, double max, double min)
/*      */   {
/* 2411 */     return zrevrangeByScore(key, Protocol.toByteArray(max), Protocol.toByteArray(min));
/*      */   }
/*      */ 
/*      */   public Set<byte[]> zrevrangeByScore(byte[] key, byte[] max, byte[] min)
/*      */   {
/* 2416 */     checkIsInMulti();
/* 2417 */     this.client.zrevrangeByScore(key, max, min);
/* 2418 */     return new LinkedHashSet(this.client.getBinaryMultiBulkReply());
/*      */   }
/*      */ 
/*      */   public Set<byte[]> zrevrangeByScore(byte[] key, double max, double min, int offset, int count)
/*      */   {
/* 2423 */     return zrevrangeByScore(key, Protocol.toByteArray(max), Protocol.toByteArray(min), offset, count);
/*      */   }
/*      */ 
/*      */   public Set<byte[]> zrevrangeByScore(byte[] key, byte[] max, byte[] min, int offset, int count)
/*      */   {
/* 2428 */     checkIsInMulti();
/* 2429 */     this.client.zrevrangeByScore(key, max, min, offset, count);
/* 2430 */     return new LinkedHashSet(this.client.getBinaryMultiBulkReply());
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrevrangeByScoreWithScores(byte[] key, double max, double min)
/*      */   {
/* 2435 */     return zrevrangeByScoreWithScores(key, Protocol.toByteArray(max), Protocol.toByteArray(min));
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrevrangeByScoreWithScores(byte[] key, double max, double min, int offset, int count)
/*      */   {
/* 2441 */     return zrevrangeByScoreWithScores(key, Protocol.toByteArray(max), Protocol.toByteArray(min), offset, count);
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrevrangeByScoreWithScores(byte[] key, byte[] max, byte[] min)
/*      */   {
/* 2446 */     checkIsInMulti();
/* 2447 */     this.client.zrevrangeByScoreWithScores(key, max, min);
/* 2448 */     Set set = getBinaryTupledSet();
/* 2449 */     return set;
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrevrangeByScoreWithScores(byte[] key, byte[] max, byte[] min, int offset, int count)
/*      */   {
/* 2455 */     checkIsInMulti();
/* 2456 */     this.client.zrevrangeByScoreWithScores(key, max, min, offset, count);
/* 2457 */     Set set = getBinaryTupledSet();
/* 2458 */     return set;
/*      */   }
/*      */ 
/*      */   public Long zremrangeByRank(byte[] key, long start, long end)
/*      */   {
/* 2475 */     checkIsInMulti();
/* 2476 */     this.client.zremrangeByRank(key, start, end);
/* 2477 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long zremrangeByScore(byte[] key, double start, double end)
/*      */   {
/* 2496 */     return zremrangeByScore(key, Protocol.toByteArray(start), Protocol.toByteArray(end));
/*      */   }
/*      */ 
/*      */   public Long zremrangeByScore(byte[] key, byte[] start, byte[] end)
/*      */   {
/* 2501 */     checkIsInMulti();
/* 2502 */     this.client.zremrangeByScore(key, start, end);
/* 2503 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long zunionstore(byte[] dstkey, byte[][] sets)
/*      */   {
/* 2545 */     checkIsInMulti();
/* 2546 */     this.client.zunionstore(dstkey, sets);
/* 2547 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long zunionstore(byte[] dstkey, ZParams params, byte[][] sets)
/*      */   {
/* 2591 */     checkIsInMulti();
/* 2592 */     this.client.zunionstore(dstkey, params, sets);
/* 2593 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long zinterstore(byte[] dstkey, byte[][] sets)
/*      */   {
/* 2635 */     checkIsInMulti();
/* 2636 */     this.client.zinterstore(dstkey, sets);
/* 2637 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long zinterstore(byte[] dstkey, ZParams params, byte[][] sets)
/*      */   {
/* 2681 */     checkIsInMulti();
/* 2682 */     this.client.zinterstore(dstkey, params, sets);
/* 2683 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String save()
/*      */   {
/* 2703 */     this.client.save();
/* 2704 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public String bgsave()
/*      */   {
/* 2718 */     this.client.bgsave();
/* 2719 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public String bgrewriteaof()
/*      */   {
/* 2741 */     this.client.bgrewriteaof();
/* 2742 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public Long lastsave()
/*      */   {
/* 2757 */     this.client.lastsave();
/* 2758 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String shutdown()
/*      */   {
/* 2774 */     this.client.shutdown();
/* 2775 */     String status = null;
/*      */     try {
/* 2777 */       status = this.client.getStatusCodeReply();
/*      */     } catch (JedisException ex) {
/* 2779 */       status = null;
/*      */     }
/* 2781 */     return status;
/*      */   }
/*      */ 
/*      */   public String info()
/*      */   {
/* 2825 */     this.client.info();
/* 2826 */     return this.client.getBulkReply();
/*      */   }
/*      */ 
/*      */   public String info(String section) {
/* 2830 */     this.client.info(section);
/* 2831 */     return this.client.getBulkReply();
/*      */   }
/*      */ 
/*      */   public void monitor(JedisMonitor jedisMonitor)
/*      */   {
/* 2845 */     this.client.monitor();
/* 2846 */     jedisMonitor.proceed(this.client);
/*      */   }
/*      */ 
/*      */   public String slaveof(String host, int port)
/*      */   {
/* 2875 */     this.client.slaveof(host, port);
/* 2876 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public String slaveofNoOne() {
/* 2880 */     this.client.slaveofNoOne();
/* 2881 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public List<byte[]> configGet(byte[] pattern)
/*      */   {
/* 2921 */     this.client.configGet(pattern);
/* 2922 */     return this.client.getBinaryMultiBulkReply();
/*      */   }
/*      */ 
/*      */   public String configResetStat()
/*      */   {
/* 2931 */     this.client.configResetStat();
/* 2932 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public byte[] configSet(byte[] parameter, byte[] value)
/*      */   {
/* 2970 */     this.client.configSet(parameter, value);
/* 2971 */     return this.client.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   public boolean isConnected() {
/* 2975 */     return this.client.isConnected();
/*      */   }
/*      */ 
/*      */   public Long strlen(byte[] key) {
/* 2979 */     this.client.strlen(key);
/* 2980 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public void sync() {
/* 2984 */     this.client.sync();
/*      */   }
/*      */ 
/*      */   public Long lpushx(byte[] key, byte[][] string) {
/* 2988 */     this.client.lpushx(key, string);
/* 2989 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long persist(byte[] key)
/*      */   {
/* 3003 */     this.client.persist(key);
/* 3004 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long rpushx(byte[] key, byte[][] string) {
/* 3008 */     this.client.rpushx(key, string);
/* 3009 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public byte[] echo(byte[] string) {
/* 3013 */     this.client.echo(string);
/* 3014 */     return this.client.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   public Long linsert(byte[] key, BinaryClient.LIST_POSITION where, byte[] pivot, byte[] value)
/*      */   {
/* 3019 */     this.client.linsert(key, where, pivot, value);
/* 3020 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String debug(DebugParams params) {
/* 3024 */     this.client.debug(params);
/* 3025 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public Client getClient() {
/* 3029 */     return this.client;
/*      */   }
/*      */ 
/*      */   public byte[] brpoplpush(byte[] source, byte[] destination, int timeout)
/*      */   {
/* 3042 */     this.client.brpoplpush(source, destination, timeout);
/* 3043 */     this.client.setTimeoutInfinite();
/* 3044 */     byte[] reply = this.client.getBinaryBulkReply();
/* 3045 */     this.client.rollbackTimeout();
/* 3046 */     return reply;
/*      */   }
/*      */ 
/*      */   public Boolean setbit(byte[] key, long offset, boolean value)
/*      */   {
/* 3058 */     this.client.setbit(key, offset, value);
/* 3059 */     if (this.client.getIntegerReply().longValue() == 1L) return Boolean.valueOf(true); return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   public Boolean setbit(byte[] key, long offset, byte[] value) {
/* 3063 */     this.client.setbit(key, offset, value);
/* 3064 */     if (this.client.getIntegerReply().longValue() == 1L) return Boolean.valueOf(true); return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   public Boolean getbit(byte[] key, long offset)
/*      */   {
/* 3075 */     this.client.getbit(key, offset);
/* 3076 */     if (this.client.getIntegerReply().longValue() == 1L) return Boolean.valueOf(true); return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   public Long setrange(byte[] key, long offset, byte[] value) {
/* 3080 */     this.client.setrange(key, offset, value);
/* 3081 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public byte[] getrange(byte[] key, long startOffset, long endOffset) {
/* 3085 */     this.client.getrange(key, startOffset, endOffset);
/* 3086 */     return this.client.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   public Long publish(byte[] channel, byte[] message) {
/* 3090 */     this.client.publish(channel, message);
/* 3091 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public void subscribe(BinaryJedisPubSub jedisPubSub, byte[][] channels) {
/* 3095 */     this.client.setTimeoutInfinite();
/* 3096 */     jedisPubSub.proceed(this.client, channels);
/* 3097 */     this.client.rollbackTimeout();
/*      */   }
/*      */ 
/*      */   public void psubscribe(BinaryJedisPubSub jedisPubSub, byte[][] patterns) {
/* 3101 */     this.client.setTimeoutInfinite();
/* 3102 */     jedisPubSub.proceedWithPatterns(this.client, patterns);
/* 3103 */     this.client.rollbackTimeout();
/*      */   }
/*      */ 
/*      */   public Long getDB() {
/* 3107 */     return this.client.getDB();
/*      */   }
/*      */ 
/*      */   public Object eval(byte[] script, List<byte[]> keys, List<byte[]> args)
/*      */   {
/* 3118 */     this.client.setTimeoutInfinite();
/* 3119 */     this.client.eval(script, Protocol.toByteArray(keys.size()), getParams(keys, args));
/* 3120 */     return this.client.getOne();
/*      */   }
/*      */ 
/*      */   private byte[][] getParams(List<byte[]> keys, List<byte[]> args) {
/* 3124 */     int keyCount = keys.size();
/* 3125 */     byte[][] params = new byte[keyCount + args.size()][];
/*      */ 
/* 3127 */     for (int i = 0; i < keyCount; i++) {
/* 3128 */       params[i] = ((byte[])keys.get(i));
/*      */     }
/* 3130 */     for (int i = 0; i < keys.size(); i++) {
/* 3131 */       params[(keyCount + i)] = ((byte[])args.get(i));
/*      */     }
/* 3133 */     return params;
/*      */   }
/*      */ 
/*      */   public Object eval(byte[] script, byte[] keyCount, byte[][] params) {
/* 3137 */     this.client.setTimeoutInfinite();
/* 3138 */     this.client.eval(script, keyCount, params);
/* 3139 */     return this.client.getOne();
/*      */   }
/*      */ 
/*      */   public Object eval(byte[] script, int keyCount, byte[][] params) {
/* 3143 */     this.client.setTimeoutInfinite();
/* 3144 */     this.client.eval(script, SafeEncoder.encode(Integer.toString(keyCount)), params);
/* 3145 */     return this.client.getOne();
/*      */   }
/*      */ 
/*      */   public Object eval(byte[] script) {
/* 3149 */     this.client.setTimeoutInfinite();
/* 3150 */     this.client.eval(script, 0, new byte[0][]);
/* 3151 */     return this.client.getOne();
/*      */   }
/*      */ 
/*      */   public Object evalsha(byte[] sha1) {
/* 3155 */     this.client.setTimeoutInfinite();
/* 3156 */     this.client.evalsha(sha1, 0, new byte[0][]);
/* 3157 */     return this.client.getOne();
/*      */   }
/*      */ 
/*      */   public Object evalsha(byte[] sha1, List<byte[]> keys, List<byte[]> args) {
/* 3161 */     this.client.setTimeoutInfinite();
/* 3162 */     this.client.evalsha(sha1, keys.size(), (byte[][])keys.toArray(new byte[0][]));
/* 3163 */     return this.client.getOne();
/*      */   }
/*      */ 
/*      */   public Object evalsha(byte[] sha1, int keyCount, byte[][] params) {
/* 3167 */     this.client.setTimeoutInfinite();
/* 3168 */     this.client.evalsha(sha1, keyCount, params);
/* 3169 */     return this.client.getOne();
/*      */   }
/*      */ 
/*      */   public String scriptFlush() {
/* 3173 */     this.client.scriptFlush();
/* 3174 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public List<Long> scriptExists(byte[][] sha1) {
/* 3178 */     this.client.scriptExists(sha1);
/* 3179 */     return this.client.getIntegerMultiBulkReply();
/*      */   }
/*      */ 
/*      */   public byte[] scriptLoad(byte[] script) {
/* 3183 */     this.client.scriptLoad(script);
/* 3184 */     return this.client.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   public String scriptKill() {
/* 3188 */     this.client.scriptKill();
/* 3189 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public String slowlogReset() {
/* 3193 */     this.client.slowlogReset();
/* 3194 */     return this.client.getBulkReply();
/*      */   }
/*      */ 
/*      */   public Long slowlogLen() {
/* 3198 */     this.client.slowlogLen();
/* 3199 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public List<byte[]> slowlogGetBinary() {
/* 3203 */     this.client.slowlogGet();
/* 3204 */     return this.client.getBinaryMultiBulkReply();
/*      */   }
/*      */ 
/*      */   public List<byte[]> slowlogGetBinary(long entries) {
/* 3208 */     this.client.slowlogGet(entries);
/* 3209 */     return this.client.getBinaryMultiBulkReply();
/*      */   }
/*      */ 
/*      */   public Long objectRefcount(byte[] key) {
/* 3213 */     this.client.objectRefcount(key);
/* 3214 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public byte[] objectEncoding(byte[] key) {
/* 3218 */     this.client.objectEncoding(key);
/* 3219 */     return this.client.getBinaryBulkReply();
/*      */   }
/*      */ 
/*      */   public Long objectIdletime(byte[] key) {
/* 3223 */     this.client.objectIdletime(key);
/* 3224 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long bitcount(byte[] key) {
/* 3228 */     this.client.bitcount(key);
/* 3229 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long bitcount(byte[] key, long start, long end) {
/* 3233 */     this.client.bitcount(key, start, end);
/* 3234 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long bitop(BitOP op, byte[] destKey, byte[][] srcKeys) {
/* 3238 */     this.client.bitop(op, destKey, srcKeys);
/* 3239 */     return this.client.getIntegerReply();
/*      */   }
/*      */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.BinaryJedis
 * JD-Core Version:    0.6.0
 */