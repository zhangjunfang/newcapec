/*    */ package cn.newcapec.framework.base.dao.redis.util;
/*    */ 
/*    */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisConnectionException;
/*    */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisException;
/*    */ import org.apache.commons.pool.PoolableObjectFactory;
/*    */ import org.apache.commons.pool.impl.GenericObjectPool;
/*    */ import org.apache.commons.pool.impl.GenericObjectPool.Config;
/*    */ 
/*    */ public abstract class Pool<T>
/*    */ {
/*    */   protected GenericObjectPool internalPool;
/*    */ 
/*    */   protected Pool()
/*    */   {
/* 13 */     this.internalPool = null;
/*    */   }
/*    */ 
/*    */   public Pool(GenericObjectPool.Config poolConfig, PoolableObjectFactory factory)
/*    */   {
/* 18 */     this.internalPool = new GenericObjectPool(factory, poolConfig);
/*    */   }
/*    */ 
/*    */   public T getResource()
/*    */   {
/*    */     try {
/* 24 */       return this.internalPool.borrowObject(); } catch (Exception e) {
/*    */     }
/* 26 */     throw new JedisConnectionException(
/* 27 */       "Could not get a resource from the pool", e);
/*    */   }
/*    */ 
/*    */   public void returnResourceObject(Object resource)
/*    */   {
/*    */     try {
/* 33 */       this.internalPool.returnObject(resource);
/*    */     } catch (Exception e) {
/* 35 */       throw new JedisException(
/* 36 */         "Could not return the resource to the pool", e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void returnBrokenResource(T resource) {
/* 41 */     returnBrokenResourceObject(resource);
/*    */   }
/*    */ 
/*    */   public void returnResource(T resource) {
/* 45 */     returnResourceObject(resource);
/*    */   }
/*    */ 
/*    */   protected void returnBrokenResourceObject(Object resource) {
/*    */     try {
/* 50 */       this.internalPool.invalidateObject(resource);
/*    */     } catch (Exception e) {
/* 52 */       throw new JedisException(
/* 53 */         "Could not return the resource to the pool", e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void destroy() {
/*    */     try {
/* 59 */       this.internalPool.close();
/*    */     } catch (Exception e) {
/* 61 */       throw new JedisException("Could not destroy the pool", e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.util.Pool
 * JD-Core Version:    0.6.0
 */