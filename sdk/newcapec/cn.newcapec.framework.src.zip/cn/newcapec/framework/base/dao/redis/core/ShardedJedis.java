/*     */ package cn.newcapec.framework.base.dao.redis.core;
/*     */ 
/*     */ import cn.newcapec.framework.base.dao.redis.util.Hashing;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class ShardedJedis extends BinaryShardedJedis
/*     */   implements JedisCommands
/*     */ {
/*     */   public ShardedJedis(List<JedisShardInfo> shards)
/*     */   {
/*  13 */     super(shards);
/*     */   }
/*     */ 
/*     */   public ShardedJedis(List<JedisShardInfo> shards, Hashing algo) {
/*  17 */     super(shards, algo);
/*     */   }
/*     */ 
/*     */   public ShardedJedis(List<JedisShardInfo> shards, Pattern keyTagPattern) {
/*  21 */     super(shards, keyTagPattern);
/*     */   }
/*     */ 
/*     */   public ShardedJedis(List<JedisShardInfo> shards, Hashing algo, Pattern keyTagPattern)
/*     */   {
/*  26 */     super(shards, algo, keyTagPattern);
/*     */   }
/*     */ 
/*     */   public String set(String key, String value) {
/*  30 */     Jedis j = (Jedis)getShard(key);
/*  31 */     return j.set(key, value);
/*     */   }
/*     */ 
/*     */   public String get(String key) {
/*  35 */     Jedis j = (Jedis)getShard(key);
/*  36 */     return j.get(key);
/*     */   }
/*     */ 
/*     */   public String echo(String string) {
/*  40 */     Jedis j = (Jedis)getShard(string);
/*  41 */     return j.echo(string);
/*     */   }
/*     */ 
/*     */   public Boolean exists(String key) {
/*  45 */     Jedis j = (Jedis)getShard(key);
/*  46 */     return j.exists(key);
/*     */   }
/*     */ 
/*     */   public String type(String key) {
/*  50 */     Jedis j = (Jedis)getShard(key);
/*  51 */     return j.type(key);
/*     */   }
/*     */ 
/*     */   public Long expire(String key, int seconds) {
/*  55 */     Jedis j = (Jedis)getShard(key);
/*  56 */     return j.expire(key, seconds);
/*     */   }
/*     */ 
/*     */   public Long expireAt(String key, long unixTime) {
/*  60 */     Jedis j = (Jedis)getShard(key);
/*  61 */     return j.expireAt(key, unixTime);
/*     */   }
/*     */ 
/*     */   public Long ttl(String key) {
/*  65 */     Jedis j = (Jedis)getShard(key);
/*  66 */     return j.ttl(key);
/*     */   }
/*     */ 
/*     */   public Boolean setbit(String key, long offset, boolean value) {
/*  70 */     Jedis j = (Jedis)getShard(key);
/*  71 */     return j.setbit(key, offset, value);
/*     */   }
/*     */ 
/*     */   public Boolean setbit(String key, long offset, String value) {
/*  75 */     Jedis j = (Jedis)getShard(key);
/*  76 */     return j.setbit(key, offset, value);
/*     */   }
/*     */ 
/*     */   public Boolean getbit(String key, long offset) {
/*  80 */     Jedis j = (Jedis)getShard(key);
/*  81 */     return j.getbit(key, offset);
/*     */   }
/*     */ 
/*     */   public Long setrange(String key, long offset, String value) {
/*  85 */     Jedis j = (Jedis)getShard(key);
/*  86 */     return j.setrange(key, offset, value);
/*     */   }
/*     */ 
/*     */   public String getrange(String key, long startOffset, long endOffset) {
/*  90 */     Jedis j = (Jedis)getShard(key);
/*  91 */     return j.getrange(key, startOffset, endOffset);
/*     */   }
/*     */ 
/*     */   public String getSet(String key, String value) {
/*  95 */     Jedis j = (Jedis)getShard(key);
/*  96 */     return j.getSet(key, value);
/*     */   }
/*     */ 
/*     */   public Long setnx(String key, String value) {
/* 100 */     Jedis j = (Jedis)getShard(key);
/* 101 */     return j.setnx(key, value);
/*     */   }
/*     */ 
/*     */   public String setex(String key, int seconds, String value) {
/* 105 */     Jedis j = (Jedis)getShard(key);
/* 106 */     return j.setex(key, seconds, value);
/*     */   }
/*     */ 
/*     */   public List<String> blpop(String arg) {
/* 110 */     Jedis j = (Jedis)getShard(arg);
/* 111 */     return j.blpop(arg);
/*     */   }
/*     */   public List<String> blpop(int timeout, String arg) {
/* 114 */     Jedis j = (Jedis)getShard(arg);
/* 115 */     return j.blpop(timeout, new String[] { arg });
/*     */   }
/*     */ 
/*     */   public List<String> brpop(String arg) {
/* 119 */     Jedis j = (Jedis)getShard(arg);
/* 120 */     return j.brpop(arg);
/*     */   }
/*     */ 
/*     */   public Long decrBy(String key, long integer) {
/* 124 */     Jedis j = (Jedis)getShard(key);
/* 125 */     return j.decrBy(key, integer);
/*     */   }
/*     */ 
/*     */   public Long decr(String key) {
/* 129 */     Jedis j = (Jedis)getShard(key);
/* 130 */     return j.decr(key);
/*     */   }
/*     */ 
/*     */   public Long incrBy(String key, long integer) {
/* 134 */     Jedis j = (Jedis)getShard(key);
/* 135 */     return j.incrBy(key, integer);
/*     */   }
/*     */ 
/*     */   public Long incr(String key) {
/* 139 */     Jedis j = (Jedis)getShard(key);
/* 140 */     return j.incr(key);
/*     */   }
/*     */ 
/*     */   public Long append(String key, String value) {
/* 144 */     Jedis j = (Jedis)getShard(key);
/* 145 */     return j.append(key, value);
/*     */   }
/*     */ 
/*     */   public String substr(String key, int start, int end) {
/* 149 */     Jedis j = (Jedis)getShard(key);
/* 150 */     return j.substr(key, start, end);
/*     */   }
/*     */ 
/*     */   public Long hset(String key, String field, String value) {
/* 154 */     Jedis j = (Jedis)getShard(key);
/* 155 */     return j.hset(key, field, value);
/*     */   }
/*     */ 
/*     */   public String hget(String key, String field) {
/* 159 */     Jedis j = (Jedis)getShard(key);
/* 160 */     return j.hget(key, field);
/*     */   }
/*     */ 
/*     */   public Long hsetnx(String key, String field, String value) {
/* 164 */     Jedis j = (Jedis)getShard(key);
/* 165 */     return j.hsetnx(key, field, value);
/*     */   }
/*     */ 
/*     */   public String hmset(String key, Map<String, String> hash) {
/* 169 */     Jedis j = (Jedis)getShard(key);
/* 170 */     return j.hmset(key, hash);
/*     */   }
/*     */ 
/*     */   public List<String> hmget(String key, String[] fields) {
/* 174 */     Jedis j = (Jedis)getShard(key);
/* 175 */     return j.hmget(key, fields);
/*     */   }
/*     */ 
/*     */   public Long hincrBy(String key, String field, long value) {
/* 179 */     Jedis j = (Jedis)getShard(key);
/* 180 */     return j.hincrBy(key, field, value);
/*     */   }
/*     */ 
/*     */   public Boolean hexists(String key, String field) {
/* 184 */     Jedis j = (Jedis)getShard(key);
/* 185 */     return j.hexists(key, field);
/*     */   }
/*     */ 
/*     */   public Long del(String key) {
/* 189 */     Jedis j = (Jedis)getShard(key);
/* 190 */     return j.del(key);
/*     */   }
/*     */ 
/*     */   public Long hdel(String key, String[] fields) {
/* 194 */     Jedis j = (Jedis)getShard(key);
/* 195 */     return j.hdel(key, fields);
/*     */   }
/*     */ 
/*     */   public Long hlen(String key) {
/* 199 */     Jedis j = (Jedis)getShard(key);
/* 200 */     return j.hlen(key);
/*     */   }
/*     */ 
/*     */   public Set<String> hkeys(String key) {
/* 204 */     Jedis j = (Jedis)getShard(key);
/* 205 */     return j.hkeys(key);
/*     */   }
/*     */ 
/*     */   public Set<String> keys(String key) {
/* 209 */     Jedis j = (Jedis)getShard(key);
/* 210 */     return j.keys(key);
/*     */   }
/*     */ 
/*     */   public List<String> hvals(String key) {
/* 214 */     Jedis j = (Jedis)getShard(key);
/* 215 */     return j.hvals(key);
/*     */   }
/*     */ 
/*     */   public Map<String, String> hgetAll(String key) {
/* 219 */     Jedis j = (Jedis)getShard(key);
/* 220 */     return j.hgetAll(key);
/*     */   }
/*     */ 
/*     */   public Long rpush(String key, String[] strings) {
/* 224 */     Jedis j = (Jedis)getShard(key);
/* 225 */     return j.rpush(key, strings);
/*     */   }
/*     */ 
/*     */   public Long lpush(String key, String[] strings) {
/* 229 */     Jedis j = (Jedis)getShard(key);
/* 230 */     return j.lpush(key, strings);
/*     */   }
/*     */ 
/*     */   public Long lpushx(String key, String[] string) {
/* 234 */     Jedis j = (Jedis)getShard(key);
/* 235 */     return j.lpushx(key, string);
/*     */   }
/*     */ 
/*     */   public Long strlen(String key) {
/* 239 */     Jedis j = (Jedis)getShard(key);
/* 240 */     return j.strlen(key);
/*     */   }
/*     */ 
/*     */   public Long move(String key, int dbIndex) {
/* 244 */     Jedis j = (Jedis)getShard(key);
/* 245 */     return j.move(key, dbIndex);
/*     */   }
/*     */ 
/*     */   public Long rpushx(String key, String[] string) {
/* 249 */     Jedis j = (Jedis)getShard(key);
/* 250 */     return j.rpushx(key, string);
/*     */   }
/*     */ 
/*     */   public Long persist(String key) {
/* 254 */     Jedis j = (Jedis)getShard(key);
/* 255 */     return j.persist(key);
/*     */   }
/*     */ 
/*     */   public Long llen(String key) {
/* 259 */     Jedis j = (Jedis)getShard(key);
/* 260 */     return j.llen(key);
/*     */   }
/*     */ 
/*     */   public List<String> lrange(String key, long start, long end) {
/* 264 */     Jedis j = (Jedis)getShard(key);
/* 265 */     return j.lrange(key, start, end);
/*     */   }
/*     */ 
/*     */   public String ltrim(String key, long start, long end) {
/* 269 */     Jedis j = (Jedis)getShard(key);
/* 270 */     return j.ltrim(key, start, end);
/*     */   }
/*     */ 
/*     */   public String lindex(String key, long index) {
/* 274 */     Jedis j = (Jedis)getShard(key);
/* 275 */     return j.lindex(key, index);
/*     */   }
/*     */ 
/*     */   public String lset(String key, long index, String value) {
/* 279 */     Jedis j = (Jedis)getShard(key);
/* 280 */     return j.lset(key, index, value);
/*     */   }
/*     */ 
/*     */   public Long lrem(String key, long count, String value) {
/* 284 */     Jedis j = (Jedis)getShard(key);
/* 285 */     return j.lrem(key, count, value);
/*     */   }
/*     */ 
/*     */   public String lpop(String key) {
/* 289 */     Jedis j = (Jedis)getShard(key);
/* 290 */     return j.lpop(key);
/*     */   }
/*     */ 
/*     */   public String rpop(String key) {
/* 294 */     Jedis j = (Jedis)getShard(key);
/* 295 */     return j.rpop(key);
/*     */   }
/*     */ 
/*     */   public Long sadd(String key, String[] members) {
/* 299 */     Jedis j = (Jedis)getShard(key);
/* 300 */     return j.sadd(key, members);
/*     */   }
/*     */ 
/*     */   public Set<String> smembers(String key) {
/* 304 */     Jedis j = (Jedis)getShard(key);
/* 305 */     return j.smembers(key);
/*     */   }
/*     */ 
/*     */   public Long srem(String key, String[] members) {
/* 309 */     Jedis j = (Jedis)getShard(key);
/* 310 */     return j.srem(key, members);
/*     */   }
/*     */ 
/*     */   public String spop(String key) {
/* 314 */     Jedis j = (Jedis)getShard(key);
/* 315 */     return j.spop(key);
/*     */   }
/*     */ 
/*     */   public Long scard(String key) {
/* 319 */     Jedis j = (Jedis)getShard(key);
/* 320 */     return j.scard(key);
/*     */   }
/*     */ 
/*     */   public Boolean sismember(String key, String member) {
/* 324 */     Jedis j = (Jedis)getShard(key);
/* 325 */     return j.sismember(key, member);
/*     */   }
/*     */ 
/*     */   public String srandmember(String key) {
/* 329 */     Jedis j = (Jedis)getShard(key);
/* 330 */     return j.srandmember(key);
/*     */   }
/*     */ 
/*     */   public Long zadd(String key, double score, String member) {
/* 334 */     Jedis j = (Jedis)getShard(key);
/* 335 */     return j.zadd(key, score, member);
/*     */   }
/*     */ 
/*     */   public Long zadd(String key, Map<Double, String> scoreMembers) {
/* 339 */     Jedis j = (Jedis)getShard(key);
/* 340 */     return j.zadd(key, scoreMembers);
/*     */   }
/*     */ 
/*     */   public Set<String> zrange(String key, long start, long end) {
/* 344 */     Jedis j = (Jedis)getShard(key);
/* 345 */     return j.zrange(key, start, end);
/*     */   }
/*     */ 
/*     */   public Long zrem(String key, String[] members) {
/* 349 */     Jedis j = (Jedis)getShard(key);
/* 350 */     return j.zrem(key, members);
/*     */   }
/*     */ 
/*     */   public Double zincrby(String key, double score, String member) {
/* 354 */     Jedis j = (Jedis)getShard(key);
/* 355 */     return j.zincrby(key, score, member);
/*     */   }
/*     */ 
/*     */   public Long zrank(String key, String member) {
/* 359 */     Jedis j = (Jedis)getShard(key);
/* 360 */     return j.zrank(key, member);
/*     */   }
/*     */ 
/*     */   public Long zrevrank(String key, String member) {
/* 364 */     Jedis j = (Jedis)getShard(key);
/* 365 */     return j.zrevrank(key, member);
/*     */   }
/*     */ 
/*     */   public Set<String> zrevrange(String key, long start, long end) {
/* 369 */     Jedis j = (Jedis)getShard(key);
/* 370 */     return j.zrevrange(key, start, end);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrangeWithScores(String key, long start, long end) {
/* 374 */     Jedis j = (Jedis)getShard(key);
/* 375 */     return j.zrangeWithScores(key, start, end);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrevrangeWithScores(String key, long start, long end) {
/* 379 */     Jedis j = (Jedis)getShard(key);
/* 380 */     return j.zrevrangeWithScores(key, start, end);
/*     */   }
/*     */ 
/*     */   public Long zcard(String key) {
/* 384 */     Jedis j = (Jedis)getShard(key);
/* 385 */     return j.zcard(key);
/*     */   }
/*     */ 
/*     */   public Double zscore(String key, String member) {
/* 389 */     Jedis j = (Jedis)getShard(key);
/* 390 */     return j.zscore(key, member);
/*     */   }
/*     */ 
/*     */   public List<String> sort(String key) {
/* 394 */     Jedis j = (Jedis)getShard(key);
/* 395 */     return j.sort(key);
/*     */   }
/*     */ 
/*     */   public List<String> sort(String key, SortingParams sortingParameters) {
/* 399 */     Jedis j = (Jedis)getShard(key);
/* 400 */     return j.sort(key, sortingParameters);
/*     */   }
/*     */ 
/*     */   public Long zcount(String key, double min, double max) {
/* 404 */     Jedis j = (Jedis)getShard(key);
/* 405 */     return j.zcount(key, min, max);
/*     */   }
/*     */ 
/*     */   public Long zcount(String key, String min, String max) {
/* 409 */     Jedis j = (Jedis)getShard(key);
/* 410 */     return j.zcount(key, min, max);
/*     */   }
/*     */ 
/*     */   public Set<String> zrangeByScore(String key, double min, double max) {
/* 414 */     Jedis j = (Jedis)getShard(key);
/* 415 */     return j.zrangeByScore(key, min, max);
/*     */   }
/*     */ 
/*     */   public Set<String> zrevrangeByScore(String key, double max, double min) {
/* 419 */     Jedis j = (Jedis)getShard(key);
/* 420 */     return j.zrevrangeByScore(key, max, min);
/*     */   }
/*     */ 
/*     */   public Set<String> zrangeByScore(String key, double min, double max, int offset, int count)
/*     */   {
/* 425 */     Jedis j = (Jedis)getShard(key);
/* 426 */     return j.zrangeByScore(key, min, max, offset, count);
/*     */   }
/*     */ 
/*     */   public Set<String> zrevrangeByScore(String key, double max, double min, int offset, int count)
/*     */   {
/* 431 */     Jedis j = (Jedis)getShard(key);
/* 432 */     return j.zrevrangeByScore(key, max, min, offset, count);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrangeByScoreWithScores(String key, double min, double max) {
/* 436 */     Jedis j = (Jedis)getShard(key);
/* 437 */     return j.zrangeByScoreWithScores(key, min, max);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrevrangeByScoreWithScores(String key, double max, double min)
/*     */   {
/* 442 */     Jedis j = (Jedis)getShard(key);
/* 443 */     return j.zrevrangeByScoreWithScores(key, max, min);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrangeByScoreWithScores(String key, double min, double max, int offset, int count)
/*     */   {
/* 448 */     Jedis j = (Jedis)getShard(key);
/* 449 */     return j.zrangeByScoreWithScores(key, min, max, offset, count);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrevrangeByScoreWithScores(String key, double max, double min, int offset, int count)
/*     */   {
/* 454 */     Jedis j = (Jedis)getShard(key);
/* 455 */     return j.zrevrangeByScoreWithScores(key, max, min, offset, count);
/*     */   }
/*     */ 
/*     */   public Set<String> zrangeByScore(String key, String min, String max) {
/* 459 */     Jedis j = (Jedis)getShard(key);
/* 460 */     return j.zrangeByScore(key, min, max);
/*     */   }
/*     */ 
/*     */   public Set<String> zrevrangeByScore(String key, String max, String min) {
/* 464 */     Jedis j = (Jedis)getShard(key);
/* 465 */     return j.zrevrangeByScore(key, max, min);
/*     */   }
/*     */ 
/*     */   public Set<String> zrangeByScore(String key, String min, String max, int offset, int count)
/*     */   {
/* 470 */     Jedis j = (Jedis)getShard(key);
/* 471 */     return j.zrangeByScore(key, min, max, offset, count);
/*     */   }
/*     */ 
/*     */   public Set<String> zrevrangeByScore(String key, String max, String min, int offset, int count)
/*     */   {
/* 476 */     Jedis j = (Jedis)getShard(key);
/* 477 */     return j.zrevrangeByScore(key, max, min, offset, count);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrangeByScoreWithScores(String key, String min, String max) {
/* 481 */     Jedis j = (Jedis)getShard(key);
/* 482 */     return j.zrangeByScoreWithScores(key, min, max);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrevrangeByScoreWithScores(String key, String max, String min)
/*     */   {
/* 487 */     Jedis j = (Jedis)getShard(key);
/* 488 */     return j.zrevrangeByScoreWithScores(key, max, min);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrangeByScoreWithScores(String key, String min, String max, int offset, int count)
/*     */   {
/* 493 */     Jedis j = (Jedis)getShard(key);
/* 494 */     return j.zrangeByScoreWithScores(key, min, max, offset, count);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrevrangeByScoreWithScores(String key, String max, String min, int offset, int count)
/*     */   {
/* 499 */     Jedis j = (Jedis)getShard(key);
/* 500 */     return j.zrevrangeByScoreWithScores(key, max, min, offset, count);
/*     */   }
/*     */ 
/*     */   public Long zremrangeByRank(String key, long start, long end) {
/* 504 */     Jedis j = (Jedis)getShard(key);
/* 505 */     return j.zremrangeByRank(key, start, end);
/*     */   }
/*     */ 
/*     */   public Long zremrangeByScore(String key, double start, double end) {
/* 509 */     Jedis j = (Jedis)getShard(key);
/* 510 */     return j.zremrangeByScore(key, start, end);
/*     */   }
/*     */ 
/*     */   public Long zremrangeByScore(String key, String start, String end) {
/* 514 */     Jedis j = (Jedis)getShard(key);
/* 515 */     return j.zremrangeByScore(key, start, end);
/*     */   }
/*     */ 
/*     */   public Long linsert(String key, BinaryClient.LIST_POSITION where, String pivot, String value)
/*     */   {
/* 520 */     Jedis j = (Jedis)getShard(key);
/* 521 */     return j.linsert(key, where, pivot, value);
/*     */   }
/*     */ 
/*     */   public Long bitcount(String key) {
/* 525 */     Jedis j = (Jedis)getShard(key);
/* 526 */     return j.bitcount(key);
/*     */   }
/*     */ 
/*     */   public Long bitcount(String key, long start, long end) {
/* 530 */     Jedis j = (Jedis)getShard(key);
/* 531 */     return j.bitcount(key, start, end);
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.ShardedJedis
 * JD-Core Version:    0.6.0
 */