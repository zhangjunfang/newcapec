/*     */ package cn.newcapec.framework.base.dao.redis.config;
/*     */ 
/*     */ import cn.newcapec.framework.base.dao.redis.core.JedisShardInfo;
/*     */ import cn.newcapec.framework.base.dao.redis.core.ShardedJedis;
/*     */ import cn.newcapec.framework.base.dao.redis.core.ShardedJedisPool;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class ShardedJedisPoolFactory
/*     */ {
/*     */   private ShardedJedisPool pool;
/*     */   private ShardedJedis shardedJedis;
/*     */   private int timeout;
/*  24 */   private String[] masterConfStrings = null;
/*  25 */   private String[] slaveConfStrings = null;
/*     */   private boolean enableReadWriteSeparation;
/*  27 */   private List<JedisShardInfo> jedisInfoList = new ArrayList();
/*     */ 
/*     */   public ShardedJedisPoolFactory(ConnectionFactoryBuilder connectionFactoryBuilder)
/*     */   {
/*  31 */     this.timeout = connectionFactoryBuilder.getTimeout();
/*  32 */     this.masterConfStrings = StringUtils.split(
/*  33 */       connectionFactoryBuilder.getMasterConfString(), ",");
/*  34 */     this.slaveConfStrings = StringUtils.split(
/*  35 */       connectionFactoryBuilder.getSlaveConfString(), ",");
/*  36 */     for (String str : this.masterConfStrings) {
/*  37 */       this.jedisInfoList.add(
/*  38 */         new JedisShardInfo(str.split(":")[0], 
/*  38 */         Integer.parseInt(str.split(":")[1])));
/*     */     }
/*  40 */     for (String str : this.slaveConfStrings)
/*     */     {
/*  42 */       this.jedisInfoList.add(
/*  43 */         new JedisShardInfo(str.split(":")[0], 
/*  43 */         Integer.parseInt(str.split(":")[1])));
/*     */     }
/*  45 */     this.pool = 
/*  46 */       new ShardedJedisPool(connectionFactoryBuilder.getJedisPoolConfig(), this.jedisInfoList);
/*     */   }
/*     */ 
/*     */   public long rpush(String key, String string)
/*     */   {
/*  59 */     this.shardedJedis = ((ShardedJedis)this.pool.getResource());
/*  60 */     long ret = 0L;
/*  61 */     ret = this.shardedJedis.rpush(key, new String[] { string }).longValue();
/*  62 */     this.pool.returnResource(this.shardedJedis);
/*  63 */     return ret;
/*     */   }
/*     */ 
/*     */   public List<String> lrange(String key, long start, long end)
/*     */   {
/*  81 */     this.shardedJedis = ((ShardedJedis)this.pool.getResource());
/*  82 */     List ret = this.shardedJedis.lrange(key, start, end);
/*  83 */     this.pool.returnResource(this.shardedJedis);
/*  84 */     return ret;
/*     */   }
/*     */ 
/*     */   public void hset(String key, String field, String value)
/*     */   {
/*  97 */     this.shardedJedis = ((ShardedJedis)this.pool.getResource());
/*  98 */     this.shardedJedis.hset(key, field, value);
/*  99 */     this.pool.returnResource(this.shardedJedis);
/*     */   }
/*     */ 
/*     */   public void set(String key, String value)
/*     */   {
/* 109 */     this.shardedJedis = ((ShardedJedis)this.pool.getResource());
/* 110 */     this.shardedJedis.set(key, value);
/* 111 */     this.pool.returnResource(this.shardedJedis);
/*     */   }
/*     */ 
/*     */   public String get(String key)
/*     */   {
/* 121 */     this.shardedJedis = ((ShardedJedis)this.pool.getResource());
/* 122 */     String value = this.shardedJedis.get(key);
/* 123 */     this.pool.returnResource(this.shardedJedis);
/* 124 */     return value;
/*     */   }
/*     */ 
/*     */   public void hmset(String key, Map<String, String> map)
/*     */   {
/* 134 */     this.shardedJedis = ((ShardedJedis)this.pool.getResource());
/* 135 */     this.shardedJedis.hmset(key, map);
/* 136 */     this.pool.returnResource(this.shardedJedis);
/*     */   }
/*     */ 
/*     */   public void setex(String key, int seconds, String value)
/*     */   {
/* 148 */     this.shardedJedis = ((ShardedJedis)this.pool.getResource());
/* 149 */     this.shardedJedis.setex(key, seconds, value);
/* 150 */     this.pool.returnResource(this.shardedJedis);
/*     */   }
/*     */ 
/*     */   public void expire(String key, int seconds)
/*     */   {
/* 161 */     this.shardedJedis = ((ShardedJedis)this.pool.getResource());
/* 162 */     this.shardedJedis.expire(key, seconds);
/* 163 */     this.pool.returnResource(this.shardedJedis);
/*     */   }
/*     */ 
/*     */   public boolean exists(String key)
/*     */   {
/* 173 */     this.shardedJedis = ((ShardedJedis)this.pool.getResource());
/* 174 */     boolean bool = this.shardedJedis.exists(key).booleanValue();
/* 175 */     this.pool.returnResource(this.shardedJedis);
/* 176 */     return bool;
/*     */   }
/*     */ 
/*     */   public String type(String key)
/*     */   {
/* 186 */     this.shardedJedis = ((ShardedJedis)this.pool.getResource());
/* 187 */     String type = this.shardedJedis.type(key);
/* 188 */     this.pool.returnResource(this.shardedJedis);
/* 189 */     return type;
/*     */   }
/*     */ 
/*     */   public String hget(String key, String field)
/*     */   {
/* 199 */     this.shardedJedis = ((ShardedJedis)this.pool.getResource());
/* 200 */     String value = this.shardedJedis.hget(key, field);
/* 201 */     this.pool.returnResource(this.shardedJedis);
/* 202 */     return value;
/*     */   }
/*     */ 
/*     */   public Map<String, String> hgetAll(String key)
/*     */   {
/* 212 */     this.shardedJedis = ((ShardedJedis)this.pool.getResource());
/* 213 */     Map map = this.shardedJedis.hgetAll(key);
/* 214 */     this.pool.returnResource(this.shardedJedis);
/* 215 */     return map;
/*     */   }
/*     */ 
/*     */   public Set<?> smembers(String key)
/*     */   {
/* 226 */     this.shardedJedis = ((ShardedJedis)this.pool.getResource());
/* 227 */     Set set = this.shardedJedis.smembers(key);
/* 228 */     this.pool.returnResource(this.shardedJedis);
/* 229 */     return set;
/*     */   }
/*     */ 
/*     */   public void delSetObj(String key, String field)
/*     */   {
/* 241 */     this.shardedJedis = ((ShardedJedis)this.pool.getResource());
/* 242 */     this.shardedJedis.srem(key, new String[] { field });
/* 243 */     this.pool.returnResource(this.shardedJedis);
/*     */   }
/*     */ 
/*     */   public boolean isNotField(String key, String field)
/*     */   {
/* 254 */     this.shardedJedis = ((ShardedJedis)this.pool.getResource());
/* 255 */     boolean bool = this.shardedJedis.sismember(key, field).booleanValue();
/* 256 */     this.pool.returnResource(this.shardedJedis);
/* 257 */     return bool;
/*     */   }
/*     */ 
/*     */   public void append(String key, String value)
/*     */   {
/* 267 */     this.shardedJedis = ((ShardedJedis)this.pool.getResource());
/* 268 */     this.shardedJedis.append(key, value);
/* 269 */     this.pool.returnResource(this.shardedJedis);
/*     */   }
/*     */ 
/*     */   public void destory() {
/* 273 */     this.pool.destroy();
/*     */   }
/*     */ 
/*     */   public boolean isEnableReadWriteSeparation() {
/* 277 */     return this.enableReadWriteSeparation;
/*     */   }
/*     */ 
/*     */   public void setEnableReadWriteSeparation(boolean enableReadWriteSeparation) {
/* 281 */     this.enableReadWriteSeparation = enableReadWriteSeparation;
/*     */   }
/*     */ 
/*     */   public ShardedJedis getShardedJedis() {
/* 285 */     return this.shardedJedis;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.config.ShardedJedisPoolFactory
 * JD-Core Version:    0.6.0
 */