package cn.newcapec.framework.base.dao.db;

public abstract interface UUIDGenerator
{
  public abstract String generate();
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.db.UUIDGenerator
 * JD-Core Version:    0.6.0
 */