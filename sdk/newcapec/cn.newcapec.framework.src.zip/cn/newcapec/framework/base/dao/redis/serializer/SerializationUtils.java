/*    */ package cn.newcapec.framework.base.dao.redis.serializer;
/*    */ 
/*    */ import cn.newcapec.framework.base.dao.redis.core.Tuple;
/*    */ import cn.newcapec.framework.base.dao.redis.exception.TedisDataException;
/*    */ import cn.newcapec.framework.base.dao.redis.exception.TedisException;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ public abstract class SerializationUtils
/*    */ {
/* 23 */   public static final byte[] EMPTY_ARRAY = new byte[0];
/*    */   public static final String CHARSET = "UTF-8";
/*    */ 
/*    */   public static boolean isEmpty(byte[] data)
/*    */   {
/* 28 */     return (data == null) || (data.length == 0);
/*    */   }
/*    */ 
/*    */   public static byte[] serialize(String str) {
/*    */     try {
/* 33 */       if (str == null) {
/* 34 */         throw new TedisDataException("value sent to redis cannot be null");
/*    */       }
/* 36 */       return str.getBytes("UTF-8"); } catch (UnsupportedEncodingException e) {
/*    */     }
/* 38 */     throw new TedisException(e);
/*    */   }
/*    */ 
/*    */   public static byte[][] serialize(List<String> strings, TedisSerializer<String> stringSerializer)
/*    */   {
/* 43 */     List raw = null;
/*    */ 
/* 45 */     if (strings == null) {
/* 46 */       raw = Collections.emptyList();
/*    */     } else {
/* 48 */       raw = new ArrayList(strings.size());
/* 49 */       for (String key : strings) {
/* 50 */         raw.add(stringSerializer.serialize(key));
/*    */       }
/*    */     }
/* 53 */     return (byte[][])raw.toArray(new byte[raw.size()][]);
/*    */   }
/*    */ 
/*    */   public static String deserialize(byte[] data) {
/*    */     try {
/* 58 */       return new String(data, "UTF-8"); } catch (UnsupportedEncodingException e) {
/*    */     }
/* 60 */     throw new TedisException(e);
/*    */   }
/*    */ 
/*    */   public static <T extends Collection<?>> T deserializeValues(Collection<byte[]> rawValues, Class<T> type, TedisSerializer<?> redisSerializer)
/*    */   {
/* 65 */     if (rawValues == null) {
/* 66 */       return null;
/*    */     }
/*    */ 
/* 69 */     Collection values = List.class.isAssignableFrom(type) ? new ArrayList(rawValues.size()) : new LinkedHashSet(rawValues.size());
/* 70 */     for (byte[] bs : rawValues) {
/* 71 */       values.add(redisSerializer.deserialize(bs));
/*    */     }
/*    */ 
/* 74 */     return values;
/*    */   }
/*    */ 
/*    */   public static <T> Set<T> deserialize(Set<byte[]> rawValues, TedisSerializer<T> redisSerializer) {
/* 78 */     return (Set)deserializeValues(rawValues, Set.class, redisSerializer);
/*    */   }
/*    */ 
/*    */   public static <T> List<T> deserialize(List<byte[]> rawValues, TedisSerializer<T> redisSerializer) {
/* 82 */     return (List)deserializeValues(rawValues, List.class, redisSerializer);
/*    */   }
/*    */ 
/*    */   public static <T> Collection<T> deserialize(Collection<byte[]> rawValues, TedisSerializer<T> redisSerializer) {
/* 86 */     return deserializeValues(rawValues, List.class, redisSerializer);
/*    */   }
/*    */ 
/*    */   public static <HK> Map<HK, Double> deserializeTruble(Set<Tuple> tuples, TedisSerializer<HK> redisSerializer) {
/* 90 */     if (tuples == null) {
/* 91 */       return null;
/*    */     }
/* 93 */     Map map = new LinkedHashMap(tuples.size());
/*    */     Tuple localTuple;
/* 94 */     for (Iterator localIterator = tuples.iterator(); localIterator.hasNext(); localTuple = (Tuple)localIterator.next());
/* 97 */     return map;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.serializer.SerializationUtils
 * JD-Core Version:    0.6.0
 */