/*    */ package cn.newcapec.framework.base.dao.redis.serializer;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ 
/*    */ public class StringTedisSerializer
/*    */   implements TedisSerializer<String>
/*    */ {
/*    */   private final Charset charset;
/*    */ 
/*    */   public StringTedisSerializer()
/*    */   {
/* 21 */     this(Charset.forName("UTF-8"));
/*    */   }
/*    */ 
/*    */   public StringTedisSerializer(Charset charset) {
/* 25 */     this.charset = charset;
/*    */   }
/*    */ 
/*    */   public String deserialize(byte[] bytes)
/*    */   {
/* 30 */     return bytes == null ? null : new String(bytes, this.charset);
/*    */   }
/*    */ 
/*    */   public byte[] serialize(String string)
/*    */   {
/* 35 */     return string == null ? null : string.getBytes(this.charset);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.serializer.StringTedisSerializer
 * JD-Core Version:    0.6.0
 */