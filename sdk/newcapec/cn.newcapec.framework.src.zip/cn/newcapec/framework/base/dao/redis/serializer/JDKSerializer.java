/*    */ package cn.newcapec.framework.base.dao.redis.serializer;
/*    */ 
/*    */ import cn.newcapec.framework.base.dao.redis.exception.SerializationException;
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class JDKSerializer
/*    */   implements TedisSerializer<Object>
/*    */ {
/*    */   public Object deserialize(byte[] source)
/*    */     throws SerializationException
/*    */   {
/* 19 */     ByteArrayInputStream byteStream = new ByteArrayInputStream(source);
/*    */     try {
/* 21 */       ObjectInputStream objectInputStream = new ObjectInputStream(byteStream);
/* 22 */       return objectInputStream.readObject(); } catch (Exception ex) {
/*    */     }
/* 24 */     throw new SerializationException("反序列化对象失败" + ex);
/*    */   }
/*    */ 
/*    */   public byte[] serialize(Object object)
/*    */     throws SerializationException
/*    */   {
/* 30 */     if (!(object instanceof Serializable))
/* 31 */       throw new IllegalArgumentException(getClass().getSimpleName() + " requires a Serializable payload " + "but received an object of type [" + object.getClass().getName() + "]");
/*    */     try
/*    */     {
/* 34 */       ByteArrayOutputStream byteStream = new ByteArrayOutputStream(128);
/* 35 */       ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteStream);
/* 36 */       objectOutputStream.writeObject(object);
/* 37 */       objectOutputStream.flush();
/* 38 */       return byteStream.toByteArray(); } catch (Exception e) {
/*    */     }
/* 40 */     throw new SerializationException("序列化对象失败:" + object.getClass(), e);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.serializer.JDKSerializer
 * JD-Core Version:    0.6.0
 */