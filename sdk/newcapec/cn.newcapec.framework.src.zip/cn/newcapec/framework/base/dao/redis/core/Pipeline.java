/*     */ package cn.newcapec.framework.base.dao.redis.core;
/*     */ 
/*     */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisDataException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Pipeline extends MultiKeyPipelineBase
/*     */ {
/*     */   private MultiResponseBuilder currentMulti;
/*     */ 
/*     */   protected <T> Response<T> getResponse(Builder<T> builder)
/*     */   {
/*  40 */     if (this.currentMulti != null) {
/*  41 */       super.getResponse(BuilderFactory.STRING);
/*     */ 
/*  43 */       Response lr = new Response(builder);
/*  44 */       this.currentMulti.addResponse(lr);
/*  45 */       return lr;
/*     */     }
/*     */ 
/*  48 */     return super.getResponse(builder);
/*     */   }
/*     */ 
/*     */   public void setClient(Client client)
/*     */   {
/*  53 */     this.client = client;
/*     */   }
/*     */ 
/*     */   protected Client getClient(byte[] key)
/*     */   {
/*  58 */     return this.client;
/*     */   }
/*     */ 
/*     */   protected Client getClient(String key)
/*     */   {
/*  63 */     return this.client;
/*     */   }
/*     */ 
/*     */   public void sync()
/*     */   {
/*  72 */     List unformatted = this.client.getAll();
/*  73 */     for (Iterator localIterator = unformatted.iterator(); localIterator.hasNext(); ) { Object o = localIterator.next();
/*  74 */       generateResponse(o);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<Object> syncAndReturnAll()
/*     */   {
/*  87 */     List unformatted = this.client.getAll();
/*  88 */     List formatted = new ArrayList();
/*     */ 
/*  90 */     for (Iterator localIterator = unformatted.iterator(); localIterator.hasNext(); ) { Object o = localIterator.next();
/*     */       try {
/*  92 */         formatted.add(generateResponse(o).get());
/*     */       } catch (JedisDataException e) {
/*  94 */         formatted.add(e);
/*     */       }
/*     */     }
/*  97 */     return formatted;
/*     */   }
/*     */ 
/*     */   public Response<String> discard() {
/* 101 */     this.client.discard();
/* 102 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<List<Object>> exec() {
/* 106 */     this.client.exec();
/* 107 */     Response response = super.getResponse(this.currentMulti);
/* 108 */     this.currentMulti = null;
/* 109 */     return response;
/*     */   }
/*     */ 
/*     */   public Response<String> multi() {
/* 113 */     this.client.multi();
/* 114 */     Response response = getResponse(BuilderFactory.STRING);
/* 115 */     this.currentMulti = new MultiResponseBuilder(null);
/* 116 */     return response;
/*     */   }
/*     */ 
/*     */   private class MultiResponseBuilder extends Builder<List<Object>>
/*     */   {
/*  13 */     private List<Response<?>> responses = new ArrayList();
/*     */ 
/*     */     private MultiResponseBuilder() {
/*     */     }
/*     */     public List<Object> build(Object data) {
/*  18 */       List list = (List)data;
/*  19 */       List values = new ArrayList();
/*     */ 
/*  21 */       if (list.size() != this.responses.size()) {
/*  22 */         throw new JedisDataException("Expected data size " + this.responses.size() + " but was " + list.size());
/*     */       }
/*     */ 
/*  25 */       for (int i = 0; i < list.size(); i++) {
/*  26 */         Response response = (Response)this.responses.get(i);
/*  27 */         response.set(list.get(i));
/*  28 */         values.add(response.get());
/*     */       }
/*  30 */       return values;
/*     */     }
/*     */ 
/*     */     public void addResponse(Response<?> response) {
/*  34 */       this.responses.add(response);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.Pipeline
 * JD-Core Version:    0.6.0
 */