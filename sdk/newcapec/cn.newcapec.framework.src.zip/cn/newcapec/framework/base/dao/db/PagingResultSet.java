/*     */ package cn.newcapec.framework.base.dao.db;
/*     */ 
/*     */ import cn.newcapec.framework.utils.tools.BeanUtils;
/*     */ import java.io.Serializable;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class PagingResultSet
/*     */   implements Serializable
/*     */ {
/*     */   private int currRow;
/*     */   private long rowCount;
/*     */   private int pageCount;
/*     */   private int pageIndex;
/*     */   private int pageSize;
/*     */   private ResultSet resultSet;
/*     */   private Class modelClass;
/*     */   private List list;
/*     */ 
/*     */   private PagingResultSet()
/*     */   {
/*     */   }
/*     */ 
/*     */   public long getRowCount()
/*     */   {
/*  39 */     return this.rowCount;
/*     */   }
/*     */ 
/*     */   public void setRowCount(long rowCount) {
/*  43 */     this.rowCount = rowCount;
/*     */   }
/*     */ 
/*     */   public PagingResultSet(ResultSet rst, Class modelClass) {
/*  47 */     this.currRow = 0;
/*  48 */     this.rowCount = 0L;
/*  49 */     this.resultSet = rst;
/*  50 */     this.modelClass = modelClass;
/*  51 */     this.list = new ArrayList();
/*     */   }
/*     */ 
/*     */   private void calcEndRow() throws SQLException {
/*  55 */     if (this.resultSet.getType() != 1003) {
/*  56 */       this.resultSet.last();
/*  57 */       this.currRow = this.resultSet.getRow();
/*     */     } else {
/*  59 */       while (isLast());
/*     */     }
/*  62 */     if (this.currRow < 0)
/*  63 */       this.currRow = 0;
/*  64 */     this.rowCount = this.currRow;
/*     */   }
/*     */ 
/*     */   private void calPageCount()
/*     */     throws SQLException
/*     */   {
/*  72 */     if (this.pageSize > 0)
/*  73 */       this.pageCount = (this.currRow % this.pageSize != 0 ? this.currRow / this.pageSize + 1 : 
/*  74 */         this.currRow / this.pageSize);
/*     */     else
/*  76 */       this.pageCount = 1;
/*     */   }
/*     */ 
/*     */   public int getPageCount() {
/*  80 */     return this.pageCount;
/*     */   }
/*     */ 
/*     */   public void setPageCount(int pageCount) {
/*  84 */     this.pageCount = pageCount;
/*     */   }
/*     */ 
/*     */   public int getPageIndex() {
/*  88 */     return this.pageIndex;
/*     */   }
/*     */ 
/*     */   private void setPageIndex(int pageIndex) {
/*  92 */     if (pageIndex < 1)
/*  93 */       this.pageIndex = 1;
/*     */     else
/*  95 */       this.pageIndex = pageIndex;
/*     */   }
/*     */ 
/*     */   private void setPageSize(int pageSize) {
/*  99 */     if (pageSize < 1)
/* 100 */       this.pageSize = 0;
/*     */     else
/* 102 */       this.pageSize = pageSize;
/*     */   }
/*     */ 
/*     */   private void updateList()
/*     */     throws Exception
/*     */   {
/* 108 */     caculFirstRow();
/* 109 */     for (int i = 0; (i < this.pageSize) && (isLast()); i++)
/* 110 */       this.list.add(BeanUtils.resultSetToDO(this.resultSet, this.modelClass, true));
/*     */   }
/*     */ 
/*     */   public List getData()
/*     */   {
/* 120 */     return this.list;
/*     */   }
/*     */ 
/*     */   private void caculFirstRow()
/*     */     throws SQLException
/*     */   {
/* 129 */     if (this.resultSet.getType() != 1003) {
/* 130 */       int startRow = this.pageSize * (this.pageIndex - 1);
/* 131 */       if (startRow == 0)
/* 132 */         this.resultSet.beforeFirst();
/*     */       else {
/* 134 */         this.resultSet.absolute(startRow);
/*     */       }
/* 136 */       this.currRow = this.resultSet.getRow();
/* 137 */       if (this.currRow < 0)
/* 138 */         this.currRow = 0;
/*     */     }
/* 141 */     else { int startRow = this.pageSize * (this.pageIndex - 1);
/* 142 */       for (int i = 0; (i < startRow) && (isLast()); i++);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isLast() throws SQLException {
/* 148 */     if (this.resultSet.next()) {
/* 149 */       this.currRow += 1;
/* 150 */       return true;
/*     */     }
/* 152 */     return false;
/*     */   }
/*     */ 
/*     */   public int tranlateData(int pageSize, int pageIndex)
/*     */     throws Exception
/*     */   {
/* 166 */     setPageSize(pageSize);
/* 167 */     setPageIndex(pageIndex);
/* 168 */     if (this.list != null)
/* 169 */       updateList();
/* 170 */     calcEndRow();
/* 171 */     calPageCount();
/* 172 */     return this.pageCount;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.db.PagingResultSet
 * JD-Core Version:    0.6.0
 */