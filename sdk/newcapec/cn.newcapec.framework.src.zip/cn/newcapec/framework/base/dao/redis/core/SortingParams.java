/*     */ package cn.newcapec.framework.base.dao.redis.core;
/*     */ 
/*     */ import cn.newcapec.framework.base.dao.redis.util.SafeEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ public class SortingParams
/*     */ {
/*  23 */   private List<byte[]> params = new ArrayList();
/*     */ 
/*     */   public SortingParams by(String pattern)
/*     */   {
/*  39 */     return by(SafeEncoder.encode(pattern));
/*     */   }
/*     */ 
/*     */   public SortingParams by(byte[] pattern)
/*     */   {
/*  56 */     this.params.add(Protocol.Keyword.BY.raw);
/*  57 */     this.params.add(pattern);
/*  58 */     return this;
/*     */   }
/*     */ 
/*     */   public SortingParams nosort()
/*     */   {
/*  70 */     this.params.add(Protocol.Keyword.BY.raw);
/*  71 */     this.params.add(Protocol.Keyword.NOSORT.raw);
/*  72 */     return this;
/*     */   }
/*     */ 
/*     */   public Collection<byte[]> getParams() {
/*  76 */     return Collections.unmodifiableCollection(this.params);
/*     */   }
/*     */ 
/*     */   public SortingParams desc()
/*     */   {
/*  85 */     this.params.add(Protocol.Keyword.DESC.raw);
/*  86 */     return this;
/*     */   }
/*     */ 
/*     */   public SortingParams asc()
/*     */   {
/*  95 */     this.params.add(Protocol.Keyword.ASC.raw);
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */   public SortingParams limit(int start, int count)
/*     */   {
/* 108 */     this.params.add(Protocol.Keyword.LIMIT.raw);
/* 109 */     this.params.add(Protocol.toByteArray(start));
/* 110 */     this.params.add(Protocol.toByteArray(count));
/* 111 */     return this;
/*     */   }
/*     */ 
/*     */   public SortingParams alpha()
/*     */   {
/* 121 */     this.params.add(Protocol.Keyword.ALPHA.raw);
/* 122 */     return this;
/*     */   }
/*     */ 
/*     */   public SortingParams get(String[] patterns)
/*     */   {
/* 141 */     for (String pattern : patterns) {
/* 142 */       this.params.add(Protocol.Keyword.GET.raw);
/* 143 */       this.params.add(SafeEncoder.encode(pattern));
/*     */     }
/* 145 */     return this;
/*     */   }
/*     */ 
/*     */   public SortingParams get(byte[][] patterns)
/*     */   {
/* 164 */     for (byte[] pattern : patterns) {
/* 165 */       this.params.add(Protocol.Keyword.GET.raw);
/* 166 */       this.params.add(pattern);
/*     */     }
/* 168 */     return this;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.SortingParams
 * JD-Core Version:    0.6.0
 */