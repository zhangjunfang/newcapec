/*    */ package cn.newcapec.framework.base.dao.redis.core;
/*    */ 
/*    */ public class DebugParams
/*    */ {
/*    */   private String[] command;
/*    */ 
/*    */   public String[] getCommand()
/*    */   {
/*  7 */     return this.command;
/*    */   }
/*    */ 
/*    */   public static DebugParams SEGFAULT()
/*    */   {
/* 15 */     DebugParams debugParams = new DebugParams();
/* 16 */     debugParams.command = new String[] { "SEGFAULT" };
/* 17 */     return debugParams;
/*    */   }
/*    */ 
/*    */   public static DebugParams OBJECT(String key) {
/* 21 */     DebugParams debugParams = new DebugParams();
/* 22 */     debugParams.command = new String[] { "OBJECT", key };
/* 23 */     return debugParams;
/*    */   }
/*    */ 
/*    */   public static DebugParams RELOAD() {
/* 27 */     DebugParams debugParams = new DebugParams();
/* 28 */     debugParams.command = new String[] { "RELOAD" };
/* 29 */     return debugParams;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.DebugParams
 * JD-Core Version:    0.6.0
 */