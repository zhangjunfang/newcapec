/*     */ package cn.newcapec.framework.base.dao.redis.core;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ abstract class PipelineBase extends Queable
/*     */   implements BinaryRedisPipeline, RedisPipeline
/*     */ {
/*     */   protected abstract Client getClient(String paramString);
/*     */ 
/*     */   protected abstract Client getClient(byte[] paramArrayOfByte);
/*     */ 
/*     */   public Response<Long> append(String key, String value)
/*     */   {
/*  20 */     getClient(key).append(key, value);
/*  21 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> append(byte[] key, byte[] value) {
/*  25 */     getClient(key).append(key, value);
/*  26 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<List<String>> blpop(String key) {
/*  30 */     String[] temp = new String[1];
/*  31 */     temp[0] = key;
/*  32 */     getClient(key).blpop(temp);
/*  33 */     return getResponse(BuilderFactory.STRING_LIST);
/*     */   }
/*     */ 
/*     */   public Response<List<String>> brpop(String key) {
/*  37 */     String[] temp = new String[1];
/*  38 */     temp[0] = key;
/*  39 */     getClient(key).brpop(temp);
/*  40 */     return getResponse(BuilderFactory.STRING_LIST);
/*     */   }
/*     */ 
/*     */   public Response<List<byte[]>> blpop(byte[] key) {
/*  44 */     byte[][] temp = new byte[1][];
/*  45 */     temp[0] = key;
/*  46 */     getClient(key).blpop(temp);
/*  47 */     return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
/*     */   }
/*     */ 
/*     */   public Response<List<byte[]>> brpop(byte[] key) {
/*  51 */     byte[][] temp = new byte[1][];
/*  52 */     temp[0] = key;
/*  53 */     getClient(key).brpop(temp);
/*  54 */     return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
/*     */   }
/*     */ 
/*     */   public Response<Long> decr(String key) {
/*  58 */     getClient(key).decr(key);
/*  59 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> decr(byte[] key) {
/*  63 */     getClient(key).decr(key);
/*  64 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> decrBy(String key, long integer) {
/*  68 */     getClient(key).decrBy(key, integer);
/*  69 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> decrBy(byte[] key, long integer) {
/*  73 */     getClient(key).decrBy(key, integer);
/*  74 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> del(String key) {
/*  78 */     getClient(key).del(new String[] { key });
/*  79 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> del(byte[] key) {
/*  83 */     getClient(key).del(new byte[][] { key });
/*  84 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<String> echo(String string) {
/*  88 */     getClient(string).echo(string);
/*  89 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<byte[]> echo(byte[] string) {
/*  93 */     getClient(string).echo(string);
/*  94 */     return getResponse(BuilderFactory.BYTE_ARRAY);
/*     */   }
/*     */ 
/*     */   public Response<Boolean> exists(String key) {
/*  98 */     getClient(key).exists(key);
/*  99 */     return getResponse(BuilderFactory.BOOLEAN);
/*     */   }
/*     */ 
/*     */   public Response<Boolean> exists(byte[] key) {
/* 103 */     getClient(key).exists(key);
/* 104 */     return getResponse(BuilderFactory.BOOLEAN);
/*     */   }
/*     */ 
/*     */   public Response<Long> expire(String key, int seconds) {
/* 108 */     getClient(key).expire(key, seconds);
/* 109 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> expire(byte[] key, int seconds) {
/* 113 */     getClient(key).expire(key, seconds);
/* 114 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> expireAt(String key, long unixTime) {
/* 118 */     getClient(key).expireAt(key, unixTime);
/* 119 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> expireAt(byte[] key, long unixTime) {
/* 123 */     getClient(key).expireAt(key, unixTime);
/* 124 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<String> get(String key) {
/* 128 */     getClient(key).get(key);
/* 129 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<byte[]> get(byte[] key) {
/* 133 */     getClient(key).get(key);
/* 134 */     return getResponse(BuilderFactory.BYTE_ARRAY);
/*     */   }
/*     */ 
/*     */   public Response<Boolean> getbit(String key, long offset) {
/* 138 */     getClient(key).getbit(key, offset);
/* 139 */     return getResponse(BuilderFactory.BOOLEAN);
/*     */   }
/*     */ 
/*     */   public Response<Boolean> getbit(byte[] key, long offset) {
/* 143 */     getClient(key).getbit(key, offset);
/* 144 */     return getResponse(BuilderFactory.BOOLEAN);
/*     */   }
/*     */ 
/*     */   public Response<String> getrange(String key, long startOffset, long endOffset)
/*     */   {
/* 149 */     getClient(key).getrange(key, startOffset, endOffset);
/* 150 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> getSet(String key, String value) {
/* 154 */     getClient(key).getSet(key, value);
/* 155 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<byte[]> getSet(byte[] key, byte[] value) {
/* 159 */     getClient(key).getSet(key, value);
/* 160 */     return getResponse(BuilderFactory.BYTE_ARRAY);
/*     */   }
/*     */ 
/*     */   public Response<Long> getrange(byte[] key, long startOffset, long endOffset) {
/* 164 */     getClient(key).getrange(key, startOffset, endOffset);
/* 165 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> hdel(String key, String field) {
/* 169 */     getClient(key).hdel(key, new String[] { field });
/* 170 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> hdel(byte[] key, byte[] field) {
/* 174 */     getClient(key).hdel(key, new byte[][] { field });
/* 175 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Boolean> hexists(String key, String field) {
/* 179 */     getClient(key).hexists(key, field);
/* 180 */     return getResponse(BuilderFactory.BOOLEAN);
/*     */   }
/*     */ 
/*     */   public Response<Boolean> hexists(byte[] key, byte[] field) {
/* 184 */     getClient(key).hexists(key, field);
/* 185 */     return getResponse(BuilderFactory.BOOLEAN);
/*     */   }
/*     */ 
/*     */   public Response<String> hget(String key, String field) {
/* 189 */     getClient(key).hget(key, field);
/* 190 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<byte[]> hget(byte[] key, byte[] field) {
/* 194 */     getClient(key).hget(key, field);
/* 195 */     return getResponse(BuilderFactory.BYTE_ARRAY);
/*     */   }
/*     */ 
/*     */   public Response<Map<String, String>> hgetAll(String key) {
/* 199 */     getClient(key).hgetAll(key);
/* 200 */     return getResponse(BuilderFactory.STRING_MAP);
/*     */   }
/*     */ 
/*     */   public Response<Map<byte[], byte[]>> hgetAll(byte[] key) {
/* 204 */     getClient(key).hgetAll(key);
/* 205 */     return getResponse(BuilderFactory.BYTE_ARRAY_MAP);
/*     */   }
/*     */ 
/*     */   public Response<Long> hincrBy(String key, String field, long value) {
/* 209 */     getClient(key).hincrBy(key, field, value);
/* 210 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> hincrBy(byte[] key, byte[] field, long value) {
/* 214 */     getClient(key).hincrBy(key, field, value);
/* 215 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Set<String>> hkeys(String key) {
/* 219 */     getClient(key).hkeys(key);
/* 220 */     return getResponse(BuilderFactory.STRING_SET);
/*     */   }
/*     */ 
/*     */   public Response<Set<byte[]>> hkeys(byte[] key) {
/* 224 */     getClient(key).hkeys(key);
/* 225 */     return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Long> hlen(String key) {
/* 229 */     getClient(key).hlen(key);
/* 230 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> hlen(byte[] key) {
/* 234 */     getClient(key).hlen(key);
/* 235 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<List<String>> hmget(String key, String[] fields) {
/* 239 */     getClient(key).hmget(key, fields);
/* 240 */     return getResponse(BuilderFactory.STRING_LIST);
/*     */   }
/*     */ 
/*     */   public Response<List<byte[]>> hmget(byte[] key, byte[][] fields) {
/* 244 */     getClient(key).hmget(key, fields);
/* 245 */     return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
/*     */   }
/*     */ 
/*     */   public Response<String> hmset(String key, Map<String, String> hash) {
/* 249 */     getClient(key).hmset(key, hash);
/* 250 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> hmset(byte[] key, Map<byte[], byte[]> hash) {
/* 254 */     getClient(key).hmset(key, hash);
/* 255 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<Long> hset(String key, String field, String value) {
/* 259 */     getClient(key).hset(key, field, value);
/* 260 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> hset(byte[] key, byte[] field, byte[] value) {
/* 264 */     getClient(key).hset(key, field, value);
/* 265 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> hsetnx(String key, String field, String value) {
/* 269 */     getClient(key).hsetnx(key, field, value);
/* 270 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> hsetnx(byte[] key, byte[] field, byte[] value) {
/* 274 */     getClient(key).hsetnx(key, field, value);
/* 275 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<List<String>> hvals(String key) {
/* 279 */     getClient(key).hvals(key);
/* 280 */     return getResponse(BuilderFactory.STRING_LIST);
/*     */   }
/*     */ 
/*     */   public Response<List<byte[]>> hvals(byte[] key) {
/* 284 */     getClient(key).hvals(key);
/* 285 */     return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
/*     */   }
/*     */ 
/*     */   public Response<Long> incr(String key) {
/* 289 */     getClient(key).incr(key);
/* 290 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> incr(byte[] key) {
/* 294 */     getClient(key).incr(key);
/* 295 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> incrBy(String key, long integer) {
/* 299 */     getClient(key).incrBy(key, integer);
/* 300 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> incrBy(byte[] key, long integer) {
/* 304 */     getClient(key).incrBy(key, integer);
/* 305 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<String> lindex(String key, int index) {
/* 309 */     getClient(key).lindex(key, index);
/* 310 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<byte[]> lindex(byte[] key, int index) {
/* 314 */     getClient(key).lindex(key, index);
/* 315 */     return getResponse(BuilderFactory.BYTE_ARRAY);
/*     */   }
/*     */ 
/*     */   public Response<Long> linsert(String key, BinaryClient.LIST_POSITION where, String pivot, String value)
/*     */   {
/* 320 */     getClient(key).linsert(key, where, pivot, value);
/* 321 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> linsert(byte[] key, BinaryClient.LIST_POSITION where, byte[] pivot, byte[] value)
/*     */   {
/* 326 */     getClient(key).linsert(key, where, pivot, value);
/* 327 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> llen(String key) {
/* 331 */     getClient(key).llen(key);
/* 332 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> llen(byte[] key) {
/* 336 */     getClient(key).llen(key);
/* 337 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<String> lpop(String key) {
/* 341 */     getClient(key).lpop(key);
/* 342 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<byte[]> lpop(byte[] key) {
/* 346 */     getClient(key).lpop(key);
/* 347 */     return getResponse(BuilderFactory.BYTE_ARRAY);
/*     */   }
/*     */ 
/*     */   public Response<Long> lpush(String key, String[] string) {
/* 351 */     getClient(key).lpush(key, string);
/* 352 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> lpush(byte[] key, byte[][] string) {
/* 356 */     getClient(key).lpush(key, string);
/* 357 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> lpushx(String key, String[] string) {
/* 361 */     getClient(key).lpushx(key, string);
/* 362 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> lpushx(byte[] key, byte[][] bytes) {
/* 366 */     getClient(key).lpushx(key, bytes);
/* 367 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<List<String>> lrange(String key, long start, long end) {
/* 371 */     getClient(key).lrange(key, start, end);
/* 372 */     return getResponse(BuilderFactory.STRING_LIST);
/*     */   }
/*     */ 
/*     */   public Response<List<byte[]>> lrange(byte[] key, long start, long end) {
/* 376 */     getClient(key).lrange(key, start, end);
/* 377 */     return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
/*     */   }
/*     */ 
/*     */   public Response<Long> lrem(String key, long count, String value) {
/* 381 */     getClient(key).lrem(key, count, value);
/* 382 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> lrem(byte[] key, long count, byte[] value) {
/* 386 */     getClient(key).lrem(key, count, value);
/* 387 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<String> lset(String key, long index, String value) {
/* 391 */     getClient(key).lset(key, index, value);
/* 392 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> lset(byte[] key, long index, byte[] value) {
/* 396 */     getClient(key).lset(key, index, value);
/* 397 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> ltrim(String key, long start, long end) {
/* 401 */     getClient(key).ltrim(key, start, end);
/* 402 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> ltrim(byte[] key, long start, long end) {
/* 406 */     getClient(key).ltrim(key, start, end);
/* 407 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<Long> move(String key, int dbIndex) {
/* 411 */     getClient(key).move(key, dbIndex);
/* 412 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> move(byte[] key, int dbIndex) {
/* 416 */     getClient(key).move(key, dbIndex);
/* 417 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> persist(String key) {
/* 421 */     getClient(key).persist(key);
/* 422 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> persist(byte[] key) {
/* 426 */     getClient(key).persist(key);
/* 427 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<String> rpop(String key) {
/* 431 */     getClient(key).rpop(key);
/* 432 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<byte[]> rpop(byte[] key) {
/* 436 */     getClient(key).rpop(key);
/* 437 */     return getResponse(BuilderFactory.BYTE_ARRAY);
/*     */   }
/*     */ 
/*     */   public Response<Long> rpush(String key, String[] string) {
/* 441 */     getClient(key).rpush(key, string);
/* 442 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> rpush(byte[] key, byte[][] string) {
/* 446 */     getClient(key).rpush(key, string);
/* 447 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> rpushx(String key, String[] string) {
/* 451 */     getClient(key).rpushx(key, string);
/* 452 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> rpushx(byte[] key, byte[][] string) {
/* 456 */     getClient(key).rpushx(key, string);
/* 457 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> sadd(String key, String[] member) {
/* 461 */     getClient(key).sadd(key, member);
/* 462 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> sadd(byte[] key, byte[][] member) {
/* 466 */     getClient(key).sadd(key, member);
/* 467 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> scard(String key) {
/* 471 */     getClient(key).scard(key);
/* 472 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> scard(byte[] key) {
/* 476 */     getClient(key).scard(key);
/* 477 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<String> set(String key, String value) {
/* 481 */     getClient(key).set(key, value);
/* 482 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> set(byte[] key, byte[] value) {
/* 486 */     getClient(key).set(key, value);
/* 487 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<Boolean> setbit(String key, long offset, boolean value) {
/* 491 */     getClient(key).setbit(key, offset, value);
/* 492 */     return getResponse(BuilderFactory.BOOLEAN);
/*     */   }
/*     */ 
/*     */   public Response<Boolean> setbit(byte[] key, long offset, byte[] value) {
/* 496 */     getClient(key).setbit(key, offset, value);
/* 497 */     return getResponse(BuilderFactory.BOOLEAN);
/*     */   }
/*     */ 
/*     */   public Response<String> setex(String key, int seconds, String value) {
/* 501 */     getClient(key).setex(key, seconds, value);
/* 502 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> setex(byte[] key, int seconds, byte[] value) {
/* 506 */     getClient(key).setex(key, seconds, value);
/* 507 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<Long> setnx(String key, String value) {
/* 511 */     getClient(key).setnx(key, value);
/* 512 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> setnx(byte[] key, byte[] value) {
/* 516 */     getClient(key).setnx(key, value);
/* 517 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> setrange(String key, long offset, String value) {
/* 521 */     getClient(key).setrange(key, offset, value);
/* 522 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> setrange(byte[] key, long offset, byte[] value) {
/* 526 */     getClient(key).setrange(key, offset, value);
/* 527 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Boolean> sismember(String key, String member) {
/* 531 */     getClient(key).sismember(key, member);
/* 532 */     return getResponse(BuilderFactory.BOOLEAN);
/*     */   }
/*     */ 
/*     */   public Response<Boolean> sismember(byte[] key, byte[] member) {
/* 536 */     getClient(key).sismember(key, member);
/* 537 */     return getResponse(BuilderFactory.BOOLEAN);
/*     */   }
/*     */ 
/*     */   public Response<Set<String>> smembers(String key) {
/* 541 */     getClient(key).smembers(key);
/* 542 */     return getResponse(BuilderFactory.STRING_SET);
/*     */   }
/*     */ 
/*     */   public Response<Set<byte[]>> smembers(byte[] key) {
/* 546 */     getClient(key).smembers(key);
/* 547 */     return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<List<String>> sort(String key) {
/* 551 */     getClient(key).sort(key);
/* 552 */     return getResponse(BuilderFactory.STRING_LIST);
/*     */   }
/*     */ 
/*     */   public Response<List<byte[]>> sort(byte[] key) {
/* 556 */     getClient(key).sort(key);
/* 557 */     return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
/*     */   }
/*     */ 
/*     */   public Response<List<String>> sort(String key, SortingParams sortingParameters)
/*     */   {
/* 562 */     getClient(key).sort(key, sortingParameters);
/* 563 */     return getResponse(BuilderFactory.STRING_LIST);
/*     */   }
/*     */ 
/*     */   public Response<List<byte[]>> sort(byte[] key, SortingParams sortingParameters)
/*     */   {
/* 568 */     getClient(key).sort(key, sortingParameters);
/* 569 */     return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
/*     */   }
/*     */ 
/*     */   public Response<String> spop(String key) {
/* 573 */     getClient(key).spop(key);
/* 574 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<byte[]> spop(byte[] key) {
/* 578 */     getClient(key).spop(key);
/* 579 */     return getResponse(BuilderFactory.BYTE_ARRAY);
/*     */   }
/*     */ 
/*     */   public Response<String> srandmember(String key) {
/* 583 */     getClient(key).srandmember(key);
/* 584 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<byte[]> srandmember(byte[] key) {
/* 588 */     getClient(key).srandmember(key);
/* 589 */     return getResponse(BuilderFactory.BYTE_ARRAY);
/*     */   }
/*     */ 
/*     */   public Response<Long> srem(String key, String member) {
/* 593 */     getClient(key).srem(key, new String[] { member });
/* 594 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> srem(byte[] key, byte[] member) {
/* 598 */     getClient(key).srem(key, new byte[][] { member });
/* 599 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> strlen(String key) {
/* 603 */     getClient(key).strlen(key);
/* 604 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> strlen(byte[] key) {
/* 608 */     getClient(key).strlen(key);
/* 609 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<String> substr(String key, int start, int end) {
/* 613 */     getClient(key).substr(key, start, end);
/* 614 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> substr(byte[] key, int start, int end) {
/* 618 */     getClient(key).substr(key, start, end);
/* 619 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<Long> ttl(String key) {
/* 623 */     getClient(key).ttl(key);
/* 624 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> ttl(byte[] key) {
/* 628 */     getClient(key).ttl(key);
/* 629 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<String> type(String key) {
/* 633 */     getClient(key).type(key);
/* 634 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> type(byte[] key) {
/* 638 */     getClient(key).type(key);
/* 639 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<Long> zadd(String key, double score, String member) {
/* 643 */     getClient(key).zadd(key, score, member);
/* 644 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zadd(byte[] key, double score, byte[] member) {
/* 648 */     getClient(key).zadd(key, score, member);
/* 649 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zcard(String key) {
/* 653 */     getClient(key).zcard(key);
/* 654 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zcard(byte[] key) {
/* 658 */     getClient(key).zcard(key);
/* 659 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zcount(String key, double min, double max) {
/* 663 */     getClient(key).zcount(key, min, max);
/* 664 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zcount(byte[] key, double min, double max) {
/* 668 */     getClient(key).zcount(key, Protocol.toByteArray(min), Protocol.toByteArray(max));
/* 669 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Double> zincrby(String key, double score, String member) {
/* 673 */     getClient(key).zincrby(key, score, member);
/* 674 */     return getResponse(BuilderFactory.DOUBLE);
/*     */   }
/*     */ 
/*     */   public Response<Double> zincrby(byte[] key, double score, byte[] member) {
/* 678 */     getClient(key).zincrby(key, score, member);
/* 679 */     return getResponse(BuilderFactory.DOUBLE);
/*     */   }
/*     */ 
/*     */   public Response<Set<String>> zrange(String key, int start, int end) {
/* 683 */     getClient(key).zrange(key, start, end);
/* 684 */     return getResponse(BuilderFactory.STRING_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<byte[]>> zrange(byte[] key, int start, int end) {
/* 688 */     getClient(key).zrange(key, start, end);
/* 689 */     return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<String>> zrangeByScore(String key, double min, double max)
/*     */   {
/* 694 */     getClient(key).zrangeByScore(key, min, max);
/* 695 */     return getResponse(BuilderFactory.STRING_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<byte[]>> zrangeByScore(byte[] key, double min, double max)
/*     */   {
/* 700 */     return zrangeByScore(key, Protocol.toByteArray(min), Protocol.toByteArray(max));
/*     */   }
/*     */ 
/*     */   public Response<Set<String>> zrangeByScore(String key, String min, String max)
/*     */   {
/* 705 */     getClient(key).zrangeByScore(key, min, max);
/* 706 */     return getResponse(BuilderFactory.STRING_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<byte[]>> zrangeByScore(byte[] key, byte[] min, byte[] max)
/*     */   {
/* 711 */     getClient(key).zrangeByScore(key, min, max);
/* 712 */     return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<String>> zrangeByScore(String key, double min, double max, int offset, int count)
/*     */   {
/* 717 */     getClient(key).zrangeByScore(key, min, max, offset, count);
/* 718 */     return getResponse(BuilderFactory.STRING_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<byte[]>> zrangeByScore(byte[] key, double min, double max, int offset, int count)
/*     */   {
/* 723 */     return zrangeByScore(key, Protocol.toByteArray(min), Protocol.toByteArray(max), offset, count);
/*     */   }
/*     */ 
/*     */   public Response<Set<byte[]>> zrangeByScore(byte[] key, byte[] min, byte[] max, int offset, int count)
/*     */   {
/* 728 */     getClient(key).zrangeByScore(key, min, max, offset, count);
/* 729 */     return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<Tuple>> zrangeByScoreWithScores(String key, double min, double max)
/*     */   {
/* 734 */     getClient(key).zrangeByScoreWithScores(key, min, max);
/* 735 */     return getResponse(BuilderFactory.TUPLE_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<Tuple>> zrangeByScoreWithScores(byte[] key, double min, double max)
/*     */   {
/* 740 */     return zrangeByScoreWithScores(key, Protocol.toByteArray(min), Protocol.toByteArray(max));
/*     */   }
/*     */ 
/*     */   public Response<Set<Tuple>> zrangeByScoreWithScores(byte[] key, byte[] min, byte[] max)
/*     */   {
/* 745 */     getClient(key).zrangeByScoreWithScores(key, min, max);
/* 746 */     return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
/*     */   }
/*     */ 
/*     */   public Response<Set<Tuple>> zrangeByScoreWithScores(String key, double min, double max, int offset, int count)
/*     */   {
/* 751 */     getClient(key).zrangeByScoreWithScores(key, min, max, offset, count);
/* 752 */     return getResponse(BuilderFactory.TUPLE_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<Tuple>> zrangeByScoreWithScores(byte[] key, double min, double max, int offset, int count)
/*     */   {
/* 757 */     getClient(key).zrangeByScoreWithScores(key, Protocol.toByteArray(min), Protocol.toByteArray(max), offset, count);
/* 758 */     return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
/*     */   }
/*     */ 
/*     */   public Response<Set<Tuple>> zrangeByScoreWithScores(byte[] key, byte[] min, byte[] max, int offset, int count)
/*     */   {
/* 763 */     getClient(key).zrangeByScoreWithScores(key, min, max, offset, count);
/* 764 */     return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
/*     */   }
/*     */ 
/*     */   public Response<Set<String>> zrevrangeByScore(String key, double max, double min)
/*     */   {
/* 769 */     getClient(key).zrevrangeByScore(key, max, min);
/* 770 */     return getResponse(BuilderFactory.STRING_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<byte[]>> zrevrangeByScore(byte[] key, double max, double min)
/*     */   {
/* 775 */     getClient(key).zrevrangeByScore(key, Protocol.toByteArray(max), Protocol.toByteArray(min));
/* 776 */     return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<String>> zrevrangeByScore(String key, String max, String min)
/*     */   {
/* 781 */     getClient(key).zrevrangeByScore(key, max, min);
/* 782 */     return getResponse(BuilderFactory.STRING_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<byte[]>> zrevrangeByScore(byte[] key, byte[] max, byte[] min)
/*     */   {
/* 787 */     getClient(key).zrevrangeByScore(key, max, min);
/* 788 */     return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<String>> zrevrangeByScore(String key, double max, double min, int offset, int count)
/*     */   {
/* 793 */     getClient(key).zrevrangeByScore(key, max, min, offset, count);
/* 794 */     return getResponse(BuilderFactory.STRING_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<byte[]>> zrevrangeByScore(byte[] key, double max, double min, int offset, int count)
/*     */   {
/* 799 */     getClient(key).zrevrangeByScore(key, Protocol.toByteArray(max), Protocol.toByteArray(min), offset, count);
/* 800 */     return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<byte[]>> zrevrangeByScore(byte[] key, byte[] max, byte[] min, int offset, int count)
/*     */   {
/* 805 */     getClient(key).zrevrangeByScore(key, max, min, offset, count);
/* 806 */     return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<Tuple>> zrevrangeByScoreWithScores(String key, double max, double min)
/*     */   {
/* 811 */     getClient(key).zrevrangeByScoreWithScores(key, max, min);
/* 812 */     return getResponse(BuilderFactory.TUPLE_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<Tuple>> zrevrangeByScoreWithScores(byte[] key, double max, double min)
/*     */   {
/* 817 */     getClient(key).zrevrangeByScoreWithScores(key, Protocol.toByteArray(max), Protocol.toByteArray(min));
/* 818 */     return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
/*     */   }
/*     */ 
/*     */   public Response<Set<Tuple>> zrevrangeByScoreWithScores(byte[] key, byte[] max, byte[] min)
/*     */   {
/* 823 */     getClient(key).zrevrangeByScoreWithScores(key, max, min);
/* 824 */     return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
/*     */   }
/*     */ 
/*     */   public Response<Set<Tuple>> zrevrangeByScoreWithScores(String key, double max, double min, int offset, int count)
/*     */   {
/* 829 */     getClient(key).zrevrangeByScoreWithScores(key, max, min, offset, count);
/* 830 */     return getResponse(BuilderFactory.TUPLE_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<Tuple>> zrevrangeByScoreWithScores(byte[] key, double max, double min, int offset, int count)
/*     */   {
/* 835 */     getClient(key).zrevrangeByScoreWithScores(key, Protocol.toByteArray(max), Protocol.toByteArray(min), offset, count);
/* 836 */     return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
/*     */   }
/*     */ 
/*     */   public Response<Set<Tuple>> zrevrangeByScoreWithScores(byte[] key, byte[] max, byte[] min, int offset, int count)
/*     */   {
/* 841 */     getClient(key).zrevrangeByScoreWithScores(key, max, min, offset, count);
/* 842 */     return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
/*     */   }
/*     */ 
/*     */   public Response<Set<Tuple>> zrangeWithScores(String key, int start, int end) {
/* 846 */     getClient(key).zrangeWithScores(key, start, end);
/* 847 */     return getResponse(BuilderFactory.TUPLE_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<Tuple>> zrangeWithScores(byte[] key, int start, int end) {
/* 851 */     getClient(key).zrangeWithScores(key, start, end);
/* 852 */     return getResponse(BuilderFactory.TUPLE_ZSET_BINARY);
/*     */   }
/*     */ 
/*     */   public Response<Long> zrank(String key, String member) {
/* 856 */     getClient(key).zrank(key, member);
/* 857 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zrank(byte[] key, byte[] member) {
/* 861 */     getClient(key).zrank(key, member);
/* 862 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zrem(String key, String member) {
/* 866 */     getClient(key).zrem(key, new String[] { member });
/* 867 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zrem(byte[] key, byte[] member) {
/* 871 */     getClient(key).zrem(key, new byte[][] { member });
/* 872 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zremrangeByRank(String key, int start, int end) {
/* 876 */     getClient(key).zremrangeByRank(key, start, end);
/* 877 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zremrangeByRank(byte[] key, int start, int end) {
/* 881 */     getClient(key).zremrangeByRank(key, start, end);
/* 882 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zremrangeByScore(String key, double start, double end) {
/* 886 */     getClient(key).zremrangeByScore(key, start, end);
/* 887 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zremrangeByScore(byte[] key, double start, double end) {
/* 891 */     getClient(key).zremrangeByScore(key, Protocol.toByteArray(start), Protocol.toByteArray(end));
/* 892 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zremrangeByScore(byte[] key, byte[] start, byte[] end) {
/* 896 */     getClient(key).zremrangeByScore(key, start, end);
/* 897 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Set<String>> zrevrange(String key, int start, int end) {
/* 901 */     getClient(key).zrevrange(key, start, end);
/* 902 */     return getResponse(BuilderFactory.STRING_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<byte[]>> zrevrange(byte[] key, int start, int end) {
/* 906 */     getClient(key).zrevrange(key, start, end);
/* 907 */     return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<Tuple>> zrevrangeWithScores(String key, int start, int end)
/*     */   {
/* 912 */     getClient(key).zrevrangeWithScores(key, start, end);
/* 913 */     return getResponse(BuilderFactory.TUPLE_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Set<Tuple>> zrevrangeWithScores(byte[] key, int start, int end)
/*     */   {
/* 918 */     getClient(key).zrevrangeWithScores(key, start, end);
/* 919 */     return getResponse(BuilderFactory.TUPLE_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Long> zrevrank(String key, String member) {
/* 923 */     getClient(key).zrevrank(key, member);
/* 924 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zrevrank(byte[] key, byte[] member) {
/* 928 */     getClient(key).zrevrank(key, member);
/* 929 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Double> zscore(String key, String member) {
/* 933 */     getClient(key).zscore(key, member);
/* 934 */     return getResponse(BuilderFactory.DOUBLE);
/*     */   }
/*     */ 
/*     */   public Response<Double> zscore(byte[] key, byte[] member) {
/* 938 */     getClient(key).zscore(key, member);
/* 939 */     return getResponse(BuilderFactory.DOUBLE);
/*     */   }
/*     */ 
/*     */   public Response<Long> bitcount(String key) {
/* 943 */     getClient(key).bitcount(key);
/* 944 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> bitcount(String key, long start, long end) {
/* 948 */     getClient(key).bitcount(key, start, end);
/* 949 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> bitcount(byte[] key) {
/* 953 */     getClient(key).bitcount(key);
/* 954 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> bitcount(byte[] key, long start, long end) {
/* 958 */     getClient(key).bitcount(key, start, end);
/* 959 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.PipelineBase
 * JD-Core Version:    0.6.0
 */