/*    */ package cn.newcapec.framework.base.dao.redis.util;
/*    */ 
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class QueueServer
/*    */ {
/* 13 */   private static final Logger log = Logger.getLogger(QueueServer.class);
/*    */ 
/*    */   public static void main(String[] args) {
/* 16 */     QueueService queueService = new RedisService();
/* 17 */     int port = 8088;
/*    */ 
/* 19 */     QueueDaemon queueDaemon = new QueueDaemon(8088, queueService);
/*    */ 
/* 21 */     log.info("QueueServer start with port 8088 start now ~");
/* 22 */     queueDaemon.start();
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.util.QueueServer
 * JD-Core Version:    0.6.0
 */