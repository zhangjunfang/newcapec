/*     */ package cn.newcapec.framework.base.dao.redis.cache;
/*     */ 
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DefaultLocalCache<K, V>
/*     */   implements LocalCache<K, V>
/*     */ {
/*  23 */   private static final Log Logger = LogFactory.getLog(DefaultLocalCache.class);
/*     */   ConcurrentHashMap<K, SoftReference<V>>[] caches;
/*     */   ConcurrentHashMap<K, Long> expiryCache;
/*     */   private ScheduledExecutorService scheduleService;
/*  30 */   private int expiryInterval = 10;
/*     */ 
/*  32 */   private int moduleSize = 10;
/*     */ 
/*     */   public DefaultLocalCache() {
/*  35 */     init();
/*     */   }
/*     */ 
/*     */   public DefaultLocalCache(int expiryInterval, int moduleSize) {
/*  39 */     this.expiryInterval = expiryInterval;
/*  40 */     this.moduleSize = moduleSize;
/*  41 */     init();
/*     */   }
/*     */ 
/*     */   private void init()
/*     */   {
/*  46 */     this.caches = new ConcurrentHashMap[this.moduleSize];
/*     */ 
/*  48 */     for (int i = 0; i < this.moduleSize; i++) {
/*  49 */       this.caches[i] = new ConcurrentHashMap();
/*     */     }
/*     */ 
/*  52 */     this.expiryCache = new ConcurrentHashMap();
/*     */ 
/*  54 */     this.scheduleService = Executors.newScheduledThreadPool(1);
/*     */ 
/*  56 */     this.scheduleService.scheduleAtFixedRate(new CheckOutOfDateSchedule(this.caches, this.expiryCache), 0L, this.expiryInterval * 60, TimeUnit.SECONDS);
/*     */ 
/*  58 */     if (Logger.isInfoEnabled())
/*  59 */       Logger.info("DefaultCache CheckService is start!");
/*     */   }
/*     */ 
/*     */   public boolean clear()
/*     */   {
/*  64 */     if (this.caches != null) {
/*  65 */       for (ConcurrentHashMap cache : this.caches) {
/*  66 */         cache.clear();
/*     */       }
/*     */     }
/*  69 */     if (this.expiryCache != null) {
/*  70 */       this.expiryCache.clear();
/*     */     }
/*     */ 
/*  73 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean containsKey(K key) {
/*  77 */     checkValidate(key);
/*  78 */     return getCache(key).containsKey(key);
/*     */   }
/*     */ 
/*     */   public V get(K key) {
/*  82 */     checkValidate(key);
/*  83 */     SoftReference sr = (SoftReference)getCache(key).get(key);
/*  84 */     if (sr == null) {
/*  85 */       this.expiryCache.remove(key);
/*  86 */       return null;
/*     */     }
/*  88 */     return sr.get();
/*     */   }
/*     */ 
/*     */   public Set<K> keySet()
/*     */   {
/*  93 */     checkAll();
/*  94 */     return this.expiryCache.keySet();
/*     */   }
/*     */ 
/*     */   public V put(K key, V value) {
/*  98 */     SoftReference result = (SoftReference)getCache(key).put(key, new SoftReference(value));
/*  99 */     this.expiryCache.put(key, Long.valueOf(-1L));
/*     */ 
/* 101 */     return result == null ? null : result.get();
/*     */   }
/*     */ 
/*     */   public V put(K key, V value, Date expiry) {
/* 105 */     SoftReference result = (SoftReference)getCache(key).put(key, new SoftReference(value));
/* 106 */     this.expiryCache.put(key, Long.valueOf(expiry.getTime()));
/*     */ 
/* 108 */     return result == null ? null : result.get();
/*     */   }
/*     */ 
/*     */   public V remove(K key) {
/* 112 */     SoftReference result = (SoftReference)getCache(key).remove(key);
/* 113 */     this.expiryCache.remove(key);
/* 114 */     return result == null ? null : result.get();
/*     */   }
/*     */ 
/*     */   public int size() {
/* 118 */     checkAll();
/*     */ 
/* 120 */     return this.expiryCache.size();
/*     */   }
/*     */ 
/*     */   public Collection<V> values() {
/* 124 */     checkAll();
/*     */ 
/* 126 */     Collection values = new ArrayList();
/*     */ 
/* 128 */     for (ConcurrentHashMap cache : this.caches) {
/* 129 */       for (SoftReference sr : cache.values()) {
/* 130 */         values.add(sr.get());
/*     */       }
/*     */     }
/*     */ 
/* 134 */     return values;
/*     */   }
/*     */ 
/*     */   private ConcurrentHashMap<K, SoftReference<V>> getCache(K key) {
/* 138 */     long hashCode = key.hashCode();
/*     */ 
/* 140 */     if (hashCode < 0L) {
/* 141 */       hashCode = -hashCode;
/*     */     }
/* 143 */     int moudleNum = (int)hashCode % this.moduleSize;
/*     */ 
/* 145 */     return this.caches[moudleNum];
/*     */   }
/*     */ 
/*     */   private void checkValidate(K key) {
/* 149 */     if ((key != null) && (this.expiryCache.get(key) != null) && (((Long)this.expiryCache.get(key)).longValue() != -1L) && (new Date(((Long)this.expiryCache.get(key)).longValue()).before(new Date()))) {
/* 150 */       getCache(key).remove(key);
/* 151 */       this.expiryCache.remove(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkAll() {
/* 156 */     Iterator iter = this.expiryCache.keySet().iterator();
/*     */ 
/* 158 */     while (iter.hasNext()) {
/* 159 */       Object key = iter.next();
/* 160 */       checkValidate(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   public V put(K key, V value, int TTL)
/*     */   {
/* 207 */     SoftReference result = (SoftReference)getCache(key).put(key, new SoftReference(value));
/*     */ 
/* 209 */     Calendar calendar = Calendar.getInstance();
/* 210 */     calendar.add(13, TTL);
/* 211 */     this.expiryCache.put(key, Long.valueOf(calendar.getTime().getTime()));
/*     */ 
/* 213 */     return result == null ? null : result.get();
/*     */   }
/*     */ 
/*     */   public void destroy() {
/*     */     try {
/* 218 */       clear();
/*     */ 
/* 220 */       if (this.scheduleService != null) {
/* 221 */         this.scheduleService.shutdown();
/*     */       }
/* 223 */       this.scheduleService = null;
/*     */     } catch (Exception ex) {
/* 225 */       Logger.error(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   class CheckOutOfDateSchedule
/*     */     implements Runnable
/*     */   {
/*     */     ConcurrentHashMap<K, SoftReference<V>>[] caches;
/*     */     ConcurrentHashMap<K, Long> expiryCache;
/*     */ 
/*     */     public CheckOutOfDateSchedule(ConcurrentHashMap<K, Long> caches)
/*     */     {
/* 169 */       this.caches = caches;
/* 170 */       this.expiryCache = expiryCache;
/*     */     }
/*     */ 
/*     */     public void run() {
/* 174 */       check();
/*     */     }
/*     */ 
/*     */     public void check() {
/*     */       try {
/* 179 */         for (ConcurrentHashMap cache : this.caches) {
/* 180 */           Iterator keys = cache.keySet().iterator();
/*     */ 
/* 182 */           while (keys.hasNext()) {
/* 183 */             Object key = keys.next();
/*     */ 
/* 185 */             if (this.expiryCache.get(key) == null) {
/*     */               continue;
/*     */             }
/* 188 */             long date = ((Long)this.expiryCache.get(key)).longValue();
/*     */ 
/* 190 */             if ((date > 0L) && (new Date(date).before(new Date()))) {
/* 191 */               this.expiryCache.remove(key);
/* 192 */               cache.remove(key);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 199 */         DefaultLocalCache.Logger.info("DefaultCache CheckService is start!");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.cache.DefaultLocalCache
 * JD-Core Version:    0.6.0
 */