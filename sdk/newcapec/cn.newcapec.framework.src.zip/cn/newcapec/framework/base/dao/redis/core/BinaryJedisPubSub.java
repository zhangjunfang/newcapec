/*     */ package cn.newcapec.framework.base.dao.redis.core;
/*     */ 
/*     */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisException;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ public abstract class BinaryJedisPubSub
/*     */ {
/*  16 */   private int subscribedChannels = 0;
/*     */   private Client client;
/*     */ 
/*     */   public abstract void onMessage(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*     */ 
/*     */   public abstract void onPMessage(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3);
/*     */ 
/*     */   public abstract void onSubscribe(byte[] paramArrayOfByte, int paramInt);
/*     */ 
/*     */   public abstract void onUnsubscribe(byte[] paramArrayOfByte, int paramInt);
/*     */ 
/*     */   public abstract void onPUnsubscribe(byte[] paramArrayOfByte, int paramInt);
/*     */ 
/*     */   public abstract void onPSubscribe(byte[] paramArrayOfByte, int paramInt);
/*     */ 
/*     */   public void unsubscribe()
/*     */   {
/*  33 */     this.client.unsubscribe();
/*  34 */     this.client.flush();
/*     */   }
/*     */ 
/*     */   public void unsubscribe(byte[][] channels) {
/*  38 */     this.client.unsubscribe(channels);
/*  39 */     this.client.flush();
/*     */   }
/*     */ 
/*     */   public void subscribe(byte[][] channels) {
/*  43 */     this.client.subscribe(channels);
/*  44 */     this.client.flush();
/*     */   }
/*     */ 
/*     */   public void psubscribe(byte[][] patterns) {
/*  48 */     this.client.psubscribe(patterns);
/*  49 */     this.client.flush();
/*     */   }
/*     */ 
/*     */   public void punsubscribe() {
/*  53 */     this.client.punsubscribe();
/*  54 */     this.client.flush();
/*     */   }
/*     */ 
/*     */   public void punsubscribe(byte[][] patterns) {
/*  58 */     this.client.punsubscribe(patterns);
/*  59 */     this.client.flush();
/*     */   }
/*     */ 
/*     */   public boolean isSubscribed() {
/*  63 */     return this.subscribedChannels > 0;
/*     */   }
/*     */ 
/*     */   public void proceedWithPatterns(Client client, byte[][] patterns) {
/*  67 */     this.client = client;
/*  68 */     client.psubscribe(patterns);
/*  69 */     process(client);
/*     */   }
/*     */ 
/*     */   public void proceed(Client client, byte[][] channels) {
/*  73 */     this.client = client;
/*  74 */     client.subscribe(channels);
/*  75 */     process(client);
/*     */   }
/*     */ 
/*     */   private void process(Client client) {
/*     */     do {
/*  80 */       List reply = client.getObjectMultiBulkReply();
/*  81 */       Object firstObj = reply.get(0);
/*  82 */       if (!(firstObj instanceof byte[])) {
/*  83 */         throw new JedisException("Unknown message type: " + firstObj);
/*     */       }
/*  85 */       byte[] resp = (byte[])firstObj;
/*  86 */       if (Arrays.equals(Protocol.Keyword.SUBSCRIBE.raw, resp)) {
/*  87 */         this.subscribedChannels = ((Long)reply.get(2)).intValue();
/*  88 */         byte[] bchannel = (byte[])reply.get(1);
/*  89 */         onSubscribe(bchannel, this.subscribedChannels);
/*  90 */       } else if (Arrays.equals(Protocol.Keyword.UNSUBSCRIBE.raw, resp)) {
/*  91 */         this.subscribedChannels = ((Long)reply.get(2)).intValue();
/*  92 */         byte[] bchannel = (byte[])reply.get(1);
/*  93 */         onUnsubscribe(bchannel, this.subscribedChannels);
/*  94 */       } else if (Arrays.equals(Protocol.Keyword.MESSAGE.raw, resp)) {
/*  95 */         byte[] bchannel = (byte[])reply.get(1);
/*  96 */         byte[] bmesg = (byte[])reply.get(2);
/*  97 */         onMessage(bchannel, bmesg);
/*  98 */       } else if (Arrays.equals(Protocol.Keyword.PMESSAGE.raw, resp)) {
/*  99 */         byte[] bpattern = (byte[])reply.get(1);
/* 100 */         byte[] bchannel = (byte[])reply.get(2);
/* 101 */         byte[] bmesg = (byte[])reply.get(3);
/* 102 */         onPMessage(bpattern, bchannel, bmesg);
/* 103 */       } else if (Arrays.equals(Protocol.Keyword.PSUBSCRIBE.raw, resp)) {
/* 104 */         this.subscribedChannels = ((Long)reply.get(2)).intValue();
/* 105 */         byte[] bpattern = (byte[])reply.get(1);
/* 106 */         onPSubscribe(bpattern, this.subscribedChannels);
/* 107 */       } else if (Arrays.equals(Protocol.Keyword.PUNSUBSCRIBE.raw, resp)) {
/* 108 */         this.subscribedChannels = ((Long)reply.get(2)).intValue();
/* 109 */         byte[] bpattern = (byte[])reply.get(1);
/* 110 */         onPUnsubscribe(bpattern, this.subscribedChannels);
/*     */       } else {
/* 112 */         throw new JedisException("Unknown message type: " + firstObj);
/*     */       }
/*     */     }
/*  79 */     while (
/* 114 */       isSubscribed());
/*     */   }
/*     */ 
/*     */   public int getSubscribedChannels() {
/* 118 */     return this.subscribedChannels;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.BinaryJedisPubSub
 * JD-Core Version:    0.6.0
 */