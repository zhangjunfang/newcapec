/*    */ package cn.newcapec.framework.base.dao.redis.util;
/*    */ 
/*    */ public abstract class ShardInfo<T>
/*    */ {
/*    */   private int weight;
/*    */ 
/*    */   public ShardInfo()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ShardInfo(int weight)
/*    */   {
/* 10 */     this.weight = weight;
/*    */   }
/*    */ 
/*    */   public int getWeight() {
/* 14 */     return this.weight;
/*    */   }
/*    */ 
/*    */   protected abstract T createResource();
/*    */ 
/*    */   public abstract String getName();
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.util.ShardInfo
 * JD-Core Version:    0.6.0
 */