/*    */ package cn.newcapec.framework.base.dao.redis.exception;
/*    */ 
/*    */ public class RedisAccessException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public RedisAccessException(String code, String msg)
/*    */   {
/*    */   }
/*    */ 
/*    */   public RedisAccessException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public RedisAccessException(String message)
/*    */   {
/* 13 */     super(message);
/*    */   }
/*    */ 
/*    */   public RedisAccessException(String message, Throwable cause) {
/* 17 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public RedisAccessException(Throwable cause) {
/* 21 */     super(cause);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.exception.RedisAccessException
 * JD-Core Version:    0.6.0
 */