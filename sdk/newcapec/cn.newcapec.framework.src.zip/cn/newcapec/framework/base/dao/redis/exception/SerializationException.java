/*    */ package cn.newcapec.framework.base.dao.redis.exception;
/*    */ 
/*    */ public class SerializationException extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -8561411072499373859L;
/*    */ 
/*    */   public SerializationException(String msg, Throwable cause)
/*    */   {
/* 17 */     super(msg, cause);
/*    */   }
/*    */ 
/*    */   public SerializationException(String msg)
/*    */   {
/* 26 */     super(msg);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.exception.SerializationException
 * JD-Core Version:    0.6.0
 */