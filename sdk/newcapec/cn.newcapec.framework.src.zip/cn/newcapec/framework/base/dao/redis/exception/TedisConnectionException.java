/*    */ package cn.newcapec.framework.base.dao.redis.exception;
/*    */ 
/*    */ public class TedisConnectionException extends TedisException
/*    */ {
/*    */   private static final long serialVersionUID = 6991632939402705878L;
/*    */ 
/*    */   public TedisConnectionException(String message)
/*    */   {
/* 10 */     super(message);
/*    */   }
/*    */ 
/*    */   public TedisConnectionException(Throwable cause) {
/* 14 */     super(cause);
/*    */   }
/*    */ 
/*    */   public TedisConnectionException(String message, Throwable cause) {
/* 18 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.exception.TedisConnectionException
 * JD-Core Version:    0.6.0
 */