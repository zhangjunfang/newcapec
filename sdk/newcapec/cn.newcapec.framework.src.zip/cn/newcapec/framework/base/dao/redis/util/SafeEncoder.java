/*    */ package cn.newcapec.framework.base.dao.redis.util;
/*    */ 
/*    */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisDataException;
/*    */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisException;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ 
/*    */ public class SafeEncoder
/*    */ {
/*    */   public static byte[][] encodeMany(String[] strs)
/*    */   {
/* 17 */     byte[][] many = new byte[strs.length][];
/* 18 */     for (int i = 0; i < strs.length; i++) {
/* 19 */       many[i] = encode(strs[i]);
/*    */     }
/* 21 */     return many;
/*    */   }
/*    */ 
/*    */   public static byte[] encode(String str) {
/*    */     try {
/* 26 */       if (str == null) {
/* 27 */         throw new JedisDataException(
/* 28 */           "value sent to redis cannot be null");
/*    */       }
/* 30 */       return str.getBytes("UTF-8"); } catch (UnsupportedEncodingException e) {
/*    */     }
/* 32 */     throw new JedisException(e);
/*    */   }
/*    */ 
/*    */   public static String encode(byte[] data)
/*    */   {
/*    */     try {
/* 38 */       return new String(data, "UTF-8"); } catch (UnsupportedEncodingException e) {
/*    */     }
/* 40 */     throw new JedisException(e);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.util.SafeEncoder
 * JD-Core Version:    0.6.0
 */