/*    */ package cn.newcapec.framework.base.dao.redis.util;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Slowlog
/*    */ {
/*    */   private final long id;
/*    */   private final long timeStamp;
/*    */   private final long executionTime;
/*    */   private final List<String> args;
/*    */ 
/*    */   public static List<Slowlog> from(List<Object> nestedMultiBulkReply)
/*    */   {
/* 14 */     List logs = new ArrayList(nestedMultiBulkReply.size());
/* 15 */     for (Iterator localIterator = nestedMultiBulkReply.iterator(); localIterator.hasNext(); ) { Object obj = localIterator.next();
/* 16 */       List properties = (List)obj;
/* 17 */       logs.add(new Slowlog(properties));
/*    */     }
/*    */ 
/* 20 */     return logs;
/*    */   }
/*    */ 
/*    */   private Slowlog(List<Object> properties)
/*    */   {
/* 26 */     this.id = ((Long)properties.get(0)).longValue();
/* 27 */     this.timeStamp = ((Long)properties.get(1)).longValue();
/* 28 */     this.executionTime = ((Long)properties.get(2)).longValue();
/*    */ 
/* 30 */     List bargs = (List)properties.get(3);
/* 31 */     this.args = new ArrayList(bargs.size());
/*    */ 
/* 33 */     for (byte[] barg : bargs)
/* 34 */       this.args.add(SafeEncoder.encode(barg));
/*    */   }
/*    */ 
/*    */   public long getId()
/*    */   {
/* 39 */     return this.id;
/*    */   }
/*    */ 
/*    */   public long getTimeStamp() {
/* 43 */     return this.timeStamp;
/*    */   }
/*    */ 
/*    */   public long getExecutionTime() {
/* 47 */     return this.executionTime;
/*    */   }
/*    */ 
/*    */   public List<String> getArgs() {
/* 51 */     return this.args;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.util.Slowlog
 * JD-Core Version:    0.6.0
 */