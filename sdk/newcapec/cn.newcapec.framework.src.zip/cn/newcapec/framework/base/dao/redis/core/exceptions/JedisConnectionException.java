/*    */ package cn.newcapec.framework.base.dao.redis.core.exceptions;
/*    */ 
/*    */ public class JedisConnectionException extends JedisException
/*    */ {
/*    */   private static final long serialVersionUID = 3878126572474819403L;
/*    */ 
/*    */   public JedisConnectionException(String message)
/*    */   {
/*  7 */     super(message);
/*    */   }
/*    */ 
/*    */   public JedisConnectionException(Throwable cause) {
/* 11 */     super(cause);
/*    */   }
/*    */ 
/*    */   public JedisConnectionException(String message, Throwable cause) {
/* 15 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.exceptions.JedisConnectionException
 * JD-Core Version:    0.6.0
 */