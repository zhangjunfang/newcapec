/*     */ package cn.newcapec.framework.base.dao.redis.core;
/*     */ 
/*     */ import cn.newcapec.framework.base.dao.redis.util.SafeEncoder;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public class Client extends BinaryClient
/*     */   implements Commands
/*     */ {
/*     */   public Client(String host)
/*     */   {
/*  13 */     super(host);
/*     */   }
/*     */ 
/*     */   public Client(String host, int port) {
/*  17 */     super(host, port);
/*     */   }
/*     */ 
/*     */   public void set(String key, String value) {
/*  21 */     set(SafeEncoder.encode(key), SafeEncoder.encode(value));
/*     */   }
/*     */ 
/*     */   public void get(String key) {
/*  25 */     get(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void exists(String key) {
/*  29 */     exists(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void del(String[] keys) {
/*  33 */     byte[][] bkeys = new byte[keys.length][];
/*  34 */     for (int i = 0; i < keys.length; i++) {
/*  35 */       bkeys[i] = SafeEncoder.encode(keys[i]);
/*     */     }
/*  37 */     del(bkeys);
/*     */   }
/*     */ 
/*     */   public void type(String key) {
/*  41 */     type(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void keys(String pattern) {
/*  45 */     keys(SafeEncoder.encode(pattern));
/*     */   }
/*     */ 
/*     */   public void rename(String oldkey, String newkey) {
/*  49 */     rename(SafeEncoder.encode(oldkey), SafeEncoder.encode(newkey));
/*     */   }
/*     */ 
/*     */   public void renamenx(String oldkey, String newkey) {
/*  53 */     renamenx(SafeEncoder.encode(oldkey), SafeEncoder.encode(newkey));
/*     */   }
/*     */ 
/*     */   public void expire(String key, int seconds) {
/*  57 */     expire(SafeEncoder.encode(key), seconds);
/*     */   }
/*     */ 
/*     */   public void expireAt(String key, long unixTime) {
/*  61 */     expireAt(SafeEncoder.encode(key), unixTime);
/*     */   }
/*     */ 
/*     */   public void ttl(String key) {
/*  65 */     ttl(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void move(String key, int dbIndex) {
/*  69 */     move(SafeEncoder.encode(key), dbIndex);
/*     */   }
/*     */ 
/*     */   public void getSet(String key, String value) {
/*  73 */     getSet(SafeEncoder.encode(key), SafeEncoder.encode(value));
/*     */   }
/*     */ 
/*     */   public void mget(String[] keys) {
/*  77 */     byte[][] bkeys = new byte[keys.length][];
/*  78 */     for (int i = 0; i < bkeys.length; i++) {
/*  79 */       bkeys[i] = SafeEncoder.encode(keys[i]);
/*     */     }
/*  81 */     mget(bkeys);
/*     */   }
/*     */ 
/*     */   public void setnx(String key, String value) {
/*  85 */     setnx(SafeEncoder.encode(key), SafeEncoder.encode(value));
/*     */   }
/*     */ 
/*     */   public void setex(String key, int seconds, String value) {
/*  89 */     setex(SafeEncoder.encode(key), seconds, SafeEncoder.encode(value));
/*     */   }
/*     */ 
/*     */   public void mset(String[] keysvalues) {
/*  93 */     byte[][] bkeysvalues = new byte[keysvalues.length][];
/*  94 */     for (int i = 0; i < keysvalues.length; i++) {
/*  95 */       bkeysvalues[i] = SafeEncoder.encode(keysvalues[i]);
/*     */     }
/*  97 */     mset(bkeysvalues);
/*     */   }
/*     */ 
/*     */   public void msetnx(String[] keysvalues) {
/* 101 */     byte[][] bkeysvalues = new byte[keysvalues.length][];
/* 102 */     for (int i = 0; i < keysvalues.length; i++) {
/* 103 */       bkeysvalues[i] = SafeEncoder.encode(keysvalues[i]);
/*     */     }
/* 105 */     msetnx(bkeysvalues);
/*     */   }
/*     */ 
/*     */   public void decrBy(String key, long integer) {
/* 109 */     decrBy(SafeEncoder.encode(key), integer);
/*     */   }
/*     */ 
/*     */   public void decr(String key) {
/* 113 */     decr(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void incrBy(String key, long integer) {
/* 117 */     incrBy(SafeEncoder.encode(key), integer);
/*     */   }
/*     */ 
/*     */   public void incr(String key) {
/* 121 */     incr(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void append(String key, String value) {
/* 125 */     append(SafeEncoder.encode(key), SafeEncoder.encode(value));
/*     */   }
/*     */ 
/*     */   public void substr(String key, int start, int end) {
/* 129 */     substr(SafeEncoder.encode(key), start, end);
/*     */   }
/*     */ 
/*     */   public void hset(String key, String field, String value) {
/* 133 */     hset(SafeEncoder.encode(key), SafeEncoder.encode(field), 
/* 134 */       SafeEncoder.encode(value));
/*     */   }
/*     */ 
/*     */   public void hget(String key, String field) {
/* 138 */     hget(SafeEncoder.encode(key), SafeEncoder.encode(field));
/*     */   }
/*     */ 
/*     */   public void hsetnx(String key, String field, String value) {
/* 142 */     hsetnx(SafeEncoder.encode(key), SafeEncoder.encode(field), 
/* 143 */       SafeEncoder.encode(value));
/*     */   }
/*     */ 
/*     */   public void hmset(String key, Map<String, String> hash) {
/* 147 */     Map bhash = new HashMap(
/* 148 */       hash.size());
/* 149 */     for (Map.Entry entry : hash.entrySet()) {
/* 150 */       bhash.put(SafeEncoder.encode((String)entry.getKey()), 
/* 151 */         SafeEncoder.encode((String)entry.getValue()));
/*     */     }
/* 153 */     hmset(SafeEncoder.encode(key), bhash);
/*     */   }
/*     */ 
/*     */   public void hmget(String key, String[] fields) {
/* 157 */     byte[][] bfields = new byte[fields.length][];
/* 158 */     for (int i = 0; i < bfields.length; i++) {
/* 159 */       bfields[i] = SafeEncoder.encode(fields[i]);
/*     */     }
/* 161 */     hmget(SafeEncoder.encode(key), bfields);
/*     */   }
/*     */ 
/*     */   public void hincrBy(String key, String field, long value) {
/* 165 */     hincrBy(SafeEncoder.encode(key), SafeEncoder.encode(field), value);
/*     */   }
/*     */ 
/*     */   public void hexists(String key, String field) {
/* 169 */     hexists(SafeEncoder.encode(key), SafeEncoder.encode(field));
/*     */   }
/*     */ 
/*     */   public void hdel(String key, String[] fields) {
/* 173 */     hdel(SafeEncoder.encode(key), SafeEncoder.encodeMany(fields));
/*     */   }
/*     */ 
/*     */   public void hlen(String key) {
/* 177 */     hlen(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void hkeys(String key) {
/* 181 */     hkeys(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void hvals(String key) {
/* 185 */     hvals(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void hgetAll(String key) {
/* 189 */     hgetAll(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void rpush(String key, String[] string) {
/* 193 */     rpush(SafeEncoder.encode(key), SafeEncoder.encodeMany(string));
/*     */   }
/*     */ 
/*     */   public void lpush(String key, String[] string) {
/* 197 */     lpush(SafeEncoder.encode(key), SafeEncoder.encodeMany(string));
/*     */   }
/*     */ 
/*     */   public void llen(String key) {
/* 201 */     llen(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void lrange(String key, long start, long end) {
/* 205 */     lrange(SafeEncoder.encode(key), start, end);
/*     */   }
/*     */ 
/*     */   public void ltrim(String key, long start, long end) {
/* 209 */     ltrim(SafeEncoder.encode(key), start, end);
/*     */   }
/*     */ 
/*     */   public void lindex(String key, long index) {
/* 213 */     lindex(SafeEncoder.encode(key), index);
/*     */   }
/*     */ 
/*     */   public void lset(String key, long index, String value) {
/* 217 */     lset(SafeEncoder.encode(key), index, SafeEncoder.encode(value));
/*     */   }
/*     */ 
/*     */   public void lrem(String key, long count, String value) {
/* 221 */     lrem(SafeEncoder.encode(key), count, SafeEncoder.encode(value));
/*     */   }
/*     */ 
/*     */   public void lpop(String key) {
/* 225 */     lpop(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void rpop(String key) {
/* 229 */     rpop(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void rpoplpush(String srckey, String dstkey) {
/* 233 */     rpoplpush(SafeEncoder.encode(srckey), SafeEncoder.encode(dstkey));
/*     */   }
/*     */ 
/*     */   public void sadd(String key, String[] members) {
/* 237 */     sadd(SafeEncoder.encode(key), SafeEncoder.encodeMany(members));
/*     */   }
/*     */ 
/*     */   public void smembers(String key) {
/* 241 */     smembers(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void srem(String key, String[] members) {
/* 245 */     srem(SafeEncoder.encode(key), SafeEncoder.encodeMany(members));
/*     */   }
/*     */ 
/*     */   public void spop(String key) {
/* 249 */     spop(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void smove(String srckey, String dstkey, String member)
/*     */   {
/* 254 */     smove(SafeEncoder.encode(srckey), SafeEncoder.encode(dstkey), 
/* 255 */       SafeEncoder.encode(member));
/*     */   }
/*     */ 
/*     */   public void scard(String key) {
/* 259 */     scard(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void sismember(String key, String member) {
/* 263 */     sismember(SafeEncoder.encode(key), SafeEncoder.encode(member));
/*     */   }
/*     */ 
/*     */   public void sinter(String[] keys) {
/* 267 */     byte[][] bkeys = new byte[keys.length][];
/* 268 */     for (int i = 0; i < bkeys.length; i++) {
/* 269 */       bkeys[i] = SafeEncoder.encode(keys[i]);
/*     */     }
/* 271 */     sinter(bkeys);
/*     */   }
/*     */ 
/*     */   public void sinterstore(String dstkey, String[] keys) {
/* 275 */     byte[][] bkeys = new byte[keys.length][];
/* 276 */     for (int i = 0; i < bkeys.length; i++) {
/* 277 */       bkeys[i] = SafeEncoder.encode(keys[i]);
/*     */     }
/* 279 */     sinterstore(SafeEncoder.encode(dstkey), bkeys);
/*     */   }
/*     */ 
/*     */   public void sunion(String[] keys) {
/* 283 */     byte[][] bkeys = new byte[keys.length][];
/* 284 */     for (int i = 0; i < bkeys.length; i++) {
/* 285 */       bkeys[i] = SafeEncoder.encode(keys[i]);
/*     */     }
/* 287 */     sunion(bkeys);
/*     */   }
/*     */ 
/*     */   public void sunionstore(String dstkey, String[] keys) {
/* 291 */     byte[][] bkeys = new byte[keys.length][];
/* 292 */     for (int i = 0; i < bkeys.length; i++) {
/* 293 */       bkeys[i] = SafeEncoder.encode(keys[i]);
/*     */     }
/* 295 */     sunionstore(SafeEncoder.encode(dstkey), bkeys);
/*     */   }
/*     */ 
/*     */   public void sdiff(String[] keys) {
/* 299 */     byte[][] bkeys = new byte[keys.length][];
/* 300 */     for (int i = 0; i < bkeys.length; i++) {
/* 301 */       bkeys[i] = SafeEncoder.encode(keys[i]);
/*     */     }
/* 303 */     sdiff(bkeys);
/*     */   }
/*     */ 
/*     */   public void sdiffstore(String dstkey, String[] keys) {
/* 307 */     byte[][] bkeys = new byte[keys.length][];
/* 308 */     for (int i = 0; i < bkeys.length; i++) {
/* 309 */       bkeys[i] = SafeEncoder.encode(keys[i]);
/*     */     }
/* 311 */     sdiffstore(SafeEncoder.encode(dstkey), bkeys);
/*     */   }
/*     */ 
/*     */   public void srandmember(String key) {
/* 315 */     srandmember(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void zadd(String key, double score, String member) {
/* 319 */     zadd(SafeEncoder.encode(key), score, SafeEncoder.encode(member));
/*     */   }
/*     */ 
/*     */   public void zrange(String key, long start, long end) {
/* 323 */     zrange(SafeEncoder.encode(key), start, end);
/*     */   }
/*     */ 
/*     */   public void zrem(String key, String[] members) {
/* 327 */     zrem(SafeEncoder.encode(key), SafeEncoder.encodeMany(members));
/*     */   }
/*     */ 
/*     */   public void zincrby(String key, double score, String member)
/*     */   {
/* 332 */     zincrby(SafeEncoder.encode(key), score, SafeEncoder.encode(member));
/*     */   }
/*     */ 
/*     */   public void zrank(String key, String member) {
/* 336 */     zrank(SafeEncoder.encode(key), SafeEncoder.encode(member));
/*     */   }
/*     */ 
/*     */   public void zrevrank(String key, String member) {
/* 340 */     zrevrank(SafeEncoder.encode(key), SafeEncoder.encode(member));
/*     */   }
/*     */ 
/*     */   public void zrevrange(String key, long start, long end) {
/* 344 */     zrevrange(SafeEncoder.encode(key), start, end);
/*     */   }
/*     */ 
/*     */   public void zrangeWithScores(String key, long start, long end)
/*     */   {
/* 349 */     zrangeWithScores(SafeEncoder.encode(key), start, end);
/*     */   }
/*     */ 
/*     */   public void zrevrangeWithScores(String key, long start, long end)
/*     */   {
/* 354 */     zrevrangeWithScores(SafeEncoder.encode(key), start, end);
/*     */   }
/*     */ 
/*     */   public void zcard(String key) {
/* 358 */     zcard(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void zscore(String key, String member) {
/* 362 */     zscore(SafeEncoder.encode(key), SafeEncoder.encode(member));
/*     */   }
/*     */ 
/*     */   public void watch(String[] keys) {
/* 366 */     byte[][] bargs = new byte[keys.length][];
/* 367 */     for (int i = 0; i < bargs.length; i++) {
/* 368 */       bargs[i] = SafeEncoder.encode(keys[i]);
/*     */     }
/* 370 */     watch(bargs);
/*     */   }
/*     */ 
/*     */   public void sort(String key) {
/* 374 */     sort(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void sort(String key, SortingParams sortingParameters) {
/* 378 */     sort(SafeEncoder.encode(key), sortingParameters);
/*     */   }
/*     */ 
/*     */   public void blpop(String[] args) {
/* 382 */     byte[][] bargs = new byte[args.length][];
/* 383 */     for (int i = 0; i < bargs.length; i++) {
/* 384 */       bargs[i] = SafeEncoder.encode(args[i]);
/*     */     }
/* 386 */     blpop(bargs);
/*     */   }
/*     */ 
/*     */   public void sort(String key, SortingParams sortingParameters, String dstkey)
/*     */   {
/* 391 */     sort(SafeEncoder.encode(key), sortingParameters, 
/* 392 */       SafeEncoder.encode(dstkey));
/*     */   }
/*     */ 
/*     */   public void sort(String key, String dstkey) {
/* 396 */     sort(SafeEncoder.encode(key), SafeEncoder.encode(dstkey));
/*     */   }
/*     */ 
/*     */   public void brpop(String[] args) {
/* 400 */     byte[][] bargs = new byte[args.length][];
/* 401 */     for (int i = 0; i < bargs.length; i++) {
/* 402 */       bargs[i] = SafeEncoder.encode(args[i]);
/*     */     }
/* 404 */     brpop(bargs);
/*     */   }
/*     */ 
/*     */   public void zcount(String key, double min, double max) {
/* 408 */     zcount(SafeEncoder.encode(key), Protocol.toByteArray(min), Protocol.toByteArray(max));
/*     */   }
/*     */ 
/*     */   public void zcount(String key, String min, String max) {
/* 412 */     zcount(SafeEncoder.encode(key), SafeEncoder.encode(min), 
/* 413 */       SafeEncoder.encode(max));
/*     */   }
/*     */ 
/*     */   public void zrangeByScore(String key, double min, double max)
/*     */   {
/* 418 */     zrangeByScore(SafeEncoder.encode(key), Protocol.toByteArray(min), 
/* 419 */       Protocol.toByteArray(max));
/*     */   }
/*     */ 
/*     */   public void zrangeByScore(String key, String min, String max)
/*     */   {
/* 424 */     zrangeByScore(SafeEncoder.encode(key), SafeEncoder.encode(min), 
/* 425 */       SafeEncoder.encode(max));
/*     */   }
/*     */ 
/*     */   public void zrangeByScore(String key, double min, double max, int offset, int count)
/*     */   {
/* 430 */     zrangeByScore(SafeEncoder.encode(key), Protocol.toByteArray(min), 
/* 431 */       Protocol.toByteArray(max), offset, count);
/*     */   }
/*     */ 
/*     */   public void zrangeByScoreWithScores(String key, double min, double max)
/*     */   {
/* 436 */     zrangeByScoreWithScores(SafeEncoder.encode(key), Protocol.toByteArray(min), 
/* 437 */       Protocol.toByteArray(max));
/*     */   }
/*     */ 
/*     */   public void zrangeByScoreWithScores(String key, double min, double max, int offset, int count)
/*     */   {
/* 442 */     zrangeByScoreWithScores(SafeEncoder.encode(key), Protocol.toByteArray(min), 
/* 443 */       Protocol.toByteArray(max), offset, count);
/*     */   }
/*     */ 
/*     */   public void zrevrangeByScore(String key, double max, double min)
/*     */   {
/* 448 */     zrevrangeByScore(SafeEncoder.encode(key), Protocol.toByteArray(max), 
/* 449 */       Protocol.toByteArray(min));
/*     */   }
/*     */ 
/*     */   public void zrangeByScore(String key, String min, String max, int offset, int count)
/*     */   {
/* 454 */     zrangeByScore(SafeEncoder.encode(key), SafeEncoder.encode(min), 
/* 455 */       SafeEncoder.encode(max), offset, count);
/*     */   }
/*     */ 
/*     */   public void zrangeByScoreWithScores(String key, String min, String max)
/*     */   {
/* 460 */     zrangeByScoreWithScores(SafeEncoder.encode(key), 
/* 461 */       SafeEncoder.encode(min), SafeEncoder.encode(max));
/*     */   }
/*     */ 
/*     */   public void zrangeByScoreWithScores(String key, String min, String max, int offset, int count)
/*     */   {
/* 466 */     zrangeByScoreWithScores(SafeEncoder.encode(key), 
/* 467 */       SafeEncoder.encode(min), SafeEncoder.encode(max), offset, count);
/*     */   }
/*     */ 
/*     */   public void zrevrangeByScore(String key, String max, String min)
/*     */   {
/* 472 */     zrevrangeByScore(SafeEncoder.encode(key), SafeEncoder.encode(max), 
/* 473 */       SafeEncoder.encode(min));
/*     */   }
/*     */ 
/*     */   public void zrevrangeByScore(String key, double max, double min, int offset, int count)
/*     */   {
/* 478 */     zrevrangeByScore(SafeEncoder.encode(key), Protocol.toByteArray(max), 
/* 479 */       Protocol.toByteArray(min), offset, count);
/*     */   }
/*     */ 
/*     */   public void zrevrangeByScore(String key, String max, String min, int offset, int count)
/*     */   {
/* 484 */     zrevrangeByScore(SafeEncoder.encode(key), SafeEncoder.encode(max), 
/* 485 */       SafeEncoder.encode(min), offset, count);
/*     */   }
/*     */ 
/*     */   public void zrevrangeByScoreWithScores(String key, double max, double min)
/*     */   {
/* 490 */     zrevrangeByScoreWithScores(SafeEncoder.encode(key), Protocol.toByteArray(max), 
/* 491 */       Protocol.toByteArray(min));
/*     */   }
/*     */ 
/*     */   public void zrevrangeByScoreWithScores(String key, String max, String min)
/*     */   {
/* 496 */     zrevrangeByScoreWithScores(SafeEncoder.encode(key), 
/* 497 */       SafeEncoder.encode(max), SafeEncoder.encode(min));
/*     */   }
/*     */ 
/*     */   public void zrevrangeByScoreWithScores(String key, double max, double min, int offset, int count)
/*     */   {
/* 502 */     zrevrangeByScoreWithScores(SafeEncoder.encode(key), Protocol.toByteArray(max), 
/* 503 */       Protocol.toByteArray(min), offset, count);
/*     */   }
/*     */ 
/*     */   public void zrevrangeByScoreWithScores(String key, String max, String min, int offset, int count)
/*     */   {
/* 508 */     zrevrangeByScoreWithScores(SafeEncoder.encode(key), 
/* 509 */       SafeEncoder.encode(max), SafeEncoder.encode(min), offset, count);
/*     */   }
/*     */ 
/*     */   public void zremrangeByRank(String key, long start, long end)
/*     */   {
/* 514 */     zremrangeByRank(SafeEncoder.encode(key), start, end);
/*     */   }
/*     */ 
/*     */   public void zremrangeByScore(String key, double start, double end)
/*     */   {
/* 519 */     zremrangeByScore(SafeEncoder.encode(key), Protocol.toByteArray(start), 
/* 520 */       Protocol.toByteArray(end));
/*     */   }
/*     */ 
/*     */   public void zremrangeByScore(String key, String start, String end)
/*     */   {
/* 525 */     zremrangeByScore(SafeEncoder.encode(key), SafeEncoder.encode(start), 
/* 526 */       SafeEncoder.encode(end));
/*     */   }
/*     */ 
/*     */   public void zunionstore(String dstkey, String[] sets) {
/* 530 */     byte[][] bsets = new byte[sets.length][];
/* 531 */     for (int i = 0; i < bsets.length; i++) {
/* 532 */       bsets[i] = SafeEncoder.encode(sets[i]);
/*     */     }
/* 534 */     zunionstore(SafeEncoder.encode(dstkey), bsets);
/*     */   }
/*     */ 
/*     */   public void zunionstore(String dstkey, ZParams params, String[] sets)
/*     */   {
/* 539 */     byte[][] bsets = new byte[sets.length][];
/* 540 */     for (int i = 0; i < bsets.length; i++) {
/* 541 */       bsets[i] = SafeEncoder.encode(sets[i]);
/*     */     }
/* 543 */     zunionstore(SafeEncoder.encode(dstkey), params, bsets);
/*     */   }
/*     */ 
/*     */   public void zinterstore(String dstkey, String[] sets) {
/* 547 */     byte[][] bsets = new byte[sets.length][];
/* 548 */     for (int i = 0; i < bsets.length; i++) {
/* 549 */       bsets[i] = SafeEncoder.encode(sets[i]);
/*     */     }
/* 551 */     zinterstore(SafeEncoder.encode(dstkey), bsets);
/*     */   }
/*     */ 
/*     */   public void zinterstore(String dstkey, ZParams params, String[] sets)
/*     */   {
/* 556 */     byte[][] bsets = new byte[sets.length][];
/* 557 */     for (int i = 0; i < bsets.length; i++) {
/* 558 */       bsets[i] = SafeEncoder.encode(sets[i]);
/*     */     }
/* 560 */     zinterstore(SafeEncoder.encode(dstkey), params, bsets);
/*     */   }
/*     */ 
/*     */   public void strlen(String key) {
/* 564 */     strlen(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void lpushx(String key, String[] string) {
/* 568 */     lpushx(SafeEncoder.encode(key), getByteParams(string));
/*     */   }
/*     */ 
/*     */   public void persist(String key) {
/* 572 */     persist(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void rpushx(String key, String[] string) {
/* 576 */     rpushx(SafeEncoder.encode(key), getByteParams(string));
/*     */   }
/*     */ 
/*     */   public void echo(String string) {
/* 580 */     echo(SafeEncoder.encode(string));
/*     */   }
/*     */ 
/*     */   public void linsert(String key, BinaryClient.LIST_POSITION where, String pivot, String value)
/*     */   {
/* 585 */     linsert(SafeEncoder.encode(key), where, SafeEncoder.encode(pivot), 
/* 586 */       SafeEncoder.encode(value));
/*     */   }
/*     */ 
/*     */   public void brpoplpush(String source, String destination, int timeout) {
/* 590 */     brpoplpush(SafeEncoder.encode(source), SafeEncoder.encode(destination), 
/* 591 */       timeout);
/*     */   }
/*     */ 
/*     */   public void setbit(String key, long offset, boolean value) {
/* 595 */     setbit(SafeEncoder.encode(key), offset, value);
/*     */   }
/*     */ 
/*     */   public void setbit(String key, long offset, String value) {
/* 599 */     setbit(SafeEncoder.encode(key), offset, SafeEncoder.encode(value));
/*     */   }
/*     */ 
/*     */   public void getbit(String key, long offset) {
/* 603 */     getbit(SafeEncoder.encode(key), offset);
/*     */   }
/*     */ 
/*     */   public void setrange(String key, long offset, String value) {
/* 607 */     setrange(SafeEncoder.encode(key), offset, SafeEncoder.encode(value));
/*     */   }
/*     */ 
/*     */   public void getrange(String key, long startOffset, long endOffset) {
/* 611 */     getrange(SafeEncoder.encode(key), startOffset, endOffset);
/*     */   }
/*     */ 
/*     */   public void publish(String channel, String message) {
/* 615 */     publish(SafeEncoder.encode(channel), SafeEncoder.encode(message));
/*     */   }
/*     */ 
/*     */   public void unsubscribe(String[] channels) {
/* 619 */     byte[][] cs = new byte[channels.length][];
/* 620 */     for (int i = 0; i < cs.length; i++) {
/* 621 */       cs[i] = SafeEncoder.encode(channels[i]);
/*     */     }
/* 623 */     unsubscribe(cs);
/*     */   }
/*     */ 
/*     */   public void psubscribe(String[] patterns) {
/* 627 */     byte[][] ps = new byte[patterns.length][];
/* 628 */     for (int i = 0; i < ps.length; i++) {
/* 629 */       ps[i] = SafeEncoder.encode(patterns[i]);
/*     */     }
/* 631 */     psubscribe(ps);
/*     */   }
/*     */ 
/*     */   public void punsubscribe(String[] patterns) {
/* 635 */     byte[][] ps = new byte[patterns.length][];
/* 636 */     for (int i = 0; i < ps.length; i++) {
/* 637 */       ps[i] = SafeEncoder.encode(patterns[i]);
/*     */     }
/* 639 */     punsubscribe(ps);
/*     */   }
/*     */ 
/*     */   public void subscribe(String[] channels) {
/* 643 */     byte[][] cs = new byte[channels.length][];
/* 644 */     for (int i = 0; i < cs.length; i++) {
/* 645 */       cs[i] = SafeEncoder.encode(channels[i]);
/*     */     }
/* 647 */     subscribe(cs);
/*     */   }
/*     */ 
/*     */   public void configSet(String parameter, String value) {
/* 651 */     configSet(SafeEncoder.encode(parameter), SafeEncoder.encode(value));
/*     */   }
/*     */ 
/*     */   public void configGet(String pattern) {
/* 655 */     configGet(SafeEncoder.encode(pattern));
/*     */   }
/*     */ 
/*     */   private byte[][] getByteParams(String[] params) {
/* 659 */     byte[][] p = new byte[params.length][];
/* 660 */     for (int i = 0; i < params.length; i++) {
/* 661 */       p[i] = SafeEncoder.encode(params[i]);
/*     */     }
/* 663 */     return p;
/*     */   }
/*     */ 
/*     */   public void eval(String script, int keyCount, String[] params) {
/* 667 */     eval(SafeEncoder.encode(script), Protocol.toByteArray(keyCount), 
/* 668 */       getByteParams(params));
/*     */   }
/*     */ 
/*     */   public void evalsha(String sha1, int keyCount, String[] params) {
/* 672 */     evalsha(SafeEncoder.encode(sha1), Protocol.toByteArray(keyCount), 
/* 673 */       getByteParams(params));
/*     */   }
/*     */ 
/*     */   public void scriptExists(String[] sha1) {
/* 677 */     byte[][] bsha1 = new byte[sha1.length][];
/* 678 */     for (int i = 0; i < bsha1.length; i++) {
/* 679 */       bsha1[i] = SafeEncoder.encode(sha1[i]);
/*     */     }
/* 681 */     scriptExists(bsha1);
/*     */   }
/*     */ 
/*     */   public void scriptLoad(String script) {
/* 685 */     scriptLoad(SafeEncoder.encode(script));
/*     */   }
/*     */ 
/*     */   public void zadd(String key, Map<Double, String> scoreMembers) {
/* 689 */     HashMap binaryScoreMembers = new HashMap();
/*     */ 
/* 691 */     for (Map.Entry entry : scoreMembers.entrySet()) {
/* 692 */       binaryScoreMembers.put((Double)entry.getKey(), 
/* 693 */         SafeEncoder.encode((String)entry.getValue()));
/*     */     }
/*     */ 
/* 696 */     zaddBinary(SafeEncoder.encode(key), binaryScoreMembers);
/*     */   }
/*     */ 
/*     */   public void objectRefcount(String key) {
/* 700 */     objectRefcount(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void objectIdletime(String key) {
/* 704 */     objectIdletime(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void objectEncoding(String key) {
/* 708 */     objectEncoding(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void bitcount(String key) {
/* 712 */     bitcount(SafeEncoder.encode(key));
/*     */   }
/*     */ 
/*     */   public void bitcount(String key, long start, long end) {
/* 716 */     bitcount(SafeEncoder.encode(key), start, end);
/*     */   }
/*     */ 
/*     */   public void bitop(BitOP op, String destKey, String[] srcKeys) {
/* 720 */     bitop(op, SafeEncoder.encode(destKey), getByteParams(srcKeys));
/*     */   }
/*     */ 
/*     */   public void sentinel(String[] args) {
/* 724 */     byte[][] arg = new byte[args.length][];
/* 725 */     for (int i = 0; i < arg.length; i++) {
/* 726 */       arg[i] = SafeEncoder.encode(args[i]);
/*     */     }
/* 728 */     sentinel(arg);
/*     */   }
/*     */ 
/*     */   public void sentinel(String cmd, String arg1, int arg2) {
/* 732 */     sentinel(new byte[][] { SafeEncoder.encode(cmd), SafeEncoder.encode(arg1), 
/* 733 */       Protocol.toByteArray(arg2) });
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.Client
 * JD-Core Version:    0.6.0
 */