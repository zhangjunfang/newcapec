/*     */ package cn.newcapec.framework.base.dao.hibernate;
/*     */ 
/*     */ import cn.newcapec.framework.base.dao.EntityDao;
/*     */ import cn.newcapec.framework.utils.GenericsUtils;
/*     */ import cn.newcapec.framework.utils.Page;
/*     */ import cn.newcapec.framework.utils.SystemContext;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.annotation.Resource;
/*     */ import javax.management.RuntimeErrorException;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.hibernate.Criteria;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.SQLQuery;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.hibernate.criterion.Criterion;
/*     */ import org.hibernate.transform.Transformers;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ 
/*     */ public class HibernateEntityDao<T> extends HibernateGenericDao
/*     */   implements EntityDao<T>
/*     */ {
/*     */   protected Class<T> entityClass;
/*     */ 
/*     */   @Resource(name="sessionFactory")
/*     */   public void setSuperSessionFactory(SessionFactory sessionFactory)
/*     */   {
/*  40 */     super.setSessionFactory(sessionFactory);
/*     */   }
/*     */ 
/*     */   public HibernateEntityDao()
/*     */   {
/*  51 */     this.entityClass = GenericsUtils.getSuperClassGenricType(getClass());
/*     */   }
/*     */ 
/*     */   protected Class<T> getEntityClass()
/*     */   {
/*  59 */     return this.entityClass;
/*     */   }
/*     */ 
/*     */   public T get(Serializable id)
/*     */   {
/*  68 */     return get(getEntityClass(), id);
/*     */   }
/*     */ 
/*     */   public List<T> getAll()
/*     */   {
/*  78 */     return getAll(getEntityClass());
/*     */   }
/*     */ 
/*     */   public void clear() {
/*  82 */     getSession().clear();
/*     */   }
/*     */ 
/*     */   public List<T> getAll(String orderBy, boolean isAsc)
/*     */   {
/*  92 */     return getAll(getEntityClass(), orderBy, isAsc);
/*     */   }
/*     */ 
/*     */   public long countAll()
/*     */   {
/*  97 */     return countAll(getEntityClass());
/*     */   }
/*     */ 
/*     */   public void removeById(Serializable id)
/*     */   {
/* 107 */     removeById(getEntityClass(), id);
/*     */   }
/*     */ 
/*     */   public int remove(String hql, Object[] values)
/*     */   {
/* 119 */     Query query = createQuery(hql, values);
/* 120 */     if (values != null) {
/* 121 */       for (int i = 0; i < values.length; i++)
/* 122 */         query.setParameter(i, values[i]);
/*     */     }
/* 124 */     return query.executeUpdate();
/*     */   }
/*     */ 
/*     */   public Criteria createCriteria(Criterion[] criterions)
/*     */   {
/* 134 */     return createCriteria(getEntityClass(), criterions);
/*     */   }
/*     */ 
/*     */   public Criteria createCriteria(String orderBy, boolean isAsc, Criterion[] criterions)
/*     */   {
/* 145 */     return createCriteria(getEntityClass(), orderBy, isAsc, criterions);
/*     */   }
/*     */ 
/*     */   public List<T> findBy(String propertyName, Object value)
/*     */   {
/* 156 */     return findBy(getEntityClass(), propertyName, value);
/*     */   }
/*     */ 
/*     */   public List<T> findBy(String propertyName, Object value, String orderBy, boolean isAsc)
/*     */   {
/* 168 */     return findBy(getEntityClass(), propertyName, value, orderBy, isAsc);
/*     */   }
/*     */ 
/*     */   public T findUniqueBy(String propertyName, Object value)
/*     */   {
/* 179 */     return findUniqueBy(getEntityClass(), propertyName, value);
/*     */   }
/*     */ 
/*     */   public boolean isUnique(Object entity, String uniquePropertyNames)
/*     */   {
/* 191 */     return isUnique(getEntityClass(), entity, uniquePropertyNames);
/*     */   }
/*     */ 
/*     */   public Page queryForpage(String hql) {
/* 195 */     return queryForpage(hql, null, null);
/*     */   }
/*     */ 
/*     */   public Page queryForpage(String hql, LinkedHashMap<String, String> orderby) {
/* 199 */     return queryForpage(hql, null, orderby);
/*     */   }
/*     */ 
/*     */   public Page queryForpage(String hql, Object[] params, LinkedHashMap<String, String> orderby)
/*     */   {
/* 204 */     return queryForpage(hql, params, SystemContext.getOffset().intValue(), 
/* 205 */       SystemContext.getPagesize().intValue(), orderby);
/*     */   }
/*     */ 
/*     */   public Page queryForpage(String hql, int offset, int pagesize, LinkedHashMap<String, String> orderby)
/*     */   {
/* 210 */     return queryForpage(hql, null, offset, pagesize, orderby);
/*     */   }
/*     */ 
/*     */   public Page queryForpage(String hql, Object values, int offset, int pagesize, LinkedHashMap<String, String> orderby)
/*     */   {
/* 215 */     return queryForpage(hql, new Object[] { values }, offset, pagesize, 
/* 216 */       orderby);
/*     */   }
/*     */ 
/*     */   public Page queryForpage(String select, Object[] values, int pagestart, int pagesize, LinkedHashMap<String, String> orderby)
/*     */   {
/* 221 */     Page page = new Page((SystemContext.getOffset().intValue() - SystemContext.getOffset().intValue() % SystemContext.getPagesize().intValue()) / SystemContext.getPagesize().intValue(), SystemContext.getPagesize().intValue());
/* 222 */     String countHql = getHibernateCountQuery(select);
/* 223 */     Long totalCount = (Long)queryForObject(countHql, values);
/* 224 */     page.setTotalCount(totalCount.intValue());
/* 225 */     page.setItems(queryForList(select, values, pagestart, pagesize, orderby));
/* 226 */     return page;
/*     */   }
/*     */ 
/*     */   public List queryForList(String select, Object[] values, int pagestart, int pagesize, LinkedHashMap<String, String> orderby)
/*     */   {
/* 232 */     HibernateCallback selectCallback = new HibernateCallback(select, orderby, values, pagestart, pagesize) {
/*     */       public Object doInHibernate(Session session) {
/* 234 */         Query query = session.createQuery(this.val$select + 
/* 235 */           HibernateEntityDao.buildOrderby(this.val$orderby));
/* 236 */         if (this.val$values != null) {
/* 237 */           for (int i = 0; i < this.val$values.length; i++)
/* 238 */             query.setParameter(i, this.val$values[i]);
/*     */         }
/* 240 */         return query.setFirstResult(this.val$pagestart).setMaxResults(this.val$pagesize)
/* 241 */           .list();
/*     */       }
/*     */     };
/* 244 */     return getHibernateTemplate().executeFind(selectCallback);
/*     */   }
/*     */ 
/*     */   public Page queryForPage(String selectCount, String select, Object[] values, int pagestart, int pagesize, LinkedHashMap<String, String> orderby)
/*     */   {
/* 251 */     Page page = new Page();
/* 252 */     Long totalCount = (Long)queryForObject(selectCount, values);
/* 253 */     page.setTotal(totalCount.intValue());
/* 254 */     page.setItems(queryForList(select, values, pagestart, pagesize, orderby));
/* 255 */     return page;
/*     */   }
/*     */ 
/*     */   public Page sqlQueryForPage(String sql, Object[] params, LinkedHashMap<String, String> orderby)
/*     */   {
/* 267 */     return sqlQueryForPage(sql, params, SystemContext.getOffset().intValue(), SystemContext.getPagesize().intValue(), orderby);
/*     */   }
/*     */ 
/*     */   public Page sqlQueryForPage(String sql, Object[] params, int offSet, int pagesize, LinkedHashMap<String, String> orderby)
/*     */   {
/* 283 */     SQLQuery countQuery = getSession().createSQLQuery(getHibernateCountQuery(sql));
/* 284 */     if ((params != null) && (params.length > 0)) {
/* 285 */       for (int i = 0; i < params.length; i++) {
/* 286 */         countQuery.setParameter(i, params[i]);
/*     */       }
/*     */     }
/* 289 */     Integer totalCount = Integer.valueOf(Integer.parseInt(countQuery.uniqueResult().toString()));
/*     */ 
/* 291 */     Page page = new Page((offSet - offSet % pagesize) / pagesize + 1, pagesize);
/* 292 */     page.setTotalCount(totalCount.intValue());
/* 293 */     page.setItems(sqlQueryForList(sql, params, Integer.valueOf(offSet), Integer.valueOf(pagesize), orderby));
/* 294 */     return page;
/*     */   }
/*     */ 
/*     */   public Object queryForObject(String select, Object[] values)
/*     */   {
/* 299 */     HibernateCallback selectCallback = new HibernateCallback(select, values) {
/*     */       public Object doInHibernate(Session session) {
/* 301 */         Query query = session.createQuery(this.val$select);
/* 302 */         if (this.val$values != null) {
/* 303 */           for (int i = 0; i < this.val$values.length; i++)
/* 304 */             query.setParameter(i, this.val$values[i]);
/*     */         }
/* 306 */         return query.uniqueResult();
/*     */       }
/*     */     };
/* 309 */     return getHibernateTemplate().execute(selectCallback);
/*     */   }
/*     */ 
/*     */   public Object querySQLForObject(String select, Object[] values)
/*     */   {
/* 314 */     HibernateCallback selectCallback = new HibernateCallback(select, values) {
/*     */       public Object doInHibernate(Session session) {
/* 316 */         Query query = session.createSQLQuery(this.val$select);
/* 317 */         if (this.val$values != null) {
/* 318 */           for (int i = 0; i < this.val$values.length; i++)
/* 319 */             query.setParameter(i, this.val$values[i]);
/*     */         }
/* 321 */         return query.uniqueResult();
/*     */       }
/*     */     };
/* 324 */     return getHibernateTemplate().execute(selectCallback);
/*     */   }
/*     */ 
/*     */   public Object findForObject(String select, Object[] values)
/*     */   {
/* 340 */     HibernateCallback selectCallback = new HibernateCallback(select, values) {
/*     */       public Object doInHibernate(Session session) {
/* 342 */         Query query = session.createQuery(this.val$select);
/* 343 */         if (this.val$values != null) {
/* 344 */           for (int i = 0; i < this.val$values.length; i++)
/* 345 */             query.setParameter(i, this.val$values[i]);
/*     */         }
/* 347 */         return query.uniqueResult();
/*     */       }
/*     */     };
/* 350 */     return getHibernateTemplate().execute(selectCallback);
/*     */   }
/*     */ 
/*     */   public List<Map<String, Object>> sqlQueryForList(String sql, Object[] params, LinkedHashMap<String, String> orderby)
/*     */   {
/* 356 */     return sqlQueryForList(sql, params, SystemContext.getOffset(), 
/* 357 */       SystemContext.getPagesize(), orderby);
/*     */   }
/*     */ 
/*     */   public List<Map<String, Object>> sqlQueryForList(String sql, Object[] params, Integer offSet, Integer pagesize, LinkedHashMap<String, String> orderby)
/*     */   {
/* 366 */     String querySql = null;
/* 367 */     sql = sql + buildOrderby(orderby);
/* 368 */     if ((offSet != null) && (pagesize != null))
/* 369 */       querySql = getSqlPagingQuery(sql, offSet.intValue(), pagesize.intValue());
/*     */     else {
/* 371 */       querySql = sql;
/*     */     }
/* 373 */     System.out.println(querySql);
/* 374 */     SQLQuery listQuery = getSession().createSQLQuery(querySql);
/* 375 */     listQuery.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
/* 376 */     int i = 0;
/* 377 */     if ((params != null) && (params.length > 0)) {
/* 378 */       for (; i < params.length; i++) {
/* 379 */         listQuery.setParameter(i, params[i]);
/*     */       }
/*     */     }
/* 382 */     return listQuery.list();
/*     */   }
/*     */ 
/*     */   protected String getSqlPagingQuery(String sql)
/*     */   {
/* 391 */     StringBuffer buffer = new StringBuffer("select * from (select t1.*,rownum rownum_ from (")
/* 392 */       .append(sql)
/* 393 */       .append(")t1 where rownum <= ?")
/* 394 */       .append(")t2 where t2.rownum_ >?");
/*     */ 
/* 396 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   protected String getSqlPagingQuery(String oldSqlStr, int firstResult, int pagesize)
/*     */   {
/* 408 */     StringBuffer sb = new StringBuffer(oldSqlStr);
/* 409 */     if (firstResult > 0) {
/* 410 */       firstResult = (firstResult - 1) * pagesize;
/*     */     }
/* 412 */     if ((firstResult >= 0) && (pagesize > 0))
/* 413 */       sb.append(" limit ").append(firstResult).append(",").append(pagesize);
/* 414 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   protected static String buildOrderby(LinkedHashMap<String, String> orderby)
/*     */   {
/* 441 */     StringBuffer orderbyql = new StringBuffer(" ");
/* 442 */     if ((orderby != null) && (orderby.size() > 0)) {
/* 443 */       orderbyql.append(" order by ");
/* 444 */       for (String key : orderby.keySet()) {
/* 445 */         orderbyql.append(key).append(" ").append((String)orderby.get(key))
/* 446 */           .append(",");
/*     */       }
/* 448 */       orderbyql.deleteCharAt(orderbyql.length() - 1);
/*     */     }
/*     */ 
/* 451 */     return orderbyql.toString();
/*     */   }
/*     */ 
/*     */   protected String getHibernateCountQuery(String hql)
/*     */   {
/* 458 */     hql = StringUtils.defaultIfEmpty(hql, "");
/* 459 */     hql = hql.toLowerCase();
/*     */ 
/* 461 */     int index = hql.indexOf("from");
/* 462 */     if (index != -1) {
/* 463 */       return "select count(*) " + hql.substring(index);
/*     */     }
/* 465 */     throw new RuntimeErrorException(null, "无效的sql语句");
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.hibernate.HibernateEntityDao
 * JD-Core Version:    0.6.0
 */