/*     */ package cn.newcapec.framework.base.dao.redis.util;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.jboss.netty.buffer.ChannelBuffers;
/*     */ import org.jboss.netty.channel.Channel;
/*     */ import org.jboss.netty.channel.ChannelFuture;
/*     */ import org.jboss.netty.channel.ChannelFutureListener;
/*     */ import org.jboss.netty.channel.ChannelHandlerContext;
/*     */ import org.jboss.netty.channel.ExceptionEvent;
/*     */ import org.jboss.netty.channel.MessageEvent;
/*     */ import org.jboss.netty.channel.SimpleChannelUpstreamHandler;
/*     */ import org.jboss.netty.handler.codec.http.DefaultHttpResponse;
/*     */ import org.jboss.netty.handler.codec.http.HttpRequest;
/*     */ import org.jboss.netty.handler.codec.http.HttpResponse;
/*     */ import org.jboss.netty.handler.codec.http.HttpResponseStatus;
/*     */ import org.jboss.netty.handler.codec.http.HttpVersion;
/*     */ import org.jboss.netty.handler.codec.http.QueryStringDecoder;
/*     */ import org.jboss.netty.util.CharsetUtil;
/*     */ 
/*     */ public class HttpRequestHandler extends SimpleChannelUpstreamHandler
/*     */ {
/*     */   private static final String RESPONSE_TEMPLATE = "{s:%d, m:'%s'}";
/*     */   private QueueService queueService;
/*     */   private static final String PATTERN = "([^?|!]*)(.*)";
/*     */ 
/*     */   public HttpRequestHandler(QueueService queueService)
/*     */   {
/*  41 */     this.queueService = queueService;
/*     */   }
/*     */ 
/*     */   private String decodeUri(String uri) {
/*     */     try {
/*  46 */       return URLDecoder.decode(uri, "UTF-8");
/*     */     } catch (UnsupportedEncodingException e) {
/*     */       try {
/*  49 */         return URLDecoder.decode(uri, "ISO-8859-1"); } catch (UnsupportedEncodingException e1) {
/*     */       }
/*     */     }
/*  51 */     return uri;
/*     */   }
/*     */ 
/*     */   private static String getParameterFromUri(String startPrefix, String uri)
/*     */   {
/*  69 */     Pattern pattern = Pattern.compile(startPrefix + "([^?|!]*)(.*)", 
/*  70 */       2);
/*  71 */     Matcher matcher = pattern.matcher(uri);
/*  72 */     if (!matcher.find()) {
/*  73 */       return null;
/*     */     }
/*  75 */     return matcher.group(1);
/*     */   }
/*     */ 
/*     */   public void messageReceived(ChannelHandlerContext ctx, MessageEvent e)
/*     */     throws Exception
/*     */   {
/*  81 */     HttpRequest request = (HttpRequest)e.getMessage();
/*  82 */     String uri = decodeUri(request.getUri());
/*  83 */     QueryStringDecoder queryStringDecoder = new QueryStringDecoder(
/*  84 */       request.getUri());
/*  85 */     Map params = queryStringDecoder.getParameters();
/*     */ 
/*  87 */     String queueName = null;
/*  88 */     String message = null;
/*  89 */     String optName = null;
/*  90 */     if (uri.startsWith("/get/")) {
/*  91 */       optName = "get";
/*  92 */       queueName = getParameterFromUri("/get/", uri);
/*  93 */     } else if (uri.startsWith("/put/")) {
/*  94 */       optName = "put";
/*  95 */       queueName = getParameterFromUri("/put/", uri);
/*     */     } else {
/*  97 */       if (params.isEmpty()) {
/*  98 */         writeResponse(
/*  99 */           e, 
/* 100 */           HttpResponseStatus.OK, 
/* 101 */           String.format("{s:%d, m:'%s'}", new Object[] { Integer.valueOf(0), "miss parameters!" }), 
/* 102 */           request);
/* 103 */         return;
/*     */       }
/*     */ 
/* 106 */       queueName = getParameterValue("name", params);
/* 107 */       optName = getParameterValue("opt", params);
/*     */     }
/*     */ 
/* 110 */     if ((optName == null) || (optName.trim().equals(""))) {
/* 111 */       optName = "get";
/*     */     }
/*     */ 
/* 114 */     if ((queueName == null) || (queueName.trim().equals(""))) {
/* 115 */       writeResponse(e, HttpResponseStatus.OK, 
/* 116 */         String.format("{s:%d, m:'%s'}", new Object[] { Integer.valueOf(0), "miss queue name!" }), 
/* 117 */         request);
/* 118 */       return;
/*     */     }
/*     */ 
/* 121 */     if (optName.toLowerCase().equals("get")) {
/* 122 */       String result = this.queueService.pop(queueName);
/* 123 */       if (result == null) {
/* 124 */         result = "";
/*     */       }
/*     */ 
/* 127 */       writeResponse(e, HttpResponseStatus.OK, String.format("{s:%d, m:'%s'}", new Object[] { Integer.valueOf(1), result }), 
/* 128 */         request);
/* 129 */       return;
/*     */     }
/*     */ 
/* 132 */     message = getParameterValue("msg", params);
/*     */ 
/* 134 */     if (message == null) {
/* 135 */       writeResponse(e, HttpResponseStatus.OK, 
/* 136 */         String.format("{s:%d, m:'%s'}", new Object[] { Integer.valueOf(0), "miss parameter msg!" }), 
/* 137 */         request);
/* 138 */       return;
/*     */     }
/*     */ 
/* 142 */     long result = this.queueService.push(queueName, message).longValue();
/*     */ 
/* 144 */     writeResponse(e, HttpResponseStatus.OK, String.format("{s:%d, m:'%s'}", new Object[] { Integer.valueOf(1), Long.valueOf(result) }), 
/* 145 */       request);
/*     */   }
/*     */ 
/*     */   private String getParameterValue(String parameterName, Map<String, List<String>> params)
/*     */   {
/* 150 */     List values = (List)params.get(parameterName);
/* 151 */     String parameterValue = null;
/* 152 */     if ((values != null) && (!values.isEmpty())) {
/* 153 */       parameterValue = (String)values.get(0);
/*     */     }
/*     */ 
/* 156 */     return parameterValue;
/*     */   }
/*     */ 
/*     */   private void writeResponse(MessageEvent e, HttpResponseStatus httpResponseStatus, String bufString, HttpRequest request)
/*     */   {
/* 162 */     HttpResponse response = new DefaultHttpResponse(HttpVersion.HTTP_1_1, 
/* 163 */       httpResponseStatus);
/* 164 */     response.setContent(ChannelBuffers.copiedBuffer(bufString, 
/* 165 */       CharsetUtil.UTF_8));
/* 166 */     response.setHeader("Content-Type", "application/json; charset=UTF-8");
/*     */ 
/* 168 */     ChannelFuture future = e.getChannel().write(response);
/*     */ 
/* 170 */     future.addListener(ChannelFutureListener.CLOSE);
/*     */   }
/*     */ 
/*     */   public void exceptionCaught(ChannelHandlerContext ctx, ExceptionEvent e)
/*     */     throws Exception
/*     */   {
/* 176 */     e.getCause().printStackTrace();
/* 177 */     e.getChannel().close();
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.util.HttpRequestHandler
 * JD-Core Version:    0.6.0
 */