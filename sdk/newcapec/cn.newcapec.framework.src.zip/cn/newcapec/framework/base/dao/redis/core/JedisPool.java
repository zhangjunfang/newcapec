/*     */ package cn.newcapec.framework.base.dao.redis.core;
/*     */ 
/*     */ import cn.newcapec.framework.base.dao.redis.util.Pool;
/*     */ import java.net.URI;
/*     */ import org.apache.commons.pool.BasePoolableObjectFactory;
/*     */ import org.apache.commons.pool.impl.GenericObjectPool;
/*     */ import org.apache.commons.pool.impl.GenericObjectPool.Config;
/*     */ 
/*     */ public class JedisPool extends Pool<Jedis>
/*     */ {
/*     */   public JedisPool(GenericObjectPool.Config poolConfig, String host)
/*     */   {
/*  14 */     this(poolConfig, host, 6379, 2000, null, 0);
/*     */   }
/*     */ 
/*     */   public JedisPool(String host, int port) {
/*  18 */     this(new GenericObjectPool.Config(), host, port, 2000, null, 0);
/*     */   }
/*     */ 
/*     */   public JedisPool(String host) {
/*  22 */     URI uri = URI.create(host);
/*  23 */     if ((uri.getScheme() != null) && (uri.getScheme().equals("redis"))) {
/*  24 */       String h = uri.getHost();
/*  25 */       int port = uri.getPort();
/*  26 */       String password = uri.getUserInfo().split(":", 2)[1];
/*  27 */       int database = Integer.parseInt(uri.getPath().split("/", 2)[1]);
/*  28 */       this.internalPool = 
/*  29 */         new GenericObjectPool(new JedisFactory(h, port, 
/*  29 */         2000, password, database), new GenericObjectPool.Config());
/*     */     } else {
/*  31 */       this.internalPool = 
/*  33 */         new GenericObjectPool(new JedisFactory(host, 
/*  32 */         6379, 2000, null, 
/*  33 */         0), new GenericObjectPool.Config());
/*     */     }
/*     */   }
/*     */ 
/*     */   public JedisPool(URI uri) {
/*  38 */     String h = uri.getHost();
/*  39 */     int port = uri.getPort();
/*  40 */     String password = uri.getUserInfo().split(":", 2)[1];
/*  41 */     int database = Integer.parseInt(uri.getPath().split("/", 2)[1]);
/*  42 */     this.internalPool = 
/*  43 */       new GenericObjectPool(new JedisFactory(h, port, 
/*  43 */       2000, password, database), new GenericObjectPool.Config());
/*     */   }
/*     */ 
/*     */   public JedisPool(GenericObjectPool.Config poolConfig, String host, int port, int timeout, String password)
/*     */   {
/*  48 */     this(poolConfig, host, port, timeout, password, 0);
/*     */   }
/*     */ 
/*     */   public JedisPool(GenericObjectPool.Config poolConfig, String host, int port) {
/*  52 */     this(poolConfig, host, port, 2000, null, 0);
/*     */   }
/*     */ 
/*     */   public JedisPool(GenericObjectPool.Config poolConfig, String host, int port, int timeout) {
/*  56 */     this(poolConfig, host, port, timeout, null, 0);
/*     */   }
/*     */ 
/*     */   public JedisPool(GenericObjectPool.Config poolConfig, String host, int port, int timeout, String password, int database)
/*     */   {
/*  61 */     super(poolConfig, new JedisFactory(host, port, timeout, password, database));
/*     */   }
/*     */ 
/*     */   public void returnBrokenResource(BinaryJedis resource)
/*     */   {
/*  66 */     returnBrokenResourceObject(resource);
/*     */   }
/*     */ 
/*     */   public void returnResource(BinaryJedis resource) {
/*  70 */     returnResourceObject(resource);
/*     */   }
/*     */ 
/*     */   private static class JedisFactory extends BasePoolableObjectFactory {
/*     */     private final String host;
/*     */     private final int port;
/*     */     private final int timeout;
/*     */     private final String password;
/*     */     private final int database;
/*     */ 
/*     */     public JedisFactory(String host, int port, int timeout, String password, int database) {
/*  86 */       this.host = host;
/*  87 */       this.port = port;
/*  88 */       this.timeout = timeout;
/*  89 */       this.password = password;
/*  90 */       this.database = database;
/*     */     }
/*     */ 
/*     */     public Object makeObject() throws Exception {
/*  94 */       Jedis jedis = new Jedis(this.host, this.port, this.timeout);
/*     */ 
/*  96 */       jedis.connect();
/*  97 */       if (this.password != null) {
/*  98 */         jedis.auth(this.password);
/*     */       }
/* 100 */       if (this.database != 0) {
/* 101 */         jedis.select(this.database);
/*     */       }
/*     */ 
/* 104 */       return jedis;
/*     */     }
/*     */ 
/*     */     public void destroyObject(Object obj) throws Exception {
/* 108 */       if ((obj instanceof Jedis)) {
/* 109 */         Jedis jedis = (Jedis)obj;
/* 110 */         if (jedis.isConnected())
/*     */           try {
/*     */             try {
/* 113 */               jedis.quit();
/*     */             } catch (Exception localException) {
/*     */             }
/* 116 */             jedis.disconnect();
/*     */           }
/*     */           catch (Exception localException1)
/*     */           {
/*     */           }
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean validateObject(Object obj) {
/* 125 */       if ((obj instanceof Jedis)) {
/* 126 */         Jedis jedis = (Jedis)obj;
/*     */         try {
/* 128 */           return (jedis.isConnected()) && (jedis.ping().equals("PONG"));
/*     */         } catch (Exception e) {
/* 130 */           return false;
/*     */         }
/*     */       }
/* 133 */       return false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.JedisPool
 * JD-Core Version:    0.6.0
 */