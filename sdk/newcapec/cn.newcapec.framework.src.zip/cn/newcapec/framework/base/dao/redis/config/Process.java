/*    */ package cn.newcapec.framework.base.dao.redis.config;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.annotation.Retention;
/*    */ import java.lang.annotation.RetentionPolicy;
/*    */ import java.lang.annotation.Target;
/*    */ 
/*    */ @Retention(RetentionPolicy.RUNTIME)
/*    */ @Target({java.lang.annotation.ElementType.METHOD})
/*    */ public @interface Process
/*    */ {
/*    */   public abstract Policy value();
/*    */ 
/*    */   public static enum Policy
/*    */   {
/* 16 */     WRITE, READ;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.config.Process
 * JD-Core Version:    0.6.0
 */