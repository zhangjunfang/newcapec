/*    */ package cn.newcapec.framework.base.dao.db;
/*    */ 
/*    */ import cn.newcapec.framework.utils.variant.Variant;
/*    */ import cn.newcapec.framework.utils.variant.VariantSet;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ParameterSet extends VariantSet
/*    */ {
/* 15 */   private Map b = new HashMap();
/*    */ 
/*    */   public Variant getVariant(String key)
/*    */   {
/* 21 */     String str = key.toLowerCase();
/* 22 */     return super.getVariant(str);
/*    */   }
/*    */ 
/*    */   public void setVariant(String name, Variant variant)
/*    */   {
/* 29 */     String str = name.toLowerCase();
/* 30 */     this.b.put(str, name);
/* 31 */     super.setVariant(str, variant);
/*    */   }
/*    */ 
/*    */   public void remove(String key)
/*    */   {
/* 38 */     String str = key.toLowerCase();
/* 39 */     this.b.remove(str);
/* 40 */     super.remove(str);
/*    */   }
/*    */ 
/*    */   public String indexToName(int index)
/*    */   {
/* 48 */     String name = super.indexToName(index);
/*    */     String key;
/* 49 */     if ((key = (String)this.b.get(name)) == null)
/* 50 */       key = name;
/* 51 */     return key;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.db.ParameterSet
 * JD-Core Version:    0.6.0
 */