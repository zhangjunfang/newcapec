/*    */ package cn.newcapec.framework.base.dao.redis.config;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class RedisPubMain
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/*  9 */     RedisPubSubManager manager = new RedisPubSubManager();
/* 10 */     Map pubMap = new HashMap();
/* 11 */     pubMap.put("testpub1", "pub1");
/* 12 */     pubMap.put("testpub2", "pub2");
/* 13 */     pubMap.put("testpub3", "pub3");
/* 14 */     System.out.println("发布消息-------------------");
/* 15 */     manager.publish(pubMap);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.config.RedisPubMain
 * JD-Core Version:    0.6.0
 */