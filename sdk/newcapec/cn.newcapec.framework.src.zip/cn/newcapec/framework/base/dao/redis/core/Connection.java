/*     */ package cn.newcapec.framework.base.dao.redis.core;
/*     */ 
/*     */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisConnectionException;
/*     */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisDataException;
/*     */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisException;
/*     */ import cn.newcapec.framework.base.dao.redis.util.RedisInputStream;
/*     */ import cn.newcapec.framework.base.dao.redis.util.RedisOutputStream;
/*     */ import cn.newcapec.framework.base.dao.redis.util.SafeEncoder;
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Connection
/*     */ {
/*     */   private String host;
/*  20 */   private int port = 6379;
/*     */   private Socket socket;
/*     */   private RedisOutputStream outputStream;
/*     */   private RedisInputStream inputStream;
/*  24 */   private int pipelinedCommands = 0;
/*  25 */   private int timeout = 2000;
/*     */ 
/*     */   public Socket getSocket() {
/*  28 */     return this.socket;
/*     */   }
/*     */ 
/*     */   public int getTimeout() {
/*  32 */     return this.timeout;
/*     */   }
/*     */ 
/*     */   public void setTimeout(int timeout) {
/*  36 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */   public void setTimeoutInfinite() {
/*     */     try {
/*  41 */       if (!isConnected()) {
/*  42 */         connect();
/*     */       }
/*  44 */       this.socket.setKeepAlive(true);
/*  45 */       this.socket.setSoTimeout(0);
/*     */     } catch (SocketException ex) {
/*  47 */       throw new JedisException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void rollbackTimeout() {
/*     */     try {
/*  53 */       this.socket.setSoTimeout(this.timeout);
/*  54 */       this.socket.setKeepAlive(false);
/*     */     } catch (SocketException ex) {
/*  56 */       throw new JedisException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Connection(String host)
/*     */   {
/*  62 */     this.host = host;
/*     */   }
/*     */ 
/*     */   protected void flush() {
/*     */     try {
/*  67 */       this.outputStream.flush();
/*     */     } catch (IOException e) {
/*  69 */       throw new JedisConnectionException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Connection sendCommand(Protocol.Command cmd, String[] args) {
/*  74 */     byte[][] bargs = new byte[args.length][];
/*  75 */     for (int i = 0; i < args.length; i++) {
/*  76 */       bargs[i] = SafeEncoder.encode(args[i]);
/*     */     }
/*  78 */     return sendCommand(cmd, bargs);
/*     */   }
/*     */ 
/*     */   protected Connection sendCommand(Protocol.Command cmd, byte[][] args) {
/*  82 */     connect();
/*  83 */     Protocol.sendCommand(this.outputStream, cmd, args);
/*  84 */     this.pipelinedCommands += 1;
/*  85 */     return this;
/*     */   }
/*     */ 
/*     */   protected Connection sendCommand(Protocol.Command cmd) {
/*  89 */     connect();
/*  90 */     Protocol.sendCommand(this.outputStream, cmd, new byte[0][]);
/*  91 */     this.pipelinedCommands += 1;
/*  92 */     return this;
/*     */   }
/*     */ 
/*     */   public Connection(String host, int port)
/*     */   {
/*  97 */     this.host = host;
/*  98 */     this.port = port;
/*     */   }
/*     */ 
/*     */   public String getHost() {
/* 102 */     return this.host;
/*     */   }
/*     */ 
/*     */   public void setHost(String host) {
/* 106 */     this.host = host;
/*     */   }
/*     */ 
/*     */   public int getPort() {
/* 110 */     return this.port;
/*     */   }
/*     */ 
/*     */   public void setPort(int port) {
/* 114 */     this.port = port;
/*     */   }
/*     */ 
/*     */   public Connection()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void connect() {
/* 122 */     if (!isConnected())
/*     */       try {
/* 124 */         this.socket = new Socket();
/*     */ 
/* 126 */         this.socket.setReuseAddress(true);
/* 127 */         this.socket.setKeepAlive(true);
/* 128 */         this.socket.setTcpNoDelay(true);
/* 129 */         this.socket.setSoLinger(true, 0);
/*     */ 
/* 132 */         this.socket.connect(new InetSocketAddress(this.host, this.port), this.timeout);
/* 133 */         this.socket.setSoTimeout(this.timeout);
/* 134 */         this.outputStream = new RedisOutputStream(this.socket.getOutputStream());
/* 135 */         this.inputStream = new RedisInputStream(this.socket.getInputStream());
/*     */       } catch (IOException ex) {
/* 137 */         throw new JedisConnectionException(ex);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void disconnect()
/*     */   {
/* 143 */     if (isConnected())
/*     */       try {
/* 145 */         this.inputStream.close();
/* 146 */         this.outputStream.close();
/* 147 */         if (!this.socket.isClosed())
/* 148 */           this.socket.close();
/*     */       }
/*     */       catch (IOException ex) {
/* 151 */         throw new JedisConnectionException(ex);
/*     */       }
/*     */   }
/*     */ 
/*     */   public boolean isConnected()
/*     */   {
/* 159 */     return (this.socket != null) && (this.socket.isBound()) && (!this.socket.isClosed()) && 
/* 158 */       (this.socket.isConnected()) && (!this.socket.isInputShutdown()) && 
/* 159 */       (!this.socket.isOutputShutdown());
/*     */   }
/*     */ 
/*     */   protected String getStatusCodeReply() {
/* 163 */     flush();
/* 164 */     this.pipelinedCommands -= 1;
/* 165 */     byte[] resp = (byte[])Protocol.read(this.inputStream);
/* 166 */     if (resp == null) {
/* 167 */       return null;
/*     */     }
/* 169 */     return SafeEncoder.encode(resp);
/*     */   }
/*     */ 
/*     */   public String getBulkReply()
/*     */   {
/* 174 */     byte[] result = getBinaryBulkReply();
/* 175 */     if (result != null) {
/* 176 */       return SafeEncoder.encode(result);
/*     */     }
/* 178 */     return null;
/*     */   }
/*     */ 
/*     */   public byte[] getBinaryBulkReply()
/*     */   {
/* 183 */     flush();
/* 184 */     this.pipelinedCommands -= 1;
/* 185 */     return (byte[])Protocol.read(this.inputStream);
/*     */   }
/*     */ 
/*     */   public Long getIntegerReply() {
/* 189 */     flush();
/* 190 */     this.pipelinedCommands -= 1;
/* 191 */     return (Long)Protocol.read(this.inputStream);
/*     */   }
/*     */ 
/*     */   public List<String> getMultiBulkReply() {
/* 195 */     return (List)BuilderFactory.STRING_LIST.build(getBinaryMultiBulkReply());
/*     */   }
/*     */ 
/*     */   public List<byte[]> getBinaryMultiBulkReply()
/*     */   {
/* 200 */     flush();
/* 201 */     this.pipelinedCommands -= 1;
/* 202 */     return (List)Protocol.read(this.inputStream);
/*     */   }
/*     */ 
/*     */   public List<Object> getObjectMultiBulkReply()
/*     */   {
/* 207 */     flush();
/* 208 */     this.pipelinedCommands -= 1;
/* 209 */     return (List)Protocol.read(this.inputStream);
/*     */   }
/*     */ 
/*     */   public List<Long> getIntegerMultiBulkReply()
/*     */   {
/* 214 */     flush();
/* 215 */     this.pipelinedCommands -= 1;
/* 216 */     return (List)Protocol.read(this.inputStream);
/*     */   }
/*     */ 
/*     */   public List<Object> getAll() {
/* 220 */     return getAll(0);
/*     */   }
/*     */ 
/*     */   public List<Object> getAll(int except) {
/* 224 */     List all = new ArrayList();
/* 225 */     flush();
/* 226 */     while (this.pipelinedCommands > except) {
/*     */       try {
/* 228 */         all.add(Protocol.read(this.inputStream));
/*     */       } catch (JedisDataException e) {
/* 230 */         all.add(e);
/*     */       }
/* 232 */       this.pipelinedCommands -= 1;
/*     */     }
/* 234 */     return all;
/*     */   }
/*     */ 
/*     */   public Object getOne() {
/* 238 */     flush();
/* 239 */     this.pipelinedCommands -= 1;
/* 240 */     return Protocol.read(this.inputStream);
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.Connection
 * JD-Core Version:    0.6.0
 */