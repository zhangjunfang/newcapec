/*     */ package cn.newcapec.framework.base.dao.redis.core;
/*     */ 
/*     */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisConnectionException;
/*     */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisException;
/*     */ import cn.newcapec.framework.base.dao.redis.util.SafeEncoder;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ public abstract class JedisPubSub
/*     */ {
/*  18 */   private int subscribedChannels = 0;
/*     */   private Client client;
/*     */ 
/*     */   public abstract void onMessage(String paramString1, String paramString2);
/*     */ 
/*     */   public abstract void onPMessage(String paramString1, String paramString2, String paramString3);
/*     */ 
/*     */   public abstract void onSubscribe(String paramString, int paramInt);
/*     */ 
/*     */   public abstract void onUnsubscribe(String paramString, int paramInt);
/*     */ 
/*     */   public abstract void onPUnsubscribe(String paramString, int paramInt);
/*     */ 
/*     */   public abstract void onPSubscribe(String paramString, int paramInt);
/*     */ 
/*     */   public void unsubscribe()
/*     */   {
/*  35 */     if (this.client == null) {
/*  36 */       throw new JedisConnectionException(
/*  37 */         "JedisPubSub was not subscribed to a Jedis instance.");
/*     */     }
/*  39 */     this.client.unsubscribe();
/*  40 */     this.client.flush();
/*     */   }
/*     */ 
/*     */   public void unsubscribe(String[] channels) {
/*  44 */     this.client.unsubscribe(channels);
/*  45 */     this.client.flush();
/*     */   }
/*     */ 
/*     */   public void subscribe(String[] channels) {
/*  49 */     this.client.subscribe(channels);
/*  50 */     this.client.flush();
/*     */   }
/*     */ 
/*     */   public void psubscribe(String[] patterns) {
/*  54 */     this.client.psubscribe(patterns);
/*  55 */     this.client.flush();
/*     */   }
/*     */ 
/*     */   public void punsubscribe() {
/*  59 */     this.client.punsubscribe();
/*  60 */     this.client.flush();
/*     */   }
/*     */ 
/*     */   public void punsubscribe(String[] patterns) {
/*  64 */     this.client.punsubscribe(patterns);
/*  65 */     this.client.flush();
/*     */   }
/*     */ 
/*     */   public boolean isSubscribed() {
/*  69 */     return this.subscribedChannels > 0;
/*     */   }
/*     */ 
/*     */   public void proceedWithPatterns(Client client, String[] patterns) {
/*  73 */     this.client = client;
/*  74 */     client.psubscribe(patterns);
/*  75 */     client.flush();
/*  76 */     process(client);
/*     */   }
/*     */ 
/*     */   public void proceed(Client client, String[] channels) {
/*  80 */     this.client = client;
/*  81 */     client.subscribe(channels);
/*  82 */     client.flush();
/*  83 */     process(client);
/*     */   }
/*     */ 
/*     */   private void process(Client client) {
/*     */     do {
/*  88 */       List reply = client.getObjectMultiBulkReply();
/*  89 */       Object firstObj = reply.get(0);
/*  90 */       if (!(firstObj instanceof byte[])) {
/*  91 */         throw new JedisException("Unknown message type: " + firstObj);
/*     */       }
/*  93 */       byte[] resp = (byte[])firstObj;
/*  94 */       if (Arrays.equals(Protocol.Keyword.SUBSCRIBE.raw, resp)) {
/*  95 */         this.subscribedChannels = ((Long)reply.get(2)).intValue();
/*  96 */         byte[] bchannel = (byte[])reply.get(1);
/*  97 */         String strchannel = bchannel == null ? null : 
/*  98 */           SafeEncoder.encode(bchannel);
/*  99 */         onSubscribe(strchannel, this.subscribedChannels);
/* 100 */       } else if (Arrays.equals(Protocol.Keyword.UNSUBSCRIBE.raw, resp)) {
/* 101 */         this.subscribedChannels = ((Long)reply.get(2)).intValue();
/* 102 */         byte[] bchannel = (byte[])reply.get(1);
/* 103 */         String strchannel = bchannel == null ? null : 
/* 104 */           SafeEncoder.encode(bchannel);
/* 105 */         onUnsubscribe(strchannel, this.subscribedChannels);
/* 106 */       } else if (Arrays.equals(Protocol.Keyword.MESSAGE.raw, resp)) {
/* 107 */         byte[] bchannel = (byte[])reply.get(1);
/* 108 */         byte[] bmesg = (byte[])reply.get(2);
/* 109 */         String strchannel = bchannel == null ? null : 
/* 110 */           SafeEncoder.encode(bchannel);
/* 111 */         String strmesg = bmesg == null ? null : 
/* 112 */           SafeEncoder.encode(bmesg);
/* 113 */         onMessage(strchannel, strmesg);
/* 114 */       } else if (Arrays.equals(Protocol.Keyword.PMESSAGE.raw, resp)) {
/* 115 */         byte[] bpattern = (byte[])reply.get(1);
/* 116 */         byte[] bchannel = (byte[])reply.get(2);
/* 117 */         byte[] bmesg = (byte[])reply.get(3);
/* 118 */         String strpattern = bpattern == null ? null : 
/* 119 */           SafeEncoder.encode(bpattern);
/* 120 */         String strchannel = bchannel == null ? null : 
/* 121 */           SafeEncoder.encode(bchannel);
/* 122 */         String strmesg = bmesg == null ? null : 
/* 123 */           SafeEncoder.encode(bmesg);
/* 124 */         onPMessage(strpattern, strchannel, strmesg);
/* 125 */       } else if (Arrays.equals(Protocol.Keyword.PSUBSCRIBE.raw, resp)) {
/* 126 */         this.subscribedChannels = ((Long)reply.get(2)).intValue();
/* 127 */         byte[] bpattern = (byte[])reply.get(1);
/* 128 */         String strpattern = bpattern == null ? null : 
/* 129 */           SafeEncoder.encode(bpattern);
/* 130 */         onPSubscribe(strpattern, this.subscribedChannels);
/* 131 */       } else if (Arrays.equals(Protocol.Keyword.PUNSUBSCRIBE.raw, resp)) {
/* 132 */         this.subscribedChannels = ((Long)reply.get(2)).intValue();
/* 133 */         byte[] bpattern = (byte[])reply.get(1);
/* 134 */         String strpattern = bpattern == null ? null : 
/* 135 */           SafeEncoder.encode(bpattern);
/* 136 */         onPUnsubscribe(strpattern, this.subscribedChannels);
/*     */       } else {
/* 138 */         throw new JedisException("Unknown message type: " + firstObj);
/*     */       }
/*     */     }
/*  87 */     while (
/* 140 */       isSubscribed());
/*     */   }
/*     */ 
/*     */   public int getSubscribedChannels() {
/* 144 */     return this.subscribedChannels;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.JedisPubSub
 * JD-Core Version:    0.6.0
 */