/*     */ package cn.newcapec.framework.base.dao.redis.core;
/*     */ 
/*     */ import cn.newcapec.framework.base.dao.redis.util.SafeEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class BuilderFactory
/*     */ {
/*   8 */   public static final Builder<Double> DOUBLE = new Builder() {
/*     */     public Double build(Object data) {
/*  10 */       String asString = (String)BuilderFactory.STRING.build(data);
/*  11 */       return asString == null ? null : Double.valueOf(asString);
/*     */     }
/*     */ 
/*     */     public String toString() {
/*  15 */       return "double";
/*     */     }
/*   8 */   };
/*     */ 
/*  18 */   public static final Builder<Boolean> BOOLEAN = new Builder() {
/*     */     public Boolean build(Object data) {
/*  20 */       if (((Long)data).longValue() == 1L) return Boolean.valueOf(true); return Boolean.valueOf(false);
/*     */     }
/*     */ 
/*     */     public String toString() {
/*  24 */       return "boolean";
/*     */     }
/*  18 */   };
/*     */ 
/*  27 */   public static final Builder<byte[]> BYTE_ARRAY = new Builder() {
/*     */     public byte[] build(Object data) {
/*  29 */       return (byte[])data;
/*     */     }
/*     */ 
/*     */     public String toString() {
/*  33 */       return "byte[]";
/*     */     }
/*  27 */   };
/*     */ 
/*  37 */   public static final Builder<Long> LONG = new Builder() {
/*     */     public Long build(Object data) {
/*  39 */       return (Long)data;
/*     */     }
/*     */ 
/*     */     public String toString() {
/*  43 */       return "long";
/*     */     }
/*  37 */   };
/*     */ 
/*  47 */   public static final Builder<String> STRING = new Builder() {
/*     */     public String build(Object data) {
/*  49 */       return data == null ? null : SafeEncoder.encode((byte[])data);
/*     */     }
/*     */ 
/*     */     public String toString() {
/*  53 */       return "string";
/*     */     }
/*  47 */   };
/*     */ 
/*  57 */   public static final Builder<List<String>> STRING_LIST = new Builder()
/*     */   {
/*     */     public List<String> build(Object data) {
/*  60 */       if (data == null) {
/*  61 */         return null;
/*     */       }
/*  63 */       List l = (List)data;
/*  64 */       ArrayList result = new ArrayList(l.size());
/*  65 */       for (byte[] barray : l) {
/*  66 */         if (barray == null)
/*  67 */           result.add(null);
/*     */         else {
/*  69 */           result.add(SafeEncoder.encode(barray));
/*     */         }
/*     */       }
/*  72 */       return result;
/*     */     }
/*     */ 
/*     */     public String toString() {
/*  76 */       return "List<String>";
/*     */     }
/*  57 */   };
/*     */ 
/*  80 */   public static final Builder<Map<String, String>> STRING_MAP = new Builder()
/*     */   {
/*     */     public Map<String, String> build(Object data) {
/*  83 */       List flatHash = (List)data;
/*  84 */       Map hash = new HashMap();
/*  85 */       Iterator iterator = flatHash.iterator();
/*  86 */       while (iterator.hasNext()) {
/*  87 */         hash.put(SafeEncoder.encode((byte[])iterator.next()), 
/*  88 */           SafeEncoder.encode((byte[])iterator.next()));
/*     */       }
/*     */ 
/*  91 */       return hash;
/*     */     }
/*     */ 
/*     */     public String toString() {
/*  95 */       return "Map<String, String>";
/*     */     }
/*  80 */   };
/*     */ 
/*  99 */   public static final Builder<Set<String>> STRING_SET = new Builder()
/*     */   {
/*     */     public Set<String> build(Object data) {
/* 102 */       if (data == null) {
/* 103 */         return null;
/*     */       }
/* 105 */       List l = (List)data;
/* 106 */       Set result = new HashSet(l.size());
/* 107 */       for (byte[] barray : l) {
/* 108 */         if (barray == null)
/* 109 */           result.add(null);
/*     */         else {
/* 111 */           result.add(SafeEncoder.encode(barray));
/*     */         }
/*     */       }
/* 114 */       return result;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 118 */       return "Set<String>";
/*     */     }
/*  99 */   };
/*     */ 
/* 123 */   public static final Builder<List<byte[]>> BYTE_ARRAY_LIST = new Builder()
/*     */   {
/*     */     public List<byte[]> build(Object data) {
/* 126 */       if (data == null) {
/* 127 */         return null;
/*     */       }
/* 129 */       List l = (List)data;
/*     */ 
/* 131 */       return l;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 135 */       return "List<byte[]>";
/*     */     }
/* 123 */   };
/*     */ 
/* 139 */   public static final Builder<Set<byte[]>> BYTE_ARRAY_ZSET = new Builder()
/*     */   {
/*     */     public Set<byte[]> build(Object data) {
/* 142 */       if (data == null) {
/* 143 */         return null;
/*     */       }
/* 145 */       List l = (List)data;
/* 146 */       Set result = new LinkedHashSet(l);
/* 147 */       for (byte[] barray : l) {
/* 148 */         if (barray == null)
/* 149 */           result.add(null);
/*     */         else {
/* 151 */           result.add(barray);
/*     */         }
/*     */       }
/* 154 */       return result;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 158 */       return "ZSet<byte[]>";
/*     */     }
/* 139 */   };
/*     */ 
/* 161 */   public static final Builder<Map<byte[], byte[]>> BYTE_ARRAY_MAP = new Builder()
/*     */   {
/*     */     public Map<byte[], byte[]> build(Object data) {
/* 164 */       List flatHash = (List)data;
/* 165 */       Map hash = new HashMap();
/* 166 */       Iterator iterator = flatHash.iterator();
/* 167 */       while (iterator.hasNext()) {
/* 168 */         hash.put((byte[])iterator.next(), (byte[])iterator.next());
/*     */       }
/*     */ 
/* 171 */       return hash;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 175 */       return "Map<byte[], byte[]>";
/*     */     }
/* 161 */   };
/*     */ 
/* 180 */   public static final Builder<Set<String>> STRING_ZSET = new Builder()
/*     */   {
/*     */     public Set<String> build(Object data) {
/* 183 */       if (data == null) {
/* 184 */         return null;
/*     */       }
/* 186 */       List l = (List)data;
/* 187 */       Set result = new LinkedHashSet(l.size());
/* 188 */       for (byte[] barray : l) {
/* 189 */         if (barray == null)
/* 190 */           result.add(null);
/*     */         else {
/* 192 */           result.add(SafeEncoder.encode(barray));
/*     */         }
/*     */       }
/* 195 */       return result;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 199 */       return "ZSet<String>";
/*     */     }
/* 180 */   };
/*     */ 
/* 204 */   public static final Builder<Set<Tuple>> TUPLE_ZSET = new Builder()
/*     */   {
/*     */     public Set<Tuple> build(Object data) {
/* 207 */       if (data == null) {
/* 208 */         return null;
/*     */       }
/* 210 */       List l = (List)data;
/* 211 */       Set result = new LinkedHashSet(l.size());
/* 212 */       Iterator iterator = l.iterator();
/* 213 */       while (iterator.hasNext()) {
/* 214 */         result.add(
/* 215 */           new Tuple(SafeEncoder.encode((byte[])iterator.next()), 
/* 215 */           Double.valueOf(SafeEncoder.encode((byte[])iterator.next()))));
/*     */       }
/* 217 */       return result;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 221 */       return "ZSet<Tuple>";
/*     */     }
/* 204 */   };
/*     */ 
/* 226 */   public static final Builder<Set<Tuple>> TUPLE_ZSET_BINARY = new Builder()
/*     */   {
/*     */     public Set<Tuple> build(Object data) {
/* 229 */       if (data == null) {
/* 230 */         return null;
/*     */       }
/* 232 */       List l = (List)data;
/* 233 */       Set result = new LinkedHashSet(l.size());
/* 234 */       Iterator iterator = l.iterator();
/* 235 */       while (iterator.hasNext()) {
/* 236 */         result.add(
/* 237 */           new Tuple((byte[])iterator.next(), 
/* 237 */           Double.valueOf(SafeEncoder.encode((byte[])iterator.next()))));
/*     */       }
/*     */ 
/* 240 */       return result;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 245 */       return "ZSet<Tuple>";
/*     */     }
/* 226 */   };
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.BuilderFactory
 * JD-Core Version:    0.6.0
 */