/*      */ package cn.newcapec.framework.base.dao.redis.config;
/*      */ 
/*      */ import cn.newcapec.framework.base.dao.redis.core.BinaryClient.LIST_POSITION;
/*      */ import cn.newcapec.framework.base.dao.redis.core.Client;
/*      */ import cn.newcapec.framework.base.dao.redis.core.Jedis;
/*      */ import cn.newcapec.framework.base.dao.redis.core.JedisShardInfo;
/*      */ import cn.newcapec.framework.base.dao.redis.core.Pipeline;
/*      */ import cn.newcapec.framework.base.dao.redis.core.ShardedJedis;
/*      */ import cn.newcapec.framework.base.dao.redis.core.ShardedJedisPool;
/*      */ import cn.newcapec.framework.base.dao.redis.core.SortingParams;
/*      */ import cn.newcapec.framework.base.dao.redis.core.Tuple;
/*      */ import cn.newcapec.framework.base.dao.redis.exception.RedisAccessException;
/*      */ import cn.newcapec.framework.base.dao.redis.util.SafeEncoder;
/*      */ import cn.newcapec.framework.utils.CollatorComparator;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.List<Ljava.lang.String;>;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.SortedMap;
/*      */ import java.util.TreeMap;
/*      */ import org.apache.log4j.Logger;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ public class RedisManager
/*      */ {
/*   38 */   private static Logger log = Logger.getLogger(RedisManager.class);
/*   39 */   private ShardedJedisPool writePool = null;
/*   40 */   private ShardedJedisPool readPool = null;
/*   41 */   private int redundancyFactor = 1;
/*   42 */   private ConnectionFactoryBuilder connectionFactoryBuilder = null;
/*   43 */   private List<String> masterConfList = null;
/*   44 */   private List<String> slaveConfList = null;
/*   45 */   private int timeout = 10000000;
/*      */ 
/*      */   public RedisManager(ConnectionFactoryBuilder connectionFactoryBuilder, List<String> masterConfList)
/*      */   {
/*   55 */     this(connectionFactoryBuilder, masterConfList, null);
/*      */   }
/*      */ 
/*      */   public RedisManager(ConnectionFactoryBuilder connectionFactoryBuilder, List<String> masterConfList, List<String> slaveConfList)
/*      */   {
/*   66 */     this.connectionFactoryBuilder = connectionFactoryBuilder;
/*   67 */     this.masterConfList = masterConfList;
/*   68 */     this.slaveConfList = slaveConfList;
/*   69 */     init();
/*      */   }
/*      */ 
/*      */   public RedisManager(ConnectionFactoryBuilder connectionFactoryBuilder)
/*      */   {
/*   78 */     this.connectionFactoryBuilder = connectionFactoryBuilder;
/*   79 */     init();
/*      */   }
/*      */ 
/*      */   private void init() {
/*   83 */     log.info("init start~");
/*   84 */     List wShards = null;
/*   85 */     List rShards = null;
/*      */ 
/*   87 */     if (StringUtils.hasLength(this.connectionFactoryBuilder.getMasterConfString()))
/*      */     {
/*   89 */       this.masterConfList = Arrays.asList(this.connectionFactoryBuilder.getMasterConfString().split("(?:\\s|,)+"));
/*      */     }
/*   91 */     if (CollectionUtils.isEmpty(this.masterConfList)) {
/*   92 */       throw new ExceptionInInitializerError("masterConfString is empty！");
/*      */     }
/*      */ 
/*   95 */     if ((StringUtils.hasLength(this.connectionFactoryBuilder.getSlaveConfString())) && 
/*   96 */       (!this.connectionFactoryBuilder.getSlaveConfString().equals(this.connectionFactoryBuilder.getMasterConfString())))
/*      */     {
/*   98 */       this.slaveConfList = Arrays.asList(this.connectionFactoryBuilder.getSlaveConfString().split("(?:\\s|,)+"));
/*      */     }
/*  100 */     wShards = new ArrayList();
/*  101 */     for (String wAddr : this.masterConfList) {
/*  102 */       if (wAddr != null) {
/*  103 */         String[] wAddrArray = wAddr.split(":");
/*  104 */         if (wAddrArray.length == 1) {
/*  105 */           throw new ExceptionInInitializerError(wAddr + " is not include host:port or host:port:passwd after split \":\"");
/*      */         }
/*  107 */         String host = wAddrArray[0];
/*  108 */         int port = Integer.valueOf(wAddrArray[1]).intValue();
/*  109 */         JedisShardInfo jedisShardInfo = new JedisShardInfo(host, port, this.connectionFactoryBuilder.getTimeout());
/*  110 */         log.info("masterConfList:" + jedisShardInfo.toString());
/*      */ 
/*  112 */         if ((wAddrArray.length == 3) && (StringUtils.hasLength(wAddrArray[2]))) {
/*  113 */           jedisShardInfo.setPassword(wAddrArray[2]);
/*      */         }
/*  115 */         wShards.add(jedisShardInfo);
/*      */       }
/*      */     }
/*      */ 
/*  119 */     if (!CollectionUtils.isEmpty(this.slaveConfList)) {
/*  120 */       rShards = new ArrayList();
/*  121 */       for (String rAddr : this.slaveConfList) {
/*  122 */         if (rAddr != null) {
/*  123 */           String[] rAddrArray = rAddr.split(":");
/*  124 */           if (rAddrArray.length == 1) {
/*  125 */             throw new ExceptionInInitializerError(rAddr + " is not include host:port or host:port:passwd after split \":\"");
/*      */           }
/*  127 */           String host = rAddrArray[0];
/*  128 */           int port = Integer.valueOf(rAddrArray[1]).intValue();
/*  129 */           JedisShardInfo jedisShardInfo = new JedisShardInfo(host, port, this.connectionFactoryBuilder.getTimeout());
/*      */ 
/*  131 */           if ((rAddrArray.length == 3) && (StringUtils.hasLength(rAddrArray[2]))) {
/*  132 */             jedisShardInfo.setPassword(rAddrArray[2]);
/*      */           }
/*  134 */           log.info("slaveConfList:" + jedisShardInfo.toString());
/*  135 */           rShards.add(jedisShardInfo);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  140 */     this.writePool = new ShardedJedisPool(this.connectionFactoryBuilder.getJedisPoolConfig(), wShards);
/*  141 */     if (rShards == null) {
/*  142 */       this.readPool = null;
/*  143 */       this.redundancyFactor = 0;
/*      */     } else {
/*  145 */       this.readPool = new ShardedJedisPool(this.connectionFactoryBuilder.getJedisPoolConfig(), rShards);
/*      */     }
/*      */ 
/*  149 */     log.info("init end~");
/*      */   }
/*      */ 
/*      */   private void init(Object configData)
/*      */   {
/*      */     try {
/*  155 */       if (configData != null) {
/*  156 */         if (log.isDebugEnabled()) {
/*  157 */           log.debug(new String((byte[])configData));
/*      */         }
/*  159 */         synchronized (this)
/*      */         {
/*  162 */           init();
/*      */         }
/*      */       }
/*  165 */       log.error("init configData is null~");
/*      */     }
/*      */     catch (Exception ex) {
/*  168 */       log.fatal(ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getShardInfo(String key) throws RedisAccessException {
/*  173 */     boolean flag = true;
/*  174 */     ShardedJedis j = null;
/*  175 */     String result = null;
/*      */     try {
/*  177 */       j = (ShardedJedis)this.writePool.getResource();
/*  178 */       result = ((JedisShardInfo)j.getShardInfo(key)).toString();
/*      */     } catch (Exception ex) {
/*  180 */       flag = false;
/*  181 */       this.writePool.returnBrokenResource(j);
/*  182 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  184 */       if (flag) {
/*  185 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  188 */     return result;
/*      */   }
/*      */ 
/*      */   public Long del(String key)
/*      */     throws RedisAccessException
/*      */   {
/*  198 */     boolean flag = true;
/*  199 */     ShardedJedis j = null;
/*  200 */     Long result = null;
/*      */     try {
/*  202 */       j = (ShardedJedis)this.writePool.getResource();
/*  203 */       result = j.del(key);
/*      */     } catch (Exception ex) {
/*  205 */       flag = false;
/*  206 */       this.writePool.returnBrokenResource(j);
/*  207 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  209 */       if (flag) {
/*  210 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  213 */     return result;
/*      */   }
/*      */ 
/*      */   public byte[] get(byte[] key)
/*      */     throws RedisAccessException
/*      */   {
/*  223 */     return get(this.redundancyFactor, key);
/*      */   }
/*      */ 
/*      */   private byte[] get(int toTryCount, byte[] key) throws RedisAccessException {
/*  227 */     byte[] result = (byte[])null;
/*  228 */     ShardedJedis j = null;
/*  229 */     boolean flag = true;
/*      */     try {
/*  231 */       if (toTryCount > 0)
/*  232 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/*  234 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/*  236 */       result = j.get(key);
/*      */     } catch (Exception ex) {
/*  238 */       flag = false;
/*  239 */       if (toTryCount > 0) {
/*  240 */         this.readPool.returnBrokenResource(j);
/*  241 */         result = get(toTryCount - 1, key);
/*      */       } else {
/*  243 */         this.writePool.returnBrokenResource(j);
/*  244 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/*  247 */       if (flag) {
/*  248 */         if (toTryCount > 0)
/*  249 */           this.readPool.returnResource(j);
/*      */         else {
/*  251 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/*  255 */     return result;
/*      */   }
/*      */ 
/*      */   public Boolean exists(byte[] key)
/*      */     throws RedisAccessException
/*      */   {
/*  264 */     return exists(this.redundancyFactor, key);
/*      */   }
/*      */ 
/*      */   private Boolean exists(int toTryCount, byte[] key) throws RedisAccessException {
/*  268 */     Boolean result = null;
/*  269 */     ShardedJedis j = null;
/*  270 */     boolean flag = true;
/*      */     try {
/*  272 */       if (toTryCount > 0)
/*  273 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/*  275 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/*  277 */       result = j.exists(key);
/*      */     } catch (Exception ex) {
/*  279 */       flag = false;
/*  280 */       if (toTryCount > 0) {
/*  281 */         this.readPool.returnBrokenResource(j);
/*  282 */         result = exists(toTryCount - 1, key);
/*      */       } else {
/*  284 */         this.writePool.returnBrokenResource(j);
/*  285 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/*  288 */       if (flag) {
/*  289 */         if (toTryCount > 0)
/*  290 */           this.readPool.returnResource(j);
/*      */         else {
/*  292 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/*  296 */     return result;
/*      */   }
/*      */ 
/*      */   public String type(byte[] key)
/*      */     throws RedisAccessException
/*      */   {
/*  305 */     return type(this.redundancyFactor, key);
/*      */   }
/*      */ 
/*      */   private String type(int toTryCount, byte[] key) throws RedisAccessException {
/*  309 */     String result = null;
/*  310 */     ShardedJedis j = null;
/*  311 */     boolean flag = true;
/*      */     try {
/*  313 */       if (toTryCount > 0)
/*  314 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/*  316 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/*  318 */       result = j.type(key);
/*      */     } catch (Exception ex) {
/*  320 */       flag = false;
/*  321 */       if (toTryCount > 0) {
/*  322 */         this.readPool.returnBrokenResource(j);
/*  323 */         result = type(toTryCount - 1, key);
/*      */       } else {
/*  325 */         this.writePool.returnBrokenResource(j);
/*  326 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     }
/*      */     finally {
/*  330 */       if (flag) {
/*  331 */         if (toTryCount > 0)
/*  332 */           this.readPool.returnResource(j);
/*      */         else {
/*  334 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/*  338 */     return result;
/*      */   }
/*      */ 
/*      */   public Long expire(byte[] key, int seconds)
/*      */     throws RedisAccessException
/*      */   {
/*  349 */     boolean flag = true;
/*  350 */     ShardedJedis j = null;
/*  351 */     Long result = null;
/*      */     try {
/*  353 */       j = (ShardedJedis)this.writePool.getResource();
/*  354 */       result = j.expire(key, seconds);
/*      */     } catch (Exception ex) {
/*  356 */       flag = false;
/*  357 */       this.writePool.returnBrokenResource(j);
/*  358 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  360 */       if (flag) {
/*  361 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  364 */     return result;
/*      */   }
/*      */ 
/*      */   public Long expireAt(byte[] key, long unixTime)
/*      */     throws RedisAccessException
/*      */   {
/*  373 */     boolean flag = true;
/*  374 */     ShardedJedis j = null;
/*  375 */     Long result = null;
/*      */     try {
/*  377 */       j = (ShardedJedis)this.writePool.getResource();
/*  378 */       result = j.expireAt(key, unixTime);
/*      */     } catch (Exception ex) {
/*  380 */       flag = false;
/*  381 */       this.writePool.returnBrokenResource(j);
/*  382 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  384 */       if (flag) {
/*  385 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  388 */     return result;
/*      */   }
/*      */ 
/*      */   public Long ttl(byte[] key)
/*      */     throws RedisAccessException
/*      */   {
/*  396 */     boolean flag = true;
/*  397 */     ShardedJedis j = null;
/*  398 */     Long result = null;
/*      */     try {
/*  400 */       j = (ShardedJedis)this.writePool.getResource();
/*  401 */       result = j.ttl(key);
/*      */     } catch (Exception ex) {
/*  403 */       flag = false;
/*  404 */       this.writePool.returnBrokenResource(j);
/*  405 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  407 */       if (flag) {
/*  408 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  411 */     return result;
/*      */   }
/*      */ 
/*      */   public byte[] getSet(byte[] key, byte[] value)
/*      */     throws RedisAccessException
/*      */   {
/*  421 */     boolean flag = true;
/*  422 */     ShardedJedis j = null;
/*  423 */     byte[] result = (byte[])null;
/*      */     try {
/*  425 */       j = (ShardedJedis)this.writePool.getResource();
/*  426 */       result = j.getSet(key, value);
/*      */     } catch (Exception ex) {
/*  428 */       flag = false;
/*  429 */       this.writePool.returnBrokenResource(j);
/*  430 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  432 */       if (flag) {
/*  433 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  436 */     return result;
/*      */   }
/*      */ 
/*      */   public Long setnx(byte[] key, byte[] value)
/*      */     throws RedisAccessException
/*      */   {
/*  446 */     boolean flag = true;
/*  447 */     ShardedJedis j = null;
/*  448 */     Long result = null;
/*      */     try {
/*  450 */       j = (ShardedJedis)this.writePool.getResource();
/*  451 */       result = j.setnx(key, value);
/*      */     } catch (Exception ex) {
/*  453 */       flag = false;
/*  454 */       this.writePool.returnBrokenResource(j);
/*  455 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  457 */       if (flag) {
/*  458 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  461 */     return result;
/*      */   }
/*      */ 
/*      */   public String setex(byte[] key, int seconds, byte[] value)
/*      */     throws RedisAccessException
/*      */   {
/*  471 */     boolean flag = true;
/*  472 */     ShardedJedis j = null;
/*  473 */     String result = null;
/*      */     try {
/*  475 */       j = (ShardedJedis)this.writePool.getResource();
/*  476 */       result = j.setex(key, seconds, value);
/*      */     } catch (Exception ex) {
/*  478 */       flag = false;
/*  479 */       this.writePool.returnBrokenResource(j);
/*  480 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  482 */       if (flag) {
/*  483 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  486 */     return result;
/*      */   }
/*      */ 
/*      */   public Long decrBy(byte[] key, long integer)
/*      */     throws RedisAccessException
/*      */   {
/*  495 */     boolean flag = true;
/*  496 */     ShardedJedis j = null;
/*  497 */     Long result = null;
/*      */     try {
/*  499 */       j = (ShardedJedis)this.writePool.getResource();
/*  500 */       result = j.decrBy(key, integer);
/*      */     } catch (Exception ex) {
/*  502 */       flag = false;
/*  503 */       this.writePool.returnBrokenResource(j);
/*  504 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  506 */       if (flag) {
/*  507 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  510 */     return result;
/*      */   }
/*      */ 
/*      */   public Long decr(byte[] key)
/*      */     throws RedisAccessException
/*      */   {
/*  520 */     boolean flag = true;
/*  521 */     ShardedJedis j = null;
/*  522 */     Long result = null;
/*      */     try {
/*  524 */       j = (ShardedJedis)this.writePool.getResource();
/*  525 */       result = j.decr(key);
/*      */     } catch (Exception ex) {
/*  527 */       flag = false;
/*  528 */       this.writePool.returnBrokenResource(j);
/*  529 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  531 */       if (flag) {
/*  532 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  535 */     return result;
/*      */   }
/*      */ 
/*      */   public Long incrBy(byte[] key, long integer)
/*      */     throws RedisAccessException
/*      */   {
/*  545 */     boolean flag = true;
/*  546 */     ShardedJedis j = null;
/*  547 */     Long result = null;
/*      */     try {
/*  549 */       j = (ShardedJedis)this.writePool.getResource();
/*  550 */       result = j.incrBy(key, integer);
/*      */     } catch (Exception ex) {
/*  552 */       flag = false;
/*  553 */       this.writePool.returnBrokenResource(j);
/*  554 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  556 */       if (flag) {
/*  557 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  560 */     return result;
/*      */   }
/*      */ 
/*      */   public Long incr(byte[] key)
/*      */     throws RedisAccessException
/*      */   {
/*  569 */     boolean flag = true;
/*  570 */     ShardedJedis j = null;
/*  571 */     Long result = null;
/*      */     try {
/*  573 */       j = (ShardedJedis)this.writePool.getResource();
/*  574 */       result = j.incr(key);
/*      */     } catch (Exception ex) {
/*  576 */       flag = false;
/*  577 */       this.writePool.returnBrokenResource(j);
/*  578 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  580 */       if (flag) {
/*  581 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  584 */     return result;
/*      */   }
/*      */ 
/*      */   public Long append(byte[] key, byte[] value)
/*      */     throws RedisAccessException
/*      */   {
/*  593 */     boolean flag = true;
/*  594 */     ShardedJedis j = null;
/*  595 */     Long result = null;
/*      */     try {
/*  597 */       j = (ShardedJedis)this.writePool.getResource();
/*  598 */       result = j.append(key, value);
/*      */     } catch (Exception ex) {
/*  600 */       flag = false;
/*  601 */       this.writePool.returnBrokenResource(j);
/*  602 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  604 */       if (flag) {
/*  605 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  608 */     return result;
/*      */   }
/*      */ 
/*      */   public byte[] substr(byte[] key, int start, int end)
/*      */     throws RedisAccessException
/*      */   {
/*  620 */     boolean flag = true;
/*  621 */     ShardedJedis j = null;
/*  622 */     byte[] result = (byte[])null;
/*      */     try {
/*  624 */       j = (ShardedJedis)this.writePool.getResource();
/*  625 */       result = j.substr(key, start, end);
/*      */     } catch (Exception ex) {
/*  627 */       flag = false;
/*  628 */       this.writePool.returnBrokenResource(j);
/*  629 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  631 */       if (flag) {
/*  632 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  635 */     return result;
/*      */   }
/*      */ 
/*      */   public Long hset(byte[] key, byte[] field, byte[] value)
/*      */     throws RedisAccessException
/*      */   {
/*  646 */     boolean flag = true;
/*  647 */     ShardedJedis j = null;
/*  648 */     Long result = null;
/*      */     try {
/*  650 */       j = (ShardedJedis)this.writePool.getResource();
/*  651 */       result = j.hset(key, field, value);
/*      */     } catch (Exception ex) {
/*  653 */       flag = false;
/*  654 */       this.writePool.returnBrokenResource(j);
/*  655 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  657 */       if (flag) {
/*  658 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  661 */     return result;
/*      */   }
/*      */ 
/*      */   public byte[] hget(byte[] key, byte[] field)
/*      */     throws RedisAccessException
/*      */   {
/*  671 */     return hget(this.redundancyFactor, key, field);
/*      */   }
/*      */ 
/*      */   private byte[] hget(int toTryCount, byte[] key, byte[] field)
/*      */     throws RedisAccessException
/*      */   {
/*  681 */     byte[] result = (byte[])null;
/*  682 */     ShardedJedis j = null;
/*  683 */     boolean flag = true;
/*      */     try {
/*  685 */       if (toTryCount > 0)
/*  686 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/*  688 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/*  690 */       result = j.hget(key, field);
/*      */     } catch (Exception ex) {
/*  692 */       flag = false;
/*  693 */       if (toTryCount > 0) {
/*  694 */         this.readPool.returnBrokenResource(j);
/*  695 */         result = hget(toTryCount - 1, key, field);
/*      */       } else {
/*  697 */         this.writePool.returnBrokenResource(j);
/*  698 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/*  701 */       if (flag) {
/*  702 */         if (toTryCount > 0)
/*  703 */           this.readPool.returnResource(j);
/*      */         else {
/*  705 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/*  709 */     return result;
/*      */   }
/*      */ 
/*      */   public Long hsetnx(byte[] key, byte[] field, byte[] value)
/*      */     throws RedisAccessException
/*      */   {
/*  720 */     boolean flag = true;
/*  721 */     ShardedJedis j = null;
/*  722 */     Long result = null;
/*      */     try {
/*  724 */       j = (ShardedJedis)this.writePool.getResource();
/*  725 */       result = j.hsetnx(key, field, value);
/*      */     } catch (Exception ex) {
/*  727 */       flag = false;
/*  728 */       this.writePool.returnBrokenResource(j);
/*  729 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  731 */       if (flag) {
/*  732 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  735 */     return result;
/*      */   }
/*      */ 
/*      */   public String hmset(byte[] key, Map<byte[], byte[]> hash)
/*      */     throws RedisAccessException
/*      */   {
/*  745 */     boolean flag = true;
/*  746 */     ShardedJedis j = null;
/*  747 */     String result = null;
/*      */     try {
/*  749 */       j = (ShardedJedis)this.writePool.getResource();
/*  750 */       result = j.hmset(key, hash);
/*      */     } catch (Exception ex) {
/*  752 */       flag = false;
/*  753 */       this.writePool.returnBrokenResource(j);
/*  754 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  756 */       if (flag) {
/*  757 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  760 */     return result;
/*      */   }
/*      */ 
/*      */   public List<byte[]> hmget(byte[] key, byte[][] fields)
/*      */     throws RedisAccessException
/*      */   {
/*  770 */     return hmget(this.redundancyFactor, key, fields);
/*      */   }
/*      */ 
/*      */   private List<byte[]> hmget(int toTryCount, byte[] key, byte[][] fields) throws RedisAccessException {
/*  774 */     List result = null;
/*  775 */     ShardedJedis j = null;
/*  776 */     boolean flag = true;
/*      */     try {
/*  778 */       if (toTryCount > 0)
/*  779 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/*  781 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/*  783 */       result = j.hmget(key, fields);
/*      */     } catch (Exception ex) {
/*  785 */       flag = false;
/*  786 */       if (toTryCount > 0) {
/*  787 */         this.readPool.returnBrokenResource(j);
/*  788 */         result = hmget(toTryCount - 1, key, fields);
/*      */       } else {
/*  790 */         this.writePool.returnBrokenResource(j);
/*  791 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/*  794 */       if (flag) {
/*  795 */         if (toTryCount > 0)
/*  796 */           this.readPool.returnResource(j);
/*      */         else {
/*  798 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/*  802 */     return result;
/*      */   }
/*      */ 
/*      */   public Long hincrBy(byte[] key, byte[] field, long value)
/*      */     throws RedisAccessException
/*      */   {
/*  814 */     boolean flag = true;
/*  815 */     ShardedJedis j = null;
/*  816 */     Long result = null;
/*      */     try {
/*  818 */       j = (ShardedJedis)this.writePool.getResource();
/*  819 */       result = j.hincrBy(key, field, value);
/*      */     } catch (Exception ex) {
/*  821 */       flag = false;
/*  822 */       this.writePool.returnBrokenResource(j);
/*  823 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  825 */       if (flag) {
/*  826 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  829 */     return result;
/*      */   }
/*      */ 
/*      */   public Boolean hexists(byte[] key, byte[] field)
/*      */     throws RedisAccessException
/*      */   {
/*  840 */     return hexists(this.redundancyFactor, key, field);
/*      */   }
/*      */ 
/*      */   private Boolean hexists(int toTryCount, byte[] key, byte[] field) throws RedisAccessException {
/*  844 */     Boolean result = null;
/*  845 */     ShardedJedis j = null;
/*  846 */     boolean flag = true;
/*      */     try {
/*  848 */       if (toTryCount > 0)
/*  849 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/*  851 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/*  853 */       result = j.hexists(key, field);
/*      */     } catch (Exception ex) {
/*  855 */       flag = false;
/*  856 */       if (toTryCount > 0) {
/*  857 */         this.readPool.returnBrokenResource(j);
/*  858 */         result = hexists(toTryCount - 1, key, field);
/*      */       } else {
/*  860 */         this.writePool.returnBrokenResource(j);
/*  861 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/*  864 */       if (flag) {
/*  865 */         if (toTryCount > 0)
/*  866 */           this.readPool.returnResource(j);
/*      */         else {
/*  868 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/*  872 */     return result;
/*      */   }
/*      */ 
/*      */   public Long hdel(byte[] key, byte[] field)
/*      */     throws RedisAccessException
/*      */   {
/*  883 */     boolean flag = true;
/*  884 */     ShardedJedis j = null;
/*  885 */     Long result = null;
/*      */     try {
/*  887 */       j = (ShardedJedis)this.writePool.getResource();
/*  888 */       result = j.hdel(key, new byte[][] { field });
/*      */     } catch (Exception ex) {
/*  890 */       flag = false;
/*  891 */       this.writePool.returnBrokenResource(j);
/*  892 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  894 */       if (flag) {
/*  895 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  898 */     return result;
/*      */   }
/*      */ 
/*      */   public String lset(byte[] key, int index, byte[] value)
/*      */     throws RedisAccessException
/*      */   {
/*  909 */     boolean flag = true;
/*  910 */     ShardedJedis j = null;
/*  911 */     String result = null;
/*      */     try {
/*  913 */       j = (ShardedJedis)this.writePool.getResource();
/*  914 */       result = j.lset(key, index, value);
/*      */     } catch (Exception ex) {
/*  916 */       flag = false;
/*  917 */       this.writePool.returnBrokenResource(j);
/*  918 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  920 */       if (flag) {
/*  921 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  924 */     return result;
/*      */   }
/*      */ 
/*      */   public Long lrem(byte[] key, int count, byte[] value)
/*      */     throws RedisAccessException
/*      */   {
/*  936 */     boolean flag = true;
/*  937 */     ShardedJedis j = null;
/*  938 */     Long result = null;
/*      */     try {
/*  940 */       j = (ShardedJedis)this.writePool.getResource();
/*  941 */       result = j.lrem(key, count, value);
/*      */     } catch (Exception ex) {
/*  943 */       flag = false;
/*  944 */       this.writePool.returnBrokenResource(j);
/*  945 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  947 */       if (flag) {
/*  948 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  951 */     return result;
/*      */   }
/*      */ 
/*      */   public byte[] lpop(byte[] key)
/*      */     throws RedisAccessException
/*      */   {
/*  961 */     boolean flag = true;
/*  962 */     ShardedJedis j = null;
/*  963 */     byte[] result = (byte[])null;
/*      */     try {
/*  965 */       j = (ShardedJedis)this.writePool.getResource();
/*  966 */       result = j.lpop(key);
/*      */     } catch (Exception ex) {
/*  968 */       flag = false;
/*  969 */       this.writePool.returnBrokenResource(j);
/*  970 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  972 */       if (flag) {
/*  973 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/*  976 */     return result;
/*      */   }
/*      */ 
/*      */   public byte[] rpop(byte[] key)
/*      */     throws RedisAccessException
/*      */   {
/*  986 */     boolean flag = true;
/*  987 */     ShardedJedis j = null;
/*  988 */     byte[] result = (byte[])null;
/*      */     try {
/*  990 */       j = (ShardedJedis)this.writePool.getResource();
/*  991 */       result = j.rpop(key);
/*      */     } catch (Exception ex) {
/*  993 */       flag = false;
/*  994 */       this.writePool.returnBrokenResource(j);
/*  995 */       throw new RedisAccessException(ex);
/*      */     } finally {
/*  997 */       if (flag) {
/*  998 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1001 */     return result;
/*      */   }
/*      */ 
/*      */   public Long sadd(byte[] key, byte[] member)
/*      */     throws RedisAccessException
/*      */   {
/* 1012 */     boolean flag = true;
/* 1013 */     ShardedJedis j = null;
/* 1014 */     Long result = null;
/*      */     try {
/* 1016 */       j = (ShardedJedis)this.writePool.getResource();
/* 1017 */       result = j.sadd(key, new byte[][] { member });
/*      */     } catch (Exception ex) {
/* 1019 */       flag = false;
/* 1020 */       this.writePool.returnBrokenResource(j);
/* 1021 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1023 */       if (flag) {
/* 1024 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1027 */     return result;
/*      */   }
/*      */ 
/*      */   public Long srem(byte[] key, byte[] member)
/*      */     throws RedisAccessException
/*      */   {
/* 1037 */     boolean flag = true;
/* 1038 */     ShardedJedis j = null;
/* 1039 */     Long result = null;
/*      */     try {
/* 1041 */       j = (ShardedJedis)this.writePool.getResource();
/* 1042 */       result = j.srem(key, new byte[][] { member });
/*      */     } catch (Exception ex) {
/* 1044 */       flag = false;
/* 1045 */       this.writePool.returnBrokenResource(j);
/* 1046 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1048 */       if (flag) {
/* 1049 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1052 */     return result;
/*      */   }
/*      */ 
/*      */   public byte[] spop(byte[] key)
/*      */     throws RedisAccessException
/*      */   {
/* 1062 */     boolean flag = true;
/* 1063 */     ShardedJedis j = null;
/* 1064 */     byte[] result = (byte[])null;
/*      */     try {
/* 1066 */       j = (ShardedJedis)this.writePool.getResource();
/* 1067 */       result = j.spop(key);
/*      */     } catch (Exception ex) {
/* 1069 */       flag = false;
/* 1070 */       this.writePool.returnBrokenResource(j);
/* 1071 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1073 */       if (flag) {
/* 1074 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1077 */     return result;
/*      */   }
/*      */ 
/*      */   public Long zadd(byte[] key, double score, byte[] member)
/*      */     throws RedisAccessException
/*      */   {
/* 1089 */     boolean flag = true;
/* 1090 */     ShardedJedis j = null;
/* 1091 */     Long result = null;
/*      */     try {
/* 1093 */       j = (ShardedJedis)this.writePool.getResource();
/* 1094 */       result = j.zadd(key, score, member);
/*      */     } catch (Exception ex) {
/* 1096 */       flag = false;
/* 1097 */       this.writePool.returnBrokenResource(j);
/* 1098 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1100 */       if (flag) {
/* 1101 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1104 */     return result;
/*      */   }
/*      */ 
/*      */   public Long zrem(byte[] key, byte[] member)
/*      */     throws RedisAccessException
/*      */   {
/* 1114 */     boolean flag = true;
/* 1115 */     ShardedJedis j = null;
/* 1116 */     Long result = null;
/*      */     try {
/* 1118 */       j = (ShardedJedis)this.writePool.getResource();
/* 1119 */       result = j.zrem(key, new byte[][] { member });
/*      */     } catch (Exception ex) {
/* 1121 */       flag = false;
/* 1122 */       this.writePool.returnBrokenResource(j);
/* 1123 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1125 */       if (flag) {
/* 1126 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1129 */     return result;
/*      */   }
/*      */ 
/*      */   public Double zincrby(byte[] key, double score, byte[] member)
/*      */     throws RedisAccessException
/*      */   {
/* 1141 */     boolean flag = true;
/* 1142 */     ShardedJedis j = null;
/* 1143 */     double result = -1.0D;
/*      */     try {
/* 1145 */       j = (ShardedJedis)this.writePool.getResource();
/* 1146 */       result = j.zincrby(key, score, member).doubleValue();
/*      */     } catch (Exception ex) {
/* 1148 */       flag = false;
/* 1149 */       this.writePool.returnBrokenResource(j);
/* 1150 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1152 */       if (flag) {
/* 1153 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1156 */     return Double.valueOf(result);
/*      */   }
/*      */ 
/*      */   public String get(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 1166 */     return get(this.redundancyFactor, key);
/*      */   }
/*      */ 
/*      */   private String get(int toTryCount, String key) throws RedisAccessException {
/* 1170 */     String result = null;
/* 1171 */     ShardedJedis j = null;
/* 1172 */     boolean flag = true;
/*      */     try {
/* 1174 */       if (toTryCount > 0)
/* 1175 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 1177 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 1179 */       result = j.get(key);
/*      */     } catch (Exception ex) {
/* 1181 */       flag = false;
/* 1182 */       if (toTryCount > 0) {
/* 1183 */         this.readPool.returnBrokenResource(j);
/* 1184 */         result = get(toTryCount - 1, key);
/*      */       } else {
/* 1186 */         this.writePool.returnBrokenResource(j);
/* 1187 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 1190 */       if (flag) {
/* 1191 */         if (toTryCount > 0)
/* 1192 */           this.readPool.returnResource(j);
/*      */         else
/* 1194 */           this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1197 */     return result;
/*      */   }
/*      */ 
/*      */   public List<String> mget(String[] keys)
/*      */     throws RedisAccessException
/*      */   {
/* 1208 */     return mget(this.redundancyFactor, keys);
/*      */   }
/*      */ 
/*      */   private List<String> mget(int toTryCount, String[] keys)
/*      */     throws RedisAccessException
/*      */   {
/* 1219 */     if (keys == null) {
/* 1220 */       return null;
/*      */     }
/* 1222 */     List result = null;
/* 1223 */     ShardedJedis j = null;
/* 1224 */     boolean flag = true;
/* 1225 */     HashMap hashMapJedisGroup = new HashMap(keys.length);
/* 1226 */     HashMap hashMapKv = new HashMap(keys.length);
/*      */     try {
/* 1228 */       if (toTryCount > 0)
/* 1229 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 1231 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 1233 */       if (keys.length > 0)
/*      */       {
/* 1235 */         for (int i = 0; i < keys.length; i++) {
/* 1236 */           Jedis jedisChild = (Jedis)j.getShard(keys[i]);
/* 1237 */           if (hashMapJedisGroup.containsKey(jedisChild)) {
/* 1238 */             ((List)hashMapJedisGroup.get(jedisChild)).add(keys[i]);
/*      */           } else {
/* 1240 */             List list = new ArrayList();
/* 1241 */             list.add(keys[i]);
/* 1242 */             hashMapJedisGroup.put(jedisChild, list);
/*      */           }
/*      */         }
/*      */         Object localObject1;
/* 1248 */         for (Jedis jedisChild : hashMapJedisGroup.keySet()) {
/* 1249 */           List listKeys = (List)hashMapJedisGroup.get(jedisChild);
/* 1250 */           int i = 0;
/* 1251 */           for (localObject1 = jedisChild.mget((String[])listKeys.toArray(new String[listKeys.size()])).iterator(); ((Iterator)localObject1).hasNext(); ) { str = (String)((Iterator)localObject1).next();
/* 1252 */             hashMapKv.put((String)listKeys.get(i), str);
/* 1253 */             i++;
/*      */           }
/*      */         }
/* 1256 */         result = new ArrayList(keys.length);
/*      */ 
/* 1258 */         String str = (localObject1 = keys).length; for (String str1 = 0; str1 < str; str1++) { String key = localObject1[str1];
/* 1259 */           result.add((String)hashMapKv.get(key)); }
/*      */       }
/*      */       else {
/* 1262 */         ArrayList localArrayList = new ArrayList();
/*      */         return localArrayList;
/*      */       }
/*      */     } catch (Exception ex) {
/* 1265 */       flag = false;
/* 1266 */       if (toTryCount > 0) {
/* 1267 */         this.readPool.returnBrokenResource(j);
/* 1268 */         result = mget(toTryCount - 1, keys);
/*      */       } else {
/* 1270 */         this.writePool.returnBrokenResource(j);
/* 1271 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 1274 */       hashMapJedisGroup = null;
/* 1275 */       hashMapKv = null;
/* 1276 */       if (flag)
/* 1277 */         if (toTryCount > 0)
/* 1278 */           this.readPool.returnResource(j);
/*      */         else
/* 1280 */           this.writePool.returnResource(j);
/*      */     }
/* 1274 */     hashMapJedisGroup = null;
/* 1275 */     hashMapKv = null;
/* 1276 */     if (flag) {
/* 1277 */       if (toTryCount > 0)
/* 1278 */         this.readPool.returnResource(j);
/*      */       else {
/* 1280 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1283 */     return (List<String>)result;
/*      */   }
/*      */ 
/*      */   public List<List<String>> lrange2pipeline(String[] keys)
/*      */     throws RedisAccessException
/*      */   {
/* 1295 */     return lrange2pipeline(this.redundancyFactor, keys);
/*      */   }
/*      */ 
/*      */   private List<List<String>> lrange2pipeline(int toTryCount, String[] keys) throws RedisAccessException {
/* 1299 */     if (keys == null) {
/* 1300 */       return null;
/*      */     }
/* 1302 */     List result = null;
/* 1303 */     ShardedJedis j = null;
/* 1304 */     boolean flag = true;
/* 1305 */     HashMap hashMapJedisGroup = new HashMap(keys.length);
/* 1306 */     HashMap hashMapKv = new HashMap(keys.length);
/*      */     try
/*      */     {
/* 1310 */       if (toTryCount > 0)
/* 1311 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 1313 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 1315 */       if (keys.length > 0)
/*      */       {
/* 1317 */         for (int i = 0; i < keys.length; i++) {
/* 1318 */           Jedis jedisChild = (Jedis)j.getShard(keys[i]);
/* 1319 */           if (hashMapJedisGroup.containsKey(jedisChild)) {
/* 1320 */             ((List)hashMapJedisGroup.get(jedisChild)).add(keys[i]);
/*      */           } else {
/* 1322 */             list = new ArrayList();
/* 1323 */             list.add(keys[i]);
/* 1324 */             hashMapJedisGroup.put(jedisChild, list);
/*      */           }
/*      */         }
/*      */         Object localObject1;
/* 1329 */         for (Jedis jedisChild : hashMapJedisGroup.keySet()) {
/* 1330 */           List listKeys = (List)hashMapJedisGroup.get(jedisChild);
/* 1331 */           Pipeline p = jedisChild.pipelined();
/* 1332 */           for (localObject1 = listKeys.iterator(); ((Iterator)localObject1).hasNext(); ) { String key = (String)((Iterator)localObject1).next();
/* 1333 */             p.lrange(key, 0L, -1L);
/*      */           }
/* 1335 */           int i = 0;
/* 1336 */           for (localObject1 = p.syncAndReturnAll().iterator(); ((Iterator)localObject1).hasNext(); ) { obj = ((Iterator)localObject1).next();
/*      */ 
/* 1338 */             hashMapKv.put((String)listKeys.get(i), (List)obj);
/* 1339 */             i++;
/*      */           }
/*      */         }
/* 1342 */         result = new ArrayList(keys.length);
/*      */ 
/* 1344 */         Object obj = (localObject1 = keys).length; for (List list = 0; list < obj; list++) { String key = localObject1[list];
/* 1345 */           result.add((List)hashMapKv.get(key)); }
/*      */       }
/*      */       else {
/* 1348 */         ArrayList localArrayList = new ArrayList();
/*      */         Pipeline p;
/*      */         List listKeys;
/*      */         return localArrayList;
/*      */       }
/*      */     } catch (Exception ex) {
/* 1351 */       flag = false;
/* 1352 */       if (toTryCount > 0) {
/* 1353 */         this.readPool.returnBrokenResource(j);
/* 1354 */         result = lrange2pipeline(toTryCount - 1, keys);
/*      */       } else {
/* 1356 */         this.writePool.returnBrokenResource(j);
/* 1357 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*      */       List listKeys;
/*      */       Pipeline p;
/* 1360 */       hashMapJedisGroup = null;
/* 1361 */       hashMapKv = null;
/* 1362 */       List listKeys = null;
/* 1363 */       Pipeline p = null;
/* 1364 */       if (flag)
/* 1365 */         if (toTryCount > 0)
/* 1366 */           this.readPool.returnResource(j);
/*      */         else
/* 1368 */           this.writePool.returnResource(j);
/*      */     }
/* 1360 */     hashMapJedisGroup = null;
/* 1361 */     hashMapKv = null;
/* 1362 */     List listKeys = null;
/* 1363 */     Pipeline p = null;
/* 1364 */     if (flag) {
/* 1365 */       if (toTryCount > 0)
/* 1366 */         this.readPool.returnResource(j);
/*      */       else {
/* 1368 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1371 */     return (List<List<String>>)result;
/*      */   }
/*      */ 
/*      */   public Boolean exists(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 1380 */     return exists(this.redundancyFactor, key);
/*      */   }
/*      */ 
/*      */   private Boolean exists(int toTryCount, String key) throws RedisAccessException {
/* 1384 */     Boolean result = null;
/* 1385 */     ShardedJedis j = null;
/* 1386 */     boolean flag = true;
/*      */     try {
/* 1388 */       if (toTryCount > 0)
/* 1389 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 1391 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 1393 */       result = j.exists(key);
/*      */     } catch (Exception ex) {
/* 1395 */       flag = false;
/* 1396 */       if (toTryCount > 0) {
/* 1397 */         this.readPool.returnBrokenResource(j);
/* 1398 */         result = exists(toTryCount - 1, key);
/*      */       } else {
/* 1400 */         this.writePool.returnBrokenResource(j);
/* 1401 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 1404 */       if (flag) {
/* 1405 */         if (toTryCount > 0)
/* 1406 */           this.readPool.returnResource(j);
/*      */         else
/* 1408 */           this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1411 */     return result;
/*      */   }
/*      */ 
/*      */   public String type(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 1420 */     return type(this.redundancyFactor, key);
/*      */   }
/*      */ 
/*      */   private String type(int toTryCount, String key) throws RedisAccessException {
/* 1424 */     String result = null;
/* 1425 */     ShardedJedis j = null;
/* 1426 */     boolean flag = true;
/*      */     try {
/* 1428 */       if (toTryCount > 0)
/* 1429 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 1431 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 1433 */       result = j.type(key);
/*      */     } catch (Exception ex) {
/* 1435 */       flag = false;
/* 1436 */       if (toTryCount > 0) {
/* 1437 */         this.readPool.returnBrokenResource(j);
/* 1438 */         result = type(toTryCount - 1, key);
/*      */       } else {
/* 1440 */         this.writePool.returnBrokenResource(j);
/* 1441 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 1444 */       if (flag) {
/* 1445 */         if (toTryCount > 0)
/* 1446 */           this.readPool.returnResource(j);
/*      */         else
/* 1448 */           this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1451 */     return result;
/*      */   }
/*      */ 
/*      */   public Long expire(String key, int seconds)
/*      */     throws RedisAccessException
/*      */   {
/* 1461 */     boolean flag = true;
/* 1462 */     ShardedJedis j = null;
/* 1463 */     Long result = null;
/*      */     try {
/* 1465 */       j = (ShardedJedis)this.writePool.getResource();
/* 1466 */       result = j.expire(key, seconds);
/*      */     } catch (Exception ex) {
/* 1468 */       flag = false;
/* 1469 */       this.writePool.returnBrokenResource(j);
/* 1470 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1472 */       if (flag) {
/* 1473 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1476 */     return result;
/*      */   }
/*      */ 
/*      */   public Long expireAt(String key, long unixTime)
/*      */     throws RedisAccessException
/*      */   {
/* 1486 */     boolean flag = true;
/* 1487 */     ShardedJedis j = null;
/* 1488 */     Long result = null;
/*      */     try {
/* 1490 */       j = (ShardedJedis)this.writePool.getResource();
/* 1491 */       result = j.expireAt(key, unixTime);
/*      */     } catch (Exception ex) {
/* 1493 */       flag = false;
/* 1494 */       this.writePool.returnBrokenResource(j);
/* 1495 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1497 */       if (flag) {
/* 1498 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1501 */     return result;
/*      */   }
/*      */ 
/*      */   public Long ttl(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 1510 */     boolean flag = true;
/* 1511 */     ShardedJedis j = null;
/* 1512 */     Long result = null;
/*      */     try {
/* 1514 */       j = (ShardedJedis)this.writePool.getResource();
/* 1515 */       result = j.ttl(key);
/*      */     } catch (Exception ex) {
/* 1517 */       flag = false;
/* 1518 */       this.writePool.returnBrokenResource(j);
/* 1519 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1521 */       if (flag) {
/* 1522 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1525 */     return result;
/*      */   }
/*      */ 
/*      */   public boolean setbit(String key, long offset, boolean value)
/*      */     throws RedisAccessException
/*      */   {
/* 1537 */     boolean flag = true;
/* 1538 */     ShardedJedis j = null;
/* 1539 */     Boolean result = null;
/*      */     try {
/* 1541 */       j = (ShardedJedis)this.writePool.getResource();
/* 1542 */       result = j.setbit(key, offset, value);
/*      */     } catch (Exception ex) {
/* 1544 */       flag = false;
/* 1545 */       this.writePool.returnBrokenResource(j);
/* 1546 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1548 */       if (flag) {
/* 1549 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1552 */     return result.booleanValue();
/*      */   }
/*      */ 
/*      */   public boolean getbit(String key, long offset)
/*      */     throws RedisAccessException
/*      */   {
/* 1563 */     return getbit(this.redundancyFactor, key, offset);
/*      */   }
/*      */ 
/*      */   private boolean getbit(int toTryCount, String key, long offset) throws RedisAccessException {
/* 1567 */     Boolean result = null;
/* 1568 */     ShardedJedis j = null;
/* 1569 */     boolean flag = true;
/*      */     try {
/* 1571 */       if (toTryCount > 0)
/* 1572 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 1574 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 1576 */       result = j.getbit(key, offset);
/*      */     } catch (Exception ex) {
/* 1578 */       flag = false;
/* 1579 */       if (toTryCount > 0) {
/* 1580 */         this.readPool.returnBrokenResource(j);
/* 1581 */         result = Boolean.valueOf(getbit(toTryCount - 1, key, offset));
/*      */       } else {
/* 1583 */         this.writePool.returnBrokenResource(j);
/* 1584 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 1587 */       if (flag) {
/* 1588 */         if (toTryCount > 0)
/* 1589 */           this.readPool.returnResource(j);
/*      */         else {
/* 1591 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 1595 */     return result.booleanValue();
/*      */   }
/*      */ 
/*      */   public long setrange(String key, long offset, String value)
/*      */     throws RedisAccessException
/*      */   {
/* 1608 */     boolean flag = true;
/* 1609 */     ShardedJedis j = null;
/* 1610 */     Long result = null;
/*      */     try {
/* 1612 */       j = (ShardedJedis)this.writePool.getResource();
/* 1613 */       result = j.setrange(key, offset, value);
/*      */     } catch (Exception ex) {
/* 1615 */       flag = false;
/* 1616 */       this.writePool.returnBrokenResource(j);
/* 1617 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1619 */       if (flag) {
/* 1620 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1623 */     return result.longValue();
/*      */   }
/*      */ 
/*      */   public String getrange(String key, long startOffset, long endOffset)
/*      */     throws RedisAccessException
/*      */   {
/* 1633 */     return getrange(this.redundancyFactor, key, startOffset, endOffset);
/*      */   }
/*      */ 
/*      */   private String getrange(int toTryCount, String key, long startOffset, long endOffset) throws RedisAccessException {
/* 1637 */     String result = null;
/* 1638 */     ShardedJedis j = null;
/* 1639 */     boolean flag = true;
/*      */     try {
/* 1641 */       if (toTryCount > 0)
/* 1642 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 1644 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 1646 */       result = j.getrange(key, startOffset, endOffset);
/*      */     } catch (Exception ex) {
/* 1648 */       flag = false;
/* 1649 */       if (toTryCount > 0) {
/* 1650 */         this.readPool.returnBrokenResource(j);
/* 1651 */         result = getrange(toTryCount - 1, key, startOffset, endOffset);
/*      */       } else {
/* 1653 */         this.writePool.returnBrokenResource(j);
/* 1654 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 1657 */       if (flag) {
/* 1658 */         if (toTryCount > 0)
/* 1659 */           this.readPool.returnResource(j);
/*      */         else {
/* 1661 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 1665 */     return result;
/*      */   }
/*      */ 
/*      */   public String getSet(String key, String value)
/*      */     throws RedisAccessException
/*      */   {
/* 1675 */     boolean flag = true;
/* 1676 */     ShardedJedis j = null;
/* 1677 */     String result = null;
/*      */     try {
/* 1679 */       j = (ShardedJedis)this.writePool.getResource();
/* 1680 */       result = j.getSet(key, value);
/*      */     } catch (Exception ex) {
/* 1682 */       flag = false;
/* 1683 */       this.writePool.returnBrokenResource(j);
/* 1684 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1686 */       if (flag) {
/* 1687 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1690 */     return result;
/*      */   }
/*      */ 
/*      */   public Long setnx(String key, String value)
/*      */     throws RedisAccessException
/*      */   {
/* 1699 */     boolean flag = true;
/* 1700 */     ShardedJedis j = null;
/* 1701 */     Long result = null;
/*      */     try {
/* 1703 */       j = (ShardedJedis)this.writePool.getResource();
/* 1704 */       result = j.setnx(key, value);
/*      */     } catch (Exception ex) {
/* 1706 */       flag = false;
/* 1707 */       this.writePool.returnBrokenResource(j);
/* 1708 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1710 */       if (flag) {
/* 1711 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1714 */     return result;
/*      */   }
/*      */ 
/*      */   public List<Object> setnx(String key, int seconds, String value)
/*      */     throws RedisAccessException
/*      */   {
/* 1726 */     boolean flag = true;
/* 1727 */     ShardedJedis j = null;
/* 1728 */     List result = null;
/* 1729 */     Pipeline p = null;
/*      */     try {
/* 1731 */       j = (ShardedJedis)this.writePool.getResource();
/* 1732 */       p = ((Jedis)j.getShard(key)).pipelined();
/* 1733 */       p.setnx(key, value);
/* 1734 */       p.expire(key, seconds);
/* 1735 */       result = p.syncAndReturnAll();
/*      */     } catch (Exception ex) {
/* 1737 */       flag = false;
/* 1738 */       this.writePool.returnBrokenResource(j);
/* 1739 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1741 */       if (flag) {
/* 1742 */         this.writePool.returnResource(j);
/*      */       }
/* 1744 */       p = null;
/*      */     }
/* 1746 */     return result;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public List<Object> setnx(String key, String value, int seconds)
/*      */     throws RedisAccessException
/*      */   {
/* 1757 */     return setnx(key, seconds, value);
/*      */   }
/*      */ 
/*      */   public List<Object> setObject(String key, int seconds, Object value)
/*      */     throws RedisAccessException
/*      */   {
/* 1770 */     boolean flag = true;
/* 1771 */     ShardedJedis j = null;
/* 1772 */     List result = null;
/* 1773 */     Pipeline p = null;
/*      */     try {
/* 1775 */       j = (ShardedJedis)this.writePool.getResource();
/* 1776 */       p = ((Jedis)j.getShard(key)).pipelined();
/*      */ 
/* 1779 */       p.expire(key, seconds);
/* 1780 */       result = p.syncAndReturnAll();
/*      */     } catch (Exception ex) {
/* 1782 */       flag = false;
/* 1783 */       this.writePool.returnBrokenResource(j);
/* 1784 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1786 */       if (flag) {
/* 1787 */         this.writePool.returnResource(j);
/*      */       }
/* 1789 */       p = null;
/*      */     }
/* 1791 */     return result;
/*      */   }
/*      */ 
/*      */   public Object getObject(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 1801 */     boolean flag = true;
/* 1802 */     ShardedJedis j = null;
/* 1803 */     Object result = null;
/*      */     try {
/* 1805 */       j = (ShardedJedis)this.writePool.getResource();
/* 1806 */       re = j.get(SafeEncoder.encode(key));
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*      */       byte[] re;
/* 1812 */       flag = false;
/* 1813 */       this.writePool.returnBrokenResource(j);
/* 1814 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1816 */       if (flag) {
/* 1817 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1820 */     return result;
/*      */   }
/*      */ 
/*      */   public String setex(String key, int seconds, String value)
/*      */     throws RedisAccessException
/*      */   {
/* 1830 */     boolean flag = true;
/* 1831 */     ShardedJedis j = null;
/* 1832 */     String result = null;
/*      */     try {
/* 1834 */       j = (ShardedJedis)this.writePool.getResource();
/* 1835 */       result = j.setex(key, seconds, value);
/*      */     } catch (Exception ex) {
/* 1837 */       flag = false;
/* 1838 */       this.writePool.returnBrokenResource(j);
/* 1839 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1841 */       if (flag) {
/* 1842 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1845 */     return result;
/*      */   }
/*      */ 
/*      */   public Long decrBy(String key, long integer)
/*      */     throws RedisAccessException
/*      */   {
/* 1854 */     boolean flag = true;
/* 1855 */     ShardedJedis j = null;
/* 1856 */     Long result = null;
/*      */     try {
/* 1858 */       j = (ShardedJedis)this.writePool.getResource();
/* 1859 */       result = j.decrBy(key, integer);
/*      */     } catch (Exception ex) {
/* 1861 */       flag = false;
/* 1862 */       this.writePool.returnBrokenResource(j);
/* 1863 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1865 */       if (flag) {
/* 1866 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1869 */     return result;
/*      */   }
/*      */ 
/*      */   public Long decr(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 1878 */     boolean flag = true;
/* 1879 */     ShardedJedis j = null;
/* 1880 */     Long result = null;
/*      */     try {
/* 1882 */       j = (ShardedJedis)this.writePool.getResource();
/* 1883 */       result = j.decr(key);
/*      */     } catch (Exception ex) {
/* 1885 */       flag = false;
/* 1886 */       this.writePool.returnBrokenResource(j);
/* 1887 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1889 */       if (flag) {
/* 1890 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1893 */     return result;
/*      */   }
/*      */ 
/*      */   public List<Object> decr(String key, int seconds)
/*      */     throws RedisAccessException
/*      */   {
/* 1904 */     boolean flag = true;
/* 1905 */     ShardedJedis j = null;
/* 1906 */     List result = null;
/* 1907 */     Pipeline p = null;
/*      */     try {
/* 1909 */       j = (ShardedJedis)this.writePool.getResource();
/* 1910 */       p = ((Jedis)j.getShard(key)).pipelined();
/* 1911 */       p.decr(key);
/* 1912 */       p.expire(key, seconds);
/* 1913 */       result = p.syncAndReturnAll();
/*      */     } catch (Exception ex) {
/* 1915 */       flag = false;
/* 1916 */       this.writePool.returnBrokenResource(j);
/* 1917 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1919 */       if (flag) {
/* 1920 */         this.writePool.returnResource(j);
/*      */       }
/* 1922 */       p = null;
/*      */     }
/* 1924 */     return result;
/*      */   }
/*      */ 
/*      */   public Long incrBy(String key, long integer)
/*      */     throws RedisAccessException
/*      */   {
/* 1935 */     boolean flag = true;
/* 1936 */     ShardedJedis j = null;
/* 1937 */     Long result = null;
/*      */     try {
/* 1939 */       j = (ShardedJedis)this.writePool.getResource();
/* 1940 */       result = j.incrBy(key, integer);
/*      */     } catch (Exception ex) {
/* 1942 */       flag = false;
/* 1943 */       this.writePool.returnBrokenResource(j);
/* 1944 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1946 */       if (flag) {
/* 1947 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1950 */     return result;
/*      */   }
/*      */ 
/*      */   public Long incr(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 1960 */     boolean flag = true;
/* 1961 */     ShardedJedis j = null;
/* 1962 */     Long result = null;
/*      */     try {
/* 1964 */       j = (ShardedJedis)this.writePool.getResource();
/* 1965 */       result = j.incr(key);
/*      */     } catch (Exception ex) {
/* 1967 */       flag = false;
/* 1968 */       this.writePool.returnBrokenResource(j);
/* 1969 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 1971 */       if (flag) {
/* 1972 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 1975 */     return result;
/*      */   }
/*      */ 
/*      */   public List<Object> incr(String key, int seconds)
/*      */     throws RedisAccessException
/*      */   {
/* 1986 */     boolean flag = true;
/* 1987 */     ShardedJedis j = null;
/* 1988 */     List result = null;
/* 1989 */     Pipeline p = null;
/*      */     try {
/* 1991 */       j = (ShardedJedis)this.writePool.getResource();
/* 1992 */       p = ((Jedis)j.getShard(key)).pipelined();
/* 1993 */       p.incr(key);
/* 1994 */       p.expire(key, seconds);
/* 1995 */       result = p.syncAndReturnAll();
/*      */     } catch (Exception ex) {
/* 1997 */       flag = false;
/* 1998 */       this.writePool.returnBrokenResource(j);
/* 1999 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2001 */       if (flag) {
/* 2002 */         this.writePool.returnResource(j);
/*      */       }
/* 2004 */       p = null;
/*      */     }
/* 2006 */     return result;
/*      */   }
/*      */ 
/*      */   public Map<String, SortedMap<String, String>> info()
/*      */     throws RedisAccessException
/*      */   {
/* 2015 */     boolean flag = true;
/* 2016 */     Map result = new HashMap();
/* 2017 */     ShardedJedis master = null;
/* 2018 */     ShardedJedis slave = null;
/* 2019 */     SortedMap re = null;
/*      */     try
/*      */     {
/* 2022 */       master = (ShardedJedis)this.writePool.getResource();
/*      */       String listStr;
/* 2023 */       for (Jedis jedis : master.getAllShards()) {
/* 2024 */         re = new TreeMap(new CollatorComparator());
/* 2025 */         for (String line : jedis.info().split("\\r\\n")) {
/* 2026 */           String[] kv = line.split(":");
/* 2027 */           re.put(kv[0], kv[1]);
/*      */         }
/*      */ 
/* 2030 */         String memKey = null;
/* 2031 */         for (Iterator localIterator2 = jedis.configGet("maxmemory*").iterator(); localIterator2.hasNext(); ) { listStr = (String)localIterator2.next();
/* 2032 */           if (memKey != null) {
/* 2033 */             re.put(memKey, listStr);
/* 2034 */             memKey = null;
/*      */           }
/* 2036 */           if (listStr.startsWith("maxmemory")) {
/* 2037 */             memKey = listStr;
/*      */           }
/*      */         }
/* 2040 */         result.put(jedis.getClient().getHost() + ":" + jedis.getClient().getPort(), re);
/*      */       }
/* 2042 */       if (this.readPool != null) {
/* 2043 */         slave = (ShardedJedis)this.readPool.getResource();
/* 2044 */         for (Jedis jedis : slave.getAllShards()) {
/* 2045 */           re = new TreeMap(new CollatorComparator());
/* 2046 */           Object localObject2 = ( = jedis.info().split("\\r\\n")).length; for (Object localObject1 = 0; localObject1 < localObject2; localObject1++) { String line = ???[localObject1];
/* 2047 */             String[] kv = line.split(":");
/* 2048 */             re.put(kv[0], kv[1]);
/*      */           }
/*      */ 
/* 2051 */           String memKey = null;
/* 2052 */           for (localObject2 = jedis.configGet("maxmemory*").iterator(); ((Iterator)localObject2).hasNext(); ) { String listStr = (String)((Iterator)localObject2).next();
/* 2053 */             if (memKey != null) {
/* 2054 */               re.put(memKey, listStr);
/* 2055 */               memKey = null;
/*      */             }
/* 2057 */             if (listStr.startsWith("maxmemory")) {
/* 2058 */               memKey = listStr;
/*      */             }
/*      */           }
/*      */ 
/* 2062 */           result.put(jedis.getClient().getHost() + ":" + jedis.getClient().getPort(), re);
/*      */         }
/*      */       }
/*      */     } catch (Exception ex) {
/* 2066 */       flag = false;
/* 2067 */       this.writePool.returnBrokenResource(master);
/* 2068 */       if (slave != null) {
/* 2069 */         this.readPool.returnBrokenResource(slave);
/*      */       }
/* 2071 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2073 */       if (flag) {
/* 2074 */         this.writePool.returnResource(master);
/* 2075 */         if (slave != null) {
/* 2076 */           this.readPool.returnResource(slave);
/*      */         }
/*      */       }
/*      */     }
/* 2080 */     return (Map<String, SortedMap<String, String>>)(Map<String, SortedMap<String, String>>)result;
/*      */   }
/*      */ 
/*      */   public Long append(String key, String value)
/*      */     throws RedisAccessException
/*      */   {
/* 2090 */     boolean flag = true;
/* 2091 */     ShardedJedis j = null;
/* 2092 */     Long result = null;
/*      */     try {
/* 2094 */       j = (ShardedJedis)this.writePool.getResource();
/* 2095 */       result = j.append(key, value);
/*      */     } catch (Exception ex) {
/* 2097 */       flag = false;
/* 2098 */       this.writePool.returnBrokenResource(j);
/* 2099 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2101 */       if (flag) {
/* 2102 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2105 */     return result;
/*      */   }
/*      */ 
/*      */   public String substr(String key, int start, int end)
/*      */     throws RedisAccessException
/*      */   {
/* 2117 */     boolean flag = true;
/* 2118 */     ShardedJedis j = null;
/* 2119 */     String result = null;
/*      */     try {
/* 2121 */       j = (ShardedJedis)this.writePool.getResource();
/* 2122 */       result = j.substr(key, start, end);
/*      */     } catch (Exception ex) {
/* 2124 */       flag = false;
/* 2125 */       this.writePool.returnBrokenResource(j);
/* 2126 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2128 */       if (flag) {
/* 2129 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2132 */     return result;
/*      */   }
/*      */ 
/*      */   public Long hset(String key, String field, String value)
/*      */     throws RedisAccessException
/*      */   {
/* 2143 */     boolean flag = true;
/* 2144 */     ShardedJedis j = null;
/* 2145 */     Long result = null;
/*      */     try {
/* 2147 */       j = (ShardedJedis)this.writePool.getResource();
/* 2148 */       result = j.hset(key, field, value);
/*      */     } catch (Exception ex) {
/* 2150 */       flag = false;
/* 2151 */       this.writePool.returnBrokenResource(j);
/* 2152 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2154 */       if (flag) {
/* 2155 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2158 */     return result;
/*      */   }
/*      */ 
/*      */   public String hget(String key, String field)
/*      */     throws RedisAccessException
/*      */   {
/* 2169 */     return hget(this.redundancyFactor, key, field);
/*      */   }
/*      */ 
/*      */   private String hget(int toTryCount, String key, String field) throws RedisAccessException {
/* 2173 */     String result = null;
/* 2174 */     ShardedJedis j = null;
/* 2175 */     boolean flag = true;
/*      */     try {
/* 2177 */       if (toTryCount > 0)
/* 2178 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 2180 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 2182 */       result = j.hget(key, field);
/*      */     } catch (Exception ex) {
/* 2184 */       flag = false;
/* 2185 */       if (toTryCount > 0) {
/* 2186 */         this.readPool.returnBrokenResource(j);
/* 2187 */         result = hget(toTryCount - 1, key, field);
/*      */       } else {
/* 2189 */         this.writePool.returnBrokenResource(j);
/* 2190 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 2193 */       if (flag) {
/* 2194 */         if (toTryCount > 0)
/* 2195 */           this.readPool.returnResource(j);
/*      */         else
/* 2197 */           this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2200 */     return result;
/*      */   }
/*      */ 
/*      */   public Long hsetnx(String key, String field, String value)
/*      */     throws RedisAccessException
/*      */   {
/* 2210 */     boolean flag = true;
/* 2211 */     ShardedJedis j = null;
/* 2212 */     Long result = null;
/*      */     try {
/* 2214 */       j = (ShardedJedis)this.writePool.getResource();
/* 2215 */       result = j.hsetnx(key, field, value);
/*      */     } catch (Exception ex) {
/* 2217 */       flag = false;
/* 2218 */       this.writePool.returnBrokenResource(j);
/* 2219 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2221 */       if (flag) {
/* 2222 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2225 */     return result;
/*      */   }
/*      */ 
/*      */   public String hmset(String key, Map<String, String> hash)
/*      */     throws RedisAccessException
/*      */   {
/* 2236 */     boolean flag = true;
/* 2237 */     ShardedJedis j = null;
/* 2238 */     String result = null;
/*      */     try {
/* 2240 */       j = (ShardedJedis)this.writePool.getResource();
/* 2241 */       result = j.hmset(key, hash);
/*      */     } catch (Exception ex) {
/* 2243 */       flag = false;
/* 2244 */       this.writePool.returnBrokenResource(j);
/* 2245 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2247 */       if (flag) {
/* 2248 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2251 */     return result;
/*      */   }
/*      */ 
/*      */   public List<String> hmget(String key, String[] fields)
/*      */     throws RedisAccessException
/*      */   {
/* 2260 */     return hmget(this.redundancyFactor, key, fields);
/*      */   }
/*      */ 
/*      */   private List<String> hmget(int toTryCount, String key, String[] fields) throws RedisAccessException {
/* 2264 */     List result = null;
/* 2265 */     ShardedJedis j = null;
/* 2266 */     boolean flag = true;
/*      */     try {
/* 2268 */       if (toTryCount > 0)
/* 2269 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 2271 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 2273 */       result = j.hmget(key, fields);
/*      */     } catch (Exception ex) {
/* 2275 */       flag = false;
/* 2276 */       if (toTryCount > 0) {
/* 2277 */         this.readPool.returnBrokenResource(j);
/* 2278 */         result = hmget(toTryCount - 1, key, fields);
/*      */       } else {
/* 2280 */         this.writePool.returnBrokenResource(j);
/* 2281 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 2284 */       if (flag) {
/* 2285 */         if (toTryCount > 0)
/* 2286 */           this.readPool.returnResource(j);
/*      */         else
/* 2288 */           this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2291 */     return result;
/*      */   }
/*      */ 
/*      */   public Long hincrBy(String key, String field, long value)
/*      */     throws RedisAccessException
/*      */   {
/* 2303 */     boolean flag = true;
/* 2304 */     ShardedJedis j = null;
/* 2305 */     Long result = null;
/*      */     try {
/* 2307 */       j = (ShardedJedis)this.writePool.getResource();
/* 2308 */       result = j.hincrBy(key, field, value);
/*      */     } catch (Exception ex) {
/* 2310 */       flag = false;
/* 2311 */       this.writePool.returnBrokenResource(j);
/* 2312 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2314 */       if (flag) {
/* 2315 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2318 */     return result;
/*      */   }
/*      */ 
/*      */   public Boolean hexists(String key, String field)
/*      */     throws RedisAccessException
/*      */   {
/* 2328 */     return hexists(this.redundancyFactor, key, field);
/*      */   }
/*      */ 
/*      */   private Boolean hexists(int toTryCount, String key, String field) throws RedisAccessException {
/* 2332 */     Boolean result = null;
/* 2333 */     ShardedJedis j = null;
/* 2334 */     boolean flag = true;
/*      */     try {
/* 2336 */       if (toTryCount > 0)
/* 2337 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 2339 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 2341 */       result = j.hexists(key, field);
/*      */     } catch (Exception ex) {
/* 2343 */       flag = false;
/* 2344 */       if (toTryCount > 0) {
/* 2345 */         this.readPool.returnBrokenResource(j);
/* 2346 */         result = hexists(toTryCount - 1, key, field);
/*      */       } else {
/* 2348 */         this.writePool.returnBrokenResource(j);
/* 2349 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 2352 */       if (flag) {
/* 2353 */         if (toTryCount > 0)
/* 2354 */           this.readPool.returnResource(j);
/*      */         else {
/* 2356 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 2360 */     return result;
/*      */   }
/*      */ 
/*      */   public Long hdel(String key, String field)
/*      */     throws RedisAccessException
/*      */   {
/* 2370 */     boolean flag = true;
/* 2371 */     ShardedJedis j = null;
/* 2372 */     Long result = null;
/*      */     try {
/* 2374 */       j = (ShardedJedis)this.writePool.getResource();
/* 2375 */       result = j.hdel(key, new String[] { field });
/*      */     } catch (Exception ex) {
/* 2377 */       flag = false;
/* 2378 */       this.writePool.returnBrokenResource(j);
/* 2379 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2381 */       if (flag) {
/* 2382 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2385 */     return result;
/*      */   }
/*      */ 
/*      */   public Long hlen(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 2394 */     return hlen(this.redundancyFactor, key);
/*      */   }
/*      */ 
/*      */   private Long hlen(int toTryCount, String key) throws RedisAccessException {
/* 2398 */     Long result = null;
/* 2399 */     ShardedJedis j = null;
/* 2400 */     boolean flag = true;
/*      */     try {
/* 2402 */       if (toTryCount > 0)
/* 2403 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 2405 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 2407 */       result = j.hlen(key);
/*      */     } catch (Exception ex) {
/* 2409 */       flag = false;
/* 2410 */       if (toTryCount > 0) {
/* 2411 */         this.readPool.returnBrokenResource(j);
/* 2412 */         result = hlen(toTryCount - 1, key);
/*      */       } else {
/* 2414 */         this.writePool.returnBrokenResource(j);
/* 2415 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 2418 */       if (flag) {
/* 2419 */         if (toTryCount > 0)
/* 2420 */           this.readPool.returnResource(j);
/*      */         else
/* 2422 */           this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2425 */     return result;
/*      */   }
/*      */ 
/*      */   public Set<String> hkeys(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 2434 */     return hkeys(this.redundancyFactor, key);
/*      */   }
/*      */ 
/*      */   private Set<String> hkeys(int toTryCount, String key) throws RedisAccessException {
/* 2438 */     Set result = null;
/* 2439 */     ShardedJedis j = null;
/* 2440 */     boolean flag = true;
/*      */     try {
/* 2442 */       if (toTryCount > 0)
/* 2443 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 2445 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 2447 */       result = j.hkeys(key);
/*      */     } catch (Exception ex) {
/* 2449 */       flag = false;
/* 2450 */       if (toTryCount > 0) {
/* 2451 */         this.readPool.returnBrokenResource(j);
/* 2452 */         result = hkeys(toTryCount - 1, key);
/*      */       } else {
/* 2454 */         this.writePool.returnBrokenResource(j);
/* 2455 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 2458 */       if (flag) {
/* 2459 */         if (toTryCount > 0)
/* 2460 */           this.readPool.returnResource(j);
/*      */         else {
/* 2462 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 2466 */     return result;
/*      */   }
/*      */ 
/*      */   public Set<String> keys(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 2474 */     return keys(this.redundancyFactor, key);
/*      */   }
/*      */ 
/*      */   private Set<String> keys(int toTryCount, String key) throws RedisAccessException {
/* 2478 */     Set result = null;
/* 2479 */     ShardedJedis j = null;
/* 2480 */     boolean flag = true;
/*      */     try {
/* 2482 */       if (toTryCount > 0)
/* 2483 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 2485 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 2487 */       result = j.keys(key);
/*      */     } catch (Exception ex) {
/* 2489 */       flag = false;
/* 2490 */       if (toTryCount > 0) {
/* 2491 */         this.readPool.returnBrokenResource(j);
/* 2492 */         result = hkeys(toTryCount - 1, key);
/*      */       } else {
/* 2494 */         this.writePool.returnBrokenResource(j);
/* 2495 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 2498 */       if (flag) {
/* 2499 */         if (toTryCount > 0)
/* 2500 */           this.readPool.returnResource(j);
/*      */         else {
/* 2502 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 2506 */     return result;
/*      */   }
/*      */ 
/*      */   public List<String> hvals(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 2515 */     return hvals(this.redundancyFactor, key);
/*      */   }
/*      */ 
/*      */   private List<String> hvals(int toTryCount, String key) throws RedisAccessException {
/* 2519 */     List result = null;
/* 2520 */     ShardedJedis j = null;
/* 2521 */     boolean flag = true;
/*      */     try {
/* 2523 */       if (toTryCount > 0)
/* 2524 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 2526 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 2528 */       result = j.hvals(key);
/*      */     } catch (Exception ex) {
/* 2530 */       flag = false;
/* 2531 */       if (toTryCount > 0) {
/* 2532 */         this.readPool.returnBrokenResource(j);
/* 2533 */         result = hvals(toTryCount - 1, key);
/*      */       } else {
/* 2535 */         this.writePool.returnBrokenResource(j);
/* 2536 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 2539 */       if (flag) {
/* 2540 */         if (toTryCount > 0)
/* 2541 */           this.readPool.returnResource(j);
/*      */         else {
/* 2543 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 2547 */     return result;
/*      */   }
/*      */ 
/*      */   public Map<String, String> hgetAll(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 2557 */     return hgetAll(this.redundancyFactor, key);
/*      */   }
/*      */ 
/*      */   private Map<String, String> hgetAll(int toTryCount, String key) throws RedisAccessException {
/* 2561 */     Map result = null;
/* 2562 */     ShardedJedis j = null;
/* 2563 */     boolean flag = true;
/*      */     try {
/* 2565 */       if (toTryCount > 0)
/* 2566 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 2568 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 2570 */       result = j.hgetAll(key);
/*      */     } catch (Exception ex) {
/* 2572 */       flag = false;
/* 2573 */       if (toTryCount > 0) {
/* 2574 */         this.readPool.returnBrokenResource(j);
/* 2575 */         result = hgetAll(toTryCount - 1, key);
/*      */       } else {
/* 2577 */         this.writePool.returnBrokenResource(j);
/* 2578 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 2581 */       if (flag) {
/* 2582 */         if (toTryCount > 0)
/* 2583 */           this.readPool.returnResource(j);
/*      */         else {
/* 2585 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 2589 */     return result;
/*      */   }
/*      */ 
/*      */   public Long rpush(String key, String string)
/*      */     throws RedisAccessException
/*      */   {
/* 2600 */     boolean flag = true;
/* 2601 */     ShardedJedis j = null;
/* 2602 */     Long result = null;
/*      */     try {
/* 2604 */       j = (ShardedJedis)this.writePool.getResource();
/* 2605 */       result = j.rpush(key, new String[] { string });
/*      */     } catch (Exception ex) {
/* 2607 */       flag = false;
/* 2608 */       this.writePool.returnBrokenResource(j);
/* 2609 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2611 */       if (flag) {
/* 2612 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2615 */     return result;
/*      */   }
/*      */ 
/*      */   public Long lpush(String key, String string)
/*      */     throws RedisAccessException
/*      */   {
/* 2626 */     boolean flag = true;
/* 2627 */     ShardedJedis j = null;
/* 2628 */     Long result = null;
/*      */     try {
/* 2630 */       j = (ShardedJedis)this.writePool.getResource();
/* 2631 */       result = j.lpush(key, new String[] { string });
/*      */     } catch (Exception ex) {
/* 2633 */       flag = false;
/* 2634 */       this.writePool.returnBrokenResource(j);
/* 2635 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2637 */       if (flag) {
/* 2638 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2641 */     return result;
/*      */   }
/*      */ 
/*      */   public Long llen(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 2650 */     return llen(this.redundancyFactor, key);
/*      */   }
/*      */ 
/*      */   private Long llen(int toTryCount, String key) throws RedisAccessException {
/* 2654 */     Long result = null;
/* 2655 */     ShardedJedis j = null;
/* 2656 */     boolean flag = true;
/*      */     try {
/* 2658 */       if (toTryCount > 0)
/* 2659 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 2661 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 2663 */       result = j.llen(key);
/*      */     } catch (Exception ex) {
/* 2665 */       flag = false;
/* 2666 */       if (toTryCount > 0) {
/* 2667 */         this.readPool.returnBrokenResource(j);
/* 2668 */         result = llen(toTryCount - 1, key);
/*      */       } else {
/* 2670 */         this.writePool.returnBrokenResource(j);
/* 2671 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 2674 */       if (flag) {
/* 2675 */         if (toTryCount > 0)
/* 2676 */           this.readPool.returnResource(j);
/*      */         else {
/* 2678 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 2682 */     return result;
/*      */   }
/*      */ 
/*      */   public List<String> lrange(String key, long start, long end)
/*      */     throws RedisAccessException
/*      */   {
/* 2692 */     return lrange(this.redundancyFactor, key, start, end);
/*      */   }
/*      */ 
/*      */   private List<String> lrange(int toTryCount, String key, long start, long end) throws RedisAccessException {
/* 2696 */     List result = null;
/* 2697 */     ShardedJedis j = null;
/* 2698 */     boolean flag = true;
/*      */     try
/*      */     {
/* 2702 */       if (toTryCount > 0)
/* 2703 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 2705 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 2707 */       result = j.lrange(key, start, end);
/*      */     } catch (Exception ex) {
/* 2709 */       flag = false;
/* 2710 */       if (toTryCount > 0) {
/* 2711 */         this.readPool.returnBrokenResource(j);
/* 2712 */         result = lrange(toTryCount - 1, key, start, end);
/*      */       } else {
/* 2714 */         this.writePool.returnBrokenResource(j);
/* 2715 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 2718 */       if (flag) {
/* 2719 */         if (toTryCount > 0)
/* 2720 */           this.readPool.returnResource(j);
/*      */         else {
/* 2722 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 2726 */     return result;
/*      */   }
/*      */ 
/*      */   public String ltrim(String key, long start, long end)
/*      */     throws RedisAccessException
/*      */   {
/* 2736 */     boolean flag = true;
/* 2737 */     ShardedJedis j = null;
/* 2738 */     String result = null;
/*      */     try {
/* 2740 */       j = (ShardedJedis)this.writePool.getResource();
/* 2741 */       result = j.ltrim(key, start, end);
/*      */     } catch (Exception ex) {
/* 2743 */       flag = false;
/* 2744 */       this.writePool.returnBrokenResource(j);
/* 2745 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2747 */       if (flag) {
/* 2748 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2751 */     return result;
/*      */   }
/*      */ 
/*      */   public String lindex(String key, long index)
/*      */     throws RedisAccessException
/*      */   {
/* 2761 */     return lindex(this.redundancyFactor, key, index);
/*      */   }
/*      */ 
/*      */   private String lindex(int toTryCount, String key, long index) throws RedisAccessException {
/* 2765 */     String result = null;
/* 2766 */     ShardedJedis j = null;
/* 2767 */     boolean flag = true;
/*      */     try {
/* 2769 */       if (toTryCount > 0)
/* 2770 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 2772 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 2774 */       result = j.lindex(key, index);
/*      */     } catch (Exception ex) {
/* 2776 */       flag = false;
/* 2777 */       if (toTryCount > 0) {
/* 2778 */         this.readPool.returnBrokenResource(j);
/* 2779 */         result = lindex(toTryCount - 1, key, index);
/*      */       } else {
/* 2781 */         this.writePool.returnBrokenResource(j);
/* 2782 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 2785 */       if (flag) {
/* 2786 */         if (toTryCount > 0)
/* 2787 */           this.readPool.returnResource(j);
/*      */         else {
/* 2789 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 2793 */     return result;
/*      */   }
/*      */ 
/*      */   public String lset(String key, long index, String value)
/*      */     throws RedisAccessException
/*      */   {
/* 2803 */     boolean flag = true;
/* 2804 */     ShardedJedis j = null;
/* 2805 */     String result = null;
/*      */     try {
/* 2807 */       j = (ShardedJedis)this.writePool.getResource();
/* 2808 */       result = j.lset(key, index, value);
/*      */     } catch (Exception ex) {
/* 2810 */       flag = false;
/* 2811 */       this.writePool.returnBrokenResource(j);
/* 2812 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2814 */       if (flag) {
/* 2815 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2818 */     return result;
/*      */   }
/*      */ 
/*      */   public Long lrem(String key, long count, String value)
/*      */     throws RedisAccessException
/*      */   {
/* 2828 */     boolean flag = true;
/* 2829 */     ShardedJedis j = null;
/* 2830 */     Long result = null;
/*      */     try {
/* 2832 */       j = (ShardedJedis)this.writePool.getResource();
/* 2833 */       result = j.lrem(key, count, value);
/*      */     } catch (Exception ex) {
/* 2835 */       flag = false;
/* 2836 */       this.writePool.returnBrokenResource(j);
/* 2837 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2839 */       if (flag) {
/* 2840 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2843 */     return result;
/*      */   }
/*      */ 
/*      */   public String lpop(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 2853 */     boolean flag = true;
/* 2854 */     ShardedJedis j = null;
/* 2855 */     String result = null;
/*      */     try {
/* 2857 */       j = (ShardedJedis)this.writePool.getResource();
/* 2858 */       result = j.lpop(key);
/*      */     } catch (Exception ex) {
/* 2860 */       flag = false;
/* 2861 */       this.writePool.returnBrokenResource(j);
/* 2862 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2864 */       if (flag) {
/* 2865 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2868 */     return result;
/*      */   }
/*      */ 
/*      */   public List<String> blpop(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 2877 */     boolean flag = true;
/* 2878 */     ShardedJedis j = null;
/* 2879 */     List result = null;
/*      */     try {
/* 2881 */       j = (ShardedJedis)this.writePool.getResource();
/* 2882 */       result = j.blpop(this.timeout, key);
/*      */     } catch (Exception ex) {
/* 2884 */       flag = false;
/* 2885 */       this.writePool.returnBrokenResource(j);
/* 2886 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2888 */       if (flag) {
/* 2889 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2892 */     return result;
/*      */   }
/*      */ 
/*      */   public String rpop(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 2902 */     boolean flag = true;
/* 2903 */     ShardedJedis j = null;
/* 2904 */     String result = null;
/*      */     try {
/* 2906 */       j = (ShardedJedis)this.writePool.getResource();
/* 2907 */       result = j.rpop(key);
/*      */     } catch (Exception ex) {
/* 2909 */       flag = false;
/* 2910 */       this.writePool.returnBrokenResource(j);
/* 2911 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2913 */       if (flag) {
/* 2914 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2917 */     return result;
/*      */   }
/*      */ 
/*      */   public Long linsert(String key, BinaryClient.LIST_POSITION where, String pivot, String value)
/*      */     throws RedisAccessException
/*      */   {
/* 2928 */     boolean flag = true;
/* 2929 */     ShardedJedis j = null;
/* 2930 */     Long result = null;
/*      */     try {
/* 2932 */       j = (ShardedJedis)this.writePool.getResource();
/* 2933 */       result = j.linsert(key, where, pivot, value);
/*      */     } catch (Exception ex) {
/* 2935 */       flag = false;
/* 2936 */       this.writePool.returnBrokenResource(j);
/* 2937 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2939 */       if (flag) {
/* 2940 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2943 */     return result;
/*      */   }
/*      */ 
/*      */   public Long sadd(String key, String member)
/*      */     throws RedisAccessException
/*      */   {
/* 2953 */     boolean flag = true;
/* 2954 */     ShardedJedis j = null;
/* 2955 */     Long result = null;
/*      */     try {
/* 2957 */       j = (ShardedJedis)this.writePool.getResource();
/* 2958 */       result = j.sadd(key, new String[] { member });
/*      */     } catch (Exception ex) {
/* 2960 */       flag = false;
/* 2961 */       this.writePool.returnBrokenResource(j);
/* 2962 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 2964 */       if (flag) {
/* 2965 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 2968 */     return result;
/*      */   }
/*      */ 
/*      */   public Set<String> smembers(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 2977 */     return smembers(this.redundancyFactor, key);
/*      */   }
/*      */   private Set<String> smembers(int toTryCount, String key) throws RedisAccessException {
/* 2980 */     Set result = null;
/* 2981 */     ShardedJedis j = null;
/* 2982 */     boolean flag = true;
/*      */     try {
/* 2984 */       if (toTryCount > 0)
/* 2985 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 2987 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 2989 */       result = j.smembers(key);
/*      */     } catch (Exception ex) {
/* 2991 */       flag = false;
/* 2992 */       if (toTryCount > 0) {
/* 2993 */         this.readPool.returnBrokenResource(j);
/* 2994 */         result = smembers(toTryCount - 1, key);
/*      */       } else {
/* 2996 */         this.writePool.returnBrokenResource(j);
/* 2997 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3000 */       if (flag) {
/* 3001 */         if (toTryCount > 0)
/* 3002 */           this.readPool.returnResource(j);
/*      */         else {
/* 3004 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3008 */     return result;
/*      */   }
/*      */ 
/*      */   public Long srem(String key, String member)
/*      */     throws RedisAccessException
/*      */   {
/* 3018 */     boolean flag = true;
/* 3019 */     ShardedJedis j = null;
/* 3020 */     Long result = null;
/*      */     try {
/* 3022 */       j = (ShardedJedis)this.writePool.getResource();
/* 3023 */       result = j.srem(key, new String[] { member });
/*      */     } catch (Exception ex) {
/* 3025 */       flag = false;
/* 3026 */       this.writePool.returnBrokenResource(j);
/* 3027 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 3029 */       if (flag) {
/* 3030 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 3033 */     return result;
/*      */   }
/*      */ 
/*      */   public String spop(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 3042 */     boolean flag = true;
/* 3043 */     ShardedJedis j = null;
/* 3044 */     String result = null;
/*      */     try {
/* 3046 */       j = (ShardedJedis)this.writePool.getResource();
/* 3047 */       result = j.spop(key);
/*      */     } catch (Exception ex) {
/* 3049 */       flag = false;
/* 3050 */       this.writePool.returnBrokenResource(j);
/* 3051 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 3053 */       if (flag) {
/* 3054 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 3057 */     return result;
/*      */   }
/*      */ 
/*      */   public Long scard(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 3065 */     return scard(this.redundancyFactor, key);
/*      */   }
/*      */ 
/*      */   private Long scard(int toTryCount, String key) throws RedisAccessException {
/* 3069 */     Long result = null;
/* 3070 */     ShardedJedis j = null;
/* 3071 */     boolean flag = true;
/*      */     try {
/* 3073 */       if (toTryCount > 0)
/* 3074 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3076 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3078 */       result = j.scard(key);
/*      */     } catch (Exception ex) {
/* 3080 */       flag = false;
/* 3081 */       if (toTryCount > 0) {
/* 3082 */         this.readPool.returnBrokenResource(j);
/* 3083 */         result = scard(toTryCount - 1, key);
/*      */       } else {
/* 3085 */         this.writePool.returnBrokenResource(j);
/* 3086 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3089 */       if (flag) {
/* 3090 */         if (toTryCount > 0)
/* 3091 */           this.readPool.returnResource(j);
/*      */         else {
/* 3093 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3097 */     return result;
/*      */   }
/*      */ 
/*      */   public Boolean sismember(String key, String member)
/*      */     throws RedisAccessException
/*      */   {
/* 3106 */     return sismember(this.redundancyFactor, key, member);
/*      */   }
/*      */ 
/*      */   private Boolean sismember(int toTryCount, String key, String member) throws RedisAccessException {
/* 3110 */     Boolean result = null;
/* 3111 */     ShardedJedis j = null;
/* 3112 */     boolean flag = true;
/*      */     try {
/* 3114 */       if (toTryCount > 0)
/* 3115 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3117 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3119 */       result = j.sismember(key, member);
/*      */     } catch (Exception ex) {
/* 3121 */       flag = false;
/* 3122 */       if (toTryCount > 0) {
/* 3123 */         this.readPool.returnBrokenResource(j);
/* 3124 */         result = sismember(toTryCount - 1, key, member);
/*      */       } else {
/* 3126 */         this.writePool.returnBrokenResource(j);
/* 3127 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3130 */       if (flag) {
/* 3131 */         if (toTryCount > 0)
/* 3132 */           this.readPool.returnResource(j);
/*      */         else {
/* 3134 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3138 */     return result;
/*      */   }
/*      */ 
/*      */   public String srandmember(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 3147 */     return srandmember(this.redundancyFactor, key);
/*      */   }
/*      */ 
/*      */   private String srandmember(int toTryCount, String key) throws RedisAccessException {
/* 3151 */     String result = null;
/* 3152 */     ShardedJedis j = null;
/* 3153 */     boolean flag = true;
/*      */     try {
/* 3155 */       if (toTryCount > 0)
/* 3156 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3158 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3160 */       result = j.srandmember(key);
/*      */     } catch (Exception ex) {
/* 3162 */       flag = false;
/* 3163 */       if (toTryCount > 0) {
/* 3164 */         this.readPool.returnBrokenResource(j);
/* 3165 */         result = srandmember(toTryCount - 1, key);
/*      */       } else {
/* 3167 */         this.writePool.returnBrokenResource(j);
/* 3168 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3171 */       if (flag) {
/* 3172 */         if (toTryCount > 0)
/* 3173 */           this.readPool.returnResource(j);
/*      */         else {
/* 3175 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3179 */     return result;
/*      */   }
/*      */ 
/*      */   public Long zadd(String key, double score, String member)
/*      */     throws RedisAccessException
/*      */   {
/* 3190 */     boolean flag = true;
/* 3191 */     ShardedJedis j = null;
/* 3192 */     Long result = null;
/*      */     try {
/* 3194 */       j = (ShardedJedis)this.writePool.getResource();
/* 3195 */       result = j.zadd(key, score, member);
/*      */     } catch (Exception ex) {
/* 3197 */       flag = false;
/* 3198 */       this.writePool.returnBrokenResource(j);
/*      */     } finally {
/* 3200 */       if (flag) {
/* 3201 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 3204 */     return result;
/*      */   }
/*      */ 
/*      */   public Long zadd(String key, Map member)
/*      */     throws RedisAccessException
/*      */   {
/* 3214 */     boolean flag = true;
/* 3215 */     ShardedJedis j = null;
/* 3216 */     Long result = null;
/*      */     try {
/* 3218 */       j = (ShardedJedis)this.writePool.getResource();
/* 3219 */       result = j.zadd(key, member);
/*      */     } catch (Exception ex) {
/* 3221 */       flag = false;
/* 3222 */       this.writePool.returnBrokenResource(j);
/*      */     } finally {
/* 3224 */       if (flag) {
/* 3225 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 3228 */     return result;
/*      */   }
/*      */ 
/*      */   public Set<String> zrange(String key, int start, int end)
/*      */     throws RedisAccessException
/*      */   {
/* 3238 */     return zrange(this.redundancyFactor, key, start, end);
/*      */   }
/*      */ 
/*      */   private Set<String> zrange(int toTryCount, String key, int start, int end) throws RedisAccessException {
/* 3242 */     Set result = null;
/* 3243 */     ShardedJedis j = null;
/* 3244 */     boolean flag = true;
/*      */     try {
/* 3246 */       if (toTryCount > 0)
/* 3247 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3249 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3251 */       result = j.zrange(key, start, end);
/*      */     } catch (Exception ex) {
/* 3253 */       flag = false;
/* 3254 */       if (toTryCount > 0) {
/* 3255 */         this.readPool.returnBrokenResource(j);
/* 3256 */         result = zrange(toTryCount - 1, key, start, end);
/*      */       } else {
/* 3258 */         this.writePool.returnBrokenResource(j);
/* 3259 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3262 */       if (flag) {
/* 3263 */         if (toTryCount > 0)
/* 3264 */           this.readPool.returnResource(j);
/*      */         else {
/* 3266 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3270 */     return result;
/*      */   }
/*      */ 
/*      */   public Long zrem(String key, String member)
/*      */     throws RedisAccessException
/*      */   {
/* 3279 */     boolean flag = true;
/* 3280 */     ShardedJedis j = null;
/* 3281 */     Long result = null;
/*      */     try {
/* 3283 */       j = (ShardedJedis)this.writePool.getResource();
/* 3284 */       result = j.zrem(key, new String[] { member });
/*      */     } catch (Exception ex) {
/* 3286 */       flag = false;
/* 3287 */       this.writePool.returnBrokenResource(j);
/* 3288 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 3290 */       if (flag) {
/* 3291 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 3294 */     return result;
/*      */   }
/*      */ 
/*      */   public Double zincrby(String key, double score, String member)
/*      */     throws RedisAccessException
/*      */   {
/* 3305 */     boolean flag = true;
/* 3306 */     ShardedJedis j = null;
/* 3307 */     double result = -1.0D;
/*      */     try {
/* 3309 */       j = (ShardedJedis)this.writePool.getResource();
/* 3310 */       result = j.zincrby(key, score, member).doubleValue();
/*      */     } catch (Exception ex) {
/* 3312 */       flag = false;
/* 3313 */       this.writePool.returnBrokenResource(j);
/* 3314 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 3316 */       if (flag) {
/* 3317 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 3320 */     return Double.valueOf(result);
/*      */   }
/*      */ 
/*      */   public Long zrank(String key, String member)
/*      */     throws RedisAccessException
/*      */   {
/* 3330 */     return zrank(this.redundancyFactor, key, member);
/*      */   }
/*      */ 
/*      */   private Long zrank(int toTryCount, String key, String member) throws RedisAccessException {
/* 3334 */     Long result = null;
/* 3335 */     ShardedJedis j = null;
/* 3336 */     boolean flag = true;
/*      */     try {
/* 3338 */       if (toTryCount > 0)
/* 3339 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3341 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3343 */       result = j.zrank(key, member);
/*      */     } catch (Exception ex) {
/* 3345 */       flag = false;
/* 3346 */       if (toTryCount > 0) {
/* 3347 */         this.readPool.returnBrokenResource(j);
/* 3348 */         result = zrank(toTryCount - 1, key, member);
/*      */       } else {
/* 3350 */         this.writePool.returnBrokenResource(j);
/* 3351 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3354 */       if (flag) {
/* 3355 */         if (toTryCount > 0)
/* 3356 */           this.readPool.returnResource(j);
/*      */         else {
/* 3358 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3362 */     return result;
/*      */   }
/*      */ 
/*      */   public Long zrevrank(String key, String member)
/*      */     throws RedisAccessException
/*      */   {
/* 3372 */     return zrevrank(this.redundancyFactor, key, member);
/*      */   }
/*      */ 
/*      */   private Long zrevrank(int toTryCount, String key, String member) throws RedisAccessException {
/* 3376 */     Long result = null;
/* 3377 */     ShardedJedis j = null;
/* 3378 */     boolean flag = true;
/*      */     try {
/* 3380 */       if (toTryCount > 0)
/* 3381 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3383 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3385 */       result = j.zrevrank(key, member);
/*      */     } catch (Exception ex) {
/* 3387 */       flag = false;
/* 3388 */       if (toTryCount > 0) {
/* 3389 */         this.readPool.returnBrokenResource(j);
/* 3390 */         result = zrevrank(toTryCount - 1, key, member);
/*      */       } else {
/* 3392 */         this.writePool.returnBrokenResource(j);
/* 3393 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3396 */       if (flag) {
/* 3397 */         if (toTryCount > 0)
/* 3398 */           this.readPool.returnResource(j);
/*      */         else {
/* 3400 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3404 */     return result;
/*      */   }
/*      */ 
/*      */   public Set<String> zrevrange(String key, int start, int end)
/*      */     throws RedisAccessException
/*      */   {
/* 3414 */     return zrevrange(this.redundancyFactor, key, start, end);
/*      */   }
/*      */ 
/*      */   private Set<String> zrevrange(int toTryCount, String key, int start, int end) throws RedisAccessException {
/* 3418 */     Set result = null;
/* 3419 */     ShardedJedis j = null;
/* 3420 */     boolean flag = true;
/*      */     try {
/* 3422 */       if (toTryCount > 0)
/* 3423 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3425 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3427 */       result = j.zrevrange(key, start, end);
/*      */     } catch (Exception ex) {
/* 3429 */       flag = false;
/* 3430 */       if (toTryCount > 0) {
/* 3431 */         this.readPool.returnBrokenResource(j);
/* 3432 */         result = zrevrange(toTryCount - 1, key, start, end);
/*      */       } else {
/* 3434 */         this.writePool.returnBrokenResource(j);
/* 3435 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3438 */       if (flag) {
/* 3439 */         if (toTryCount > 0)
/* 3440 */           this.readPool.returnResource(j);
/*      */         else {
/* 3442 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3446 */     return result;
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrevrangeWithScores(String key, int start, int end)
/*      */     throws RedisAccessException
/*      */   {
/* 3459 */     return zrevrangeWithScores(this.redundancyFactor, key, start, end);
/*      */   }
/*      */ 
/*      */   private Set<Tuple> zrevrangeWithScores(int toTryCount, String key, int start, int end) throws RedisAccessException {
/* 3463 */     Set result = null;
/* 3464 */     ShardedJedis j = null;
/* 3465 */     boolean flag = true;
/*      */     try {
/* 3467 */       if (toTryCount > 0)
/* 3468 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3470 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3472 */       result = j.zrevrangeWithScores(key, start, end);
/*      */     } catch (Exception ex) {
/* 3474 */       flag = false;
/* 3475 */       if (toTryCount > 0) {
/* 3476 */         this.readPool.returnBrokenResource(j);
/* 3477 */         result = zrevrangeWithScores(toTryCount - 1, key, start, end);
/*      */       } else {
/* 3479 */         this.writePool.returnBrokenResource(j);
/* 3480 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3483 */       if (flag) {
/* 3484 */         if (toTryCount > 0)
/* 3485 */           this.readPool.returnResource(j);
/*      */         else {
/* 3487 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3491 */     return result;
/*      */   }
/*      */ 
/*      */   public Long zcard(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 3499 */     return zcard(this.redundancyFactor, key);
/*      */   }
/*      */ 
/*      */   private Long zcard(int toTryCount, String key) throws RedisAccessException {
/* 3503 */     Long result = null;
/* 3504 */     ShardedJedis j = null;
/* 3505 */     boolean flag = true;
/*      */     try {
/* 3507 */       if (toTryCount > 0)
/* 3508 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3510 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3512 */       result = j.zcard(key);
/*      */     } catch (Exception ex) {
/* 3514 */       flag = false;
/* 3515 */       if (toTryCount > 0) {
/* 3516 */         this.readPool.returnBrokenResource(j);
/* 3517 */         result = zcard(toTryCount - 1, key);
/*      */       } else {
/* 3519 */         this.writePool.returnBrokenResource(j);
/* 3520 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3523 */       if (flag) {
/* 3524 */         if (toTryCount > 0)
/* 3525 */           this.readPool.returnResource(j);
/*      */         else {
/* 3527 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3531 */     return result;
/*      */   }
/*      */ 
/*      */   public Double zscore(String key, String member)
/*      */     throws RedisAccessException
/*      */   {
/* 3540 */     return zscore(this.redundancyFactor, key, member);
/*      */   }
/*      */ 
/*      */   private Double zscore(int toTryCount, String key, String member) throws RedisAccessException {
/* 3544 */     Double result = null;
/* 3545 */     ShardedJedis j = null;
/* 3546 */     boolean flag = true;
/*      */     try {
/* 3548 */       if (toTryCount > 0)
/* 3549 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3551 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3553 */       result = j.zscore(key, member);
/*      */     } catch (Exception ex) {
/* 3555 */       flag = false;
/* 3556 */       if (toTryCount > 0) {
/* 3557 */         this.readPool.returnBrokenResource(j);
/* 3558 */         result = zscore(toTryCount - 1, key, member);
/*      */       } else {
/* 3560 */         this.writePool.returnBrokenResource(j);
/* 3561 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3564 */       if (flag) {
/* 3565 */         if (toTryCount > 0)
/* 3566 */           this.readPool.returnResource(j);
/*      */         else {
/* 3568 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3572 */     return result;
/*      */   }
/*      */ 
/*      */   public List<String> sort(String key)
/*      */     throws RedisAccessException
/*      */   {
/* 3581 */     return sort(this.redundancyFactor, key);
/*      */   }
/*      */ 
/*      */   private List<String> sort(int toTryCount, String key) throws RedisAccessException {
/* 3585 */     List result = null;
/* 3586 */     ShardedJedis j = null;
/* 3587 */     boolean flag = true;
/*      */     try {
/* 3589 */       if (toTryCount > 0)
/* 3590 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3592 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3594 */       result = j.sort(key);
/*      */     } catch (Exception ex) {
/* 3596 */       flag = false;
/* 3597 */       if (toTryCount > 0) {
/* 3598 */         this.readPool.returnBrokenResource(j);
/* 3599 */         result = sort(toTryCount - 1, key);
/*      */       } else {
/* 3601 */         this.writePool.returnBrokenResource(j);
/* 3602 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3605 */       if (flag) {
/* 3606 */         if (toTryCount > 0)
/* 3607 */           this.readPool.returnResource(j);
/*      */         else {
/* 3609 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3613 */     return result;
/*      */   }
/*      */ 
/*      */   public List<String> sort(String key, SortingParams sortingParameters)
/*      */     throws RedisAccessException
/*      */   {
/* 3622 */     boolean flag = true;
/* 3623 */     ShardedJedis j = null;
/* 3624 */     List result = null;
/*      */     try {
/* 3626 */       j = (ShardedJedis)this.writePool.getResource();
/* 3627 */       result = j.sort(key, sortingParameters);
/*      */     } catch (Exception ex) {
/* 3629 */       flag = false;
/* 3630 */       this.writePool.returnBrokenResource(j);
/* 3631 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 3633 */       if (flag) {
/* 3634 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 3637 */     return result;
/*      */   }
/*      */ 
/*      */   public Long zcount(String key, double min, double max)
/*      */     throws RedisAccessException
/*      */   {
/* 3646 */     return zcount(this.redundancyFactor, key, min, max);
/*      */   }
/*      */ 
/*      */   private Long zcount(int toTryCount, String key, double min, double max) throws RedisAccessException {
/* 3650 */     Long result = null;
/* 3651 */     ShardedJedis j = null;
/* 3652 */     boolean flag = true;
/*      */     try {
/* 3654 */       if (toTryCount > 0)
/* 3655 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3657 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3659 */       result = j.zcount(key, min, max);
/*      */     } catch (Exception ex) {
/* 3661 */       flag = false;
/* 3662 */       if (toTryCount > 0) {
/* 3663 */         this.readPool.returnBrokenResource(j);
/* 3664 */         result = zcount(toTryCount - 1, key, min, max);
/*      */       } else {
/* 3666 */         this.writePool.returnBrokenResource(j);
/* 3667 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3670 */       if (flag) {
/* 3671 */         if (toTryCount > 0)
/* 3672 */           this.readPool.returnResource(j);
/*      */         else {
/* 3674 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3678 */     return result;
/*      */   }
/*      */ 
/*      */   public Set<String> zrangeByScore(String key, double min, double max)
/*      */     throws RedisAccessException
/*      */   {
/* 3688 */     return zrangeByScore(this.redundancyFactor, key, min, max);
/*      */   }
/*      */ 
/*      */   private Set<String> zrangeByScore(int toTryCount, String key, double min, double max) throws RedisAccessException {
/* 3692 */     Set result = null;
/* 3693 */     ShardedJedis j = null;
/* 3694 */     boolean flag = true;
/*      */     try {
/* 3696 */       if (toTryCount > 0)
/* 3697 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3699 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3701 */       result = j.zrangeByScore(key, min, max);
/*      */     } catch (Exception ex) {
/* 3703 */       flag = false;
/* 3704 */       if (toTryCount > 0) {
/* 3705 */         this.readPool.returnBrokenResource(j);
/* 3706 */         result = zrangeByScore(toTryCount - 1, key, min, max);
/*      */       } else {
/* 3708 */         this.writePool.returnBrokenResource(j);
/* 3709 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3712 */       if (flag) {
/* 3713 */         if (toTryCount > 0)
/* 3714 */           this.readPool.returnResource(j);
/*      */         else {
/* 3716 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3720 */     return result;
/*      */   }
/*      */ 
/*      */   public Set<String> zrevrangeByScore(String key, double max, double min)
/*      */     throws RedisAccessException
/*      */   {
/* 3730 */     return zrevrangeByScore(this.redundancyFactor, key, max, min);
/*      */   }
/*      */ 
/*      */   private Set<String> zrevrangeByScore(int toTryCount, String key, double max, double min) throws RedisAccessException {
/* 3734 */     Set result = null;
/* 3735 */     ShardedJedis j = null;
/* 3736 */     boolean flag = true;
/*      */     try {
/* 3738 */       if (toTryCount > 0)
/* 3739 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3741 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3743 */       result = j.zrevrangeByScore(key, max, min);
/*      */     } catch (Exception ex) {
/* 3745 */       flag = false;
/* 3746 */       if (toTryCount > 0) {
/* 3747 */         this.readPool.returnBrokenResource(j);
/* 3748 */         result = zrevrangeByScore(toTryCount - 1, key, max, min);
/*      */       } else {
/* 3750 */         this.writePool.returnBrokenResource(j);
/* 3751 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3754 */       if (flag) {
/* 3755 */         if (toTryCount > 0)
/* 3756 */           this.readPool.returnResource(j);
/*      */         else {
/* 3758 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3762 */     return result;
/*      */   }
/*      */ 
/*      */   public Set<String> zrangeByScore(String key, double min, double max, int offset, int count)
/*      */     throws RedisAccessException
/*      */   {
/* 3775 */     return zrangeByScore(this.redundancyFactor, key, min, max, offset, count);
/*      */   }
/*      */ 
/*      */   private Set<String> zrangeByScore(int toTryCount, String key, double min, double max, int offset, int count) throws RedisAccessException {
/* 3779 */     Set result = null;
/* 3780 */     ShardedJedis j = null;
/* 3781 */     boolean flag = true;
/*      */     try {
/* 3783 */       if (toTryCount > 0)
/* 3784 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3786 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3788 */       result = j.zrangeByScore(key, min, max, offset, count);
/*      */     } catch (Exception ex) {
/* 3790 */       flag = false;
/* 3791 */       if (toTryCount > 0) {
/* 3792 */         this.readPool.returnBrokenResource(j);
/* 3793 */         result = zrangeByScore(toTryCount - 1, key, min, max, offset, count);
/*      */       } else {
/* 3795 */         this.writePool.returnBrokenResource(j);
/* 3796 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3799 */       if (flag) {
/* 3800 */         if (toTryCount > 0)
/* 3801 */           this.readPool.returnResource(j);
/*      */         else {
/* 3803 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3807 */     return result;
/*      */   }
/*      */ 
/*      */   public Set<String> zrevrangeByScore(String key, double max, double min, int offset, int count)
/*      */     throws RedisAccessException
/*      */   {
/* 3820 */     return zrevrangeByScore(this.redundancyFactor, key, max, min, offset, count);
/*      */   }
/*      */ 
/*      */   private Set<String> zrevrangeByScore(int toTryCount, String key, double max, double min, int offset, int count) throws RedisAccessException {
/* 3824 */     Set result = null;
/* 3825 */     ShardedJedis j = null;
/* 3826 */     boolean flag = true;
/*      */     try {
/* 3828 */       if (toTryCount > 0)
/* 3829 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3831 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3833 */       result = j.zrevrangeByScore(key, max, min, offset, count);
/*      */     } catch (Exception ex) {
/* 3835 */       flag = false;
/* 3836 */       if (toTryCount > 0) {
/* 3837 */         this.readPool.returnBrokenResource(j);
/* 3838 */         result = zrevrangeByScore(toTryCount - 1, key, max, min, offset, count);
/*      */       } else {
/* 3840 */         this.writePool.returnBrokenResource(j);
/* 3841 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3844 */       if (flag) {
/* 3845 */         if (toTryCount > 0)
/* 3846 */           this.readPool.returnResource(j);
/*      */         else {
/* 3848 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3852 */     return result;
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrangeByScoreWithScores(String key, double min, double max)
/*      */     throws RedisAccessException
/*      */   {
/* 3863 */     return zrangeByScoreWithScores(this.redundancyFactor, key, min, max);
/*      */   }
/*      */ 
/*      */   private Set<Tuple> zrangeByScoreWithScores(int toTryCount, String key, double min, double max) throws RedisAccessException {
/* 3867 */     Set result = null;
/* 3868 */     ShardedJedis j = null;
/* 3869 */     boolean flag = true;
/*      */     try {
/* 3871 */       if (toTryCount > 0)
/* 3872 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3874 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3876 */       result = j.zrangeByScoreWithScores(key, min, max);
/*      */     } catch (Exception ex) {
/* 3878 */       flag = false;
/* 3879 */       if (toTryCount > 0) {
/* 3880 */         this.readPool.returnBrokenResource(j);
/* 3881 */         result = zrangeByScoreWithScores(toTryCount - 1, key, min, max);
/*      */       } else {
/* 3883 */         this.writePool.returnBrokenResource(j);
/* 3884 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3887 */       if (flag) {
/* 3888 */         if (toTryCount > 0)
/* 3889 */           this.readPool.returnResource(j);
/*      */         else {
/* 3891 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3895 */     return result;
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrangeByScoreWithScores(String key, double min, double max, int offset, int count)
/*      */     throws RedisAccessException
/*      */   {
/* 3909 */     return zrangeByScoreWithScores(this.redundancyFactor, key, min, max, offset, count);
/*      */   }
/*      */ 
/*      */   private Set<Tuple> zrangeByScoreWithScores(int toTryCount, String key, double min, double max, int offset, int count) throws RedisAccessException {
/* 3913 */     Set result = null;
/* 3914 */     ShardedJedis j = null;
/* 3915 */     boolean flag = true;
/*      */     try {
/* 3917 */       if (toTryCount > 0)
/* 3918 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3920 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3922 */       result = j.zrangeByScoreWithScores(key, min, max, offset, count);
/*      */     } catch (Exception ex) {
/* 3924 */       flag = false;
/* 3925 */       if (toTryCount > 0) {
/* 3926 */         this.readPool.returnBrokenResource(j);
/* 3927 */         result = zrangeByScoreWithScores(toTryCount - 1, key, min, max, offset, count);
/*      */       } else {
/* 3929 */         this.writePool.returnBrokenResource(j);
/* 3930 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3933 */       if (flag) {
/* 3934 */         if (toTryCount > 0)
/* 3935 */           this.readPool.returnResource(j);
/*      */         else {
/* 3937 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3941 */     return result;
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrevrangeByScoreWithScores(String key, double max, double min, int offset, int count)
/*      */     throws RedisAccessException
/*      */   {
/* 3954 */     return zrevrangeByScoreWithScores(this.redundancyFactor, key, max, min, offset, count);
/*      */   }
/*      */ 
/*      */   private Set<Tuple> zrevrangeByScoreWithScores(int toTryCount, String key, double max, double min, int offset, int count) throws RedisAccessException {
/* 3958 */     Set result = null;
/* 3959 */     ShardedJedis j = null;
/* 3960 */     boolean flag = true;
/*      */     try {
/* 3962 */       if (toTryCount > 0)
/* 3963 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 3965 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 3967 */       result = j.zrevrangeByScoreWithScores(key, min, max, offset, count);
/*      */     } catch (Exception ex) {
/* 3969 */       flag = false;
/* 3970 */       if (toTryCount > 0) {
/* 3971 */         this.readPool.returnBrokenResource(j);
/* 3972 */         result = zrevrangeByScoreWithScores(toTryCount - 1, key, min, max, offset, count);
/*      */       } else {
/* 3974 */         this.writePool.returnBrokenResource(j);
/* 3975 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 3978 */       if (flag) {
/* 3979 */         if (toTryCount > 0)
/* 3980 */           this.readPool.returnResource(j);
/*      */         else {
/* 3982 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 3986 */     return result;
/*      */   }
/*      */ 
/*      */   public Long zremrangeByRank(String key, int start, int end)
/*      */     throws RedisAccessException
/*      */   {
/* 3997 */     boolean flag = true;
/* 3998 */     ShardedJedis j = null;
/* 3999 */     Long result = null;
/*      */     try {
/* 4001 */       j = (ShardedJedis)this.writePool.getResource();
/* 4002 */       result = j.zremrangeByRank(key, start, end);
/*      */     } catch (Exception ex) {
/* 4004 */       flag = false;
/* 4005 */       this.writePool.returnBrokenResource(j);
/* 4006 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 4008 */       if (flag) {
/* 4009 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 4012 */     return result;
/*      */   }
/*      */ 
/*      */   public Long zremrangeByScore(String key, double start, double end)
/*      */     throws RedisAccessException
/*      */   {
/* 4023 */     boolean flag = true;
/* 4024 */     ShardedJedis j = null;
/* 4025 */     Long result = null;
/*      */     try {
/* 4027 */       j = (ShardedJedis)this.writePool.getResource();
/* 4028 */       result = j.zremrangeByScore(key, start, end);
/*      */     } catch (Exception ex) {
/* 4030 */       flag = false;
/* 4031 */       this.writePool.returnBrokenResource(j);
/* 4032 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 4034 */       if (flag) {
/* 4035 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 4038 */     return result;
/*      */   }
/*      */ 
/*      */   public String set(byte[] key, byte[] value)
/*      */     throws RedisAccessException
/*      */   {
/* 4048 */     boolean flag = true;
/* 4049 */     ShardedJedis j = null;
/* 4050 */     String result = null;
/*      */     try {
/* 4052 */       j = (ShardedJedis)this.writePool.getResource();
/* 4053 */       result = j.set(key, value);
/*      */     } catch (Exception ex) {
/* 4055 */       flag = false;
/* 4056 */       this.writePool.returnBrokenResource(j);
/* 4057 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 4059 */       if (flag) {
/* 4060 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 4063 */     return result;
/*      */   }
/*      */ 
/*      */   public String set(String key, String value)
/*      */     throws RedisAccessException
/*      */   {
/* 4073 */     boolean flag = true;
/* 4074 */     ShardedJedis j = null;
/* 4075 */     String result = null;
/*      */     try {
/* 4077 */       j = (ShardedJedis)this.writePool.getResource();
/* 4078 */       result = j.set(key, value);
/*      */     } catch (Exception ex) {
/* 4080 */       flag = false;
/* 4081 */       this.writePool.returnBrokenResource(j);
/* 4082 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 4084 */       if (flag) {
/* 4085 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 4088 */     return result;
/*      */   }
/*      */ 
/*      */   public List<Object> set(String key, int seconds, String value)
/*      */     throws RedisAccessException
/*      */   {
/* 4100 */     boolean flag = true;
/* 4101 */     ShardedJedis j = null;
/* 4102 */     List result = null;
/* 4103 */     Pipeline p = null;
/*      */     try {
/* 4105 */       j = (ShardedJedis)this.writePool.getResource();
/* 4106 */       p = ((Jedis)j.getShard(key)).pipelined();
/* 4107 */       p.set(key, value);
/* 4108 */       p.expire(key, seconds);
/* 4109 */       result = p.syncAndReturnAll();
/*      */     } catch (Exception ex) {
/* 4111 */       flag = false;
/* 4112 */       this.writePool.returnBrokenResource(j);
/* 4113 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 4115 */       if (flag) {
/* 4116 */         this.writePool.returnResource(j);
/*      */       }
/* 4118 */       p = null;
/*      */     }
/* 4120 */     return result;
/*      */   }
/*      */   public long zadd(byte[] key, int score, byte[] value) throws RedisAccessException {
/* 4131 */     boolean flag = true;
/* 4132 */     ShardedJedis j = null;
/*      */     long result;
/*      */     try {
/* 4135 */       j = (ShardedJedis)this.writePool.getResource();
/* 4136 */       result = j.zadd(key, score, value).longValue();
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*      */       long result;
/* 4138 */       flag = false;
/* 4139 */       this.writePool.returnBrokenResource(j);
/* 4140 */       throw new RedisAccessException(ex);
/*      */     } finally {
/* 4142 */       if (flag) {
/* 4143 */         this.writePool.returnResource(j);
/*      */       }
/*      */     }
/* 4146 */     return result;
/*      */   }
/*      */ 
/*      */   public String zelementAtScore(String key, int score)
/*      */     throws RedisAccessException
/*      */   {
/* 4157 */     byte[] temp = zelementAtScore(this.redundancyFactor, SafeEncoder.encode(key), score);
/* 4158 */     if (temp == null) {
/* 4159 */       return null;
/*      */     }
/* 4161 */     return SafeEncoder.encode(temp);
/*      */   }
/*      */   public Set<Tuple> zrangeWithScores(String key, int start, int end) throws RedisAccessException {
/* 4164 */     return zrangeWithScores(this.redundancyFactor, key, start, end);
/*      */   }
/*      */ 
/*      */   private Set<Tuple> zrangeWithScores(int toTryCount, String key, int start, int end) throws RedisAccessException {
/* 4168 */     Set result = null;
/* 4169 */     ShardedJedis j = null;
/* 4170 */     boolean flag = true;
/*      */     try {
/* 4172 */       if (toTryCount > 0)
/* 4173 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 4175 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 4177 */       result = j.zrangeWithScores(key, start, end);
/*      */     } catch (Exception ex) {
/* 4179 */       flag = false;
/* 4180 */       if (toTryCount > 0) {
/* 4181 */         this.readPool.returnBrokenResource(j);
/* 4182 */         result = zrangeWithScores(toTryCount - 1, key, start, end);
/*      */       } else {
/* 4184 */         this.writePool.returnBrokenResource(j);
/* 4185 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 4188 */       if (flag) {
/* 4189 */         if (toTryCount > 0)
/* 4190 */           this.readPool.returnResource(j);
/*      */         else {
/* 4192 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 4196 */     return result;
/*      */   }
/*      */   public Set<Tuple> zrevrangeByScoreWithScores(String key, double max, double min) throws RedisAccessException {
/* 4199 */     return zrevrangeByScoreWithScores(this.redundancyFactor, key, max, min);
/*      */   }
/*      */ 
/*      */   private Set<Tuple> zrevrangeByScoreWithScores(int toTryCount, String key, double max, double min) throws RedisAccessException {
/* 4203 */     Set result = null;
/* 4204 */     ShardedJedis j = null;
/* 4205 */     boolean flag = true;
/*      */     try {
/* 4207 */       if (toTryCount > 0)
/* 4208 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 4210 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 4212 */       result = j.zrevrangeByScoreWithScores(key, max, min);
/*      */     } catch (Exception ex) {
/* 4214 */       flag = false;
/* 4215 */       if (toTryCount > 0) {
/* 4216 */         this.readPool.returnBrokenResource(j);
/* 4217 */         result = zrevrangeByScoreWithScores(toTryCount - 1, key, max, min);
/*      */       } else {
/* 4219 */         this.writePool.returnBrokenResource(j);
/* 4220 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 4223 */       if (flag) {
/* 4224 */         if (toTryCount > 0)
/* 4225 */           this.readPool.returnResource(j);
/*      */         else {
/* 4227 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 4231 */     return result;
/*      */   }
/*      */   public byte[] zelementAtScore(byte[] keyBA, int redundancyFactor, int score) throws RedisAccessException {
/* 4234 */     return zelementAtScore(redundancyFactor, keyBA, score);
/*      */   }
/*      */ 
/*      */   private byte[] zelementAtScore(int toTryCount, byte[] keyBA, int score) throws RedisAccessException {
/* 4238 */     byte[] result = (byte[])null;
/* 4239 */     ShardedJedis j = null;
/* 4240 */     boolean flag = true;
/*      */ 
/* 4242 */     label215: 
/*      */     try { if (toTryCount > 0)
/* 4243 */         j = (ShardedJedis)this.readPool.getResource();
/*      */       else {
/* 4245 */         j = (ShardedJedis)this.writePool.getResource();
/*      */       }
/* 4247 */       Set temp = j.zrange(keyBA, score, score);
/* 4248 */       if (!temp.isEmpty()) { if (temp.size() > 1) break label215; result = (byte[])temp.iterator().next(); }
/*      */     } catch (Exception ex) {
/* 4251 */       flag = false;
/* 4252 */       if (toTryCount > 0) {
/* 4253 */         this.readPool.returnBrokenResource(j);
/* 4254 */         result = zelementAtScore(toTryCount - 1, keyBA, score);
/*      */       } else {
/* 4256 */         this.writePool.returnBrokenResource(j);
/* 4257 */         throw new RedisAccessException(ex);
/*      */       }
/*      */     } finally {
/* 4260 */       if (flag) {
/* 4261 */         if (toTryCount > 0)
/* 4262 */           this.readPool.returnResource(j);
/*      */         else {
/* 4264 */           this.writePool.returnResource(j);
/*      */         }
/*      */       }
/*      */     }
/* 4268 */     return result;
/*      */   }
/*      */ 
/*      */   public void destroy() {
/* 4272 */     if (this.writePool != null) {
/* 4273 */       this.writePool.destroy();
/*      */     }
/* 4275 */     if (this.readPool != null)
/* 4276 */       this.readPool.destroy();
/*      */   }
/*      */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.config.RedisManager
 * JD-Core Version:    0.6.0
 */