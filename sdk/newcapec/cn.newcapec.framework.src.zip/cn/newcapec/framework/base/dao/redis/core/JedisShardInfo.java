/*    */ package cn.newcapec.framework.base.dao.redis.core;
/*    */ 
/*    */ import cn.newcapec.framework.base.dao.redis.util.ShardInfo;
/*    */ import java.net.URI;
/*    */ 
/*    */ public class JedisShardInfo extends ShardInfo<Jedis>
/*    */ {
/*    */   private int timeout;
/*    */   private String host;
/*    */   private int port;
/* 16 */   private String password = null;
/* 17 */   private String name = null;
/*    */ 
/*    */   public String toString()
/*    */   {
/* 10 */     return this.host + ":" + this.port + "*" + getWeight();
/*    */   }
/*    */ 
/*    */   public String getHost()
/*    */   {
/* 20 */     return this.host;
/*    */   }
/*    */ 
/*    */   public int getPort() {
/* 24 */     return this.port;
/*    */   }
/*    */ 
/*    */   public JedisShardInfo(String host) {
/* 28 */     super(1);
/* 29 */     URI uri = URI.create(host);
/* 30 */     if ((uri.getScheme() != null) && (uri.getScheme().equals("redis"))) {
/* 31 */       this.host = uri.getHost();
/* 32 */       this.port = uri.getPort();
/* 33 */       this.password = uri.getUserInfo().split(":", 2)[1];
/*    */     } else {
/* 35 */       this.host = host;
/* 36 */       this.port = 6379;
/*    */     }
/*    */   }
/*    */ 
/*    */   public JedisShardInfo(String host, String name) {
/* 41 */     this(host, 6379, name);
/*    */   }
/*    */ 
/*    */   public JedisShardInfo(String host, int port) {
/* 45 */     this(host, port, 2000);
/*    */   }
/*    */ 
/*    */   public JedisShardInfo(String host, int port, String name) {
/* 49 */     this(host, port, 2000, name);
/*    */   }
/*    */ 
/*    */   public JedisShardInfo(String host, int port, int timeout) {
/* 53 */     this(host, port, timeout, 1);
/*    */   }
/*    */ 
/*    */   public JedisShardInfo(String host, int port, int timeout, String name) {
/* 57 */     this(host, port, timeout, 1);
/* 58 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public JedisShardInfo(String host, int port, int timeout, int weight) {
/* 62 */     super(weight);
/* 63 */     this.host = host;
/* 64 */     this.port = port;
/* 65 */     this.timeout = timeout;
/*    */   }
/*    */ 
/*    */   public JedisShardInfo(URI uri) {
/* 69 */     super(1);
/* 70 */     this.host = uri.getHost();
/* 71 */     this.port = uri.getPort();
/* 72 */     this.password = uri.getUserInfo().split(":", 2)[1];
/*    */   }
/*    */ 
/*    */   public String getPassword() {
/* 76 */     return this.password;
/*    */   }
/*    */ 
/*    */   public void setPassword(String auth) {
/* 80 */     this.password = auth;
/*    */   }
/*    */ 
/*    */   public int getTimeout() {
/* 84 */     return this.timeout;
/*    */   }
/*    */ 
/*    */   public void setTimeout(int timeout) {
/* 88 */     this.timeout = timeout;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 92 */     return this.name;
/*    */   }
/*    */ 
/*    */   public Jedis createResource()
/*    */   {
/* 97 */     return new Jedis(this);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.JedisShardInfo
 * JD-Core Version:    0.6.0
 */