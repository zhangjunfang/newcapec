/*    */ package cn.newcapec.framework.base.dao.redis.config;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class RedisSubMain
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 11 */     RedisPubSubManager manager = new RedisPubSubManager();
/* 12 */     System.out.println("订阅消息-------------------");
/* 13 */     manager.psubscribe(new String[] { "testpub1", "testpub3" });
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.config.RedisSubMain
 * JD-Core Version:    0.6.0
 */