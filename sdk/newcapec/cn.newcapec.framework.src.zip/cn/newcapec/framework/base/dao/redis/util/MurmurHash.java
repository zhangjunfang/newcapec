/*     */ package cn.newcapec.framework.base.dao.redis.util;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ public class MurmurHash
/*     */   implements Hashing
/*     */ {
/*     */   public static int hash(byte[] data, int seed)
/*     */   {
/*  43 */     return hash(ByteBuffer.wrap(data), seed);
/*     */   }
/*     */ 
/*     */   public static int hash(byte[] data, int offset, int length, int seed)
/*     */   {
/*  60 */     return hash(ByteBuffer.wrap(data, offset, length), seed);
/*     */   }
/*     */ 
/*     */   public static int hash(ByteBuffer buf, int seed)
/*     */   {
/*  74 */     ByteOrder byteOrder = buf.order();
/*  75 */     buf.order(ByteOrder.LITTLE_ENDIAN);
/*     */ 
/*  77 */     int m = 1540483477;
/*  78 */     int r = 24;
/*     */ 
/*  80 */     int h = seed ^ buf.remaining();
/*     */ 
/*  83 */     while (buf.remaining() >= 4) {
/*  84 */       int k = buf.getInt();
/*     */ 
/*  86 */       k *= m;
/*  87 */       k ^= k >>> r;
/*  88 */       k *= m;
/*     */ 
/*  90 */       h *= m;
/*  91 */       h ^= k;
/*     */     }
/*     */ 
/*  94 */     if (buf.remaining() > 0) {
/*  95 */       ByteBuffer finish = ByteBuffer.allocate(4).order(
/*  96 */         ByteOrder.LITTLE_ENDIAN);
/*     */ 
/*  99 */       finish.put(buf).rewind();
/* 100 */       h ^= finish.getInt();
/* 101 */       h *= m;
/*     */     }
/*     */ 
/* 104 */     h ^= h >>> 13;
/* 105 */     h *= m;
/* 106 */     h ^= h >>> 15;
/*     */ 
/* 108 */     buf.order(byteOrder);
/* 109 */     return h;
/*     */   }
/*     */ 
/*     */   public static long hash64A(byte[] data, int seed) {
/* 113 */     return hash64A(ByteBuffer.wrap(data), seed);
/*     */   }
/*     */ 
/*     */   public static long hash64A(byte[] data, int offset, int length, int seed) {
/* 117 */     return hash64A(ByteBuffer.wrap(data, offset, length), seed);
/*     */   }
/*     */ 
/*     */   public static long hash64A(ByteBuffer buf, int seed) {
/* 121 */     ByteOrder byteOrder = buf.order();
/* 122 */     buf.order(ByteOrder.LITTLE_ENDIAN);
/*     */ 
/* 124 */     long m = -4132994306676758123L;
/* 125 */     int r = 47;
/*     */ 
/* 127 */     long h = seed ^ buf.remaining() * m;
/*     */ 
/* 130 */     while (buf.remaining() >= 8) {
/* 131 */       long k = buf.getLong();
/*     */ 
/* 133 */       k *= m;
/* 134 */       k ^= k >>> r;
/* 135 */       k *= m;
/*     */ 
/* 137 */       h ^= k;
/* 138 */       h *= m;
/*     */     }
/*     */ 
/* 141 */     if (buf.remaining() > 0) {
/* 142 */       ByteBuffer finish = ByteBuffer.allocate(8).order(
/* 143 */         ByteOrder.LITTLE_ENDIAN);
/*     */ 
/* 146 */       finish.put(buf).rewind();
/* 147 */       h ^= finish.getLong();
/* 148 */       h *= m;
/*     */     }
/*     */ 
/* 151 */     h ^= h >>> r;
/* 152 */     h *= m;
/* 153 */     h ^= h >>> r;
/*     */ 
/* 155 */     buf.order(byteOrder);
/* 156 */     return h;
/*     */   }
/*     */ 
/*     */   public long hash(byte[] key) {
/* 160 */     return hash64A(key, 305441741);
/*     */   }
/*     */ 
/*     */   public long hash(String key) {
/* 164 */     return hash(SafeEncoder.encode(key));
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.util.MurmurHash
 * JD-Core Version:    0.6.0
 */