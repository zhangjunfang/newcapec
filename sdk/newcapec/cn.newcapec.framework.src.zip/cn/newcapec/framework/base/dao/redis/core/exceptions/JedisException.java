/*    */ package cn.newcapec.framework.base.dao.redis.core.exceptions;
/*    */ 
/*    */ public class JedisException extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -2946266495682282677L;
/*    */ 
/*    */   public JedisException(String message)
/*    */   {
/*  8 */     super(message);
/*    */   }
/*    */ 
/*    */   public JedisException(Throwable e) {
/* 12 */     super(e);
/*    */   }
/*    */ 
/*    */   public JedisException(String message, Throwable cause) {
/* 16 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.exceptions.JedisException
 * JD-Core Version:    0.6.0
 */