/*    */ package cn.newcapec.framework.base.dao.redis.config;
/*    */ 
/*    */ import cn.newcapec.framework.base.dao.redis.core.JedisPoolConfig;
/*    */ 
/*    */ public class ConnectionFactoryBuilder
/*    */ {
/*    */   private JedisPoolConfig jedisPoolConfig;
/* 11 */   private int timeout = 2000;
/* 12 */   private String masterConfString = null;
/* 13 */   private String slaveConfString = null;
/*    */ 
/*    */   public ConnectionFactoryBuilder(JedisPoolConfig jedisPoolConfig)
/*    */   {
/* 18 */     this.jedisPoolConfig = jedisPoolConfig;
/*    */   }
/*    */ 
/*    */   public void setMaxActive(int maxActive) {
/* 22 */     this.jedisPoolConfig.setMaxActive(maxActive);
/*    */   }
/*    */ 
/*    */   public void setMaxIdle(int maxIdle) {
/* 26 */     this.jedisPoolConfig.setMaxIdle(maxIdle);
/*    */   }
/*    */ 
/*    */   public void setMaxWait(int maxWait) {
/* 30 */     this.jedisPoolConfig.setMaxWait(maxWait);
/*    */   }
/*    */ 
/*    */   public void setTestOnBorrow(boolean flag) {
/* 34 */     this.jedisPoolConfig.setTestOnBorrow(flag);
/*    */   }
/*    */ 
/*    */   public void setTimeout(int timeout) {
/* 38 */     this.timeout = timeout;
/*    */   }
/*    */ 
/*    */   public JedisPoolConfig getJedisPoolConfig() {
/* 42 */     return this.jedisPoolConfig;
/*    */   }
/*    */ 
/*    */   public int getTimeout() {
/* 46 */     return this.timeout;
/*    */   }
/*    */ 
/*    */   public String getMasterConfString() {
/* 50 */     return this.masterConfString;
/*    */   }
/*    */ 
/*    */   public void setMasterConfString(String masterConfString) {
/* 54 */     this.masterConfString = masterConfString;
/*    */   }
/*    */ 
/*    */   public String getSlaveConfString() {
/* 58 */     return this.slaveConfString;
/*    */   }
/*    */ 
/*    */   public void setSlaveConfString(String slaveConfString) {
/* 62 */     this.slaveConfString = slaveConfString;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.config.ConnectionFactoryBuilder
 * JD-Core Version:    0.6.0
 */