/*    */ package cn.newcapec.framework.base.dao.redis.core;
/*    */ 
/*    */ import cn.newcapec.framework.base.dao.redis.util.SafeEncoder;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ZParams
/*    */ {
/* 24 */   private List<byte[]> params = new ArrayList();
/*    */ 
/*    */   public ZParams weights(int[] weights) {
/* 27 */     this.params.add(Protocol.Keyword.WEIGHTS.raw);
/* 28 */     for (int weight : weights) {
/* 29 */       this.params.add(Protocol.toByteArray(weight));
/*    */     }
/*    */ 
/* 32 */     return this;
/*    */   }
/*    */ 
/*    */   public Collection<byte[]> getParams() {
/* 36 */     return Collections.unmodifiableCollection(this.params);
/*    */   }
/*    */ 
/*    */   public ZParams aggregate(Aggregate aggregate) {
/* 40 */     this.params.add(Protocol.Keyword.AGGREGATE.raw);
/* 41 */     this.params.add(aggregate.raw);
/* 42 */     return this;
/*    */   }
/*    */ 
/*    */   public static enum Aggregate
/*    */   {
/* 15 */     SUM, MIN, MAX;
/*    */ 
/*    */     public final byte[] raw;
/*    */ 
/* 20 */     private Aggregate() { this.raw = SafeEncoder.encode(name());
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.ZParams
 * JD-Core Version:    0.6.0
 */