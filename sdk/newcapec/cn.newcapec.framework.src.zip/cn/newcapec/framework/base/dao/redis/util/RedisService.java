/*    */ package cn.newcapec.framework.base.dao.redis.util;
/*    */ 
/*    */ import cn.newcapec.framework.base.dao.redis.core.Jedis;
/*    */ import cn.newcapec.framework.base.dao.redis.core.JedisPool;
/*    */ import cn.newcapec.framework.base.dao.redis.core.JedisPoolConfig;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ public class RedisService
/*    */   implements QueueService
/*    */ {
/*    */   private static JedisPool pool;
/*    */ 
/*    */   static
/*    */   {
/* 20 */     ResourceBundle bundle = ResourceBundle.getBundle("config/redis/redis");
/* 21 */     if (bundle == null) {
/* 22 */       throw new IllegalArgumentException(
/* 23 */         "cannot find the SignVerProp.properties");
/*    */     }
/*    */ 
/* 26 */     JedisPoolConfig config = new JedisPoolConfig();
/* 27 */     config.setMaxActive(Integer.valueOf(bundle
/* 28 */       .getString("redis.pool.maxActive")).intValue());
/*    */ 
/* 29 */     config.setMaxIdle(Integer.valueOf(bundle
/* 30 */       .getString("redis.pool.maxIdle")).intValue());
/*    */ 
/* 31 */     config.setMaxWait(Integer.valueOf(bundle
/* 32 */       .getString("redis.pool.maxWait")).intValue());
/*    */ 
/* 34 */     pool = new JedisPool(config, bundle.getString("redis2.ip"), 
/* 35 */       Integer.valueOf(bundle.getString("redis.port")).intValue());
/*    */   }
/*    */ 
/*    */   public static Jedis getJedis()
/*    */   {
/* 47 */     return (Jedis)pool.getResource();
/*    */   }
/*    */ 
/*    */   public static void closeJedis(Jedis jedis)
/*    */   {
/* 59 */     pool.returnResource(jedis);
/*    */   }
/*    */ 
/*    */   public Long push(String key, String value)
/*    */   {
/* 69 */     Jedis jedis = (Jedis)pool.getResource();
/*    */     try {
/* 71 */       Long localLong = jedis.rpush(key, new String[] { value });
/*    */       return localLong;
/*    */     } catch (Exception e) {
/* 73 */       e.printStackTrace();
/*    */     } finally {
/* 75 */       pool.returnResource(jedis);
/*    */     }
/*    */ 
/* 78 */     return null;
/*    */   }
/*    */ 
/*    */   public String pop(String key)
/*    */   {
/* 88 */     Jedis jedis = (Jedis)pool.getResource();
/* 89 */     String result = null;
/*    */     try {
/* 91 */       result = jedis.lpop(key);
/*    */     } finally {
/* 93 */       pool.returnResource(jedis);
/*    */     }
/*    */ 
/* 96 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.util.RedisService
 * JD-Core Version:    0.6.0
 */