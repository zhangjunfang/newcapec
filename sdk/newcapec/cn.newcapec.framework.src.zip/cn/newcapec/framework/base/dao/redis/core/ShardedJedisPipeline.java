/*    */ package cn.newcapec.framework.base.dao.redis.core;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import java.util.Queue;
/*    */ 
/*    */ public class ShardedJedisPipeline extends PipelineBase
/*    */ {
/*    */   private BinaryShardedJedis jedis;
/* 10 */   private List<FutureResult> results = new ArrayList();
/* 11 */   private Queue<Client> clients = new LinkedList();
/*    */ 
/*    */   public void setShardedJedis(BinaryShardedJedis jedis)
/*    */   {
/* 26 */     this.jedis = jedis;
/*    */   }
/*    */ 
/*    */   public List<Object> getResults() {
/* 30 */     List r = new ArrayList();
/* 31 */     for (FutureResult fr : this.results) {
/* 32 */       r.add(fr.get());
/*    */     }
/* 34 */     return r;
/*    */   }
/*    */ 
/*    */   public void sync()
/*    */   {
/* 43 */     for (Client client : this.clients)
/* 44 */       generateResponse(client.getOne());
/*    */   }
/*    */ 
/*    */   public List<Object> syncAndReturnAll()
/*    */   {
/* 57 */     List formatted = new ArrayList();
/* 58 */     for (Client client : this.clients) {
/* 59 */       formatted.add(generateResponse(client.getOne()).get());
/*    */     }
/* 61 */     return formatted;
/*    */   }
/*    */ 
/*    */   @Deprecated
/*    */   public void execute()
/*    */   {
/*    */   }
/*    */ 
/*    */   protected Client getClient(String key)
/*    */   {
/* 74 */     Client client = ((Jedis)this.jedis.getShard(key)).getClient();
/* 75 */     this.clients.add(client);
/* 76 */     this.results.add(new FutureResult(client));
/* 77 */     return client;
/*    */   }
/*    */ 
/*    */   protected Client getClient(byte[] key)
/*    */   {
/* 82 */     Client client = ((Jedis)this.jedis.getShard(key)).getClient();
/* 83 */     this.clients.add(client);
/* 84 */     this.results.add(new FutureResult(client));
/* 85 */     return client;
/*    */   }
/*    */ 
/*    */   private static class FutureResult
/*    */   {
/*    */     private Client client;
/*    */ 
/*    */     public FutureResult(Client client)
/*    */     {
/* 17 */       this.client = client;
/*    */     }
/*    */ 
/*    */     public Object get() {
/* 21 */       return this.client.getOne();
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.ShardedJedisPipeline
 * JD-Core Version:    0.6.0
 */