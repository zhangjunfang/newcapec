package cn.newcapec.framework.base.dao.redis.core;

public abstract class JedisMonitor
{
  protected Client client;

  public void proceed(Client client)
  {
    this.client = client;
    this.client.setTimeoutInfinite();
    do {
      String command = client.getBulkReply();
      onCommand(command);
    }
    while (
      client.isConnected());
  }

  public abstract void onCommand(String paramString);
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.JedisMonitor
 * JD-Core Version:    0.6.0
 */