package cn.newcapec.framework.base.dao.redis.core;

public abstract class Builder<T>
{
  public abstract T build(Object paramObject);
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.Builder
 * JD-Core Version:    0.6.0
 */