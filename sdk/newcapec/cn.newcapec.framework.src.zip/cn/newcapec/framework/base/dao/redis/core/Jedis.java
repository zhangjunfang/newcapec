/*      */ package cn.newcapec.framework.base.dao.redis.core;
/*      */ 
/*      */ import cn.newcapec.framework.base.dao.redis.util.SafeEncoder;
/*      */ import cn.newcapec.framework.base.dao.redis.util.Slowlog;
/*      */ import java.net.URI;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ 
/*      */ public class Jedis extends BinaryJedis
/*      */   implements JedisCommands, MultiKeyCommands, AdvancedJedisCommands, ScriptingCommands
/*      */ {
/*      */   public Jedis(String host)
/*      */   {
/*   19 */     super(host);
/*      */   }
/*      */ 
/*      */   public Jedis(String host, int port) {
/*   23 */     super(host, port);
/*      */   }
/*      */ 
/*      */   public Jedis(String host, int port, int timeout) {
/*   27 */     super(host, port, timeout);
/*      */   }
/*      */ 
/*      */   public Jedis(JedisShardInfo shardInfo) {
/*   31 */     super(shardInfo);
/*      */   }
/*      */ 
/*      */   public Jedis(URI uri) {
/*   35 */     super(uri);
/*      */   }
/*      */ 
/*      */   public String set(String key, String value)
/*      */   {
/*   49 */     checkIsInMulti();
/*   50 */     this.client.set(key, value);
/*   51 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public String get(String key)
/*      */   {
/*   65 */     checkIsInMulti();
/*   66 */     this.client.sendCommand(Protocol.Command.GET, new String[] { key });
/*   67 */     return this.client.getBulkReply();
/*      */   }
/*      */ 
/*      */   public Boolean exists(String key)
/*      */   {
/*   81 */     checkIsInMulti();
/*   82 */     this.client.exists(key);
/*   83 */     if (this.client.getIntegerReply().longValue() == 1L) return Boolean.valueOf(true); return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   public Long del(String[] keys)
/*      */   {
/*   97 */     checkIsInMulti();
/*   98 */     this.client.del(keys);
/*   99 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long del(String key) {
/*  103 */     this.client.del(new String[] { key });
/*  104 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String type(String key)
/*      */   {
/*  122 */     checkIsInMulti();
/*  123 */     this.client.type(key);
/*  124 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public Set<String> keys(String pattern)
/*      */   {
/*  159 */     checkIsInMulti();
/*  160 */     this.client.keys(pattern);
/*  161 */     return 
/*  162 */       (Set)BuilderFactory.STRING_SET
/*  162 */       .build(this.client.getBinaryMultiBulkReply());
/*      */   }
/*      */ 
/*      */   public String randomKey()
/*      */   {
/*  174 */     checkIsInMulti();
/*  175 */     this.client.randomKey();
/*  176 */     return this.client.getBulkReply();
/*      */   }
/*      */ 
/*      */   public String rename(String oldkey, String newkey)
/*      */   {
/*  191 */     checkIsInMulti();
/*  192 */     this.client.rename(oldkey, newkey);
/*  193 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public Long renamenx(String oldkey, String newkey)
/*      */   {
/*  208 */     checkIsInMulti();
/*  209 */     this.client.renamenx(oldkey, newkey);
/*  210 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long expire(String key, int seconds)
/*      */   {
/*  242 */     checkIsInMulti();
/*  243 */     this.client.expire(key, seconds);
/*  244 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long expireAt(String key, long unixTime)
/*      */   {
/*  278 */     checkIsInMulti();
/*  279 */     this.client.expireAt(key, unixTime);
/*  280 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long ttl(String key)
/*      */   {
/*  295 */     checkIsInMulti();
/*  296 */     this.client.ttl(key);
/*  297 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long move(String key, int dbIndex)
/*      */   {
/*  314 */     checkIsInMulti();
/*  315 */     this.client.move(key, dbIndex);
/*  316 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String getSet(String key, String value)
/*      */   {
/*  331 */     checkIsInMulti();
/*  332 */     this.client.getSet(key, value);
/*  333 */     return this.client.getBulkReply();
/*      */   }
/*      */ 
/*      */   public List<String> mget(String[] keys)
/*      */   {
/*  347 */     checkIsInMulti();
/*  348 */     this.client.mget(keys);
/*  349 */     return this.client.getMultiBulkReply();
/*      */   }
/*      */ 
/*      */   public Long setnx(String key, String value)
/*      */   {
/*  365 */     checkIsInMulti();
/*  366 */     this.client.setnx(key, value);
/*  367 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String setex(String key, int seconds, String value)
/*      */   {
/*  383 */     checkIsInMulti();
/*  384 */     this.client.setex(key, seconds, value);
/*  385 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public String mset(String[] keysvalues)
/*      */   {
/*  409 */     checkIsInMulti();
/*  410 */     this.client.mset(keysvalues);
/*  411 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public Long msetnx(String[] keysvalues)
/*      */   {
/*  436 */     checkIsInMulti();
/*  437 */     this.client.msetnx(keysvalues);
/*  438 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long decrBy(String key, long integer)
/*      */   {
/*  464 */     checkIsInMulti();
/*  465 */     this.client.decrBy(key, integer);
/*  466 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long decr(String key)
/*      */   {
/*  492 */     checkIsInMulti();
/*  493 */     this.client.decr(key);
/*  494 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long incrBy(String key, long integer)
/*      */   {
/*  520 */     checkIsInMulti();
/*  521 */     this.client.incrBy(key, integer);
/*  522 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long incr(String key)
/*      */   {
/*  548 */     checkIsInMulti();
/*  549 */     this.client.incr(key);
/*  550 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long append(String key, String value)
/*      */   {
/*  570 */     checkIsInMulti();
/*  571 */     this.client.append(key, value);
/*  572 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String substr(String key, int start, int end)
/*      */   {
/*  594 */     checkIsInMulti();
/*  595 */     this.client.substr(key, start, end);
/*  596 */     return this.client.getBulkReply();
/*      */   }
/*      */ 
/*      */   public Long hset(String key, String field, String value)
/*      */   {
/*  615 */     checkIsInMulti();
/*  616 */     this.client.hset(key, field, value);
/*  617 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String hget(String key, String field)
/*      */   {
/*  634 */     checkIsInMulti();
/*  635 */     this.client.hget(key, field);
/*  636 */     return this.client.getBulkReply();
/*      */   }
/*      */ 
/*      */   public Long hsetnx(String key, String field, String value)
/*      */   {
/*  651 */     checkIsInMulti();
/*  652 */     this.client.hsetnx(key, field, value);
/*  653 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String hmset(String key, Map<String, String> hash)
/*      */   {
/*  669 */     checkIsInMulti();
/*  670 */     this.client.hmset(key, hash);
/*  671 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public List<String> hmget(String key, String[] fields)
/*      */   {
/*  688 */     checkIsInMulti();
/*  689 */     this.client.hmget(key, fields);
/*  690 */     return this.client.getMultiBulkReply();
/*      */   }
/*      */ 
/*      */   public Long hincrBy(String key, String field, long value)
/*      */   {
/*  712 */     checkIsInMulti();
/*  713 */     this.client.hincrBy(key, field, value);
/*  714 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Boolean hexists(String key, String field)
/*      */   {
/*  728 */     checkIsInMulti();
/*  729 */     this.client.hexists(key, field);
/*  730 */     if (this.client.getIntegerReply().longValue() == 1L) return Boolean.valueOf(true); return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   public Long hdel(String key, String[] fields)
/*      */   {
/*  744 */     checkIsInMulti();
/*  745 */     this.client.hdel(key, fields);
/*  746 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long hlen(String key)
/*      */   {
/*  760 */     checkIsInMulti();
/*  761 */     this.client.hlen(key);
/*  762 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Set<String> hkeys(String key)
/*      */   {
/*  774 */     checkIsInMulti();
/*  775 */     this.client.hkeys(key);
/*  776 */     return 
/*  777 */       (Set)BuilderFactory.STRING_SET
/*  777 */       .build(this.client.getBinaryMultiBulkReply());
/*      */   }
/*      */ 
/*      */   public List<String> hvals(String key)
/*      */   {
/*  789 */     checkIsInMulti();
/*  790 */     this.client.hvals(key);
/*  791 */     List lresult = this.client.getMultiBulkReply();
/*  792 */     return lresult;
/*      */   }
/*      */ 
/*      */   public Map<String, String> hgetAll(String key)
/*      */   {
/*  804 */     checkIsInMulti();
/*  805 */     this.client.hgetAll(key);
/*  806 */     return 
/*  807 */       (Map)BuilderFactory.STRING_MAP
/*  807 */       .build(this.client.getBinaryMultiBulkReply());
/*      */   }
/*      */ 
/*      */   public Long rpush(String key, String[] strings)
/*      */   {
/*  824 */     checkIsInMulti();
/*  825 */     this.client.rpush(key, strings);
/*  826 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long lpush(String key, String[] strings)
/*      */   {
/*  843 */     checkIsInMulti();
/*  844 */     this.client.lpush(key, strings);
/*  845 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long llen(String key)
/*      */   {
/*  859 */     checkIsInMulti();
/*  860 */     this.client.llen(key);
/*  861 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public List<String> lrange(String key, long start, long end)
/*      */   {
/*  904 */     checkIsInMulti();
/*  905 */     this.client.lrange(key, start, end);
/*  906 */     return this.client.getMultiBulkReply();
/*      */   }
/*      */ 
/*      */   public String ltrim(String key, long start, long end)
/*      */   {
/*  944 */     checkIsInMulti();
/*  945 */     this.client.ltrim(key, start, end);
/*  946 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public String lindex(String key, long index)
/*      */   {
/*  968 */     checkIsInMulti();
/*  969 */     this.client.lindex(key, index);
/*  970 */     return this.client.getBulkReply();
/*      */   }
/*      */ 
/*      */   public String lset(String key, long index, String value)
/*      */   {
/*  995 */     checkIsInMulti();
/*  996 */     this.client.lset(key, index, value);
/*  997 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public Long lrem(String key, long count, String value)
/*      */   {
/* 1020 */     checkIsInMulti();
/* 1021 */     this.client.lrem(key, count, value);
/* 1022 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String lpop(String key)
/*      */   {
/* 1039 */     checkIsInMulti();
/* 1040 */     this.client.lpop(key);
/* 1041 */     return this.client.getBulkReply();
/*      */   }
/*      */ 
/*      */   public String rpop(String key)
/*      */   {
/* 1058 */     checkIsInMulti();
/* 1059 */     this.client.rpop(key);
/* 1060 */     return this.client.getBulkReply();
/*      */   }
/*      */ 
/*      */   public String rpoplpush(String srckey, String dstkey)
/*      */   {
/* 1082 */     checkIsInMulti();
/* 1083 */     this.client.rpoplpush(srckey, dstkey);
/* 1084 */     return this.client.getBulkReply();
/*      */   }
/*      */ 
/*      */   public Long sadd(String key, String[] members)
/*      */   {
/* 1101 */     checkIsInMulti();
/* 1102 */     this.client.sadd(key, members);
/* 1103 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Set<String> smembers(String key)
/*      */   {
/* 1116 */     checkIsInMulti();
/* 1117 */     this.client.smembers(key);
/* 1118 */     List members = this.client.getMultiBulkReply();
/* 1119 */     return new HashSet(members);
/*      */   }
/*      */ 
/*      */   public Long srem(String key, String[] members)
/*      */   {
/* 1135 */     checkIsInMulti();
/* 1136 */     this.client.srem(key, members);
/* 1137 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String spop(String key)
/*      */   {
/* 1153 */     checkIsInMulti();
/* 1154 */     this.client.spop(key);
/* 1155 */     return this.client.getBulkReply();
/*      */   }
/*      */ 
/*      */   public Long smove(String srckey, String dstkey, String member)
/*      */   {
/* 1183 */     checkIsInMulti();
/* 1184 */     this.client.smove(srckey, dstkey, member);
/* 1185 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long scard(String key)
/*      */   {
/* 1197 */     checkIsInMulti();
/* 1198 */     this.client.scard(key);
/* 1199 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Boolean sismember(String key, String member)
/*      */   {
/* 1215 */     checkIsInMulti();
/* 1216 */     this.client.sismember(key, member);
/* 1217 */     if (this.client.getIntegerReply().longValue() == 1L) return Boolean.valueOf(true); return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   public Set<String> sinter(String[] keys)
/*      */   {
/* 1240 */     checkIsInMulti();
/* 1241 */     this.client.sinter(keys);
/* 1242 */     List members = this.client.getMultiBulkReply();
/* 1243 */     return new HashSet(members);
/*      */   }
/*      */ 
/*      */   public Long sinterstore(String dstkey, String[] keys)
/*      */   {
/* 1258 */     checkIsInMulti();
/* 1259 */     this.client.sinterstore(dstkey, keys);
/* 1260 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Set<String> sunion(String[] keys)
/*      */   {
/* 1280 */     checkIsInMulti();
/* 1281 */     this.client.sunion(keys);
/* 1282 */     List members = this.client.getMultiBulkReply();
/* 1283 */     return new HashSet(members);
/*      */   }
/*      */ 
/*      */   public Long sunionstore(String dstkey, String[] keys)
/*      */   {
/* 1299 */     checkIsInMulti();
/* 1300 */     this.client.sunionstore(dstkey, keys);
/* 1301 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Set<String> sdiff(String[] keys)
/*      */   {
/* 1328 */     checkIsInMulti();
/* 1329 */     this.client.sdiff(keys);
/* 1330 */     return 
/* 1331 */       (Set)BuilderFactory.STRING_SET
/* 1331 */       .build(this.client.getBinaryMultiBulkReply());
/*      */   }
/*      */ 
/*      */   public Long sdiffstore(String dstkey, String[] keys)
/*      */   {
/* 1343 */     checkIsInMulti();
/* 1344 */     this.client.sdiffstore(dstkey, keys);
/* 1345 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String srandmember(String key)
/*      */   {
/* 1361 */     checkIsInMulti();
/* 1362 */     this.client.srandmember(key);
/* 1363 */     return this.client.getBulkReply();
/*      */   }
/*      */ 
/*      */   public Long zadd(String key, double score, String member)
/*      */   {
/* 1388 */     checkIsInMulti();
/* 1389 */     this.client.zadd(key, score, member);
/* 1390 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long zadd(String key, Map<Double, String> scoreMembers) {
/* 1394 */     checkIsInMulti();
/* 1395 */     this.client.zadd(key, scoreMembers);
/* 1396 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Set<String> zrange(String key, long start, long end) {
/* 1400 */     checkIsInMulti();
/* 1401 */     this.client.zrange(key, start, end);
/* 1402 */     List members = this.client.getMultiBulkReply();
/* 1403 */     return new LinkedHashSet(members);
/*      */   }
/*      */ 
/*      */   public Long zrem(String key, String[] members)
/*      */   {
/* 1422 */     checkIsInMulti();
/* 1423 */     this.client.zrem(key, members);
/* 1424 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Double zincrby(String key, double score, String member)
/*      */   {
/* 1453 */     checkIsInMulti();
/* 1454 */     this.client.zincrby(key, score, member);
/* 1455 */     String newscore = this.client.getBulkReply();
/* 1456 */     return Double.valueOf(newscore);
/*      */   }
/*      */ 
/*      */   public Long zrank(String key, String member)
/*      */   {
/* 1480 */     checkIsInMulti();
/* 1481 */     this.client.zrank(key, member);
/* 1482 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long zrevrank(String key, String member)
/*      */   {
/* 1506 */     checkIsInMulti();
/* 1507 */     this.client.zrevrank(key, member);
/* 1508 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Set<String> zrevrange(String key, long start, long end)
/*      */   {
/* 1513 */     checkIsInMulti();
/* 1514 */     this.client.zrevrange(key, start, end);
/* 1515 */     List members = this.client.getMultiBulkReply();
/* 1516 */     return new LinkedHashSet(members);
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrangeWithScores(String key, long start, long end)
/*      */   {
/* 1521 */     checkIsInMulti();
/* 1522 */     this.client.zrangeWithScores(key, start, end);
/* 1523 */     Set set = getTupledSet();
/* 1524 */     return set;
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrevrangeWithScores(String key, long start, long end)
/*      */   {
/* 1529 */     checkIsInMulti();
/* 1530 */     this.client.zrevrangeWithScores(key, start, end);
/* 1531 */     Set set = getTupledSet();
/* 1532 */     return set;
/*      */   }
/*      */ 
/*      */   public Long zcard(String key)
/*      */   {
/* 1545 */     checkIsInMulti();
/* 1546 */     this.client.zcard(key);
/* 1547 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Double zscore(String key, String member)
/*      */   {
/* 1562 */     checkIsInMulti();
/* 1563 */     this.client.zscore(key, member);
/* 1564 */     String score = this.client.getBulkReply();
/* 1565 */     return score != null ? new Double(score) : null;
/*      */   }
/*      */ 
/*      */   public String watch(String[] keys) {
/* 1569 */     this.client.watch(keys);
/* 1570 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public List<String> sort(String key)
/*      */   {
/* 1591 */     checkIsInMulti();
/* 1592 */     this.client.sort(key);
/* 1593 */     return this.client.getMultiBulkReply();
/*      */   }
/*      */ 
/*      */   public List<String> sort(String key, SortingParams sortingParameters)
/*      */   {
/* 1674 */     checkIsInMulti();
/* 1675 */     this.client.sort(key, sortingParameters);
/* 1676 */     return this.client.getMultiBulkReply();
/*      */   }
/*      */ 
/*      */   public List<String> blpop(int timeout, String[] keys)
/*      */   {
/* 1752 */     checkIsInMulti();
/* 1753 */     List args = new ArrayList();
/* 1754 */     for (String arg : keys) {
/* 1755 */       args.add(arg);
/*      */     }
/* 1757 */     args.add(String.valueOf(timeout));
/*      */ 
/* 1759 */     this.client.blpop((String[])args.toArray(new String[args.size()]));
/* 1760 */     this.client.setTimeoutInfinite();
/* 1761 */     List multiBulkReply = this.client.getMultiBulkReply();
/* 1762 */     this.client.rollbackTimeout();
/* 1763 */     return multiBulkReply;
/*      */   }
/*      */ 
/*      */   public List<String> blpop(String[] args) {
/* 1767 */     this.client.blpop(args);
/* 1768 */     this.client.setTimeoutInfinite();
/* 1769 */     List multiBulkReply = this.client.getMultiBulkReply();
/* 1770 */     this.client.rollbackTimeout();
/* 1771 */     return multiBulkReply;
/*      */   }
/*      */ 
/*      */   public List<String> brpop(String[] args) {
/* 1775 */     this.client.brpop(args);
/* 1776 */     this.client.setTimeoutInfinite();
/* 1777 */     List multiBulkReply = this.client.getMultiBulkReply();
/* 1778 */     this.client.rollbackTimeout();
/* 1779 */     return multiBulkReply;
/*      */   }
/*      */ 
/*      */   public List<String> blpop(String arg) {
/* 1783 */     String[] args = new String[1];
/* 1784 */     args[0] = arg;
/* 1785 */     this.client.blpop(args);
/* 1786 */     this.client.setTimeoutInfinite();
/* 1787 */     List multiBulkReply = this.client.getMultiBulkReply();
/* 1788 */     this.client.rollbackTimeout();
/* 1789 */     return multiBulkReply;
/*      */   }
/*      */ 
/*      */   public List<String> brpop(String arg) {
/* 1793 */     String[] args = new String[1];
/* 1794 */     args[0] = arg;
/* 1795 */     this.client.brpop(args);
/* 1796 */     this.client.setTimeoutInfinite();
/* 1797 */     List multiBulkReply = this.client.getMultiBulkReply();
/* 1798 */     this.client.rollbackTimeout();
/* 1799 */     return multiBulkReply;
/*      */   }
/*      */ 
/*      */   public Long sort(String key, SortingParams sortingParameters, String dstkey)
/*      */   {
/* 1817 */     checkIsInMulti();
/* 1818 */     this.client.sort(key, sortingParameters, dstkey);
/* 1819 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long sort(String key, String dstkey)
/*      */   {
/* 1839 */     checkIsInMulti();
/* 1840 */     this.client.sort(key, dstkey);
/* 1841 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public List<String> brpop(int timeout, String[] keys)
/*      */   {
/* 1917 */     checkIsInMulti();
/* 1918 */     List args = new ArrayList();
/* 1919 */     for (String arg : keys) {
/* 1920 */       args.add(arg);
/*      */     }
/* 1922 */     args.add(String.valueOf(timeout));
/*      */ 
/* 1924 */     this.client.brpop((String[])args.toArray(new String[args.size()]));
/* 1925 */     this.client.setTimeoutInfinite();
/* 1926 */     List multiBulkReply = this.client.getMultiBulkReply();
/* 1927 */     this.client.rollbackTimeout();
/*      */ 
/* 1929 */     return multiBulkReply;
/*      */   }
/*      */ 
/*      */   public Long zcount(String key, double min, double max)
/*      */   {
/* 1935 */     checkIsInMulti();
/* 1936 */     this.client.zcount(key, min, max);
/* 1937 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long zcount(String key, String min, String max) {
/* 1941 */     checkIsInMulti();
/* 1942 */     this.client.zcount(key, min, max);
/* 1943 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Set<String> zrangeByScore(String key, double min, double max)
/*      */   {
/* 2005 */     checkIsInMulti();
/* 2006 */     this.client.zrangeByScore(key, min, max);
/* 2007 */     return new LinkedHashSet(this.client.getMultiBulkReply());
/*      */   }
/*      */ 
/*      */   public Set<String> zrangeByScore(String key, String min, String max)
/*      */   {
/* 2012 */     checkIsInMulti();
/* 2013 */     this.client.zrangeByScore(key, min, max);
/* 2014 */     return new LinkedHashSet(this.client.getMultiBulkReply());
/*      */   }
/*      */ 
/*      */   public Set<String> zrangeByScore(String key, double min, double max, int offset, int count)
/*      */   {
/* 2075 */     checkIsInMulti();
/* 2076 */     this.client.zrangeByScore(key, min, max, offset, count);
/* 2077 */     return new LinkedHashSet(this.client.getMultiBulkReply());
/*      */   }
/*      */ 
/*      */   public Set<String> zrangeByScore(String key, String min, String max, int offset, int count)
/*      */   {
/* 2082 */     checkIsInMulti();
/* 2083 */     this.client.zrangeByScore(key, min, max, offset, count);
/* 2084 */     return new LinkedHashSet(this.client.getMultiBulkReply());
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrangeByScoreWithScores(String key, double min, double max)
/*      */   {
/* 2145 */     checkIsInMulti();
/* 2146 */     this.client.zrangeByScoreWithScores(key, min, max);
/* 2147 */     Set set = getTupledSet();
/* 2148 */     return set;
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrangeByScoreWithScores(String key, String min, String max)
/*      */   {
/* 2153 */     checkIsInMulti();
/* 2154 */     this.client.zrangeByScoreWithScores(key, min, max);
/* 2155 */     Set set = getTupledSet();
/* 2156 */     return set;
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrangeByScoreWithScores(String key, double min, double max, int offset, int count)
/*      */   {
/* 2218 */     checkIsInMulti();
/* 2219 */     this.client.zrangeByScoreWithScores(key, min, max, offset, count);
/* 2220 */     Set set = getTupledSet();
/* 2221 */     return set;
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrangeByScoreWithScores(String key, String min, String max, int offset, int count)
/*      */   {
/* 2227 */     checkIsInMulti();
/* 2228 */     this.client.zrangeByScoreWithScores(key, min, max, offset, count);
/* 2229 */     Set set = getTupledSet();
/* 2230 */     return set;
/*      */   }
/*      */ 
/*      */   private Set<Tuple> getTupledSet() {
/* 2234 */     checkIsInMulti();
/* 2235 */     List membersWithScores = this.client.getMultiBulkReply();
/* 2236 */     Set set = new LinkedHashSet();
/* 2237 */     Iterator iterator = membersWithScores.iterator();
/* 2238 */     while (iterator.hasNext()) {
/* 2239 */       set.add(new Tuple((String)iterator.next(), Double.valueOf((String)iterator.next())));
/*      */     }
/* 2241 */     return set;
/*      */   }
/*      */ 
/*      */   public Set<String> zrevrangeByScore(String key, double max, double min)
/*      */   {
/* 2246 */     checkIsInMulti();
/* 2247 */     this.client.zrevrangeByScore(key, max, min);
/* 2248 */     return new LinkedHashSet(this.client.getMultiBulkReply());
/*      */   }
/*      */ 
/*      */   public Set<String> zrevrangeByScore(String key, String max, String min)
/*      */   {
/* 2253 */     checkIsInMulti();
/* 2254 */     this.client.zrevrangeByScore(key, max, min);
/* 2255 */     return new LinkedHashSet(this.client.getMultiBulkReply());
/*      */   }
/*      */ 
/*      */   public Set<String> zrevrangeByScore(String key, double max, double min, int offset, int count)
/*      */   {
/* 2260 */     checkIsInMulti();
/* 2261 */     this.client.zrevrangeByScore(key, max, min, offset, count);
/* 2262 */     return new LinkedHashSet(this.client.getMultiBulkReply());
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrevrangeByScoreWithScores(String key, double max, double min)
/*      */   {
/* 2267 */     checkIsInMulti();
/* 2268 */     this.client.zrevrangeByScoreWithScores(key, max, min);
/* 2269 */     Set set = getTupledSet();
/* 2270 */     return set;
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrevrangeByScoreWithScores(String key, double max, double min, int offset, int count)
/*      */   {
/* 2276 */     checkIsInMulti();
/* 2277 */     this.client.zrevrangeByScoreWithScores(key, max, min, offset, count);
/* 2278 */     Set set = getTupledSet();
/* 2279 */     return set;
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrevrangeByScoreWithScores(String key, String max, String min, int offset, int count)
/*      */   {
/* 2285 */     checkIsInMulti();
/* 2286 */     this.client.zrevrangeByScoreWithScores(key, max, min, offset, count);
/* 2287 */     Set set = getTupledSet();
/* 2288 */     return set;
/*      */   }
/*      */ 
/*      */   public Set<String> zrevrangeByScore(String key, String max, String min, int offset, int count)
/*      */   {
/* 2293 */     checkIsInMulti();
/* 2294 */     this.client.zrevrangeByScore(key, max, min, offset, count);
/* 2295 */     return new LinkedHashSet(this.client.getMultiBulkReply());
/*      */   }
/*      */ 
/*      */   public Set<Tuple> zrevrangeByScoreWithScores(String key, String max, String min)
/*      */   {
/* 2300 */     checkIsInMulti();
/* 2301 */     this.client.zrevrangeByScoreWithScores(key, max, min);
/* 2302 */     Set set = getTupledSet();
/* 2303 */     return set;
/*      */   }
/*      */ 
/*      */   public Long zremrangeByRank(String key, long start, long end)
/*      */   {
/* 2321 */     checkIsInMulti();
/* 2322 */     this.client.zremrangeByRank(key, start, end);
/* 2323 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long zremrangeByScore(String key, double start, double end)
/*      */   {
/* 2342 */     checkIsInMulti();
/* 2343 */     this.client.zremrangeByScore(key, start, end);
/* 2344 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long zremrangeByScore(String key, String start, String end)
/*      */   {
/* 2349 */     checkIsInMulti();
/* 2350 */     this.client.zremrangeByScore(key, start, end);
/* 2351 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long zunionstore(String dstkey, String[] sets)
/*      */   {
/* 2393 */     checkIsInMulti();
/* 2394 */     this.client.zunionstore(dstkey, sets);
/* 2395 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long zunionstore(String dstkey, ZParams params, String[] sets)
/*      */   {
/* 2439 */     checkIsInMulti();
/* 2440 */     this.client.zunionstore(dstkey, params, sets);
/* 2441 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long zinterstore(String dstkey, String[] sets)
/*      */   {
/* 2483 */     checkIsInMulti();
/* 2484 */     this.client.zinterstore(dstkey, sets);
/* 2485 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long zinterstore(String dstkey, ZParams params, String[] sets)
/*      */   {
/* 2529 */     checkIsInMulti();
/* 2530 */     this.client.zinterstore(dstkey, params, sets);
/* 2531 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long strlen(String key) {
/* 2535 */     this.client.strlen(key);
/* 2536 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long lpushx(String key, String[] string) {
/* 2540 */     this.client.lpushx(key, string);
/* 2541 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long persist(String key)
/*      */   {
/* 2555 */     this.client.persist(key);
/* 2556 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long rpushx(String key, String[] string) {
/* 2560 */     this.client.rpushx(key, string);
/* 2561 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String echo(String string) {
/* 2565 */     this.client.echo(string);
/* 2566 */     return this.client.getBulkReply();
/*      */   }
/*      */ 
/*      */   public Long linsert(String key, BinaryClient.LIST_POSITION where, String pivot, String value)
/*      */   {
/* 2571 */     this.client.linsert(key, where, pivot, value);
/* 2572 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String brpoplpush(String source, String destination, int timeout)
/*      */   {
/* 2585 */     this.client.brpoplpush(source, destination, timeout);
/* 2586 */     this.client.setTimeoutInfinite();
/* 2587 */     String reply = this.client.getBulkReply();
/* 2588 */     this.client.rollbackTimeout();
/* 2589 */     return reply;
/*      */   }
/*      */ 
/*      */   public Boolean setbit(String key, long offset, boolean value)
/*      */   {
/* 2601 */     this.client.setbit(key, offset, value);
/* 2602 */     if (this.client.getIntegerReply().longValue() == 1L) return Boolean.valueOf(true); return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   public Boolean setbit(String key, long offset, String value) {
/* 2606 */     this.client.setbit(key, offset, value);
/* 2607 */     if (this.client.getIntegerReply().longValue() == 1L) return Boolean.valueOf(true); return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   public Boolean getbit(String key, long offset)
/*      */   {
/* 2618 */     this.client.getbit(key, offset);
/* 2619 */     if (this.client.getIntegerReply().longValue() == 1L) return Boolean.valueOf(true); return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   public Long setrange(String key, long offset, String value) {
/* 2623 */     this.client.setrange(key, offset, value);
/* 2624 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String getrange(String key, long startOffset, long endOffset) {
/* 2628 */     this.client.getrange(key, startOffset, endOffset);
/* 2629 */     return this.client.getBulkReply();
/*      */   }
/*      */ 
/*      */   public List<String> configGet(String pattern)
/*      */   {
/* 2669 */     this.client.configGet(pattern);
/* 2670 */     return this.client.getMultiBulkReply();
/*      */   }
/*      */ 
/*      */   public String configSet(String parameter, String value)
/*      */   {
/* 2708 */     this.client.configSet(parameter, value);
/* 2709 */     return this.client.getStatusCodeReply();
/*      */   }
/*      */ 
/*      */   public Object eval(String script, int keyCount, String[] params) {
/* 2713 */     this.client.setTimeoutInfinite();
/* 2714 */     this.client.eval(script, keyCount, params);
/*      */ 
/* 2716 */     return getEvalResult();
/*      */   }
/*      */ 
/*      */   public void subscribe(JedisPubSub jedisPubSub, String[] channels)
/*      */   {
/* 2721 */     this.client.setTimeoutInfinite();
/* 2722 */     jedisPubSub.proceed(this.client, channels);
/* 2723 */     this.client.rollbackTimeout();
/*      */   }
/*      */ 
/*      */   public Long publish(String channel, String message) {
/* 2727 */     checkIsInMulti();
/* 2728 */     connect();
/* 2729 */     this.client.publish(channel, message);
/* 2730 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public void psubscribe(JedisPubSub jedisPubSub, String[] patterns)
/*      */   {
/* 2735 */     checkIsInMulti();
/* 2736 */     connect();
/* 2737 */     this.client.setTimeoutInfinite();
/* 2738 */     jedisPubSub.proceedWithPatterns(this.client, patterns);
/* 2739 */     this.client.rollbackTimeout();
/*      */   }
/*      */ 
/*      */   private String[] getParams(List<String> keys, List<String> args) {
/* 2743 */     int keyCount = keys.size();
/* 2744 */     int argCount = args.size();
/*      */ 
/* 2746 */     String[] params = new String[keyCount + args.size()];
/*      */ 
/* 2748 */     for (int i = 0; i < keyCount; i++) {
/* 2749 */       params[i] = ((String)keys.get(i));
/*      */     }
/* 2751 */     for (int i = 0; i < argCount; i++) {
/* 2752 */       params[(keyCount + i)] = ((String)args.get(i));
/*      */     }
/* 2754 */     return params;
/*      */   }
/*      */ 
/*      */   public Object eval(String script, List<String> keys, List<String> args) {
/* 2758 */     return eval(script, keys.size(), getParams(keys, args));
/*      */   }
/*      */ 
/*      */   public Object eval(String script) {
/* 2762 */     return eval(script, 0, new String[0]);
/*      */   }
/*      */ 
/*      */   public Object evalsha(String script) {
/* 2766 */     return evalsha(script, 0, new String[0]);
/*      */   }
/*      */ 
/*      */   private Object getEvalResult() {
/* 2770 */     Object result = this.client.getOne();
/*      */ 
/* 2772 */     if ((result instanceof byte[])) {
/* 2773 */       return SafeEncoder.encode((byte[])result);
/*      */     }
/* 2775 */     if ((result instanceof List)) {
/* 2776 */       List list = (List)result;
/* 2777 */       List listResult = new ArrayList(list.size());
/* 2778 */       for (Iterator localIterator = list.iterator(); localIterator.hasNext(); ) { Object bin = localIterator.next();
/* 2779 */         listResult.add(bin == null ? null : 
/* 2780 */           SafeEncoder.encode((byte[])bin));
/*      */       }
/*      */ 
/* 2783 */       return listResult;
/*      */     }
/*      */ 
/* 2786 */     return result;
/*      */   }
/*      */ 
/*      */   public Object evalsha(String sha1, List<String> keys, List<String> args) {
/* 2790 */     return evalsha(sha1, keys.size(), getParams(keys, args));
/*      */   }
/*      */ 
/*      */   public Object evalsha(String sha1, int keyCount, String[] params) {
/* 2794 */     checkIsInMulti();
/* 2795 */     this.client.evalsha(sha1, keyCount, params);
/*      */ 
/* 2797 */     return getEvalResult();
/*      */   }
/*      */ 
/*      */   public Boolean scriptExists(String sha1) {
/* 2801 */     String[] a = new String[1];
/* 2802 */     a[0] = sha1;
/* 2803 */     return (Boolean)scriptExists(a).get(0);
/*      */   }
/*      */ 
/*      */   public List<Boolean> scriptExists(String[] sha1) {
/* 2807 */     this.client.scriptExists(sha1);
/* 2808 */     List result = this.client.getIntegerMultiBulkReply();
/* 2809 */     List exists = new ArrayList();
/*      */ 
/* 2811 */     for (Long value : result) {
/* 2812 */       exists.add(Boolean.valueOf(value.longValue() == 1L));
/*      */     }
/* 2814 */     return exists;
/*      */   }
/*      */ 
/*      */   public String scriptLoad(String script) {
/* 2818 */     this.client.scriptLoad(script);
/* 2819 */     return this.client.getBulkReply();
/*      */   }
/*      */ 
/*      */   public List<Slowlog> slowlogGet() {
/* 2823 */     this.client.slowlogGet();
/* 2824 */     return Slowlog.from(this.client.getObjectMultiBulkReply());
/*      */   }
/*      */ 
/*      */   public List<Slowlog> slowlogGet(long entries) {
/* 2828 */     this.client.slowlogGet(entries);
/* 2829 */     return Slowlog.from(this.client.getObjectMultiBulkReply());
/*      */   }
/*      */ 
/*      */   public Long objectRefcount(String string) {
/* 2833 */     this.client.objectRefcount(string);
/* 2834 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public String objectEncoding(String string) {
/* 2838 */     this.client.objectEncoding(string);
/* 2839 */     return this.client.getBulkReply();
/*      */   }
/*      */ 
/*      */   public Long objectIdletime(String string) {
/* 2843 */     this.client.objectIdletime(string);
/* 2844 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long bitcount(String key) {
/* 2848 */     this.client.bitcount(key);
/* 2849 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long bitcount(String key, long start, long end) {
/* 2853 */     this.client.bitcount(key, start, end);
/* 2854 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public Long bitop(BitOP op, String destKey, String[] srcKeys) {
/* 2858 */     this.client.bitop(op, destKey, srcKeys);
/* 2859 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public List<Map<String, String>> sentinelMasters()
/*      */   {
/* 2895 */     this.client.sentinel(new String[] { "masters" });
/* 2896 */     List reply = this.client.getObjectMultiBulkReply();
/*      */ 
/* 2898 */     List masters = new ArrayList();
/* 2899 */     for (Iterator localIterator = reply.iterator(); localIterator.hasNext(); ) { Object obj = localIterator.next();
/* 2900 */       masters.add((Map)BuilderFactory.STRING_MAP.build((List)obj));
/*      */     }
/* 2902 */     return masters;
/*      */   }
/*      */ 
/*      */   public List<String> sentinelGetMasterAddrByName(String masterName)
/*      */   {
/* 2916 */     this.client.sentinel(new String[] { "get-master-addr-by-name", masterName });
/* 2917 */     List reply = this.client.getObjectMultiBulkReply();
/* 2918 */     return (List)BuilderFactory.STRING_LIST.build(reply);
/*      */   }
/*      */ 
/*      */   public Long sentinelReset(String pattern)
/*      */   {
/* 2931 */     this.client.sentinel(new String[] { "reset", pattern });
/* 2932 */     return this.client.getIntegerReply();
/*      */   }
/*      */ 
/*      */   public List<Map<String, String>> sentinelSlaves(String masterName)
/*      */   {
/* 2972 */     this.client.sentinel(new String[] { "slaves", masterName });
/* 2973 */     List reply = this.client.getObjectMultiBulkReply();
/*      */ 
/* 2975 */     List slaves = new ArrayList();
/* 2976 */     for (Iterator localIterator = reply.iterator(); localIterator.hasNext(); ) { Object obj = localIterator.next();
/* 2977 */       slaves.add((Map)BuilderFactory.STRING_MAP.build((List)obj));
/*      */     }
/* 2979 */     return slaves;
/*      */   }
/*      */ 
/*      */   public List<? extends Object> sentinelIsMasterDownByAddr(String host, int port)
/*      */   {
/* 2996 */     this.client.sentinel("is-master-down-by-addr", host, port);
/* 2997 */     List reply = this.client.getObjectMultiBulkReply();
/*      */ 
/* 2999 */     return Arrays.asList(new Comparable[] { (Comparable)BuilderFactory.LONG.build(reply.get(0)), 
/* 2999 */       (Comparable)BuilderFactory.STRING.build(reply.get(1)) });
/*      */   }
/*      */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.Jedis
 * JD-Core Version:    0.6.0
 */