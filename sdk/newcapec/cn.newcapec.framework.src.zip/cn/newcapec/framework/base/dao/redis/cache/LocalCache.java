package cn.newcapec.framework.base.dao.redis.cache;

import java.util.Collection;
import java.util.Date;
import java.util.Set;

public abstract interface LocalCache<K, V>
{
  public abstract V put(K paramK, V paramV);

  public abstract V put(K paramK, V paramV, Date paramDate);

  public abstract V put(K paramK, V paramV, int paramInt);

  public abstract V get(K paramK);

  public abstract V remove(K paramK);

  public abstract boolean clear();

  public abstract int size();

  public abstract Set<K> keySet();

  public abstract Collection<V> values();

  public abstract boolean containsKey(K paramK);

  public abstract void destroy();
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.cache.LocalCache
 * JD-Core Version:    0.6.0
 */