/*    */ package cn.newcapec.framework.base.dao.redis.core;
/*    */ 
/*    */ import cn.newcapec.framework.base.dao.redis.util.SafeEncoder;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ public class Tuple
/*    */   implements Comparable<Tuple>
/*    */ {
/*    */   private byte[] element;
/*    */   private Double score;
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 12 */     int prime = 31;
/* 13 */     int result = 1;
/* 14 */     result *= 31;
/* 15 */     if (this.element != null) {
/* 16 */       for (byte b : this.element) {
/* 17 */         result = 31 * result + b;
/*    */       }
/*    */     }
/*    */ 
/* 21 */     long temp = Double.doubleToLongBits(this.score.doubleValue());
/* 22 */     result = 31 * result + (int)(temp ^ temp >>> 32);
/* 23 */     return result;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj) {
/* 27 */     if (this == obj)
/* 28 */       return true;
/* 29 */     if (obj == null)
/* 30 */       return false;
/* 31 */     if (getClass() != obj.getClass())
/* 32 */       return false;
/* 33 */     Tuple other = (Tuple)obj;
/* 34 */     if (this.element == null) {
/* 35 */       if (other.element != null)
/* 36 */         return false;
/* 37 */     } else if (!Arrays.equals(this.element, other.element))
/* 38 */       return false;
/* 39 */     return true;
/*    */   }
/*    */ 
/*    */   public int compareTo(Tuple other) {
/* 43 */     if (Arrays.equals(this.element, other.element)) {
/* 44 */       return 0;
/*    */     }
/* 46 */     return this.score.doubleValue() < other.getScore() ? -1 : 1;
/*    */   }
/*    */ 
/*    */   public Tuple(String element, Double score)
/*    */   {
/* 51 */     this.element = SafeEncoder.encode(element);
/* 52 */     this.score = score;
/*    */   }
/*    */ 
/*    */   public Tuple(byte[] element, Double score)
/*    */   {
/* 57 */     this.element = element;
/* 58 */     this.score = score;
/*    */   }
/*    */ 
/*    */   public String getElement() {
/* 62 */     if (this.element != null) {
/* 63 */       return SafeEncoder.encode(this.element);
/*    */     }
/* 65 */     return null;
/*    */   }
/*    */ 
/*    */   public byte[] getBinaryElement()
/*    */   {
/* 70 */     return this.element;
/*    */   }
/*    */ 
/*    */   public double getScore() {
/* 74 */     return this.score.doubleValue();
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 78 */     return '[' + Arrays.toString(this.element) + ',' + this.score + ']';
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.Tuple
 * JD-Core Version:    0.6.0
 */