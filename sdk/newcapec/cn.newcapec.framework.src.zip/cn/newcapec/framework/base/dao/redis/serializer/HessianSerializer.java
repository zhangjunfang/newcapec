/*    */ package cn.newcapec.framework.base.dao.redis.serializer;
/*    */ 
/*    */ import cn.newcapec.framework.base.dao.redis.exception.SerializationException;
/*    */ import com.caucho.hessian.io.HessianInput;
/*    */ import com.caucho.hessian.io.HessianOutput;
/*    */ import com.caucho.hessian.io.SerializerFactory;
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public class HessianSerializer
/*    */   implements TedisSerializer<Object>
/*    */ {
/* 22 */   private static SerializerFactory _serializerFactory = new SerializerFactory();
/*    */ 
/*    */   public static HessianOutput createHessianOutput(OutputStream out)
/*    */   {
/* 26 */     HessianOutput hout = new HessianOutput(out);
/* 27 */     hout.setSerializerFactory(_serializerFactory);
/* 28 */     return hout;
/*    */   }
/*    */ 
/*    */   public static HessianInput createHessianInput(InputStream in) {
/* 32 */     HessianInput hin = new HessianInput(in);
/* 33 */     hin.setSerializerFactory(_serializerFactory);
/* 34 */     return hin;
/*    */   }
/*    */ 
/*    */   public Object deserialize(byte[] bytes) throws SerializationException
/*    */   {
/* 39 */     if (bytes == null)
/* 40 */       return null;
/*    */     try
/*    */     {
/* 43 */       ByteArrayInputStream input = new ByteArrayInputStream(bytes);
/* 44 */       HessianInput hin = createHessianInput(input);
/* 45 */       return hin.readObject(); } catch (IOException e) {
/*    */     }
/* 47 */     throw new SerializationException("反序列化对象失败", e);
/*    */   }
/*    */ 
/*    */   public byte[] serialize(Object t) throws SerializationException
/*    */   {
/*    */     try
/*    */     {
/* 54 */       ByteArrayOutputStream bout = new ByteArrayOutputStream();
/* 55 */       createHessianOutput(bout).writeObject(t);
/* 56 */       return bout.toByteArray(); } catch (IOException e) {
/*    */     }
/* 58 */     throw new SerializationException("序列化对象失败：" + t.getClass(), e);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.serializer.HessianSerializer
 * JD-Core Version:    0.6.0
 */