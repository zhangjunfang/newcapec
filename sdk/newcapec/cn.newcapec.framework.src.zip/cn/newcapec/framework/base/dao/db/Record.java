/*     */ package cn.newcapec.framework.base.dao.db;
/*     */ 
/*     */ import cn.newcapec.framework.base.exception.BaseException;
/*     */ import cn.newcapec.framework.utils.tools.BeanUtils;
/*     */ import cn.newcapec.framework.utils.tools.StringUtil;
/*     */ import cn.newcapec.framework.utils.variant.VariantSet;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class Record extends VariantSet
/*     */ {
/*  19 */   private Logger logger = Logger.getLogger(getClass().getName());
/*     */   private int state;
/*     */   public static final int ADD = 1;
/*     */   public static final int MODIFY = 2;
/*     */   public static final int DELETE = 3;
/*     */ 
/*     */   public int getState()
/*     */   {
/*  30 */     return this.state;
/*     */   }
/*     */ 
/*     */   public void setState(int state) {
/*  34 */     this.state = state;
/*     */   }
/*     */ 
/*     */   public static Record fromDO(Object object)
/*     */   {
/*  44 */     Record record = null;
/*  45 */     Method[] method = object.getClass().getMethods();
/*  46 */     int i = 0; for (int len = method.length; i < len; i++) {
/*  47 */       if (record == null) {
/*  48 */         record = new Record();
/*     */       }
/*  50 */       Method aMethod = method[i];
/*  51 */       String methodname = aMethod.getName();
/*  52 */       if (methodname.startsWith("set")) {
/*  53 */         String propertyName = methodname.substring(3);
/*  54 */         String s = String.valueOf(propertyName.charAt(0)).toLowerCase();
/*  55 */         propertyName = s + propertyName.substring(1);
/*  56 */         record.setValue(propertyName, 
/*  57 */           BeanUtils.getProperty(object, propertyName));
/*     */       }
/*     */     }
/*     */ 
/*  61 */     return record;
/*     */   }
/*     */ 
/*     */   public void toDO(Object obj)
/*     */   {
/*  71 */     int i = 0; for (int len = count(); i < len; i++) {
/*  72 */       String name = indexToName(i);
/*  73 */       Object value = getValue(i);
/*     */ 
/*  75 */       if (((value instanceof String)) && 
/*  76 */         (StringUtil.isEmpty((String)value)))
/*  77 */         value = null;
/*     */       try
/*     */       {
/*  80 */         BeanUtils.copyProperty(obj, name, value);
/*     */       }
/*     */       catch (Exception ex) {
/*  83 */         this.logger.error(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public <T> T toDO(Class<T> clazz)
/*     */   {
/*     */     try
/*     */     {
/*  96 */       Object object = clazz.newInstance();
/*  97 */       toDO(object);
/*  98 */       return object; } catch (Exception ex) {
/*     */     }
/* 100 */     throw new BaseException("转换DO对象出错！", ex);
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.db.Record
 * JD-Core Version:    0.6.0
 */