/*    */ package cn.newcapec.framework.base.dao.hibernate;
/*    */ 
/*    */ import org.hibernate.Hibernate;
/*    */ import org.hibernate.dialect.MySQL5Dialect;
/*    */ import org.hibernate.type.NullableType;
/*    */ 
/*    */ public class NewcapecSQLDialect extends MySQL5Dialect
/*    */ {
/*    */   public NewcapecSQLDialect()
/*    */   {
/* 19 */     registerHibernateType(-1, Hibernate.STRING.getName());
/* 20 */     registerHibernateType(-1, Hibernate.TEXT.getName());
/* 21 */     registerHibernateType(3, Hibernate.BIG_INTEGER.getName());
/* 22 */     registerHibernateType(-1, 65535, "text");
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.hibernate.NewcapecSQLDialect
 * JD-Core Version:    0.6.0
 */