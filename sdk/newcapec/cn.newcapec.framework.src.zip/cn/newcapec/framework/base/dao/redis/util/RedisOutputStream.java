/*     */ package cn.newcapec.framework.base.dao.redis.util;
/*     */ 
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public final class RedisOutputStream extends FilterOutputStream
/*     */ {
/*     */   protected final byte[] buf;
/*     */   protected int count;
/* 151 */   private static final int[] sizeTable = { 9, 99, 999, 9999, 99999, 999999, 9999999, 99999999, 999999999, 2147483647 };
/*     */ 
/* 153 */   private static final byte[] DigitTens = { 
/* 154 */     48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 
/* 155 */     49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 
/* 156 */     50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 
/* 157 */     51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 
/* 158 */     52, 52, 52, 52, 52, 52, 52, 52, 52, 52, 
/* 159 */     53, 53, 53, 53, 53, 53, 53, 53, 53, 53, 
/* 160 */     54, 54, 54, 54, 54, 54, 54, 54, 54, 54, 
/* 161 */     55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 
/* 162 */     56, 56, 56, 56, 56, 56, 56, 56, 56, 56, 
/* 163 */     57, 57, 57, 57, 57, 57, 57, 57, 57, 57 };
/*     */ 
/* 166 */   private static final byte[] DigitOnes = { 
/* 167 */     48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 
/* 168 */     48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 
/* 169 */     48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 
/* 170 */     48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 
/* 171 */     48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 
/* 172 */     48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 
/* 173 */     48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 
/* 174 */     48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 
/* 175 */     48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 
/* 176 */     48, 49, 50, 51, 52, 53, 54, 55, 56, 57 };
/*     */ 
/* 179 */   private static final byte[] digits = { 
/* 180 */     48, 49, 50, 51, 52, 53, 
/* 181 */     54, 55, 56, 57, 97, 98, 
/* 182 */     99, 100, 101, 102, 103, 104, 
/* 183 */     105, 106, 107, 108, 109, 110, 
/* 184 */     111, 112, 113, 114, 115, 116, 
/* 185 */     117, 118, 119, 120, 121, 122 };
/*     */ 
/*     */   public RedisOutputStream(OutputStream out)
/*     */   {
/*  16 */     this(out, 8192);
/*     */   }
/*     */ 
/*     */   public RedisOutputStream(OutputStream out, int size) {
/*  20 */     super(out);
/*  21 */     if (size <= 0) {
/*  22 */       throw new IllegalArgumentException("Buffer size <= 0");
/*     */     }
/*  24 */     this.buf = new byte[size];
/*     */   }
/*     */ 
/*     */   private void flushBuffer() throws IOException {
/*  28 */     if (this.count > 0) {
/*  29 */       this.out.write(this.buf, 0, this.count);
/*  30 */       this.count = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void write(byte b) throws IOException {
/*  35 */     this.buf[(this.count++)] = b;
/*  36 */     if (this.count == this.buf.length)
/*  37 */       flushBuffer();
/*     */   }
/*     */ 
/*     */   public void write(byte[] b) throws IOException
/*     */   {
/*  42 */     write(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/*  46 */     if (len >= this.buf.length) {
/*  47 */       flushBuffer();
/*  48 */       this.out.write(b, off, len);
/*     */     } else {
/*  50 */       if (len >= this.buf.length - this.count) {
/*  51 */         flushBuffer();
/*     */       }
/*     */ 
/*  54 */       System.arraycopy(b, off, this.buf, this.count, len);
/*  55 */       this.count += len;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void writeAsciiCrLf(String in) throws IOException {
/*  60 */     int size = in.length();
/*     */ 
/*  62 */     for (int i = 0; i != size; i++) {
/*  63 */       this.buf[(this.count++)] = (byte)in.charAt(i);
/*  64 */       if (this.count == this.buf.length) {
/*  65 */         flushBuffer();
/*     */       }
/*     */     }
/*     */ 
/*  69 */     writeCrLf();
/*     */   }
/*     */ 
/*     */   public static boolean isSurrogate(char ch) {
/*  73 */     return (ch >= 55296) && (ch <= 57343);
/*     */   }
/*     */ 
/*     */   public static int utf8Length(String str) {
/*  77 */     int strLen = str.length(); int utfLen = 0;
/*  78 */     for (int i = 0; i != strLen; i++) {
/*  79 */       char c = str.charAt(i);
/*  80 */       if (c < '') {
/*  81 */         utfLen++;
/*  82 */       } else if (c < 'ࠀ') {
/*  83 */         utfLen += 2;
/*  84 */       } else if (isSurrogate(c)) {
/*  85 */         i++;
/*  86 */         utfLen += 4;
/*     */       } else {
/*  88 */         utfLen += 3;
/*     */       }
/*     */     }
/*  91 */     return utfLen;
/*     */   }
/*     */ 
/*     */   public void writeCrLf() throws IOException {
/*  95 */     if (2 >= this.buf.length - this.count) {
/*  96 */       flushBuffer();
/*     */     }
/*     */ 
/*  99 */     this.buf[(this.count++)] = 13;
/* 100 */     this.buf[(this.count++)] = 10;
/*     */   }
/*     */ 
/*     */   public void writeUtf8CrLf(String str) throws IOException {
/* 104 */     int strLen = str.length();
/*     */ 
/* 107 */     for (int i = 0; i < strLen; i++) {
/* 108 */       char c = str.charAt(i);
/* 109 */       if (c >= '') break;
/* 110 */       this.buf[(this.count++)] = (byte)c;
/* 111 */       if (this.count == this.buf.length) {
/* 112 */         flushBuffer();
/*     */       }
/*     */     }
/*     */ 
/* 116 */     for (; i < strLen; i++) {
/* 117 */       char c = str.charAt(i);
/* 118 */       if (c < '') {
/* 119 */         this.buf[(this.count++)] = (byte)c;
/* 120 */         if (this.count == this.buf.length)
/* 121 */           flushBuffer();
/*     */       }
/* 123 */       else if (c < 'ࠀ') {
/* 124 */         if (2 >= this.buf.length - this.count) {
/* 125 */           flushBuffer();
/*     */         }
/* 127 */         this.buf[(this.count++)] = (byte)(0xC0 | c >> '\006');
/* 128 */         this.buf[(this.count++)] = (byte)(0x80 | c & 0x3F);
/* 129 */       } else if (isSurrogate(c)) {
/* 130 */         if (4 >= this.buf.length - this.count) {
/* 131 */           flushBuffer();
/*     */         }
/* 133 */         int uc = Character.toCodePoint(c, str.charAt(i++));
/* 134 */         this.buf[(this.count++)] = (byte)(0xF0 | uc >> 18);
/* 135 */         this.buf[(this.count++)] = (byte)(0x80 | uc >> 12 & 0x3F);
/* 136 */         this.buf[(this.count++)] = (byte)(0x80 | uc >> 6 & 0x3F);
/* 137 */         this.buf[(this.count++)] = (byte)(0x80 | uc & 0x3F);
/*     */       } else {
/* 139 */         if (3 >= this.buf.length - this.count) {
/* 140 */           flushBuffer();
/*     */         }
/* 142 */         this.buf[(this.count++)] = (byte)(0xE0 | c >> '\f');
/* 143 */         this.buf[(this.count++)] = (byte)(0x80 | c >> '\006' & 0x3F);
/* 144 */         this.buf[(this.count++)] = (byte)(0x80 | c & 0x3F);
/*     */       }
/*     */     }
/*     */ 
/* 148 */     writeCrLf();
/*     */   }
/*     */ 
/*     */   public void writeIntCrLf(int value)
/*     */     throws IOException
/*     */   {
/* 189 */     if (value < 0) {
/* 190 */       write(45);
/* 191 */       value = -value;
/*     */     }
/*     */ 
/* 194 */     int size = 0;
/* 195 */     while (value > sizeTable[size]) {
/* 196 */       size++;
/*     */     }
/* 198 */     size++;
/* 199 */     if (size >= this.buf.length - this.count) {
/* 200 */       flushBuffer();
/*     */     }
/*     */ 
/* 204 */     int charPos = this.count + size;
/*     */ 
/* 206 */     while (value >= 65536) {
/* 207 */       int q = value / 100;
/* 208 */       int r = value - ((q << 6) + (q << 5) + (q << 2));
/* 209 */       value = q;
/* 210 */       charPos--; this.buf[charPos] = DigitOnes[r];
/* 211 */       charPos--; this.buf[charPos] = DigitTens[r];
/*     */     }
/*     */     do
/*     */     {
/* 215 */       int q = value * 52429 >>> 19;
/* 216 */       int r = value - ((q << 3) + (q << 1));
/* 217 */       charPos--; this.buf[charPos] = digits[r];
/* 218 */       value = q;
/* 219 */     }while (value != 0);
/*     */ 
/* 221 */     this.count += size;
/*     */ 
/* 223 */     writeCrLf();
/*     */   }
/*     */ 
/*     */   public void flush() throws IOException {
/* 227 */     flushBuffer();
/* 228 */     this.out.flush();
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.util.RedisOutputStream
 * JD-Core Version:    0.6.0
 */