/*    */ package cn.newcapec.framework.base.dao.redis.core;
/*    */ 
/*    */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisException;
/*    */ 
/*    */ public abstract class TransactionBlock extends Transaction
/*    */ {
/*    */   public TransactionBlock(Client client)
/*    */   {
/*  7 */     super(client);
/*    */   }
/*    */   public TransactionBlock() {
/*    */   }
/*    */ 
/*    */   public abstract void execute() throws JedisException;
/*    */ 
/*    */   public void setClient(Client client) {
/* 16 */     this.client = client;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.TransactionBlock
 * JD-Core Version:    0.6.0
 */