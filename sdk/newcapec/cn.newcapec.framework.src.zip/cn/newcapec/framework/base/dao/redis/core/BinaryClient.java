/*     */ package cn.newcapec.framework.base.dao.redis.core;
/*     */ 
/*     */ import cn.newcapec.framework.base.dao.redis.util.SafeEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public class BinaryClient extends Connection
/*     */ {
/*     */   private boolean isInMulti;
/*     */   private String password;
/*     */   private long db;
/*     */ 
/*     */   public boolean isInMulti()
/*     */   {
/*  42 */     return this.isInMulti;
/*     */   }
/*     */ 
/*     */   public BinaryClient(String host) {
/*  46 */     super(host);
/*     */   }
/*     */ 
/*     */   public BinaryClient(String host, int port) {
/*  50 */     super(host, port);
/*     */   }
/*     */ 
/*     */   private byte[][] joinParameters(byte[] first, byte[][] rest) {
/*  54 */     byte[][] result = new byte[rest.length + 1][];
/*  55 */     result[0] = first;
/*  56 */     for (int i = 0; i < rest.length; i++) {
/*  57 */       result[(i + 1)] = rest[i];
/*     */     }
/*  59 */     return result;
/*     */   }
/*     */ 
/*     */   public void setPassword(String password) {
/*  63 */     this.password = password;
/*     */   }
/*     */ 
/*     */   public void connect()
/*     */   {
/*  68 */     if (!isConnected()) {
/*  69 */       super.connect();
/*  70 */       if (this.password != null) {
/*  71 */         auth(this.password);
/*  72 */         getStatusCodeReply();
/*     */       }
/*  74 */       if (this.db > 0L) {
/*  75 */         select(Long.valueOf(this.db).intValue());
/*  76 */         getStatusCodeReply();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void ping() {
/*  82 */     sendCommand(Protocol.Command.PING);
/*     */   }
/*     */ 
/*     */   public void set(byte[] key, byte[] value) {
/*  86 */     sendCommand(Protocol.Command.SET, new byte[][] { key, value });
/*     */   }
/*     */ 
/*     */   public void get(byte[] key) {
/*  90 */     sendCommand(Protocol.Command.GET, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void quit() {
/*  94 */     this.db = 0L;
/*  95 */     sendCommand(Protocol.Command.QUIT);
/*     */   }
/*     */ 
/*     */   public void exists(byte[] key) {
/*  99 */     sendCommand(Protocol.Command.EXISTS, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void del(byte[][] keys) {
/* 103 */     sendCommand(Protocol.Command.DEL, keys);
/*     */   }
/*     */ 
/*     */   public void type(byte[] key) {
/* 107 */     sendCommand(Protocol.Command.TYPE, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void flushDB() {
/* 111 */     sendCommand(Protocol.Command.FLUSHDB);
/*     */   }
/*     */ 
/*     */   public void keys(byte[] pattern) {
/* 115 */     sendCommand(Protocol.Command.KEYS, new byte[][] { pattern });
/*     */   }
/*     */ 
/*     */   public void randomKey() {
/* 119 */     sendCommand(Protocol.Command.RANDOMKEY);
/*     */   }
/*     */ 
/*     */   public void rename(byte[] oldkey, byte[] newkey) {
/* 123 */     sendCommand(Protocol.Command.RENAME, new byte[][] { oldkey, newkey });
/*     */   }
/*     */ 
/*     */   public void renamenx(byte[] oldkey, byte[] newkey) {
/* 127 */     sendCommand(Protocol.Command.RENAMENX, new byte[][] { oldkey, newkey });
/*     */   }
/*     */ 
/*     */   public void dbSize() {
/* 131 */     sendCommand(Protocol.Command.DBSIZE);
/*     */   }
/*     */ 
/*     */   public void expire(byte[] key, int seconds) {
/* 135 */     sendCommand(Protocol.Command.EXPIRE, new byte[][] { key, Protocol.toByteArray(seconds) });
/*     */   }
/*     */ 
/*     */   public void expireAt(byte[] key, long unixTime) {
/* 139 */     sendCommand(Protocol.Command.EXPIREAT, new byte[][] { key, Protocol.toByteArray(unixTime) });
/*     */   }
/*     */ 
/*     */   public void ttl(byte[] key) {
/* 143 */     sendCommand(Protocol.Command.TTL, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void select(int index) {
/* 147 */     this.db = index;
/* 148 */     sendCommand(Protocol.Command.SELECT, new byte[][] { Protocol.toByteArray(index) });
/*     */   }
/*     */ 
/*     */   public void move(byte[] key, int dbIndex) {
/* 152 */     sendCommand(Protocol.Command.MOVE, new byte[][] { key, Protocol.toByteArray(dbIndex) });
/*     */   }
/*     */ 
/*     */   public void flushAll() {
/* 156 */     sendCommand(Protocol.Command.FLUSHALL);
/*     */   }
/*     */ 
/*     */   public void getSet(byte[] key, byte[] value) {
/* 160 */     sendCommand(Protocol.Command.GETSET, new byte[][] { key, value });
/*     */   }
/*     */ 
/*     */   public void mget(byte[][] keys) {
/* 164 */     sendCommand(Protocol.Command.MGET, keys);
/*     */   }
/*     */ 
/*     */   public void setnx(byte[] key, byte[] value) {
/* 168 */     sendCommand(Protocol.Command.SETNX, new byte[][] { key, value });
/*     */   }
/*     */ 
/*     */   public void setex(byte[] key, int seconds, byte[] value) {
/* 172 */     sendCommand(Protocol.Command.SETEX, new byte[][] { key, Protocol.toByteArray(seconds), value });
/*     */   }
/*     */ 
/*     */   public void mset(byte[][] keysvalues) {
/* 176 */     sendCommand(Protocol.Command.MSET, keysvalues);
/*     */   }
/*     */ 
/*     */   public void msetnx(byte[][] keysvalues) {
/* 180 */     sendCommand(Protocol.Command.MSETNX, keysvalues);
/*     */   }
/*     */ 
/*     */   public void decrBy(byte[] key, long integer) {
/* 184 */     sendCommand(Protocol.Command.DECRBY, new byte[][] { key, Protocol.toByteArray(integer) });
/*     */   }
/*     */ 
/*     */   public void decr(byte[] key) {
/* 188 */     sendCommand(Protocol.Command.DECR, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void incrBy(byte[] key, long integer) {
/* 192 */     sendCommand(Protocol.Command.INCRBY, new byte[][] { key, Protocol.toByteArray(integer) });
/*     */   }
/*     */ 
/*     */   public void incr(byte[] key) {
/* 196 */     sendCommand(Protocol.Command.INCR, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void append(byte[] key, byte[] value) {
/* 200 */     sendCommand(Protocol.Command.APPEND, new byte[][] { key, value });
/*     */   }
/*     */ 
/*     */   public void substr(byte[] key, int start, int end) {
/* 204 */     sendCommand(Protocol.Command.SUBSTR, new byte[][] { key, Protocol.toByteArray(start), Protocol.toByteArray(end) });
/*     */   }
/*     */ 
/*     */   public void hset(byte[] key, byte[] field, byte[] value) {
/* 208 */     sendCommand(Protocol.Command.HSET, new byte[][] { key, field, value });
/*     */   }
/*     */ 
/*     */   public void hget(byte[] key, byte[] field) {
/* 212 */     sendCommand(Protocol.Command.HGET, new byte[][] { key, field });
/*     */   }
/*     */ 
/*     */   public void hsetnx(byte[] key, byte[] field, byte[] value) {
/* 216 */     sendCommand(Protocol.Command.HSETNX, new byte[][] { key, field, value });
/*     */   }
/*     */ 
/*     */   public void hmset(byte[] key, Map<byte[], byte[]> hash) {
/* 220 */     List params = new ArrayList();
/* 221 */     params.add(key);
/*     */ 
/* 223 */     for (Map.Entry entry : hash.entrySet()) {
/* 224 */       params.add((byte[])entry.getKey());
/* 225 */       params.add((byte[])entry.getValue());
/*     */     }
/* 227 */     sendCommand(Protocol.Command.HMSET, (byte[][])params.toArray(new byte[params.size()][]));
/*     */   }
/*     */ 
/*     */   public void hmget(byte[] key, byte[][] fields) {
/* 231 */     byte[][] params = new byte[fields.length + 1][];
/* 232 */     params[0] = key;
/* 233 */     System.arraycopy(fields, 0, params, 1, fields.length);
/* 234 */     sendCommand(Protocol.Command.HMGET, params);
/*     */   }
/*     */ 
/*     */   public void hincrBy(byte[] key, byte[] field, long value) {
/* 238 */     sendCommand(Protocol.Command.HINCRBY, new byte[][] { key, field, Protocol.toByteArray(value) });
/*     */   }
/*     */ 
/*     */   public void hexists(byte[] key, byte[] field) {
/* 242 */     sendCommand(Protocol.Command.HEXISTS, new byte[][] { key, field });
/*     */   }
/*     */ 
/*     */   public void hdel(byte[] key, byte[][] fields) {
/* 246 */     sendCommand(Protocol.Command.HDEL, joinParameters(key, fields));
/*     */   }
/*     */ 
/*     */   public void hlen(byte[] key) {
/* 250 */     sendCommand(Protocol.Command.HLEN, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void hkeys(byte[] key) {
/* 254 */     sendCommand(Protocol.Command.HKEYS, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void hvals(byte[] key) {
/* 258 */     sendCommand(Protocol.Command.HVALS, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void hgetAll(byte[] key) {
/* 262 */     sendCommand(Protocol.Command.HGETALL, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void rpush(byte[] key, byte[][] strings) {
/* 266 */     sendCommand(Protocol.Command.RPUSH, joinParameters(key, strings));
/*     */   }
/*     */ 
/*     */   public void lpush(byte[] key, byte[][] strings) {
/* 270 */     sendCommand(Protocol.Command.LPUSH, joinParameters(key, strings));
/*     */   }
/*     */ 
/*     */   public void llen(byte[] key) {
/* 274 */     sendCommand(Protocol.Command.LLEN, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void lrange(byte[] key, long start, long end) {
/* 278 */     sendCommand(Protocol.Command.LRANGE, new byte[][] { key, Protocol.toByteArray(start), Protocol.toByteArray(end) });
/*     */   }
/*     */ 
/*     */   public void ltrim(byte[] key, long start, long end) {
/* 282 */     sendCommand(Protocol.Command.LTRIM, new byte[][] { key, Protocol.toByteArray(start), Protocol.toByteArray(end) });
/*     */   }
/*     */ 
/*     */   public void lindex(byte[] key, long index) {
/* 286 */     sendCommand(Protocol.Command.LINDEX, new byte[][] { key, Protocol.toByteArray(index) });
/*     */   }
/*     */ 
/*     */   public void lset(byte[] key, long index, byte[] value) {
/* 290 */     sendCommand(Protocol.Command.LSET, new byte[][] { key, Protocol.toByteArray(index), value });
/*     */   }
/*     */ 
/*     */   public void lrem(byte[] key, long count, byte[] value) {
/* 294 */     sendCommand(Protocol.Command.LREM, new byte[][] { key, Protocol.toByteArray(count), value });
/*     */   }
/*     */ 
/*     */   public void lpop(byte[] key) {
/* 298 */     sendCommand(Protocol.Command.LPOP, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void rpop(byte[] key) {
/* 302 */     sendCommand(Protocol.Command.RPOP, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void rpoplpush(byte[] srckey, byte[] dstkey) {
/* 306 */     sendCommand(Protocol.Command.RPOPLPUSH, new byte[][] { srckey, dstkey });
/*     */   }
/*     */ 
/*     */   public void sadd(byte[] key, byte[][] members) {
/* 310 */     sendCommand(Protocol.Command.SADD, joinParameters(key, members));
/*     */   }
/*     */ 
/*     */   public void smembers(byte[] key) {
/* 314 */     sendCommand(Protocol.Command.SMEMBERS, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void srem(byte[] key, byte[][] members) {
/* 318 */     sendCommand(Protocol.Command.SREM, joinParameters(key, members));
/*     */   }
/*     */ 
/*     */   public void spop(byte[] key) {
/* 322 */     sendCommand(Protocol.Command.SPOP, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void smove(byte[] srckey, byte[] dstkey, byte[] member)
/*     */   {
/* 327 */     sendCommand(Protocol.Command.SMOVE, new byte[][] { srckey, dstkey, member });
/*     */   }
/*     */ 
/*     */   public void scard(byte[] key) {
/* 331 */     sendCommand(Protocol.Command.SCARD, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void sismember(byte[] key, byte[] member) {
/* 335 */     sendCommand(Protocol.Command.SISMEMBER, new byte[][] { key, member });
/*     */   }
/*     */ 
/*     */   public void sinter(byte[][] keys) {
/* 339 */     sendCommand(Protocol.Command.SINTER, keys);
/*     */   }
/*     */ 
/*     */   public void sinterstore(byte[] dstkey, byte[][] keys) {
/* 343 */     byte[][] params = new byte[keys.length + 1][];
/* 344 */     params[0] = dstkey;
/* 345 */     System.arraycopy(keys, 0, params, 1, keys.length);
/* 346 */     sendCommand(Protocol.Command.SINTERSTORE, params);
/*     */   }
/*     */ 
/*     */   public void sunion(byte[][] keys) {
/* 350 */     sendCommand(Protocol.Command.SUNION, keys);
/*     */   }
/*     */ 
/*     */   public void sunionstore(byte[] dstkey, byte[][] keys) {
/* 354 */     byte[][] params = new byte[keys.length + 1][];
/* 355 */     params[0] = dstkey;
/* 356 */     System.arraycopy(keys, 0, params, 1, keys.length);
/* 357 */     sendCommand(Protocol.Command.SUNIONSTORE, params);
/*     */   }
/*     */ 
/*     */   public void sdiff(byte[][] keys) {
/* 361 */     sendCommand(Protocol.Command.SDIFF, keys);
/*     */   }
/*     */ 
/*     */   public void sdiffstore(byte[] dstkey, byte[][] keys) {
/* 365 */     byte[][] params = new byte[keys.length + 1][];
/* 366 */     params[0] = dstkey;
/* 367 */     System.arraycopy(keys, 0, params, 1, keys.length);
/* 368 */     sendCommand(Protocol.Command.SDIFFSTORE, params);
/*     */   }
/*     */ 
/*     */   public void srandmember(byte[] key) {
/* 372 */     sendCommand(Protocol.Command.SRANDMEMBER, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void zadd(byte[] key, double score, byte[] member) {
/* 376 */     sendCommand(Protocol.Command.ZADD, new byte[][] { key, Protocol.toByteArray(score), member });
/*     */   }
/*     */ 
/*     */   public void zaddBinary(byte[] key, Map<Double, byte[]> scoreMembers) {
/* 380 */     ArrayList args = new ArrayList(
/* 381 */       scoreMembers.size() * 2 + 1);
/*     */ 
/* 383 */     args.add(key);
/*     */ 
/* 385 */     for (Map.Entry entry : scoreMembers.entrySet()) {
/* 386 */       args.add(Protocol.toByteArray(((Double)entry.getKey()).doubleValue()));
/* 387 */       args.add((byte[])entry.getValue());
/*     */     }
/*     */ 
/* 390 */     byte[][] argsArray = new byte[args.size()][];
/* 391 */     args.toArray(argsArray);
/*     */ 
/* 393 */     sendCommand(Protocol.Command.ZADD, argsArray);
/*     */   }
/*     */ 
/*     */   public void zrange(byte[] key, long start, long end) {
/* 397 */     sendCommand(Protocol.Command.ZRANGE, new byte[][] { key, Protocol.toByteArray(start), Protocol.toByteArray(end) });
/*     */   }
/*     */ 
/*     */   public void zrem(byte[] key, byte[][] members) {
/* 401 */     sendCommand(Protocol.Command.ZREM, joinParameters(key, members));
/*     */   }
/*     */ 
/*     */   public void zincrby(byte[] key, double score, byte[] member)
/*     */   {
/* 406 */     sendCommand(Protocol.Command.ZINCRBY, new byte[][] { key, Protocol.toByteArray(score), member });
/*     */   }
/*     */ 
/*     */   public void zrank(byte[] key, byte[] member) {
/* 410 */     sendCommand(Protocol.Command.ZRANK, new byte[][] { key, member });
/*     */   }
/*     */ 
/*     */   public void zrevrank(byte[] key, byte[] member) {
/* 414 */     sendCommand(Protocol.Command.ZREVRANK, new byte[][] { key, member });
/*     */   }
/*     */ 
/*     */   public void zrevrange(byte[] key, long start, long end) {
/* 418 */     sendCommand(Protocol.Command.ZREVRANGE, new byte[][] { key, Protocol.toByteArray(start), Protocol.toByteArray(end) });
/*     */   }
/*     */ 
/*     */   public void zrangeWithScores(byte[] key, long start, long end)
/*     */   {
/* 423 */     sendCommand(Protocol.Command.ZRANGE, new byte[][] { key, Protocol.toByteArray(start), Protocol.toByteArray(end), 
/* 424 */       Protocol.Keyword.WITHSCORES.raw });
/*     */   }
/*     */ 
/*     */   public void zrevrangeWithScores(byte[] key, long start, long end)
/*     */   {
/* 429 */     sendCommand(Protocol.Command.ZREVRANGE, new byte[][] { key, Protocol.toByteArray(start), Protocol.toByteArray(end), 
/* 430 */       Protocol.Keyword.WITHSCORES.raw });
/*     */   }
/*     */ 
/*     */   public void zcard(byte[] key) {
/* 434 */     sendCommand(Protocol.Command.ZCARD, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void zscore(byte[] key, byte[] member) {
/* 438 */     sendCommand(Protocol.Command.ZSCORE, new byte[][] { key, member });
/*     */   }
/*     */ 
/*     */   public void multi() {
/* 442 */     sendCommand(Protocol.Command.MULTI);
/* 443 */     this.isInMulti = true;
/*     */   }
/*     */ 
/*     */   public void discard() {
/* 447 */     sendCommand(Protocol.Command.DISCARD);
/* 448 */     this.isInMulti = false;
/*     */   }
/*     */ 
/*     */   public void exec() {
/* 452 */     sendCommand(Protocol.Command.EXEC);
/* 453 */     this.isInMulti = false;
/*     */   }
/*     */ 
/*     */   public void watch(byte[][] keys) {
/* 457 */     sendCommand(Protocol.Command.WATCH, keys);
/*     */   }
/*     */ 
/*     */   public void unwatch() {
/* 461 */     sendCommand(Protocol.Command.UNWATCH);
/*     */   }
/*     */ 
/*     */   public void sort(byte[] key) {
/* 465 */     sendCommand(Protocol.Command.SORT, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void sort(byte[] key, SortingParams sortingParameters) {
/* 469 */     List args = new ArrayList();
/* 470 */     args.add(key);
/* 471 */     args.addAll(sortingParameters.getParams());
/* 472 */     sendCommand(Protocol.Command.SORT, (byte[][])args.toArray(new byte[args.size()][]));
/*     */   }
/*     */ 
/*     */   public void blpop(byte[][] args) {
/* 476 */     sendCommand(Protocol.Command.BLPOP, args);
/*     */   }
/*     */ 
/*     */   public void sort(byte[] key, SortingParams sortingParameters, byte[] dstkey)
/*     */   {
/* 481 */     List args = new ArrayList();
/* 482 */     args.add(key);
/* 483 */     args.addAll(sortingParameters.getParams());
/* 484 */     args.add(Protocol.Keyword.STORE.raw);
/* 485 */     args.add(dstkey);
/* 486 */     sendCommand(Protocol.Command.SORT, (byte[][])args.toArray(new byte[args.size()][]));
/*     */   }
/*     */ 
/*     */   public void sort(byte[] key, byte[] dstkey) {
/* 490 */     sendCommand(Protocol.Command.SORT, new byte[][] { key, Protocol.Keyword.STORE.raw, dstkey });
/*     */   }
/*     */ 
/*     */   public void brpop(byte[][] args) {
/* 494 */     sendCommand(Protocol.Command.BRPOP, args);
/*     */   }
/*     */ 
/*     */   public void auth(String password) {
/* 498 */     setPassword(password);
/* 499 */     sendCommand(Protocol.Command.AUTH, new String[] { password });
/*     */   }
/*     */ 
/*     */   public void subscribe(byte[][] channels) {
/* 503 */     sendCommand(Protocol.Command.SUBSCRIBE, channels);
/*     */   }
/*     */ 
/*     */   public void publish(byte[] channel, byte[] message) {
/* 507 */     sendCommand(Protocol.Command.PUBLISH, new byte[][] { channel, message });
/*     */   }
/*     */ 
/*     */   public void unsubscribe() {
/* 511 */     sendCommand(Protocol.Command.UNSUBSCRIBE);
/*     */   }
/*     */ 
/*     */   public void unsubscribe(byte[][] channels) {
/* 515 */     sendCommand(Protocol.Command.UNSUBSCRIBE, channels);
/*     */   }
/*     */ 
/*     */   public void psubscribe(byte[][] patterns) {
/* 519 */     sendCommand(Protocol.Command.PSUBSCRIBE, patterns);
/*     */   }
/*     */ 
/*     */   public void punsubscribe() {
/* 523 */     sendCommand(Protocol.Command.PUNSUBSCRIBE);
/*     */   }
/*     */ 
/*     */   public void punsubscribe(byte[][] patterns) {
/* 527 */     sendCommand(Protocol.Command.PUNSUBSCRIBE, patterns);
/*     */   }
/*     */ 
/*     */   public void zcount(byte[] key, byte[] min, byte[] max) {
/* 531 */     sendCommand(Protocol.Command.ZCOUNT, new byte[][] { key, min, max });
/*     */   }
/*     */ 
/*     */   public void zrangeByScore(byte[] key, byte[] min, byte[] max)
/*     */   {
/* 536 */     sendCommand(Protocol.Command.ZRANGEBYSCORE, new byte[][] { key, min, max });
/*     */   }
/*     */ 
/*     */   public void zrevrangeByScore(byte[] key, byte[] max, byte[] min)
/*     */   {
/* 541 */     sendCommand(Protocol.Command.ZREVRANGEBYSCORE, new byte[][] { key, max, min });
/*     */   }
/*     */ 
/*     */   public void zrangeByScore(byte[] key, byte[] min, byte[] max, int offset, int count)
/*     */   {
/* 546 */     sendCommand(Protocol.Command.ZRANGEBYSCORE, new byte[][] { key, min, max, Protocol.Keyword.LIMIT.raw, 
/* 547 */       Protocol.toByteArray(offset), Protocol.toByteArray(count) });
/*     */   }
/*     */ 
/*     */   public void zrevrangeByScore(byte[] key, byte[] max, byte[] min, int offset, int count)
/*     */   {
/* 552 */     sendCommand(Protocol.Command.ZREVRANGEBYSCORE, new byte[][] { key, max, min, Protocol.Keyword.LIMIT.raw, 
/* 553 */       Protocol.toByteArray(offset), Protocol.toByteArray(count) });
/*     */   }
/*     */ 
/*     */   public void zrangeByScoreWithScores(byte[] key, byte[] min, byte[] max)
/*     */   {
/* 558 */     sendCommand(Protocol.Command.ZRANGEBYSCORE, new byte[][] { key, min, max, Protocol.Keyword.WITHSCORES.raw });
/*     */   }
/*     */ 
/*     */   public void zrevrangeByScoreWithScores(byte[] key, byte[] max, byte[] min)
/*     */   {
/* 563 */     sendCommand(Protocol.Command.ZREVRANGEBYSCORE, new byte[][] { key, max, min, Protocol.Keyword.WITHSCORES.raw });
/*     */   }
/*     */ 
/*     */   public void zrangeByScoreWithScores(byte[] key, byte[] min, byte[] max, int offset, int count)
/*     */   {
/* 568 */     sendCommand(Protocol.Command.ZRANGEBYSCORE, new byte[][] { key, min, max, Protocol.Keyword.LIMIT.raw, 
/* 569 */       Protocol.toByteArray(offset), Protocol.toByteArray(count), Protocol.Keyword.WITHSCORES.raw });
/*     */   }
/*     */ 
/*     */   public void zrevrangeByScoreWithScores(byte[] key, byte[] max, byte[] min, int offset, int count)
/*     */   {
/* 574 */     sendCommand(Protocol.Command.ZREVRANGEBYSCORE, new byte[][] { key, max, min, Protocol.Keyword.LIMIT.raw, 
/* 575 */       Protocol.toByteArray(offset), Protocol.toByteArray(count), Protocol.Keyword.WITHSCORES.raw });
/*     */   }
/*     */ 
/*     */   public void zremrangeByRank(byte[] key, long start, long end)
/*     */   {
/* 580 */     sendCommand(Protocol.Command.ZREMRANGEBYRANK, new byte[][] { key, Protocol.toByteArray(start), Protocol.toByteArray(end) });
/*     */   }
/*     */ 
/*     */   public void zremrangeByScore(byte[] key, byte[] start, byte[] end)
/*     */   {
/* 585 */     sendCommand(Protocol.Command.ZREMRANGEBYSCORE, new byte[][] { key, start, end });
/*     */   }
/*     */ 
/*     */   public void zunionstore(byte[] dstkey, byte[][] sets) {
/* 589 */     byte[][] params = new byte[sets.length + 2][];
/* 590 */     params[0] = dstkey;
/* 591 */     params[1] = Protocol.toByteArray(sets.length);
/* 592 */     System.arraycopy(sets, 0, params, 2, sets.length);
/* 593 */     sendCommand(Protocol.Command.ZUNIONSTORE, params);
/*     */   }
/*     */ 
/*     */   public void zunionstore(byte[] dstkey, ZParams params, byte[][] sets)
/*     */   {
/* 598 */     List args = new ArrayList();
/* 599 */     args.add(dstkey);
/* 600 */     args.add(Protocol.toByteArray(sets.length));
/* 601 */     for (byte[] set : sets) {
/* 602 */       args.add(set);
/*     */     }
/* 604 */     args.addAll(params.getParams());
/* 605 */     sendCommand(Protocol.Command.ZUNIONSTORE, (byte[][])args.toArray(new byte[args.size()][]));
/*     */   }
/*     */ 
/*     */   public void zinterstore(byte[] dstkey, byte[][] sets) {
/* 609 */     byte[][] params = new byte[sets.length + 2][];
/* 610 */     params[0] = dstkey;
/* 611 */     params[1] = Protocol.toByteArray(sets.length);
/* 612 */     System.arraycopy(sets, 0, params, 2, sets.length);
/* 613 */     sendCommand(Protocol.Command.ZINTERSTORE, params);
/*     */   }
/*     */ 
/*     */   public void zinterstore(byte[] dstkey, ZParams params, byte[][] sets)
/*     */   {
/* 618 */     List args = new ArrayList();
/* 619 */     args.add(dstkey);
/* 620 */     args.add(Protocol.toByteArray(sets.length));
/* 621 */     for (byte[] set : sets) {
/* 622 */       args.add(set);
/*     */     }
/* 624 */     args.addAll(params.getParams());
/* 625 */     sendCommand(Protocol.Command.ZINTERSTORE, (byte[][])args.toArray(new byte[args.size()][]));
/*     */   }
/*     */ 
/*     */   public void save() {
/* 629 */     sendCommand(Protocol.Command.SAVE);
/*     */   }
/*     */ 
/*     */   public void bgsave() {
/* 633 */     sendCommand(Protocol.Command.BGSAVE);
/*     */   }
/*     */ 
/*     */   public void bgrewriteaof() {
/* 637 */     sendCommand(Protocol.Command.BGREWRITEAOF);
/*     */   }
/*     */ 
/*     */   public void lastsave() {
/* 641 */     sendCommand(Protocol.Command.LASTSAVE);
/*     */   }
/*     */ 
/*     */   public void shutdown() {
/* 645 */     sendCommand(Protocol.Command.SHUTDOWN);
/*     */   }
/*     */ 
/*     */   public void info() {
/* 649 */     sendCommand(Protocol.Command.INFO);
/*     */   }
/*     */ 
/*     */   public void info(String section) {
/* 653 */     sendCommand(Protocol.Command.INFO, new String[] { section });
/*     */   }
/*     */ 
/*     */   public void monitor() {
/* 657 */     sendCommand(Protocol.Command.MONITOR);
/*     */   }
/*     */ 
/*     */   public void slaveof(String host, int port) {
/* 661 */     sendCommand(Protocol.Command.SLAVEOF, new String[] { host, String.valueOf(port) });
/*     */   }
/*     */ 
/*     */   public void slaveofNoOne() {
/* 665 */     sendCommand(Protocol.Command.SLAVEOF, new byte[][] { Protocol.Keyword.NO.raw, Protocol.Keyword.ONE.raw });
/*     */   }
/*     */ 
/*     */   public void configGet(byte[] pattern) {
/* 669 */     sendCommand(Protocol.Command.CONFIG, new byte[][] { Protocol.Keyword.GET.raw, pattern });
/*     */   }
/*     */ 
/*     */   public void configSet(byte[] parameter, byte[] value) {
/* 673 */     sendCommand(Protocol.Command.CONFIG, new byte[][] { Protocol.Keyword.SET.raw, parameter, value });
/*     */   }
/*     */ 
/*     */   public void strlen(byte[] key) {
/* 677 */     sendCommand(Protocol.Command.STRLEN, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void sync() {
/* 681 */     sendCommand(Protocol.Command.SYNC);
/*     */   }
/*     */ 
/*     */   public void lpushx(byte[] key, byte[][] string) {
/* 685 */     sendCommand(Protocol.Command.LPUSHX, joinParameters(key, string));
/*     */   }
/*     */ 
/*     */   public void persist(byte[] key) {
/* 689 */     sendCommand(Protocol.Command.PERSIST, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void rpushx(byte[] key, byte[][] string) {
/* 693 */     sendCommand(Protocol.Command.RPUSHX, joinParameters(key, string));
/*     */   }
/*     */ 
/*     */   public void echo(byte[] string) {
/* 697 */     sendCommand(Protocol.Command.ECHO, new byte[][] { string });
/*     */   }
/*     */ 
/*     */   public void linsert(byte[] key, LIST_POSITION where, byte[] pivot, byte[] value)
/*     */   {
/* 702 */     sendCommand(Protocol.Command.LINSERT, new byte[][] { key, where.raw, pivot, value });
/*     */   }
/*     */ 
/*     */   public void debug(DebugParams params) {
/* 706 */     sendCommand(Protocol.Command.DEBUG, params.getCommand());
/*     */   }
/*     */ 
/*     */   public void brpoplpush(byte[] source, byte[] destination, int timeout)
/*     */   {
/* 711 */     sendCommand(Protocol.Command.BRPOPLPUSH, new byte[][] { source, destination, Protocol.toByteArray(timeout) });
/*     */   }
/*     */ 
/*     */   public void configResetStat() {
/* 715 */     sendCommand(Protocol.Command.CONFIG, new String[] { Protocol.Keyword.RESETSTAT.name() });
/*     */   }
/*     */ 
/*     */   public void setbit(byte[] key, long offset, byte[] value) {
/* 719 */     sendCommand(Protocol.Command.SETBIT, new byte[][] { key, Protocol.toByteArray(offset), value });
/*     */   }
/*     */ 
/*     */   public void setbit(byte[] key, long offset, boolean value) {
/* 723 */     sendCommand(Protocol.Command.SETBIT, new byte[][] { key, Protocol.toByteArray(offset), Protocol.toByteArray(value) });
/*     */   }
/*     */ 
/*     */   public void getbit(byte[] key, long offset) {
/* 727 */     sendCommand(Protocol.Command.GETBIT, new byte[][] { key, Protocol.toByteArray(offset) });
/*     */   }
/*     */ 
/*     */   public void setrange(byte[] key, long offset, byte[] value) {
/* 731 */     sendCommand(Protocol.Command.SETRANGE, new byte[][] { key, Protocol.toByteArray(offset), value });
/*     */   }
/*     */ 
/*     */   public void getrange(byte[] key, long startOffset, long endOffset) {
/* 735 */     sendCommand(Protocol.Command.GETRANGE, new byte[][] { key, Protocol.toByteArray(startOffset), 
/* 736 */       Protocol.toByteArray(endOffset) });
/*     */   }
/*     */ 
/*     */   public Long getDB() {
/* 740 */     return Long.valueOf(this.db);
/*     */   }
/*     */ 
/*     */   public void disconnect() {
/* 744 */     this.db = 0L;
/* 745 */     super.disconnect();
/*     */   }
/*     */ 
/*     */   private void sendEvalCommand(Protocol.Command command, byte[] script, byte[] keyCount, byte[][] params)
/*     */   {
/* 751 */     byte[][] allArgs = new byte[params.length + 2][];
/*     */ 
/* 753 */     allArgs[0] = script;
/* 754 */     allArgs[1] = keyCount;
/*     */ 
/* 756 */     for (int i = 0; i < params.length; i++) {
/* 757 */       allArgs[(i + 2)] = params[i];
/*     */     }
/* 759 */     sendCommand(command, allArgs);
/*     */   }
/*     */ 
/*     */   public void eval(byte[] script, byte[] keyCount, byte[][] params) {
/* 763 */     sendEvalCommand(Protocol.Command.EVAL, script, keyCount, params);
/*     */   }
/*     */ 
/*     */   public void eval(byte[] script, int keyCount, byte[][] params) {
/* 767 */     eval(script, Protocol.toByteArray(keyCount), params);
/*     */   }
/*     */ 
/*     */   public void evalsha(byte[] sha1, byte[] keyCount, byte[][] params) {
/* 771 */     sendEvalCommand(Protocol.Command.EVALSHA, sha1, keyCount, params);
/*     */   }
/*     */ 
/*     */   public void evalsha(byte[] sha1, int keyCount, byte[][] params) {
/* 775 */     sendEvalCommand(Protocol.Command.EVALSHA, sha1, Protocol.toByteArray(keyCount), params);
/*     */   }
/*     */ 
/*     */   public void scriptFlush() {
/* 779 */     sendCommand(Protocol.Command.SCRIPT, new byte[][] { Protocol.Keyword.FLUSH.raw });
/*     */   }
/*     */ 
/*     */   public void scriptExists(byte[][] sha1) {
/* 783 */     byte[][] args = new byte[sha1.length + 1][];
/* 784 */     args[0] = Protocol.Keyword.EXISTS.raw;
/* 785 */     for (int i = 0; i < sha1.length; i++) {
/* 786 */       args[(i + 1)] = sha1[i];
/*     */     }
/* 788 */     sendCommand(Protocol.Command.SCRIPT, args);
/*     */   }
/*     */ 
/*     */   public void scriptLoad(byte[] script) {
/* 792 */     sendCommand(Protocol.Command.SCRIPT, new byte[][] { Protocol.Keyword.LOAD.raw, script });
/*     */   }
/*     */ 
/*     */   public void scriptKill() {
/* 796 */     sendCommand(Protocol.Command.SCRIPT, new byte[][] { Protocol.Keyword.KILL.raw });
/*     */   }
/*     */ 
/*     */   public void slowlogGet() {
/* 800 */     sendCommand(Protocol.Command.SLOWLOG, new byte[][] { Protocol.Keyword.GET.raw });
/*     */   }
/*     */ 
/*     */   public void slowlogGet(long entries) {
/* 804 */     sendCommand(Protocol.Command.SLOWLOG, new byte[][] { Protocol.Keyword.GET.raw, Protocol.toByteArray(entries) });
/*     */   }
/*     */ 
/*     */   public void slowlogReset() {
/* 808 */     sendCommand(Protocol.Command.SLOWLOG, new byte[][] { Protocol.Keyword.RESET.raw });
/*     */   }
/*     */ 
/*     */   public void slowlogLen() {
/* 812 */     sendCommand(Protocol.Command.SLOWLOG, new byte[][] { Protocol.Keyword.LEN.raw });
/*     */   }
/*     */ 
/*     */   public void objectRefcount(byte[] key) {
/* 816 */     sendCommand(Protocol.Command.OBJECT, new byte[][] { Protocol.Keyword.REFCOUNT.raw, key });
/*     */   }
/*     */ 
/*     */   public void objectIdletime(byte[] key) {
/* 820 */     sendCommand(Protocol.Command.OBJECT, new byte[][] { Protocol.Keyword.IDLETIME.raw, key });
/*     */   }
/*     */ 
/*     */   public void objectEncoding(byte[] key) {
/* 824 */     sendCommand(Protocol.Command.OBJECT, new byte[][] { Protocol.Keyword.ENCODING.raw, key });
/*     */   }
/*     */ 
/*     */   public void bitcount(byte[] key) {
/* 828 */     sendCommand(Protocol.Command.BITCOUNT, new byte[][] { key });
/*     */   }
/*     */ 
/*     */   public void bitcount(byte[] key, long start, long end) {
/* 832 */     sendCommand(Protocol.Command.BITCOUNT, new byte[][] { key, Protocol.toByteArray(start), Protocol.toByteArray(end) });
/*     */   }
/*     */ 
/*     */   public void bitop(BitOP op, byte[] destKey, byte[][] srcKeys) {
/* 836 */     Protocol.Keyword kw = Protocol.Keyword.AND;
/* 837 */     int len = srcKeys.length;
/* 838 */     switch (op) {
/*     */     case AND:
/* 840 */       kw = Protocol.Keyword.AND;
/* 841 */       break;
/*     */     case NOT:
/* 843 */       kw = Protocol.Keyword.OR;
/* 844 */       break;
/*     */     case OR:
/* 846 */       kw = Protocol.Keyword.XOR;
/* 847 */       break;
/*     */     case XOR:
/* 849 */       kw = Protocol.Keyword.NOT;
/* 850 */       len = Math.min(1, len);
/*     */     }
/*     */ 
/* 854 */     byte[][] bargs = new byte[len + 2][];
/* 855 */     bargs[0] = kw.raw;
/* 856 */     bargs[1] = destKey;
/* 857 */     for (int i = 0; i < len; i++) {
/* 858 */       bargs[(i + 2)] = srcKeys[i];
/*     */     }
/*     */ 
/* 861 */     sendCommand(Protocol.Command.BITOP, bargs);
/*     */   }
/*     */ 
/*     */   public void sentinel(byte[][] args) {
/* 865 */     sendCommand(Protocol.Command.SENTINEL, args);
/*     */   }
/*     */ 
/*     */   public static enum LIST_POSITION
/*     */   {
/*  27 */     BEFORE, AFTER;
/*     */ 
/*     */     public final byte[] raw;
/*     */ 
/*  31 */     private LIST_POSITION() { this.raw = SafeEncoder.encode(name());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.BinaryClient
 * JD-Core Version:    0.6.0
 */