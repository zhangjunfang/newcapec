/*    */ package cn.newcapec.framework.base.dao.redis.exception;
/*    */ 
/*    */ public class TedisException extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -1611101501690221263L;
/*    */ 
/*    */   public TedisException(String message)
/*    */   {
/*  8 */     super(message);
/*    */   }
/*    */ 
/*    */   public TedisException(Throwable e) {
/* 12 */     super(e);
/*    */   }
/*    */ 
/*    */   public TedisException(String message, Throwable cause) {
/* 16 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.exception.TedisException
 * JD-Core Version:    0.6.0
 */