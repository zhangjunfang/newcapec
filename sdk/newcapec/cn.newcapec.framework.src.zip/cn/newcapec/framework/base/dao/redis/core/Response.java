/*    */ package cn.newcapec.framework.base.dao.redis.core;
/*    */ 
/*    */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisDataException;
/*    */ 
/*    */ public class Response<T>
/*    */ {
/*  6 */   protected T response = null;
/*  7 */   private boolean built = false;
/*  8 */   private boolean set = false;
/*    */   private Builder<T> builder;
/*    */   private Object data;
/*    */ 
/*    */   public Response(Builder<T> b)
/*    */   {
/* 13 */     this.builder = b;
/*    */   }
/*    */ 
/*    */   public void set(Object data) {
/* 17 */     this.data = data;
/* 18 */     this.set = true;
/*    */   }
/*    */ 
/*    */   public T get() {
/* 22 */     if (!this.set) {
/* 23 */       throw new JedisDataException(
/* 24 */         "Please close pipeline or multi block before calling this method.");
/*    */     }
/* 26 */     if (!this.built) {
/* 27 */       if (this.data != null) {
/* 28 */         if ((this.data instanceof JedisDataException)) {
/* 29 */           throw new JedisDataException((JedisDataException)this.data);
/*    */         }
/* 31 */         this.response = this.builder.build(this.data);
/*    */       }
/* 33 */       this.data = null;
/* 34 */       this.built = true;
/*    */     }
/* 36 */     return this.response;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 40 */     return "Response " + this.builder.toString();
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.Response
 * JD-Core Version:    0.6.0
 */