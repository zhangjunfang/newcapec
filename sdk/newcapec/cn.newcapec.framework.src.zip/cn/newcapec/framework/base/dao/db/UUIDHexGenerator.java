/*    */ package cn.newcapec.framework.base.dao.db;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.net.InetAddress;
/*    */ 
/*    */ public class UUIDHexGenerator
/*    */   implements UUIDGenerator
/*    */ {
/* 11 */   private String sep = "";
/*    */   private static final int IP;
/* 13 */   private static short counter = 0;
/* 14 */   private static final int JVM = (int)(System.currentTimeMillis() >>> 8);
/* 15 */   private static UUIDHexGenerator uuidgen = new UUIDHexGenerator();
/*    */ 
/*    */   static { int ipadd;
/*    */     try { ipadd = toInt(InetAddress.getLocalHost().getAddress());
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */       int ipadd;
/* 21 */       ipadd = 0;
/*    */     }
/* 23 */     IP = ipadd; }
/*    */ 
/*    */   public static UUIDHexGenerator getInstance()
/*    */   {
/* 27 */     return uuidgen;
/*    */   }
/*    */ 
/*    */   public static int toInt(byte[] bytes) {
/* 31 */     int result = 0;
/* 32 */     for (int i = 0; i < 4; i++) {
/* 33 */       result = (result << 8) - -128 + bytes[i];
/*    */     }
/* 35 */     return result;
/*    */   }
/*    */ 
/*    */   protected String format(int intval) {
/* 39 */     String formatted = Integer.toHexString(intval);
/* 40 */     StringBuffer buf = new StringBuffer("00000000");
/* 41 */     buf.replace(8 - formatted.length(), 8, formatted);
/* 42 */     return buf.toString();
/*    */   }
/*    */ 
/*    */   protected String format(short shortval) {
/* 46 */     String formatted = Integer.toHexString(shortval);
/* 47 */     StringBuffer buf = new StringBuffer("0000");
/* 48 */     buf.replace(4 - formatted.length(), 4, formatted);
/* 49 */     return buf.toString();
/*    */   }
/*    */ 
/*    */   protected int getJVM() {
/* 53 */     return JVM;
/*    */   }
/*    */ 
/*    */   protected synchronized short getCount() {
/* 57 */     if (counter < 0) {
/* 58 */       counter = 0;
/*    */     }
/* 60 */     return counter++;
/*    */   }
/*    */ 
/*    */   protected int getIP() {
/* 64 */     return IP;
/*    */   }
/*    */ 
/*    */   protected short getHiTime() {
/* 68 */     return (short)(int)(System.currentTimeMillis() >>> 32);
/*    */   }
/*    */ 
/*    */   protected int getLoTime() {
/* 72 */     return (int)System.currentTimeMillis();
/*    */   }
/*    */ 
/*    */   public String generate() {
/* 76 */     return 36 + format(getIP()) + this.sep + 
/* 77 */       format(getJVM()) + this.sep + format(getHiTime()) + 
/* 78 */       this.sep + format(getLoTime()) + this.sep + 
/* 79 */       format(getCount());
/*    */   }
/*    */ 
/*    */   public static void main(String[] str) {
/* 83 */     UUIDHexGenerator id = new UUIDHexGenerator();
/* 84 */     for (int i = 0; i <= 100; i++)
/* 85 */       new Thread() {
/*    */         public void run() {
/* 87 */           for (int i = 0; i <= 100; i++)
/* 88 */             System.out.println(Thread.currentThread().getId() + "-" + i + ":" + UUIDHexGenerator.getInstance().generate());
/*    */         }
/*    */       }
/* 91 */       .start();
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.db.UUIDHexGenerator
 * JD-Core Version:    0.6.0
 */