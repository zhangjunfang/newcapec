/*     */ package cn.newcapec.framework.base.dao.redis.util;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class Sharded<R, S extends ShardInfo<R>>
/*     */ {
/*     */   public static final int DEFAULT_WEIGHT = 1;
/*     */   private TreeMap<Long, S> nodes;
/*     */   private final Hashing algo;
/*  18 */   private final Map<ShardInfo<R>, R> resources = new LinkedHashMap();
/*     */ 
/*  26 */   private Pattern tagPattern = null;
/*     */ 
/*  29 */   public static final Pattern DEFAULT_KEY_TAG_PATTERN = Pattern.compile("\\{(.+?)\\}");
/*     */ 
/*     */   public Sharded(List<S> shards) {
/*  32 */     this(shards, Hashing.MURMUR_HASH);
/*     */   }
/*     */ 
/*     */   public Sharded(List<S> shards, Hashing algo)
/*     */   {
/*  37 */     this.algo = algo;
/*  38 */     initialize(shards);
/*     */   }
/*     */ 
/*     */   public Sharded(List<S> shards, Pattern tagPattern) {
/*  42 */     this(shards, Hashing.MURMUR_HASH, tagPattern);
/*     */   }
/*     */ 
/*     */   public Sharded(List<S> shards, Hashing algo, Pattern tagPattern)
/*     */   {
/*  48 */     this.algo = algo;
/*  49 */     this.tagPattern = tagPattern;
/*  50 */     initialize(shards);
/*     */   }
/*     */ 
/*     */   private void initialize(List<S> shards) {
/*  54 */     this.nodes = new TreeMap();
/*     */ 
/*  56 */     for (int i = 0; i != shards.size(); i++) {
/*  57 */       ShardInfo shardInfo = (ShardInfo)shards.get(i);
/*  58 */       if (shardInfo.getName() == null) {
/*  59 */         for (int n = 0; n < 160 * shardInfo.getWeight(); n++)
/*  60 */           this.nodes.put(Long.valueOf(this.algo.hash("SHARD-" + i + "-NODE-" + n)), shardInfo);
/*     */       }
/*     */       else {
/*  63 */         for (int n = 0; n < 160 * shardInfo.getWeight(); n++)
/*  64 */           this.nodes.put(Long.valueOf(this.algo.hash(shardInfo.getName() + "*" + shardInfo.getWeight() + n)), shardInfo);
/*     */       }
/*  66 */       this.resources.put(shardInfo, shardInfo.createResource());
/*     */     }
/*     */   }
/*     */ 
/*     */   public R getShard(byte[] key) {
/*  71 */     return this.resources.get(getShardInfo(key));
/*     */   }
/*     */ 
/*     */   public R getShard(String key) {
/*  75 */     return this.resources.get(getShardInfo(key));
/*     */   }
/*     */ 
/*     */   public S getShardInfo(byte[] key) {
/*  79 */     SortedMap tail = this.nodes.tailMap(Long.valueOf(this.algo.hash(key)));
/*  80 */     if (tail.isEmpty()) {
/*  81 */       return (ShardInfo)this.nodes.get(this.nodes.firstKey());
/*     */     }
/*  83 */     return (ShardInfo)tail.get(tail.firstKey());
/*     */   }
/*     */ 
/*     */   public S getShardInfo(String key) {
/*  87 */     return getShardInfo(SafeEncoder.encode(getKeyTag(key)));
/*     */   }
/*     */ 
/*     */   public String getKeyTag(String key)
/*     */   {
/* 100 */     if (this.tagPattern != null) {
/* 101 */       Matcher m = this.tagPattern.matcher(key);
/* 102 */       if (m.find())
/* 103 */         return m.group(1);
/*     */     }
/* 105 */     return key;
/*     */   }
/*     */ 
/*     */   public Collection<S> getAllShardInfo() {
/* 109 */     return Collections.unmodifiableCollection(this.nodes.values());
/*     */   }
/*     */ 
/*     */   public Collection<R> getAllShards() {
/* 113 */     return Collections.unmodifiableCollection(this.resources.values());
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.util.Sharded
 * JD-Core Version:    0.6.0
 */