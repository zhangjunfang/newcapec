/*     */ package cn.newcapec.framework.base.dao.redis.util;
/*     */ 
/*     */ import cn.newcapec.framework.base.dao.redis.core.exceptions.JedisConnectionException;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class RedisInputStream extends FilterInputStream
/*     */ {
/*     */   protected final byte[] buf;
/*     */   protected int count;
/*     */   protected int limit;
/*     */ 
/*     */   public RedisInputStream(InputStream in, int size)
/*     */   {
/*  32 */     super(in);
/*  33 */     if (size <= 0) {
/*  34 */       throw new IllegalArgumentException("Buffer size <= 0");
/*     */     }
/*  36 */     this.buf = new byte[size];
/*     */   }
/*     */ 
/*     */   public RedisInputStream(InputStream in) {
/*  40 */     this(in, 8192);
/*     */   }
/*     */ 
/*     */   public byte readByte() throws IOException {
/*  44 */     if (this.count == this.limit) {
/*  45 */       fill();
/*     */     }
/*     */ 
/*  48 */     return this.buf[(this.count++)];
/*     */   }
/*     */ 
/*     */   public String readLine()
/*     */   {
/*  54 */     StringBuilder sb = new StringBuilder();
/*     */     try
/*     */     {
/*     */       while (true) {
/*  58 */         if (this.count == this.limit) {
/*  59 */           fill();
/*     */         }
/*  61 */         if (this.limit == -1) {
/*     */           break;
/*     */         }
/*  64 */         int b = this.buf[(this.count++)];
/*  65 */         if (b == 13) {
/*  66 */           if (this.count == this.limit) {
/*  67 */             fill();
/*     */           }
/*     */ 
/*  70 */           if (this.limit == -1) {
/*  71 */             sb.append((char)b);
/*  72 */             break;
/*     */           }
/*     */ 
/*  75 */           byte c = this.buf[(this.count++)];
/*  76 */           if (c == 10) {
/*     */             break;
/*     */           }
/*  79 */           sb.append((char)b);
/*  80 */           sb.append((char)c); continue;
/*     */         }
/*  82 */         sb.append((char)b);
/*     */       }
/*     */     }
/*     */     catch (IOException e) {
/*  86 */       throw new JedisConnectionException(e);
/*     */     }
/*  88 */     String reply = sb.toString();
/*  89 */     if (reply.length() == 0) {
/*  90 */       throw new JedisConnectionException(
/*  91 */         "It seems like server has closed the connection.");
/*     */     }
/*  93 */     return reply;
/*     */   }
/*     */ 
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/*  97 */     if (this.count == this.limit) {
/*  98 */       fill();
/*  99 */       if (this.limit == -1)
/* 100 */         return -1;
/*     */     }
/* 102 */     int length = Math.min(this.limit - this.count, len);
/* 103 */     System.arraycopy(this.buf, this.count, b, off, length);
/* 104 */     this.count += length;
/* 105 */     return length;
/*     */   }
/*     */ 
/*     */   private void fill() throws IOException {
/* 109 */     this.limit = this.in.read(this.buf);
/* 110 */     this.count = 0;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.util.RedisInputStream
 * JD-Core Version:    0.6.0
 */