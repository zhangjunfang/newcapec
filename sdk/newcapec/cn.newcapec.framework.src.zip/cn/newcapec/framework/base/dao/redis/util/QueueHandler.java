/*    */ package cn.newcapec.framework.base.dao.redis.util;
/*    */ 
/*    */ import org.apache.log4j.Logger;
/*    */ import org.springframework.stereotype.Service;
/*    */ 
/*    */ @Service("queueHandler")
/*    */ public class QueueHandler
/*    */ {
/* 16 */   private static final Logger log = Logger.getLogger(QueueHandler.class);
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.util.QueueHandler
 * JD-Core Version:    0.6.0
 */