/*    */ package cn.newcapec.framework.base.dao.redis.exception;
/*    */ 
/*    */ public class TedisDataException extends TedisException
/*    */ {
/*    */   private static final long serialVersionUID = 7530985946271632187L;
/*    */ 
/*    */   public TedisDataException(String message)
/*    */   {
/* 12 */     super(message);
/*    */   }
/*    */ 
/*    */   public TedisDataException(Throwable cause) {
/* 16 */     super(cause);
/*    */   }
/*    */ 
/*    */   public TedisDataException(String message, Throwable cause) {
/* 20 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.exception.TedisDataException
 * JD-Core Version:    0.6.0
 */