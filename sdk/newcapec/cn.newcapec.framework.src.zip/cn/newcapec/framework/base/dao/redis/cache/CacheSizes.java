/*    */ package cn.newcapec.framework.base.dao.redis.cache;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class CacheSizes
/*    */ {
/*    */   public static int sizeOfObject()
/*    */   {
/* 13 */     return 4;
/*    */   }
/*    */ 
/*    */   public static int sizeOfString(String string) {
/* 17 */     if (string == null) {
/* 18 */       return 0;
/*    */     }
/* 20 */     return 4 + string.length() * 2;
/*    */   }
/*    */ 
/*    */   public static int sizeOfInt() {
/* 24 */     return 4;
/*    */   }
/*    */ 
/*    */   public static int sizeOfChar() {
/* 28 */     return 2;
/*    */   }
/*    */ 
/*    */   public static int sizeOfBoolean() {
/* 32 */     return 1;
/*    */   }
/*    */ 
/*    */   public static int sizeOfLong() {
/* 36 */     return 8;
/*    */   }
/*    */ 
/*    */   public static int sizeOfDouble() {
/* 40 */     return 8;
/*    */   }
/*    */ 
/*    */   public static int sizeOfDate() {
/* 44 */     return 12;
/*    */   }
/*    */ 
/*    */   public static int sizeOfMap(Map map)
/*    */   {
/* 49 */     if (map == null)
/* 50 */       return 0;
/* 51 */     int size = 36;
/* 52 */     Object[] values = map.values().toArray();
/* 53 */     for (int i = 0; i < values.length; i++) {
/* 54 */       size += sizeOfString((String)values[i]);
/*    */     }
/* 56 */     Object[] keys = map.keySet().toArray();
/* 57 */     for (int i = 0; i < keys.length; i++) {
/* 58 */       size += sizeOfString((String)keys[i]);
/*    */     }
/* 60 */     return size;
/*    */   }
/*    */ 
/*    */   public static int sizeOfList(List list)
/*    */   {
/* 65 */     if (list == null)
/* 66 */       return 0;
/* 67 */     int size = 36;
/* 68 */     Object[] values = list.toArray();
/* 69 */     for (int i = 0; i < values.length; i++) {
/* 70 */       Object obj = values[i];
/* 71 */       if ((obj instanceof String)) {
/* 72 */         size += sizeOfString((String)obj);
/*    */       }
/* 75 */       else if ((obj instanceof Long))
/* 76 */         size += sizeOfLong() + sizeOfObject();
/*    */       else {
/* 78 */         size += ((Cacheable)obj).getCachedSize();
/*    */       }
/*    */     }
/* 81 */     return size;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.cache.CacheSizes
 * JD-Core Version:    0.6.0
 */