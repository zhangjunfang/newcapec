package cn.newcapec.framework.base.dao.redis.cache;

public abstract interface Cacheable
{
  public abstract int getCachedSize();
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.cache.Cacheable
 * JD-Core Version:    0.6.0
 */