/*     */ package cn.newcapec.framework.base.dao.hibernate;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ import org.hibernate.Criteria;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.hibernate.criterion.Criterion;
/*     */ import org.hibernate.criterion.DetachedCriteria;
/*     */ import org.hibernate.criterion.Order;
/*     */ import org.hibernate.criterion.Projections;
/*     */ import org.hibernate.criterion.Restrictions;
/*     */ import org.hibernate.metadata.ClassMetadata;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class HibernateGenericDao extends HibernateDaoSupport
/*     */ {
/*     */   public <T> T get(Class<T> entityClass, Serializable id)
/*     */   {
/*  37 */     return getHibernateTemplate().get(entityClass, id);
/*     */   }
/*     */ 
/*     */   public <T> List<T> getAll(Class<T> entityClass)
/*     */   {
/*  44 */     return getHibernateTemplate().loadAll(entityClass);
/*     */   }
/*     */ 
/*     */   public <T> List<T> getAll(Class<T> entityClass, String orderBy, boolean isAsc)
/*     */   {
/*  52 */     Assert.hasText(orderBy);
/*  53 */     if (isAsc) {
/*  54 */       return getHibernateTemplate().findByCriteria(
/*  55 */         DetachedCriteria.forClass(entityClass).addOrder(
/*  56 */         Order.asc(orderBy)));
/*     */     }
/*  58 */     return getHibernateTemplate().findByCriteria(
/*  59 */       DetachedCriteria.forClass(entityClass).addOrder(
/*  60 */       Order.desc(orderBy)));
/*     */   }
/*     */ 
/*     */   public void save(Object o)
/*     */   {
/*  67 */     getHibernateTemplate().saveOrUpdate(o);
/*     */   }
/*     */ 
/*     */   public void remove(Object o)
/*     */   {
/*  74 */     getHibernateTemplate().delete(o);
/*     */   }
/*     */ 
/*     */   public <T> void removeById(Class<T> entityClass, Serializable id)
/*     */   {
/*  81 */     remove(get(entityClass, id));
/*     */   }
/*     */ 
/*     */   public void flush() {
/*  85 */     getHibernateTemplate().flush();
/*     */   }
/*     */ 
/*     */   public void clear() {
/*  89 */     getHibernateTemplate().clear();
/*     */   }
/*     */ 
/*     */   public Query createQuery(String hql, Object[] values)
/*     */   {
/* 114 */     Assert.hasText(hql);
/* 115 */     Query query = getSession().createQuery(hql);
/* 116 */     for (int i = 0; i < values.length; i++) {
/* 117 */       query.setParameter(i, values[i]);
/*     */     }
/* 119 */     return query;
/*     */   }
/*     */ 
/*     */   public <T> Criteria createCriteria(Class<T> entityClass, Criterion[] criterions)
/*     */   {
/* 130 */     Criteria criteria = getSession().createCriteria(entityClass);
/* 131 */     for (Criterion c : criterions) {
/* 132 */       criteria.add(c);
/*     */     }
/* 134 */     return criteria;
/*     */   }
/*     */ 
/*     */   public <T> Criteria createCriteria(Class<T> entityClass, String orderBy, boolean isAsc, Criterion[] criterions)
/*     */   {
/* 144 */     Assert.hasText(orderBy);
/*     */ 
/* 146 */     Criteria criteria = createCriteria(entityClass, criterions);
/*     */ 
/* 148 */     if (isAsc)
/* 149 */       criteria.addOrder(Order.asc(orderBy));
/*     */     else {
/* 151 */       criteria.addOrder(Order.desc(orderBy));
/*     */     }
/* 153 */     return criteria;
/*     */   }
/*     */ 
/*     */   public List find(String hql, Object[] values)
/*     */   {
/* 164 */     Assert.hasText(hql);
/* 165 */     return getHibernateTemplate().find(hql, values);
/*     */   }
/*     */ 
/*     */   public <T> List<T> findBy(Class<T> entityClass, String propertyName, Object value)
/*     */   {
/* 175 */     Assert.hasText(propertyName);
/* 176 */     return createCriteria(entityClass, new Criterion[] { Restrictions.eq(propertyName, value) })
/* 177 */       .list();
/*     */   }
/*     */ 
/*     */   public <T> List<T> findBy(Class<T> entityClass, String propertyName, Object value, String orderBy, boolean isAsc)
/*     */   {
/* 185 */     Assert.hasText(propertyName);
/* 186 */     Assert.hasText(orderBy);
/* 187 */     return createCriteria(entityClass, orderBy, isAsc, new Criterion[] { 
/* 188 */       Restrictions.eq(propertyName, value) }).list();
/*     */   }
/*     */ 
/*     */   public <T> T findUniqueBy(Class<T> entityClass, String propertyName, Object value)
/*     */   {
/* 198 */     Assert.hasText(propertyName);
/* 199 */     return createCriteria(entityClass, new Criterion[] { 
/* 200 */       Restrictions.eq(propertyName, value) }).uniqueResult();
/*     */   }
/*     */ 
/*     */   public <V> V findUniqueBy(Class<V> entityClass, String[] propertyName, Object[] value)
/*     */   {
/* 215 */     if ((propertyName != null) && (value != null) && (propertyName.length == value.length)) {
/* 216 */       Criteria criteria = getSession().createCriteria(entityClass);
/* 217 */       for (int i = 0; i < propertyName.length; i++) {
/* 218 */         Criterion c = Restrictions.eq(propertyName[i], value[i]);
/* 219 */         criteria.add(c);
/*     */       }
/* 221 */       List list = criteria.list();
/* 222 */       if ((list != null) && (list.size() > 0)) {
/* 223 */         return list.get(0);
/*     */       }
/*     */     }
/* 226 */     return null;
/*     */   }
/*     */ 
/*     */   public <T> boolean isUnique(Class<T> entityClass, Object entity, String uniquePropertyNames)
/*     */   {
/* 237 */     Assert.hasText(uniquePropertyNames);
/* 238 */     Criteria criteria = createCriteria(entityClass, new Criterion[0]).setProjection(
/* 239 */       Projections.rowCount());
/* 240 */     String[] nameList = uniquePropertyNames.split(",");
/*     */     try
/*     */     {
/* 243 */       for (String name : nameList) {
/* 244 */         criteria.add(Restrictions.eq(name, 
/* 245 */           PropertyUtils.getProperty(entity, name)));
/*     */       }
/*     */ 
/* 250 */       String idName = getIdName(entityClass);
/*     */ 
/* 253 */       Serializable id = getId(entityClass, entity);
/*     */ 
/* 256 */       if (id != null)
/* 257 */         criteria.add(Restrictions.not(Restrictions.eq(idName, id)));
/*     */     } catch (Exception e) {
/* 259 */       ReflectionUtils.handleReflectionException(e);
/*     */     }
/* 261 */     return ((Integer)criteria.uniqueResult()).intValue() == 0;
/*     */   }
/*     */ 
/*     */   public Serializable getId(Class entityClass, Object entity)
/*     */     throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 271 */     Assert.notNull(entity);
/* 272 */     Assert.notNull(entityClass);
/* 273 */     return (Serializable)PropertyUtils.getProperty(entity, 
/* 274 */       getIdName(entityClass));
/*     */   }
/*     */ 
/*     */   public String getIdName(Class clazz)
/*     */   {
/* 282 */     Assert.notNull(clazz);
/* 283 */     ClassMetadata meta = getSessionFactory().getClassMetadata(clazz);
/* 284 */     Assert.notNull(meta, "Class " + clazz + 
/* 285 */       " not define in hibernate session factory.");
/* 286 */     String idName = meta.getIdentifierPropertyName();
/* 287 */     Assert.hasText(idName, clazz.getSimpleName() + 
/* 288 */       " has no identifier property define.");
/* 289 */     return idName;
/*     */   }
/*     */ 
/*     */   private static String removeSelect(String hql)
/*     */   {
/* 299 */     Assert.hasText(hql);
/* 300 */     int beginPos = hql.toLowerCase().indexOf("from");
/* 301 */     Assert.isTrue(beginPos != -1, " hql : " + hql + 
/* 302 */       " must has a keyword 'from'");
/* 303 */     return hql.substring(beginPos);
/*     */   }
/*     */ 
/*     */   private static String removeOrders(String hql)
/*     */   {
/* 313 */     Assert.hasText(hql);
/* 314 */     Pattern p = Pattern.compile("order\\s*by[\\w|\\W|\\s|\\S]*", 
/* 315 */       2);
/* 316 */     Matcher m = p.matcher(hql);
/* 317 */     StringBuffer sb = new StringBuffer();
/* 318 */     while (m.find()) {
/* 319 */       m.appendReplacement(sb, "");
/*     */     }
/* 321 */     m.appendTail(sb);
/* 322 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public <T> long countAll(Class<T> entityClass) {
/* 326 */     Criteria criteria = getSession().createCriteria(entityClass);
/* 327 */     Object count = criteria.setProjection(Projections.rowCount())
/* 328 */       .uniqueResult();
/* 329 */     long result = Long.parseLong(count.toString());
/* 330 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.hibernate.HibernateGenericDao
 * JD-Core Version:    0.6.0
 */