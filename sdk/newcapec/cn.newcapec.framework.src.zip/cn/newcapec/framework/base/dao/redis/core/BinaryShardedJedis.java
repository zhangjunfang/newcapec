/*     */ package cn.newcapec.framework.base.dao.redis.core;
/*     */ 
/*     */ import cn.newcapec.framework.base.dao.redis.util.Hashing;
/*     */ import cn.newcapec.framework.base.dao.redis.util.Sharded;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class BinaryShardedJedis extends Sharded<Jedis, JedisShardInfo>
/*     */   implements BinaryJedisCommands
/*     */ {
/*     */   public BinaryShardedJedis(List<JedisShardInfo> shards)
/*     */   {
/*  17 */     super(shards);
/*     */   }
/*     */ 
/*     */   public BinaryShardedJedis(List<JedisShardInfo> shards, Hashing algo) {
/*  21 */     super(shards, algo);
/*     */   }
/*     */ 
/*     */   public BinaryShardedJedis(List<JedisShardInfo> shards, Pattern keyTagPattern) {
/*  25 */     super(shards, keyTagPattern);
/*     */   }
/*     */ 
/*     */   public BinaryShardedJedis(List<JedisShardInfo> shards, Hashing algo, Pattern keyTagPattern)
/*     */   {
/*  30 */     super(shards, algo, keyTagPattern);
/*     */   }
/*     */ 
/*     */   public void disconnect() {
/*  34 */     for (Jedis jedis : getAllShards()) {
/*  35 */       jedis.quit();
/*  36 */       jedis.disconnect();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Jedis create(JedisShardInfo shard) {
/*  41 */     return new Jedis(shard);
/*     */   }
/*     */ 
/*     */   public String set(byte[] key, byte[] value) {
/*  45 */     Jedis j = (Jedis)getShard(key);
/*  46 */     return j.set(key, value);
/*     */   }
/*     */ 
/*     */   public byte[] get(byte[] key) {
/*  50 */     Jedis j = (Jedis)getShard(key);
/*  51 */     return j.get(key);
/*     */   }
/*     */ 
/*     */   public Boolean exists(byte[] key) {
/*  55 */     Jedis j = (Jedis)getShard(key);
/*  56 */     return j.exists(key);
/*     */   }
/*     */ 
/*     */   public String type(byte[] key) {
/*  60 */     Jedis j = (Jedis)getShard(key);
/*  61 */     return j.type(key);
/*     */   }
/*     */ 
/*     */   public Long expire(byte[] key, int seconds) {
/*  65 */     Jedis j = (Jedis)getShard(key);
/*  66 */     return j.expire(key, seconds);
/*     */   }
/*     */ 
/*     */   public Long expireAt(byte[] key, long unixTime) {
/*  70 */     Jedis j = (Jedis)getShard(key);
/*  71 */     return j.expireAt(key, unixTime);
/*     */   }
/*     */ 
/*     */   public Long ttl(byte[] key) {
/*  75 */     Jedis j = (Jedis)getShard(key);
/*  76 */     return j.ttl(key);
/*     */   }
/*     */ 
/*     */   public byte[] getSet(byte[] key, byte[] value) {
/*  80 */     Jedis j = (Jedis)getShard(key);
/*  81 */     return j.getSet(key, value);
/*     */   }
/*     */ 
/*     */   public Long setnx(byte[] key, byte[] value) {
/*  85 */     Jedis j = (Jedis)getShard(key);
/*  86 */     return j.setnx(key, value);
/*     */   }
/*     */ 
/*     */   public String setex(byte[] key, int seconds, byte[] value) {
/*  90 */     Jedis j = (Jedis)getShard(key);
/*  91 */     return j.setex(key, seconds, value);
/*     */   }
/*     */ 
/*     */   public Long decrBy(byte[] key, long integer) {
/*  95 */     Jedis j = (Jedis)getShard(key);
/*  96 */     return j.decrBy(key, integer);
/*     */   }
/*     */ 
/*     */   public Long decr(byte[] key) {
/* 100 */     Jedis j = (Jedis)getShard(key);
/* 101 */     return j.decr(key);
/*     */   }
/*     */ 
/*     */   public Long del(byte[] key) {
/* 105 */     Jedis j = (Jedis)getShard(key);
/* 106 */     return j.del(key);
/*     */   }
/*     */ 
/*     */   public Long incrBy(byte[] key, long integer) {
/* 110 */     Jedis j = (Jedis)getShard(key);
/* 111 */     return j.incrBy(key, integer);
/*     */   }
/*     */ 
/*     */   public Long incr(byte[] key) {
/* 115 */     Jedis j = (Jedis)getShard(key);
/* 116 */     return j.incr(key);
/*     */   }
/*     */ 
/*     */   public Long append(byte[] key, byte[] value) {
/* 120 */     Jedis j = (Jedis)getShard(key);
/* 121 */     return j.append(key, value);
/*     */   }
/*     */ 
/*     */   public byte[] substr(byte[] key, int start, int end) {
/* 125 */     Jedis j = (Jedis)getShard(key);
/* 126 */     return j.substr(key, start, end);
/*     */   }
/*     */ 
/*     */   public Long hset(byte[] key, byte[] field, byte[] value) {
/* 130 */     Jedis j = (Jedis)getShard(key);
/* 131 */     return j.hset(key, field, value);
/*     */   }
/*     */ 
/*     */   public byte[] hget(byte[] key, byte[] field) {
/* 135 */     Jedis j = (Jedis)getShard(key);
/* 136 */     return j.hget(key, field);
/*     */   }
/*     */ 
/*     */   public Long hsetnx(byte[] key, byte[] field, byte[] value) {
/* 140 */     Jedis j = (Jedis)getShard(key);
/* 141 */     return j.hsetnx(key, field, value);
/*     */   }
/*     */ 
/*     */   public String hmset(byte[] key, Map<byte[], byte[]> hash) {
/* 145 */     Jedis j = (Jedis)getShard(key);
/* 146 */     return j.hmset(key, hash);
/*     */   }
/*     */ 
/*     */   public List<byte[]> hmget(byte[] key, byte[][] fields) {
/* 150 */     Jedis j = (Jedis)getShard(key);
/* 151 */     return j.hmget(key, fields);
/*     */   }
/*     */ 
/*     */   public Long hincrBy(byte[] key, byte[] field, long value) {
/* 155 */     Jedis j = (Jedis)getShard(key);
/* 156 */     return j.hincrBy(key, field, value);
/*     */   }
/*     */ 
/*     */   public Boolean hexists(byte[] key, byte[] field) {
/* 160 */     Jedis j = (Jedis)getShard(key);
/* 161 */     return j.hexists(key, field);
/*     */   }
/*     */ 
/*     */   public Long hdel(byte[] key, byte[][] fields) {
/* 165 */     Jedis j = (Jedis)getShard(key);
/* 166 */     return j.hdel(key, fields);
/*     */   }
/*     */ 
/*     */   public Long hlen(byte[] key) {
/* 170 */     Jedis j = (Jedis)getShard(key);
/* 171 */     return j.hlen(key);
/*     */   }
/*     */ 
/*     */   public Set<byte[]> hkeys(byte[] key) {
/* 175 */     Jedis j = (Jedis)getShard(key);
/* 176 */     return j.hkeys(key);
/*     */   }
/*     */ 
/*     */   public Collection<byte[]> hvals(byte[] key) {
/* 180 */     Jedis j = (Jedis)getShard(key);
/* 181 */     return j.hvals(key);
/*     */   }
/*     */ 
/*     */   public Map<byte[], byte[]> hgetAll(byte[] key) {
/* 185 */     Jedis j = (Jedis)getShard(key);
/* 186 */     return j.hgetAll(key);
/*     */   }
/*     */ 
/*     */   public Long rpush(byte[] key, byte[][] strings) {
/* 190 */     Jedis j = (Jedis)getShard(key);
/* 191 */     return j.rpush(key, strings);
/*     */   }
/*     */ 
/*     */   public Long lpush(byte[] key, byte[][] strings) {
/* 195 */     Jedis j = (Jedis)getShard(key);
/* 196 */     return j.lpush(key, strings);
/*     */   }
/*     */ 
/*     */   public Long strlen(byte[] key) {
/* 200 */     Jedis j = (Jedis)getShard(key);
/* 201 */     return j.strlen(key);
/*     */   }
/*     */ 
/*     */   public Long lpushx(byte[] key, byte[][] string) {
/* 205 */     Jedis j = (Jedis)getShard(key);
/* 206 */     return j.lpushx(key, string);
/*     */   }
/*     */ 
/*     */   public Long persist(byte[] key) {
/* 210 */     Jedis j = (Jedis)getShard(key);
/* 211 */     return j.persist(key);
/*     */   }
/*     */ 
/*     */   public Long rpushx(byte[] key, byte[][] string) {
/* 215 */     Jedis j = (Jedis)getShard(key);
/* 216 */     return j.rpushx(key, string);
/*     */   }
/*     */ 
/*     */   public Long llen(byte[] key) {
/* 220 */     Jedis j = (Jedis)getShard(key);
/* 221 */     return j.llen(key);
/*     */   }
/*     */ 
/*     */   public List<byte[]> lrange(byte[] key, long start, long end) {
/* 225 */     Jedis j = (Jedis)getShard(key);
/* 226 */     return j.lrange(key, start, end);
/*     */   }
/*     */ 
/*     */   public String ltrim(byte[] key, long start, long end) {
/* 230 */     Jedis j = (Jedis)getShard(key);
/* 231 */     return j.ltrim(key, start, end);
/*     */   }
/*     */ 
/*     */   public byte[] lindex(byte[] key, long index) {
/* 235 */     Jedis j = (Jedis)getShard(key);
/* 236 */     return j.lindex(key, index);
/*     */   }
/*     */ 
/*     */   public String lset(byte[] key, long index, byte[] value) {
/* 240 */     Jedis j = (Jedis)getShard(key);
/* 241 */     return j.lset(key, index, value);
/*     */   }
/*     */ 
/*     */   public Long lrem(byte[] key, long count, byte[] value) {
/* 245 */     Jedis j = (Jedis)getShard(key);
/* 246 */     return j.lrem(key, count, value);
/*     */   }
/*     */ 
/*     */   public byte[] lpop(byte[] key) {
/* 250 */     Jedis j = (Jedis)getShard(key);
/* 251 */     return j.lpop(key);
/*     */   }
/*     */ 
/*     */   public byte[] rpop(byte[] key) {
/* 255 */     Jedis j = (Jedis)getShard(key);
/* 256 */     return j.rpop(key);
/*     */   }
/*     */ 
/*     */   public Long sadd(byte[] key, byte[][] members) {
/* 260 */     Jedis j = (Jedis)getShard(key);
/* 261 */     return j.sadd(key, members);
/*     */   }
/*     */ 
/*     */   public Set<byte[]> smembers(byte[] key) {
/* 265 */     Jedis j = (Jedis)getShard(key);
/* 266 */     return j.smembers(key);
/*     */   }
/*     */ 
/*     */   public Long srem(byte[] key, byte[][] members) {
/* 270 */     Jedis j = (Jedis)getShard(key);
/* 271 */     return j.srem(key, members);
/*     */   }
/*     */ 
/*     */   public byte[] spop(byte[] key) {
/* 275 */     Jedis j = (Jedis)getShard(key);
/* 276 */     return j.spop(key);
/*     */   }
/*     */ 
/*     */   public Long scard(byte[] key) {
/* 280 */     Jedis j = (Jedis)getShard(key);
/* 281 */     return j.scard(key);
/*     */   }
/*     */ 
/*     */   public Boolean sismember(byte[] key, byte[] member) {
/* 285 */     Jedis j = (Jedis)getShard(key);
/* 286 */     return j.sismember(key, member);
/*     */   }
/*     */ 
/*     */   public byte[] srandmember(byte[] key) {
/* 290 */     Jedis j = (Jedis)getShard(key);
/* 291 */     return j.srandmember(key);
/*     */   }
/*     */ 
/*     */   public Long zadd(byte[] key, double score, byte[] member) {
/* 295 */     Jedis j = (Jedis)getShard(key);
/* 296 */     return j.zadd(key, score, member);
/*     */   }
/*     */ 
/*     */   public Long zadd(byte[] key, Map<Double, byte[]> scoreMembers) {
/* 300 */     Jedis j = (Jedis)getShard(key);
/* 301 */     return j.zadd(key, scoreMembers);
/*     */   }
/*     */ 
/*     */   public Set<byte[]> zrange(byte[] key, long start, long end) {
/* 305 */     Jedis j = (Jedis)getShard(key);
/* 306 */     return j.zrange(key, start, end);
/*     */   }
/*     */ 
/*     */   public Long zrem(byte[] key, byte[][] members) {
/* 310 */     Jedis j = (Jedis)getShard(key);
/* 311 */     return j.zrem(key, members);
/*     */   }
/*     */ 
/*     */   public Double zincrby(byte[] key, double score, byte[] member) {
/* 315 */     Jedis j = (Jedis)getShard(key);
/* 316 */     return j.zincrby(key, score, member);
/*     */   }
/*     */ 
/*     */   public Long zrank(byte[] key, byte[] member) {
/* 320 */     Jedis j = (Jedis)getShard(key);
/* 321 */     return j.zrank(key, member);
/*     */   }
/*     */ 
/*     */   public Long zrevrank(byte[] key, byte[] member) {
/* 325 */     Jedis j = (Jedis)getShard(key);
/* 326 */     return j.zrevrank(key, member);
/*     */   }
/*     */ 
/*     */   public Set<byte[]> zrevrange(byte[] key, long start, long end) {
/* 330 */     Jedis j = (Jedis)getShard(key);
/* 331 */     return j.zrevrange(key, start, end);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrangeWithScores(byte[] key, long start, long end) {
/* 335 */     Jedis j = (Jedis)getShard(key);
/* 336 */     return j.zrangeWithScores(key, start, end);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrevrangeWithScores(byte[] key, long start, long end) {
/* 340 */     Jedis j = (Jedis)getShard(key);
/* 341 */     return j.zrevrangeWithScores(key, start, end);
/*     */   }
/*     */ 
/*     */   public Long zcard(byte[] key) {
/* 345 */     Jedis j = (Jedis)getShard(key);
/* 346 */     return j.zcard(key);
/*     */   }
/*     */ 
/*     */   public Double zscore(byte[] key, byte[] member) {
/* 350 */     Jedis j = (Jedis)getShard(key);
/* 351 */     return j.zscore(key, member);
/*     */   }
/*     */ 
/*     */   public List<byte[]> sort(byte[] key) {
/* 355 */     Jedis j = (Jedis)getShard(key);
/* 356 */     return j.sort(key);
/*     */   }
/*     */ 
/*     */   public List<byte[]> sort(byte[] key, SortingParams sortingParameters) {
/* 360 */     Jedis j = (Jedis)getShard(key);
/* 361 */     return j.sort(key, sortingParameters);
/*     */   }
/*     */ 
/*     */   public Long zcount(byte[] key, double min, double max) {
/* 365 */     Jedis j = (Jedis)getShard(key);
/* 366 */     return j.zcount(key, min, max);
/*     */   }
/*     */ 
/*     */   public Long zcount(byte[] key, byte[] min, byte[] max) {
/* 370 */     Jedis j = (Jedis)getShard(key);
/* 371 */     return j.zcount(key, min, max);
/*     */   }
/*     */ 
/*     */   public Set<byte[]> zrangeByScore(byte[] key, double min, double max) {
/* 375 */     Jedis j = (Jedis)getShard(key);
/* 376 */     return j.zrangeByScore(key, min, max);
/*     */   }
/*     */ 
/*     */   public Set<byte[]> zrangeByScore(byte[] key, double min, double max, int offset, int count)
/*     */   {
/* 381 */     Jedis j = (Jedis)getShard(key);
/* 382 */     return j.zrangeByScore(key, min, max, offset, count);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrangeByScoreWithScores(byte[] key, double min, double max) {
/* 386 */     Jedis j = (Jedis)getShard(key);
/* 387 */     return j.zrangeByScoreWithScores(key, min, max);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrangeByScoreWithScores(byte[] key, double min, double max, int offset, int count)
/*     */   {
/* 392 */     Jedis j = (Jedis)getShard(key);
/* 393 */     return j.zrangeByScoreWithScores(key, min, max, offset, count);
/*     */   }
/*     */ 
/*     */   public Set<byte[]> zrangeByScore(byte[] key, byte[] min, byte[] max) {
/* 397 */     Jedis j = (Jedis)getShard(key);
/* 398 */     return j.zrangeByScore(key, min, max);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrangeByScoreWithScores(byte[] key, byte[] min, byte[] max) {
/* 402 */     Jedis j = (Jedis)getShard(key);
/* 403 */     return j.zrangeByScoreWithScores(key, min, max);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrangeByScoreWithScores(byte[] key, byte[] min, byte[] max, int offset, int count)
/*     */   {
/* 408 */     Jedis j = (Jedis)getShard(key);
/* 409 */     return j.zrangeByScoreWithScores(key, min, max, offset, count);
/*     */   }
/*     */ 
/*     */   public Set<byte[]> zrangeByScore(byte[] key, byte[] min, byte[] max, int offset, int count) {
/* 413 */     Jedis j = (Jedis)getShard(key);
/* 414 */     return j.zrangeByScore(key, min, max, offset, count);
/*     */   }
/*     */ 
/*     */   public Set<byte[]> zrevrangeByScore(byte[] key, double max, double min) {
/* 418 */     Jedis j = (Jedis)getShard(key);
/* 419 */     return j.zrevrangeByScore(key, max, min);
/*     */   }
/*     */ 
/*     */   public Set<byte[]> zrevrangeByScore(byte[] key, double max, double min, int offset, int count)
/*     */   {
/* 424 */     Jedis j = (Jedis)getShard(key);
/* 425 */     return j.zrevrangeByScore(key, max, min, offset, count);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrevrangeByScoreWithScores(byte[] key, double max, double min)
/*     */   {
/* 430 */     Jedis j = (Jedis)getShard(key);
/* 431 */     return j.zrevrangeByScoreWithScores(key, max, min);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrevrangeByScoreWithScores(byte[] key, double max, double min, int offset, int count)
/*     */   {
/* 436 */     Jedis j = (Jedis)getShard(key);
/* 437 */     return j.zrevrangeByScoreWithScores(key, max, min, offset, count);
/*     */   }
/*     */ 
/*     */   public Set<byte[]> zrevrangeByScore(byte[] key, byte[] max, byte[] min) {
/* 441 */     Jedis j = (Jedis)getShard(key);
/* 442 */     return j.zrevrangeByScore(key, max, min);
/*     */   }
/*     */ 
/*     */   public Set<byte[]> zrevrangeByScore(byte[] key, byte[] max, byte[] min, int offset, int count)
/*     */   {
/* 447 */     Jedis j = (Jedis)getShard(key);
/* 448 */     return j.zrevrangeByScore(key, max, min, offset, count);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrevrangeByScoreWithScores(byte[] key, byte[] max, byte[] min)
/*     */   {
/* 453 */     Jedis j = (Jedis)getShard(key);
/* 454 */     return j.zrevrangeByScoreWithScores(key, max, min);
/*     */   }
/*     */ 
/*     */   public Set<Tuple> zrevrangeByScoreWithScores(byte[] key, byte[] max, byte[] min, int offset, int count)
/*     */   {
/* 459 */     Jedis j = (Jedis)getShard(key);
/* 460 */     return j.zrevrangeByScoreWithScores(key, max, min, offset, count);
/*     */   }
/*     */ 
/*     */   public Long zremrangeByRank(byte[] key, long start, long end) {
/* 464 */     Jedis j = (Jedis)getShard(key);
/* 465 */     return j.zremrangeByRank(key, start, end);
/*     */   }
/*     */ 
/*     */   public Long zremrangeByScore(byte[] key, double start, double end) {
/* 469 */     Jedis j = (Jedis)getShard(key);
/* 470 */     return j.zremrangeByScore(key, start, end);
/*     */   }
/*     */ 
/*     */   public Long zremrangeByScore(byte[] key, byte[] start, byte[] end) {
/* 474 */     Jedis j = (Jedis)getShard(key);
/* 475 */     return j.zremrangeByScore(key, start, end);
/*     */   }
/*     */ 
/*     */   public Long linsert(byte[] key, BinaryClient.LIST_POSITION where, byte[] pivot, byte[] value)
/*     */   {
/* 480 */     Jedis j = (Jedis)getShard(key);
/* 481 */     return j.linsert(key, where, pivot, value);
/*     */   }
/*     */   @Deprecated
/*     */   public List<Object> pipelined(ShardedJedisPipeline shardedJedisPipeline) {
/* 486 */     shardedJedisPipeline.setShardedJedis(this);
/* 487 */     shardedJedisPipeline.execute();
/* 488 */     return shardedJedisPipeline.getResults();
/*     */   }
/*     */ 
/*     */   public ShardedJedisPipeline pipelined() {
/* 492 */     ShardedJedisPipeline pipeline = new ShardedJedisPipeline();
/* 493 */     pipeline.setShardedJedis(this);
/* 494 */     return pipeline;
/*     */   }
/*     */ 
/*     */   public Long objectRefcount(byte[] key) {
/* 498 */     Jedis j = (Jedis)getShard(key);
/* 499 */     return j.objectRefcount(key);
/*     */   }
/*     */ 
/*     */   public byte[] objectEncoding(byte[] key) {
/* 503 */     Jedis j = (Jedis)getShard(key);
/* 504 */     return j.objectEncoding(key);
/*     */   }
/*     */ 
/*     */   public Long objectIdletime(byte[] key) {
/* 508 */     Jedis j = (Jedis)getShard(key);
/* 509 */     return j.objectIdletime(key);
/*     */   }
/*     */ 
/*     */   public Boolean setbit(byte[] key, long offset, boolean value) {
/* 513 */     Jedis j = (Jedis)getShard(key);
/* 514 */     return j.setbit(key, offset, value);
/*     */   }
/*     */ 
/*     */   public Boolean setbit(byte[] key, long offset, byte[] value) {
/* 518 */     Jedis j = (Jedis)getShard(key);
/* 519 */     return j.setbit(key, offset, value);
/*     */   }
/*     */ 
/*     */   public Boolean getbit(byte[] key, long offset) {
/* 523 */     Jedis j = (Jedis)getShard(key);
/* 524 */     return j.getbit(key, offset);
/*     */   }
/*     */ 
/*     */   public Long setrange(byte[] key, long offset, byte[] value) {
/* 528 */     Jedis j = (Jedis)getShard(key);
/* 529 */     return j.setrange(key, offset, value);
/*     */   }
/*     */ 
/*     */   public byte[] getrange(byte[] key, long startOffset, long endOffset) {
/* 533 */     Jedis j = (Jedis)getShard(key);
/* 534 */     return j.getrange(key, startOffset, endOffset);
/*     */   }
/*     */ 
/*     */   public Long move(byte[] key, int dbIndex) {
/* 538 */     Jedis j = (Jedis)getShard(key);
/* 539 */     return j.move(key, dbIndex);
/*     */   }
/*     */ 
/*     */   public byte[] echo(byte[] arg) {
/* 543 */     Jedis j = (Jedis)getShard(arg);
/* 544 */     return j.echo(arg);
/*     */   }
/*     */ 
/*     */   public List<byte[]> brpop(byte[] arg) {
/* 548 */     Jedis j = (Jedis)getShard(arg);
/* 549 */     return j.brpop(arg);
/*     */   }
/*     */ 
/*     */   public List<byte[]> blpop(byte[] arg) {
/* 553 */     Jedis j = (Jedis)getShard(arg);
/* 554 */     return j.blpop(arg);
/*     */   }
/*     */ 
/*     */   public Long bitcount(byte[] key) {
/* 558 */     Jedis j = (Jedis)getShard(key);
/* 559 */     return j.bitcount(key);
/*     */   }
/*     */ 
/*     */   public Long bitcount(byte[] key, long start, long end) {
/* 563 */     Jedis j = (Jedis)getShard(key);
/* 564 */     return j.bitcount(key, start, end);
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.BinaryShardedJedis
 * JD-Core Version:    0.6.0
 */