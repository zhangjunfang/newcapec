/*     */ package cn.newcapec.framework.base.dao.redis.core;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ abstract class MultiKeyPipelineBase extends PipelineBase
/*     */   implements BasicRedisPipeline, MultiKeyBinaryRedisPipeline, MultiKeyCommandsPipeline
/*     */ {
/*  11 */   protected Client client = null;
/*     */ 
/*     */   public Response<List<String>> brpop(String[] args) {
/*  14 */     this.client.brpop(args);
/*  15 */     return getResponse(BuilderFactory.STRING_LIST);
/*     */   }
/*     */ 
/*     */   public Response<List<String>> blpop(String[] args) {
/*  19 */     this.client.blpop(args);
/*  20 */     return getResponse(BuilderFactory.STRING_LIST);
/*     */   }
/*     */ 
/*     */   public Response<List<byte[]>> brpop(byte[][] args) {
/*  24 */     this.client.brpop(args);
/*  25 */     return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
/*     */   }
/*     */ 
/*     */   public Response<List<byte[]>> blpop(byte[][] args) {
/*  29 */     this.client.blpop(args);
/*  30 */     return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
/*     */   }
/*     */ 
/*     */   public Response<Long> del(String[] keys) {
/*  34 */     this.client.del(keys);
/*  35 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> del(byte[][] keys) {
/*  39 */     this.client.del(keys);
/*  40 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Set<String>> keys(String pattern) {
/*  44 */     getClient(pattern).keys(pattern);
/*  45 */     return getResponse(BuilderFactory.STRING_SET);
/*     */   }
/*     */ 
/*     */   public Response<Set<byte[]>> keys(byte[] pattern) {
/*  49 */     getClient(pattern).keys(pattern);
/*  50 */     return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<List<String>> mget(String[] keys) {
/*  54 */     this.client.mget(keys);
/*  55 */     return getResponse(BuilderFactory.STRING_LIST);
/*     */   }
/*     */ 
/*     */   public Response<List<byte[]>> mget(byte[][] keys) {
/*  59 */     this.client.mget(keys);
/*  60 */     return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
/*     */   }
/*     */ 
/*     */   public Response<String> mset(String[] keysvalues) {
/*  64 */     this.client.mset(keysvalues);
/*  65 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> mset(byte[][] keysvalues) {
/*  69 */     this.client.mset(keysvalues);
/*  70 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<Long> msetnx(String[] keysvalues) {
/*  74 */     this.client.msetnx(keysvalues);
/*  75 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> msetnx(byte[][] keysvalues) {
/*  79 */     this.client.msetnx(keysvalues);
/*  80 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<String> rename(String oldkey, String newkey) {
/*  84 */     this.client.rename(oldkey, newkey);
/*  85 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> rename(byte[] oldkey, byte[] newkey) {
/*  89 */     this.client.rename(oldkey, newkey);
/*  90 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<Long> renamenx(String oldkey, String newkey) {
/*  94 */     this.client.renamenx(oldkey, newkey);
/*  95 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> renamenx(byte[] oldkey, byte[] newkey) {
/*  99 */     this.client.renamenx(oldkey, newkey);
/* 100 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<String> rpoplpush(String srckey, String dstkey) {
/* 104 */     this.client.rpoplpush(srckey, dstkey);
/* 105 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<byte[]> rpoplpush(byte[] srckey, byte[] dstkey) {
/* 109 */     this.client.rpoplpush(srckey, dstkey);
/* 110 */     return getResponse(BuilderFactory.BYTE_ARRAY);
/*     */   }
/*     */ 
/*     */   public Response<Set<String>> sdiff(String[] keys) {
/* 114 */     this.client.sdiff(keys);
/* 115 */     return getResponse(BuilderFactory.STRING_SET);
/*     */   }
/*     */ 
/*     */   public Response<Set<byte[]>> sdiff(byte[][] keys) {
/* 119 */     this.client.sdiff(keys);
/* 120 */     return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Long> sdiffstore(String dstkey, String[] keys) {
/* 124 */     this.client.sdiffstore(dstkey, keys);
/* 125 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> sdiffstore(byte[] dstkey, byte[][] keys) {
/* 129 */     this.client.sdiffstore(dstkey, keys);
/* 130 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Set<String>> sinter(String[] keys) {
/* 134 */     this.client.sinter(keys);
/* 135 */     return getResponse(BuilderFactory.STRING_SET);
/*     */   }
/*     */ 
/*     */   public Response<Set<byte[]>> sinter(byte[][] keys) {
/* 139 */     this.client.sinter(keys);
/* 140 */     return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Long> sinterstore(String dstkey, String[] keys) {
/* 144 */     this.client.sinterstore(dstkey, keys);
/* 145 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> sinterstore(byte[] dstkey, byte[][] keys) {
/* 149 */     this.client.sinterstore(dstkey, keys);
/* 150 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> smove(String srckey, String dstkey, String member) {
/* 154 */     this.client.smove(srckey, dstkey, member);
/* 155 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> smove(byte[] srckey, byte[] dstkey, byte[] member) {
/* 159 */     this.client.smove(srckey, dstkey, member);
/* 160 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<List<String>> sort(String key, SortingParams sortingParameters, String dstkey)
/*     */   {
/* 165 */     this.client.sort(key, sortingParameters, dstkey);
/* 166 */     return getResponse(BuilderFactory.STRING_LIST);
/*     */   }
/*     */ 
/*     */   public Response<List<byte[]>> sort(byte[] key, SortingParams sortingParameters, byte[] dstkey)
/*     */   {
/* 171 */     this.client.sort(key, sortingParameters, dstkey);
/* 172 */     return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
/*     */   }
/*     */ 
/*     */   public Response<List<String>> sort(String key, String dstkey) {
/* 176 */     this.client.sort(key, dstkey);
/* 177 */     return getResponse(BuilderFactory.STRING_LIST);
/*     */   }
/*     */ 
/*     */   public Response<List<byte[]>> sort(byte[] key, byte[] dstkey) {
/* 181 */     this.client.sort(key, dstkey);
/* 182 */     return getResponse(BuilderFactory.BYTE_ARRAY_LIST);
/*     */   }
/*     */ 
/*     */   public Response<Set<String>> sunion(String[] keys) {
/* 186 */     this.client.sunion(keys);
/* 187 */     return getResponse(BuilderFactory.STRING_SET);
/*     */   }
/*     */ 
/*     */   public Response<Set<byte[]>> sunion(byte[][] keys) {
/* 191 */     this.client.sunion(keys);
/* 192 */     return getResponse(BuilderFactory.BYTE_ARRAY_ZSET);
/*     */   }
/*     */ 
/*     */   public Response<Long> sunionstore(String dstkey, String[] keys) {
/* 196 */     this.client.sunionstore(dstkey, keys);
/* 197 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> sunionstore(byte[] dstkey, byte[][] keys) {
/* 201 */     this.client.sunionstore(dstkey, keys);
/* 202 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<String> watch(String[] keys) {
/* 206 */     this.client.watch(keys);
/* 207 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> watch(byte[][] keys) {
/* 211 */     this.client.watch(keys);
/* 212 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<Long> zinterstore(String dstkey, String[] sets) {
/* 216 */     this.client.zinterstore(dstkey, sets);
/* 217 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zinterstore(byte[] dstkey, byte[][] sets) {
/* 221 */     this.client.zinterstore(dstkey, sets);
/* 222 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zinterstore(String dstkey, ZParams params, String[] sets)
/*     */   {
/* 227 */     this.client.zinterstore(dstkey, params, sets);
/* 228 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zinterstore(byte[] dstkey, ZParams params, byte[][] sets)
/*     */   {
/* 233 */     this.client.zinterstore(dstkey, params, sets);
/* 234 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zunionstore(String dstkey, String[] sets) {
/* 238 */     this.client.zunionstore(dstkey, sets);
/* 239 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zunionstore(byte[] dstkey, byte[][] sets) {
/* 243 */     this.client.zunionstore(dstkey, sets);
/* 244 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zunionstore(String dstkey, ZParams params, String[] sets)
/*     */   {
/* 249 */     this.client.zunionstore(dstkey, params, sets);
/* 250 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> zunionstore(byte[] dstkey, ZParams params, byte[][] sets)
/*     */   {
/* 255 */     this.client.zunionstore(dstkey, params, sets);
/* 256 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<String> bgrewriteaof() {
/* 260 */     this.client.bgrewriteaof();
/* 261 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> bgsave() {
/* 265 */     this.client.bgsave();
/* 266 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> configGet(String pattern) {
/* 270 */     this.client.configGet(pattern);
/* 271 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> configSet(String parameter, String value) {
/* 275 */     this.client.configSet(parameter, value);
/* 276 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> brpoplpush(String source, String destination, int timeout)
/*     */   {
/* 281 */     this.client.brpoplpush(source, destination, timeout);
/* 282 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<byte[]> brpoplpush(byte[] source, byte[] destination, int timeout)
/*     */   {
/* 287 */     this.client.brpoplpush(source, destination, timeout);
/* 288 */     return getResponse(BuilderFactory.BYTE_ARRAY);
/*     */   }
/*     */ 
/*     */   public Response<String> configResetStat() {
/* 292 */     this.client.configResetStat();
/* 293 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> save() {
/* 297 */     this.client.save();
/* 298 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<Long> lastsave() {
/* 302 */     this.client.lastsave();
/* 303 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> publish(String channel, String message) {
/* 307 */     this.client.publish(channel, message);
/* 308 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> publish(byte[] channel, byte[] message) {
/* 312 */     this.client.publish(channel, message);
/* 313 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<String> randomKey() {
/* 317 */     this.client.randomKey();
/* 318 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<byte[]> randomKeyBinary() {
/* 322 */     this.client.randomKey();
/* 323 */     return getResponse(BuilderFactory.BYTE_ARRAY);
/*     */   }
/*     */ 
/*     */   public Response<String> flushDB() {
/* 327 */     this.client.flushDB();
/* 328 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> flushAll() {
/* 332 */     this.client.flushAll();
/* 333 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> info() {
/* 337 */     this.client.info();
/* 338 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<Long> dbSize() {
/* 342 */     this.client.dbSize();
/* 343 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<String> shutdown() {
/* 347 */     this.client.shutdown();
/* 348 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> ping() {
/* 352 */     this.client.ping();
/* 353 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<String> select(int index) {
/* 357 */     this.client.select(index);
/* 358 */     return getResponse(BuilderFactory.STRING);
/*     */   }
/*     */ 
/*     */   public Response<Long> bitop(BitOP op, byte[] destKey, byte[][] srcKeys) {
/* 362 */     this.client.bitop(op, destKey, srcKeys);
/* 363 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ 
/*     */   public Response<Long> bitop(BitOP op, String destKey, String[] srcKeys) {
/* 367 */     this.client.bitop(op, destKey, srcKeys);
/* 368 */     return getResponse(BuilderFactory.LONG);
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.MultiKeyPipelineBase
 * JD-Core Version:    0.6.0
 */