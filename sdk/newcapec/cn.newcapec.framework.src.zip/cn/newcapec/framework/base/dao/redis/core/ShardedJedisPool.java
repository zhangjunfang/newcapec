/*    */ package cn.newcapec.framework.base.dao.redis.core;
/*    */ 
/*    */ import cn.newcapec.framework.base.dao.redis.util.Hashing;
/*    */ import cn.newcapec.framework.base.dao.redis.util.Pool;
/*    */ import java.util.List;
/*    */ import java.util.regex.Pattern;
/*    */ import org.apache.commons.pool.BasePoolableObjectFactory;
/*    */ import org.apache.commons.pool.impl.GenericObjectPool.Config;
/*    */ 
/*    */ public class ShardedJedisPool extends Pool<ShardedJedis>
/*    */ {
/*    */   public ShardedJedisPool(GenericObjectPool.Config poolConfig, List<JedisShardInfo> shards)
/*    */   {
/* 15 */     this(poolConfig, shards, Hashing.MURMUR_HASH);
/*    */   }
/*    */ 
/*    */   public ShardedJedisPool(GenericObjectPool.Config poolConfig, List<JedisShardInfo> shards, Hashing algo)
/*    */   {
/* 20 */     this(poolConfig, shards, algo, null);
/*    */   }
/*    */ 
/*    */   public ShardedJedisPool(GenericObjectPool.Config poolConfig, List<JedisShardInfo> shards, Pattern keyTagPattern)
/*    */   {
/* 25 */     this(poolConfig, shards, Hashing.MURMUR_HASH, keyTagPattern);
/*    */   }
/*    */ 
/*    */   public ShardedJedisPool(GenericObjectPool.Config poolConfig, List<JedisShardInfo> shards, Hashing algo, Pattern keyTagPattern)
/*    */   {
/* 30 */     super(poolConfig, new ShardedJedisFactory(shards, algo, keyTagPattern));
/*    */   }
/*    */ 
/*    */   private static class ShardedJedisFactory extends BasePoolableObjectFactory
/*    */   {
/*    */     private List<JedisShardInfo> shards;
/*    */     private Hashing algo;
/*    */     private Pattern keyTagPattern;
/*    */ 
/*    */     public ShardedJedisFactory(List<JedisShardInfo> shards, Hashing algo, Pattern keyTagPattern) {
/* 43 */       this.shards = shards;
/* 44 */       this.algo = algo;
/* 45 */       this.keyTagPattern = keyTagPattern;
/*    */     }
/*    */ 
/*    */     public Object makeObject() throws Exception {
/* 49 */       ShardedJedis jedis = new ShardedJedis(this.shards, this.algo, this.keyTagPattern);
/* 50 */       return jedis;
/*    */     }
/*    */ 
/*    */     public void destroyObject(Object obj) throws Exception {
/* 54 */       if ((obj != null) && ((obj instanceof ShardedJedis))) {
/* 55 */         ShardedJedis shardedJedis = (ShardedJedis)obj;
/* 56 */         for (Jedis jedis : shardedJedis.getAllShards())
/*    */           try {
/*    */             try {
/* 59 */               jedis.quit();
/*    */             }
/*    */             catch (Exception localException) {
/*    */             }
/* 63 */             jedis.disconnect();
/*    */           }
/*    */           catch (Exception localException1)
/*    */           {
/*    */           }
/*    */       }
/*    */     }
/*    */ 
/*    */     public boolean validateObject(Object obj) {
/*    */       try {
/* 73 */         ShardedJedis jedis = (ShardedJedis)obj;
/* 74 */         for (Jedis shard : jedis.getAllShards()) {
/* 75 */           if (!shard.ping().equals("PONG")) {
/* 76 */             return false;
/*    */           }
/*    */         }
/* 79 */         return true; } catch (Exception ex) {
/*    */       }
/* 81 */       return false;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.ShardedJedisPool
 * JD-Core Version:    0.6.0
 */