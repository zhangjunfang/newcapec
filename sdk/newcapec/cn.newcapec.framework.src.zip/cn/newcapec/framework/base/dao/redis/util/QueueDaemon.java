/*    */ package cn.newcapec.framework.base.dao.redis.util;
/*    */ 
/*    */ import java.net.InetSocketAddress;
/*    */ import java.util.concurrent.Executors;
/*    */ import org.jboss.netty.bootstrap.ServerBootstrap;
/*    */ import org.jboss.netty.channel.ChannelPipeline;
/*    */ import org.jboss.netty.channel.ChannelPipelineFactory;
/*    */ import org.jboss.netty.channel.Channels;
/*    */ import org.jboss.netty.channel.socket.nio.NioServerSocketChannelFactory;
/*    */ import org.jboss.netty.handler.codec.http.HttpRequestDecoder;
/*    */ import org.jboss.netty.handler.codec.http.HttpResponseEncoder;
/*    */ 
/*    */ public class QueueDaemon
/*    */ {
/*    */   private int port;
/*    */   private QueueService queueService;
/*    */ 
/*    */   public QueueDaemon(int port, QueueService queueService)
/*    */   {
/* 27 */     this.port = port;
/* 28 */     this.queueService = queueService;
/*    */   }
/*    */ 
/*    */   public void start() {
/* 32 */     ServerBootstrap bootstrap = new ServerBootstrap(
/* 33 */       new NioServerSocketChannelFactory(
/* 34 */       Executors.newCachedThreadPool(), 
/* 35 */       Executors.newCachedThreadPool()));
/*    */ 
/* 37 */     bootstrap.setPipelineFactory(new ChannelPipelineFactory() {
/*    */       public ChannelPipeline getPipeline() throws Exception {
/* 39 */         ChannelPipeline pipeline = Channels.pipeline();
/*    */ 
/* 41 */         pipeline.addLast("decoder", new HttpRequestDecoder());
/* 42 */         pipeline.addLast("encoder", new HttpResponseEncoder());
/*    */ 
/* 44 */         pipeline.addLast("handler", 
/* 45 */           new HttpRequestHandler(QueueDaemon.this.queueService));
/* 46 */         return pipeline;
/*    */       }
/*    */     });
/* 50 */     bootstrap.setOption("child.tcpNoDelay", Boolean.valueOf(true));
/* 51 */     bootstrap.setOption("child.keepAlive", Boolean.valueOf(true));
/* 52 */     bootstrap.setOption("child.reuseAddress", Boolean.valueOf(true));
/* 53 */     bootstrap.setOption("child.connectTimeoutMillis", Integer.valueOf(100));
/*    */ 
/* 55 */     bootstrap.bind(new InetSocketAddress(this.port));
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.util.QueueDaemon
 * JD-Core Version:    0.6.0
 */