/*    */ package cn.newcapec.framework.base.dao.redis.core.exceptions;
/*    */ 
/*    */ public class JedisDataException extends JedisException
/*    */ {
/*    */   private static final long serialVersionUID = 3878126572474819403L;
/*    */ 
/*    */   public JedisDataException(String message)
/*    */   {
/*  7 */     super(message);
/*    */   }
/*    */ 
/*    */   public JedisDataException(Throwable cause) {
/* 11 */     super(cause);
/*    */   }
/*    */ 
/*    */   public JedisDataException(String message, Throwable cause) {
/* 15 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.exceptions.JedisDataException
 * JD-Core Version:    0.6.0
 */