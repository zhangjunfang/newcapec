package cn.newcapec.framework.base.dao;

import java.io.Serializable;
import java.util.List;

public abstract interface EntityDao<T>
{
  public abstract T get(Serializable paramSerializable);

  public abstract List<T> getAll();

  public abstract void save(Object paramObject);

  public abstract void remove(Object paramObject);

  public abstract void removeById(Serializable paramSerializable);

  public abstract String getIdName(Class paramClass);

  public abstract long countAll();

  public abstract void clear();

  public abstract <V> V findUniqueBy(Class<V> paramClass, String paramString, Object paramObject);

  public abstract <V> V findUniqueBy(Class<V> paramClass, String[] paramArrayOfString, Object[] paramArrayOfObject);

  public abstract <V> List<V> findBy(Class<V> paramClass, String paramString, Object paramObject);
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.EntityDao
 * JD-Core Version:    0.6.0
 */