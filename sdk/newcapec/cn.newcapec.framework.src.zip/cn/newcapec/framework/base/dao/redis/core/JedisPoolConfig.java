/*     */ package cn.newcapec.framework.base.dao.redis.core;
/*     */ 
/*     */ import org.apache.commons.pool.impl.GenericObjectPool.Config;
/*     */ 
/*     */ public class JedisPoolConfig extends GenericObjectPool.Config
/*     */ {
/*     */   public JedisPoolConfig()
/*     */   {
/*  28 */     setTestWhileIdle(true);
/*  29 */     setMinEvictableIdleTimeMillis(60000L);
/*  30 */     setTimeBetweenEvictionRunsMillis(30000L);
/*  31 */     setNumTestsPerEvictionRun(-1);
/*     */   }
/*     */ 
/*     */   public int getMaxIdle() {
/*  35 */     return this.maxIdle;
/*     */   }
/*     */ 
/*     */   public void setMaxIdle(int maxIdle) {
/*  39 */     this.maxIdle = maxIdle;
/*     */   }
/*     */ 
/*     */   public int getMinIdle() {
/*  43 */     return this.minIdle;
/*     */   }
/*     */ 
/*     */   public void setMinIdle(int minIdle) {
/*  47 */     this.minIdle = minIdle;
/*     */   }
/*     */ 
/*     */   public int getMaxActive() {
/*  51 */     return this.maxActive;
/*     */   }
/*     */ 
/*     */   public void setMaxActive(int maxActive) {
/*  55 */     this.maxActive = maxActive;
/*     */   }
/*     */ 
/*     */   public long getMaxWait() {
/*  59 */     return this.maxWait;
/*     */   }
/*     */ 
/*     */   public void setMaxWait(long maxWait) {
/*  63 */     this.maxWait = maxWait;
/*     */   }
/*     */ 
/*     */   public byte getWhenExhaustedAction() {
/*  67 */     return this.whenExhaustedAction;
/*     */   }
/*     */ 
/*     */   public void setWhenExhaustedAction(byte whenExhaustedAction) {
/*  71 */     this.whenExhaustedAction = whenExhaustedAction;
/*     */   }
/*     */ 
/*     */   public boolean isTestOnBorrow() {
/*  75 */     return this.testOnBorrow;
/*     */   }
/*     */ 
/*     */   public void setTestOnBorrow(boolean testOnBorrow) {
/*  79 */     this.testOnBorrow = testOnBorrow;
/*     */   }
/*     */ 
/*     */   public boolean isTestOnReturn() {
/*  83 */     return this.testOnReturn;
/*     */   }
/*     */ 
/*     */   public void setTestOnReturn(boolean testOnReturn) {
/*  87 */     this.testOnReturn = testOnReturn;
/*     */   }
/*     */ 
/*     */   public boolean isTestWhileIdle() {
/*  91 */     return this.testWhileIdle;
/*     */   }
/*     */ 
/*     */   public void setTestWhileIdle(boolean testWhileIdle) {
/*  95 */     this.testWhileIdle = testWhileIdle;
/*     */   }
/*     */ 
/*     */   public long getTimeBetweenEvictionRunsMillis() {
/*  99 */     return this.timeBetweenEvictionRunsMillis;
/*     */   }
/*     */ 
/*     */   public void setTimeBetweenEvictionRunsMillis(long timeBetweenEvictionRunsMillis)
/*     */   {
/* 104 */     this.timeBetweenEvictionRunsMillis = timeBetweenEvictionRunsMillis;
/*     */   }
/*     */ 
/*     */   public int getNumTestsPerEvictionRun() {
/* 108 */     return this.numTestsPerEvictionRun;
/*     */   }
/*     */ 
/*     */   public void setNumTestsPerEvictionRun(int numTestsPerEvictionRun) {
/* 112 */     this.numTestsPerEvictionRun = numTestsPerEvictionRun;
/*     */   }
/*     */ 
/*     */   public long getMinEvictableIdleTimeMillis() {
/* 116 */     return this.minEvictableIdleTimeMillis;
/*     */   }
/*     */ 
/*     */   public void setMinEvictableIdleTimeMillis(long minEvictableIdleTimeMillis) {
/* 120 */     this.minEvictableIdleTimeMillis = minEvictableIdleTimeMillis;
/*     */   }
/*     */ 
/*     */   public long getSoftMinEvictableIdleTimeMillis() {
/* 124 */     return this.softMinEvictableIdleTimeMillis;
/*     */   }
/*     */ 
/*     */   public void setSoftMinEvictableIdleTimeMillis(long softMinEvictableIdleTimeMillis)
/*     */   {
/* 129 */     this.softMinEvictableIdleTimeMillis = softMinEvictableIdleTimeMillis;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.JedisPoolConfig
 * JD-Core Version:    0.6.0
 */