/*    */ package cn.newcapec.framework.base.dao.redis.core;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ import java.util.Queue;
/*    */ 
/*    */ public class Queable
/*    */ {
/*  7 */   private Queue<Response<?>> pipelinedResponses = new LinkedList();
/*    */ 
/*    */   protected void clean() {
/* 10 */     this.pipelinedResponses.clear();
/*    */   }
/*    */ 
/*    */   protected Response<?> generateResponse(Object data) {
/* 14 */     Response response = (Response)this.pipelinedResponses.poll();
/* 15 */     if (response != null) {
/* 16 */       response.set(data);
/*    */     }
/* 18 */     return response;
/*    */   }
/*    */ 
/*    */   protected <T> Response<T> getResponse(Builder<T> builder) {
/* 22 */     Response lr = new Response(builder);
/* 23 */     this.pipelinedResponses.add(lr);
/* 24 */     return lr;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.Queable
 * JD-Core Version:    0.6.0
 */