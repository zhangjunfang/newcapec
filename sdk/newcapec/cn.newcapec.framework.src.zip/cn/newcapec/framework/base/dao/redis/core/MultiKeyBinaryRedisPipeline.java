package cn.newcapec.framework.base.dao.redis.core;

import java.util.List;
import java.util.Set;

public abstract interface MultiKeyBinaryRedisPipeline
{
  public abstract Response<Long> del(byte[][] paramArrayOfByte);

  public abstract Response<List<byte[]>> blpop(byte[][] paramArrayOfByte);

  public abstract Response<List<byte[]>> brpop(byte[][] paramArrayOfByte);

  public abstract Response<Set<byte[]>> keys(byte[] paramArrayOfByte);

  public abstract Response<List<byte[]>> mget(byte[][] paramArrayOfByte);

  public abstract Response<String> mset(byte[][] paramArrayOfByte);

  public abstract Response<Long> msetnx(byte[][] paramArrayOfByte);

  public abstract Response<String> rename(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Response<Long> renamenx(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Response<byte[]> rpoplpush(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Response<Set<byte[]>> sdiff(byte[][] paramArrayOfByte);

  public abstract Response<Long> sdiffstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);

  public abstract Response<Set<byte[]>> sinter(byte[][] paramArrayOfByte);

  public abstract Response<Long> sinterstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);

  public abstract Response<Long> smove(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3);

  public abstract Response<List<byte[]>> sort(byte[] paramArrayOfByte1, SortingParams paramSortingParams, byte[] paramArrayOfByte2);

  public abstract Response<List<byte[]>> sort(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Response<Set<byte[]>> sunion(byte[][] paramArrayOfByte);

  public abstract Response<Long> sunionstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);

  public abstract Response<String> watch(byte[][] paramArrayOfByte);

  public abstract Response<Long> zinterstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);

  public abstract Response<Long> zinterstore(byte[] paramArrayOfByte, ZParams paramZParams, byte[][] paramArrayOfByte1);

  public abstract Response<Long> zunionstore(byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);

  public abstract Response<Long> zunionstore(byte[] paramArrayOfByte, ZParams paramZParams, byte[][] paramArrayOfByte1);

  public abstract Response<byte[]> brpoplpush(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt);

  public abstract Response<Long> publish(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  public abstract Response<byte[]> randomKeyBinary();

  public abstract Response<Long> bitop(BitOP paramBitOP, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1);
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.core.MultiKeyBinaryRedisPipeline
 * JD-Core Version:    0.6.0
 */