/*     */ package cn.newcapec.framework.base.dao.db;
/*     */ 
/*     */ public class PagingHelper
/*     */ {
/*  10 */   private int pageSize = 0;
/*     */ 
/*  12 */   private int pageIndex = 1;
/*     */ 
/*  14 */   private int totalCount = -1;
/*     */ 
/*  16 */   private int fromIndex = 0;
/*     */ 
/*  18 */   private int toIndex = 0;
/*     */ 
/*  20 */   private int pageCount = 0;
/*     */ 
/*  22 */   private static int DEFAULT_MAX_PAGING_LINK = 10;
/*     */ 
/*     */   public int[] getPaginLinks()
/*     */   {
/*  33 */     if (this.pageCount == 0) {
/*  34 */       return new int[] { 1 };
/*     */     }
/*     */ 
/*  37 */     if (this.pageIndex > this.pageCount) {
/*  38 */       this.pageIndex = this.pageCount;
/*     */     }
/*     */ 
/*  42 */     int firstNo = this.pageIndex - DEFAULT_MAX_PAGING_LINK / 2;
/*  43 */     int offset = firstNo - 1;
/*     */ 
/*  45 */     int endNo = this.pageIndex + DEFAULT_MAX_PAGING_LINK / 2 - 1;
/*  46 */     int endoffset = endNo - this.pageCount;
/*  47 */     if (offset < 0) {
/*  48 */       if (endoffset > 0) {
/*  49 */         firstNo = 1;
/*     */       } else {
/*  51 */         endNo -= offset;
/*  52 */         endoffset = endNo - this.pageCount;
/*     */       }
/*     */     }
/*  55 */     if (endoffset > 0) {
/*  56 */       if (offset < 0)
/*  57 */         endNo = this.pageCount;
/*     */       else {
/*  59 */         firstNo -= endoffset;
/*     */       }
/*     */     }
/*  62 */     if (firstNo < 1) {
/*  63 */       firstNo = 1;
/*     */     }
/*  65 */     if (endNo > this.pageCount) {
/*  66 */       endNo = this.pageCount;
/*     */     }
/*  68 */     if (endNo == 0) {
/*  69 */       endNo = 1;
/*     */     }
/*     */ 
/*  72 */     int[] nums = new int[endNo - firstNo + 1];
/*  73 */     int i = 0;
/*  74 */     while (firstNo <= endNo) {
/*  75 */       nums[(i++)] = firstNo;
/*  76 */       firstNo++;
/*     */     }
/*  78 */     return nums;
/*     */   }
/*     */ 
/*     */   public PagingHelper(int pageSize, int pageIndex)
/*     */   {
/*  88 */     doSetPageSize(pageSize);
/*  89 */     doSetPageIndex(pageIndex);
/*  90 */     calc();
/*     */   }
/*     */ 
/*     */   public PagingHelper(int pageSize, int pageIndex, int totalCount)
/*     */   {
/* 101 */     doSetPageSize(pageSize);
/* 102 */     doSetPageIndex(pageIndex);
/* 103 */     this.totalCount = totalCount;
/* 104 */     calc();
/*     */   }
/*     */ 
/*     */   private void calc()
/*     */   {
/* 112 */     if ((this.totalCount > -1) && 
/* 113 */       (this.pageSize * (this.pageIndex - 1) > this.totalCount))
/* 114 */       this.pageIndex = ((this.totalCount - 1) / this.pageSize + 1);
/* 115 */     this.fromIndex = (this.pageSize * (this.pageIndex - 1));
/* 116 */     this.toIndex = (this.fromIndex + this.pageSize);
/* 117 */     if ((this.totalCount > -1) && (this.toIndex > this.totalCount))
/* 118 */       this.toIndex = this.totalCount;
/* 119 */     if (this.totalCount > -1) {
/* 120 */       if (this.totalCount > 0) {
/* 121 */         this.pageCount = ((this.totalCount - 1) / this.pageSize + 1);
/* 122 */         return;
/*     */       }
/* 124 */       this.pageCount = 0;
/* 125 */       return;
/*     */     }
/* 127 */     this.pageCount = this.pageIndex;
/*     */   }
/*     */ 
/*     */   private void doSetPageIndex(int pageIndex)
/*     */   {
/* 136 */     if (pageIndex < 1)
/* 137 */       pageIndex = 1;
/* 138 */     this.pageIndex = pageIndex;
/*     */   }
/*     */ 
/*     */   private void doSetPageSize(int pageSize)
/*     */   {
/* 147 */     if (pageSize < 0)
/* 148 */       pageSize = 0;
/* 149 */     this.pageSize = pageSize;
/*     */   }
/*     */ 
/*     */   public void setPageIndex(int pageIndex)
/*     */   {
/* 158 */     doSetPageIndex(pageIndex);
/* 159 */     calc();
/*     */   }
/*     */ 
/*     */   public void setPageSize(int pageSize)
/*     */   {
/* 168 */     doSetPageSize(pageSize);
/* 169 */     calc();
/*     */   }
/*     */ 
/*     */   public void setTotalRow(int totalCount)
/*     */   {
/* 178 */     this.totalCount = totalCount;
/* 179 */     calc();
/*     */   }
/*     */ 
/*     */   public int getPageIndex()
/*     */   {
/* 188 */     return this.pageIndex;
/*     */   }
/*     */ 
/*     */   public int getPageSize()
/*     */   {
/* 197 */     return this.pageSize;
/*     */   }
/*     */ 
/*     */   public int getTotalRow()
/*     */   {
/* 206 */     return this.totalCount;
/*     */   }
/*     */ 
/*     */   public int getFromIndex()
/*     */   {
/* 215 */     return this.fromIndex;
/*     */   }
/*     */ 
/*     */   public int getToIndex()
/*     */   {
/* 224 */     return this.toIndex;
/*     */   }
/*     */ 
/*     */   public int getPageCount()
/*     */   {
/* 233 */     return this.pageCount;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.db.PagingHelper
 * JD-Core Version:    0.6.0
 */