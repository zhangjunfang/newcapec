/*    */ package cn.newcapec.framework.base.dao.redis.config;
/*    */ 
/*    */ import cn.newcapec.framework.base.dao.redis.core.Jedis;
/*    */ import cn.newcapec.framework.base.dao.redis.util.JedisPubSubListener;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ 
/*    */ public class RedisPubSubManager
/*    */ {
/*    */ 
/*    */   @Autowired
/* 22 */   private Jedis jedis = new Jedis("192.168.1.168", 6379);
/*    */ 
/*    */   public void publish(Map<String, String> pubMap)
/*    */   {
/* 28 */     Set set = pubMap.keySet();
/* 29 */     for (String key : set)
/* 30 */       this.jedis.publish(key, (String)pubMap.get(key));
/*    */   }
/*    */ 
/*    */   public void psubscribe(String[] keyArray)
/*    */   {
/* 38 */     JedisPubSubListener listener = new JedisPubSubListener();
/* 39 */     this.jedis.psubscribe(listener, keyArray);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dao.redis.config.RedisPubSubManager
 * JD-Core Version:    0.6.0
 */