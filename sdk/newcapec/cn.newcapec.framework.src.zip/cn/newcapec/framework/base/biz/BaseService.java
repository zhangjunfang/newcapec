package cn.newcapec.framework.base.biz;

public abstract interface BaseService<T>
{
  public abstract void removeUnused(String paramString);

  public abstract T get(String paramString);

  public abstract void saveOrUpdate(T paramT);
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.biz.BaseService
 * JD-Core Version:    0.6.0
 */