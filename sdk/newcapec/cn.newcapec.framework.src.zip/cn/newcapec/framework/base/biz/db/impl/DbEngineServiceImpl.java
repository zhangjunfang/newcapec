/*     */ package cn.newcapec.framework.base.biz.db.impl;
/*     */ 
/*     */ import cn.newcapec.framework.base.biz.db.DbEngineService;
/*     */ import cn.newcapec.framework.base.dao.db.PagingResultSet;
/*     */ import cn.newcapec.framework.base.dbmeta.Container;
/*     */ import cn.newcapec.framework.base.dbmeta.DBTable;
/*     */ import cn.newcapec.framework.base.dbmeta.DbContainerHelper;
/*     */ import cn.newcapec.framework.base.exception.BaseException;
/*     */ import cn.newcapec.framework.base.log.LogEnabled;
/*     */ import cn.newcapec.framework.utils.tools.BeanUtils;
/*     */ import cn.newcapec.framework.utils.tools.StringUtil;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Resource;
/*     */ import javax.sql.DataSource;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ import org.springframework.orm.hibernate3.SessionFactoryUtils;
/*     */ import org.springframework.stereotype.Service;
/*     */ 
/*     */ @Service("dbEngineService")
/*     */ public class DbEngineServiceImpl
/*     */   implements DbEngineService, LogEnabled
/*     */ {
/*     */ 
/*     */   @Resource(name="sessionFactory")
/*     */   SessionFactory sessionFactory;
/*     */   HibernateTemplate hibernateTemplate;
/*     */ 
/*     */   public SessionFactory getSessionFactory()
/*     */   {
/*  47 */     return this.sessionFactory;
/*     */   }
/*     */ 
/*     */   public void setSessionFactory(SessionFactory sessionFactory) {
/*  51 */     this.sessionFactory = sessionFactory;
/*     */   }
/*     */ 
/*     */   public HibernateTemplate getHibernateTemplate() {
/*  55 */     if (this.hibernateTemplate == null) {
/*  56 */       this.hibernateTemplate = new HibernateTemplate(getSessionFactory());
/*     */     }
/*  58 */     return this.hibernateTemplate;
/*     */   }
/*     */ 
/*     */   public List query(String querySQL, Class modelClass, boolean convertFieldName)
/*     */     throws BaseException
/*     */   {
/*  79 */     List model = new ArrayList();
/*  80 */     PreparedStatement pstmt = null;
/*  81 */     ResultSet rs = null;
/*  82 */     Connection conn = null;
/*     */     try {
/*  84 */       conn = SessionFactoryUtils.getDataSource(getSessionFactory())
/*  85 */         .getConnection();
/*     */ 
/*  87 */       pstmt = conn.prepareStatement(querySQL);
/*  88 */       rs = pstmt.executeQuery();
/*     */ 
/*  90 */       while (rs.next()) {
/*  91 */         model.add(BeanUtils.resultSetToDO(rs, modelClass, 
/*  92 */           convertFieldName));
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  97 */       if (BaseException.class.isInstance(ex)) {
/*  98 */         throw ((BaseException)ex);
/*     */       }
/* 100 */       throw new BaseException("查询失败！", ex);
/*     */     }
/*     */     finally {
/*     */       try {
/* 104 */         if (rs != null)
/* 105 */           rs.close();
/*     */       } catch (Exception localException1) {
/*     */       }
/*     */       try {
/* 109 */         if (pstmt != null)
/* 110 */           pstmt.close();
/*     */       } catch (Exception localException2) {
/*     */       }
/*     */       try {
/* 114 */         if (conn != null)
/* 115 */           conn.close();
/*     */       }
/*     */       catch (Exception localException3) {
/*     */       }
/*     */     }
/* 120 */     return model;
/*     */   }
/*     */ 
/*     */   private int getParameterCount(String querySQL)
/*     */   {
/* 125 */     int count = 0;
/*     */ 
/* 127 */     if (querySQL != null) {
/* 128 */       StringBuffer buffer = new StringBuffer(querySQL);
/* 129 */       int pos = -1;
/* 130 */       while ((pos = buffer.indexOf("?")) != -1) {
/* 131 */         buffer.delete(0, pos + 1);
/* 132 */         count++;
/*     */       }
/*     */     }
/* 135 */     return count;
/*     */   }
/*     */ 
/*     */   public List query(String querySQL, Object[] params, Class modelClass, boolean convertFieldName)
/*     */   {
/* 153 */     List model = new ArrayList();
/* 154 */     PreparedStatement pstmt = null;
/* 155 */     ResultSet rs = null;
/* 156 */     Connection conn = null;
/*     */     try {
/* 158 */       conn = SessionFactoryUtils.getDataSource(getSessionFactory())
/* 159 */         .getConnection();
/*     */ 
/* 162 */       pstmt = conn.prepareStatement(querySQL);
/*     */ 
/* 164 */       int count = getParameterCount(querySQL);
/* 165 */       if ((count > 0) && (
/* 166 */         (params == null) || (params.length != count))) {
/* 167 */         throw new BaseException("SQL 参数传递错误！");
/*     */       }
/*     */ 
/* 171 */       for (int i = 0; i < count; i++)
/*     */       {
/* 173 */         pstmt.setObject(i + 1, params[i]);
/*     */       }
/*     */ 
/* 176 */       rs = pstmt.executeQuery();
/*     */ 
/* 178 */       while (rs.next()) {
/* 179 */         model.add(BeanUtils.resultSetToDO(rs, modelClass, 
/* 180 */           convertFieldName));
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 185 */       if (BaseException.class.isInstance(ex)) {
/* 186 */         throw ((BaseException)ex);
/*     */       }
/* 188 */       throw new BaseException("query failed！", ex);
/*     */     }
/*     */     finally {
/*     */       try {
/* 192 */         if (rs != null)
/* 193 */           rs.close();
/*     */       } catch (Exception localException1) {
/*     */       }
/*     */       try {
/* 197 */         if (pstmt != null)
/* 198 */           pstmt.close();
/*     */       } catch (Exception localException2) {
/*     */       }
/*     */       try {
/* 202 */         if (conn != null)
/* 203 */           conn.close();
/*     */       } catch (Exception localException3) {
/*     */       }
/*     */     }
/* 207 */     return model;
/*     */   }
/*     */ 
/*     */   public int execute(String querySQL, Object[] params)
/*     */   {
/* 215 */     return ((Integer)getHibernateTemplate().execute(
/* 216 */       new HibernateCallback(querySQL, params)
/*     */     {
/*     */       public Object doInHibernate(Session sess) throws HibernateException, SQLException
/*     */       {
/* 220 */         PreparedStatement pstmt = null;
/* 221 */         ResultSet rs = null;
/*     */         try {
/* 223 */           Connection conn = sess.connection();
/*     */ 
/* 225 */           pstmt = conn.prepareStatement(this.val$querySQL);
/*     */ 
/* 227 */           int count = DbEngineServiceImpl.this.getParameterCount(this.val$querySQL);
/* 228 */           if ((count > 0) && (
/* 229 */             (this.val$params == null) || (this.val$params.length != count))) {
/* 230 */             throw new BaseException("SQL 参数传递错误！");
/*     */           }
/*     */ 
/* 234 */           for (int i = 0; i < count; i++) {
/* 235 */             pstmt.setObject(i + 1, this.val$params[i]);
/*     */           }
/* 237 */           pstmt.execute();
/* 238 */           Integer localInteger = Integer.valueOf(1);
/*     */           return localInteger;
/*     */         }
/*     */         catch (Exception ex)
/*     */         {
/* 242 */           if (BaseException.class.isInstance(ex)) {
/* 243 */             throw ((BaseException)ex);
/*     */           }
/* 245 */           throw new BaseException("执行SQL失败！", ex);
/*     */         }
/*     */         finally
/*     */         {
/*     */           try {
/* 250 */             if (rs != null)
/* 251 */               rs.close();
/*     */           } catch (Exception localException3) {
/*     */           }
/*     */           try {
/* 255 */             if (pstmt != null)
/* 256 */               pstmt.close();
/*     */           } catch (Exception localException4) {
/*     */           }
/*     */         }
/* 260 */         throw localObject;
/*     */       }
/*     */     })).intValue();
/*     */   }
/*     */ 
/*     */   public String getTableName(String sql, int type)
/*     */   {
/* 278 */     String strOut = "";
/* 279 */     sql = sql.toLowerCase();
/* 280 */     int pos = -1;
/* 281 */     switch (type) {
/*     */     case 1:
/* 283 */       pos = sql.indexOf(" from ");
/* 284 */       if (pos < 0) break;
/* 285 */       strOut = sql.substring(pos + 6);
/* 286 */       strOut = strOut.trim();
/* 287 */       pos = strOut.indexOf(" ");
/* 288 */       if (pos <= 0) break;
/* 289 */       strOut = strOut.substring(0, pos).trim();
/*     */ 
/* 294 */       break;
/*     */     case 2:
/* 296 */       pos = sql.indexOf(" into ");
/* 297 */       if (pos < 0) break;
/* 298 */       strOut = sql.substring(pos + 6);
/* 299 */       strOut = strOut.trim();
/*     */ 
/* 301 */       pos = strOut.indexOf("(");
/* 302 */       if (pos <= 0) break;
/* 303 */       strOut = strOut.substring(0, pos).trim();
/*     */ 
/* 308 */       break;
/*     */     case 3:
/* 310 */       pos = sql.indexOf("update ");
/* 311 */       if (pos < 0) break;
/* 312 */       strOut = sql.substring(pos + 7);
/* 313 */       strOut = strOut.trim();
/* 314 */       pos = strOut.indexOf(" ");
/* 315 */       if (pos <= 0) break;
/* 316 */       strOut = strOut.substring(0, pos).trim();
/*     */     }
/*     */ 
/* 324 */     return strOut;
/*     */   }
/*     */ 
/*     */   public List query(String querySQL, Object[] params, Class modelClass, int pageSize, int pageIndex)
/*     */     throws BaseException
/*     */   {
/* 335 */     PagingResultSet pagingResultSet = getPagingResultSet(querySQL, params, 
/* 336 */       modelClass, pageSize, pageIndex);
/* 337 */     if (pagingResultSet == null) {
/* 338 */       return null;
/*     */     }
/* 340 */     return pagingResultSet.getData();
/*     */   }
/*     */ 
/*     */   public PagingResultSet getPagingResultSet(String querySQL, Object[] params, Class modelClass, int pageSize, int pageIndex)
/*     */     throws BaseException
/*     */   {
/* 351 */     PreparedStatement pstmt = null;
/* 352 */     ResultSet rs = null;
/* 353 */     Connection conn = null;
/*     */     try {
/* 355 */       conn = SessionFactoryUtils.getDataSource(getSessionFactory())
/* 356 */         .getConnection();
/*     */ 
/* 359 */       pstmt = conn.prepareStatement(querySQL);
/* 360 */       int count = getParameterCount(querySQL);
/* 361 */       if ((count > 0) && (
/* 362 */         (params == null) || (params.length != count))) {
/* 363 */         throw new BaseException("SQL 参数传递错误！");
/*     */       }
/*     */ 
/* 367 */       for (int i = 0; i < count; i++) {
/* 368 */         pstmt.setObject(i + 1, params[i]);
/*     */       }
/* 370 */       rs = pstmt.executeQuery();
/* 371 */       PagingResultSet pagingResultSet = new PagingResultSet(rs, 
/* 372 */         modelClass);
/*     */ 
/* 374 */       pagingResultSet.tranlateData(pageSize, pageIndex);
/* 375 */       PagingResultSet localPagingResultSet1 = pagingResultSet;
/*     */       return localPagingResultSet1;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 379 */       if (BaseException.class.isInstance(ex)) {
/* 380 */         throw ((BaseException)ex);
/*     */       }
/* 382 */       throw new BaseException("查询失败！", ex);
/*     */     }
/*     */     finally {
/*     */       try {
/* 386 */         if (rs != null)
/* 387 */           rs.close();
/*     */       }
/*     */       catch (Exception localException4) {
/*     */       }
/*     */       try {
/* 392 */         if (pstmt != null)
/* 393 */           pstmt.close();
/*     */       } catch (Exception localException5) {
/*     */       }
/*     */       try {
/* 397 */         if (conn != null)
/* 398 */           conn.close(); 
/*     */       } catch (Exception localException6) {
/*     */       }
/*     */     }
/* 401 */     throw localObject;
/*     */   }
/*     */ 
/*     */   public boolean checkRecordExist(String tableName, String field, Object value, String extraSql, Object[] params)
/*     */   {
/* 410 */     return ((Boolean)getHibernateTemplate().execute(
/* 411 */       new HibernateCallback(extraSql, field, tableName, params, value)
/*     */     {
/*     */       public Object doInHibernate(Session sess) throws HibernateException, SQLException
/*     */       {
/* 415 */         boolean flag = false;
/* 416 */         PreparedStatement pstmt = null;
/* 417 */         ResultSet rs = null;
/*     */         try
/*     */         {
/* 420 */           String sqlWhere = this.val$extraSql;
/* 421 */           if (StringUtil.isEmpty(sqlWhere))
/* 422 */             sqlWhere = this.val$field + " = ? ";
/*     */           else {
/* 424 */             sqlWhere = sqlWhere + " and " + this.val$field + " = ? ";
/*     */           }
/*     */ 
/* 427 */           String sql = "select distinct 1  from " + this.val$tableName + 
/* 428 */             " where  " + sqlWhere;
/*     */ 
/* 430 */           Connection conn = sess.connection();
/*     */ 
/* 432 */           pstmt = conn.prepareStatement(sql);
/*     */ 
/* 434 */           int count = DbEngineServiceImpl.this.getParameterCount(sql);
/* 435 */           List paramList = new ArrayList();
/* 436 */           if (this.val$params != null) {
/* 437 */             int i = 0; for (int len = this.val$params.length; i < len; i++) {
/* 438 */               paramList.add(this.val$params[i]);
/*     */             }
/*     */           }
/*     */ 
/* 442 */           paramList.add(this.val$value);
/*     */ 
/* 444 */           if ((count > 0) && (
/* 445 */             (paramList == null) || 
/* 446 */             (paramList.size() != count))) {
/* 447 */             throw new BaseException("SQL 参数传递错误！");
/*     */           }
/*     */ 
/* 451 */           for (int i = 0; i < count; i++) {
/* 452 */             pstmt.setObject(i + 1, paramList.get(i));
/*     */           }
/* 454 */           rs = pstmt.executeQuery();
/* 455 */           flag = rs.next();
/* 456 */           Boolean localBoolean = Boolean.valueOf(flag);
/*     */           return localBoolean;
/*     */         }
/*     */         catch (Exception ex)
/*     */         {
/* 460 */           if (BaseException.class.isInstance(ex)) {
/* 461 */             throw ((BaseException)ex);
/*     */           }
/* 463 */           throw new BaseException("校验记录是否存在出错！", ex);
/*     */         }
/*     */         finally
/*     */         {
/*     */           try {
/* 468 */             if (rs != null)
/* 469 */               rs.close();
/*     */           } catch (Exception localException3) {
/*     */           }
/*     */           try {
/* 473 */             if (pstmt != null)
/* 474 */               pstmt.close(); 
/*     */           } catch (Exception localException4) {
/*     */           }
/*     */         }
/* 477 */         throw localObject;
/*     */       }
/*     */     })).booleanValue();
/*     */   }
/*     */ 
/*     */   public boolean checkRecordExist(Class entityClass, String propertyName, Object value, String extraHql, Object[] params)
/*     */   {
/*     */     try
/*     */     {
/* 494 */       String hqlWhere = extraHql;
/* 495 */       if (StringUtil.isEmpty(extraHql))
/* 496 */         hqlWhere = propertyName + " = ? ";
/*     */       else {
/* 498 */         hqlWhere = hqlWhere + " and " + propertyName + " = ? ";
/*     */       }
/*     */ 
/* 501 */       String hql = "select count(*)  from " + entityClass.getName() + " where  " + 
/* 502 */         hqlWhere;
/*     */ 
/* 504 */       int count = getParameterCount(hql);
/* 505 */       List paramList = new ArrayList();
/* 506 */       if (params != null) {
/* 507 */         int i = 0; for (int len = params.length; i < len; i++) {
/* 508 */           paramList.add(params[i]);
/*     */         }
/*     */       }
/*     */ 
/* 512 */       paramList.add(value);
/*     */ 
/* 514 */       if ((count > 0) && (
/* 515 */         (paramList == null) || (paramList.size() != count))) {
/* 516 */         throw new BaseException("查询 HQL 参数传递错误！");
/*     */       }
/*     */ 
/* 521 */       List list = getHibernateTemplate().find(hql.toString(), 
/* 522 */         paramList.toArray());
/*     */ 
/* 524 */       count = 0;
/*     */ 
/* 526 */       if ((list != null) && (list.size() > 0))
/*     */       {
/* 528 */         count = Integer.parseInt(list.get(0).toString());
/*     */       }
/*     */ 
/* 531 */       return count > 0;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 535 */       if (BaseException.class.isInstance(ex))
/* 536 */         throw ((BaseException)ex);
/*     */     }
/* 538 */     throw new BaseException("校验记录是否存在出错！", ex);
/*     */   }
/*     */ 
/*     */   public Container getDBContainer(String schemaPattern, String tablePattern)
/*     */   {
/* 555 */     return (Container)getHibernateTemplate().execute(
/* 556 */       new HibernateCallback(schemaPattern, tablePattern)
/*     */     {
/*     */       public Object doInHibernate(Session sess)
/*     */         throws HibernateException, SQLException
/*     */       {
/* 561 */         return DbContainerHelper.getDBContainer(this.val$schemaPattern, 
/* 562 */           this.val$tablePattern, sess.connection());
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public DBTable getDBTable(String tableName)
/*     */   {
/* 576 */     return (DBTable)getHibernateTemplate().execute(
/* 577 */       new HibernateCallback(tableName)
/*     */     {
/*     */       public Object doInHibernate(Session sess)
/*     */         throws HibernateException, SQLException
/*     */       {
/* 582 */         return DbContainerHelper.getDBTable(this.val$tableName, sess
/* 583 */           .connection());
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public List<DBTable> getDBTables(String schemaPattern, String tablePattern)
/*     */   {
/* 599 */     return (List)getHibernateTemplate().execute(
/* 600 */       new HibernateCallback(schemaPattern, tablePattern)
/*     */     {
/*     */       public Object doInHibernate(Session sess)
/*     */         throws HibernateException, SQLException
/*     */       {
/* 605 */         return DbContainerHelper.getDBTables(this.val$schemaPattern, 
/* 606 */           this.val$tablePattern, sess.connection());
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public Set<String> getTableList(String schemaPattern, String tablePattern)
/*     */   {
/* 623 */     return (Set)getHibernateTemplate().execute(
/* 624 */       new HibernateCallback(schemaPattern, tablePattern)
/*     */     {
/*     */       public Object doInHibernate(Session sess)
/*     */         throws HibernateException, SQLException
/*     */       {
/* 629 */         return DbContainerHelper.getTableList(this.val$schemaPattern, 
/* 630 */           this.val$tablePattern, sess.connection());
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.biz.db.impl.DbEngineServiceImpl
 * JD-Core Version:    0.6.0
 */