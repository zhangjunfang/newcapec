package cn.newcapec.framework.base.biz.db;

import cn.newcapec.framework.base.dao.db.PagingResultSet;
import cn.newcapec.framework.base.dbmeta.Container;
import cn.newcapec.framework.base.dbmeta.DBTable;
import cn.newcapec.framework.base.exception.BaseException;
import java.util.List;
import java.util.Set;

public abstract interface DbEngineService
{
  public abstract List query(String paramString, Class paramClass, boolean paramBoolean)
    throws BaseException;

  public abstract PagingResultSet getPagingResultSet(String paramString, Object[] paramArrayOfObject, Class paramClass, int paramInt1, int paramInt2)
    throws BaseException;

  public abstract List query(String paramString, Object[] paramArrayOfObject, Class paramClass, int paramInt1, int paramInt2)
    throws BaseException;

  public abstract List query(String paramString, Object[] paramArrayOfObject, Class paramClass, boolean paramBoolean);

  public abstract int execute(String paramString, Object[] paramArrayOfObject);

  public abstract boolean checkRecordExist(String paramString1, String paramString2, Object paramObject, String paramString3, Object[] paramArrayOfObject);

  public abstract boolean checkRecordExist(Class paramClass, String paramString1, Object paramObject, String paramString2, Object[] paramArrayOfObject);

  public abstract Container getDBContainer(String paramString1, String paramString2);

  public abstract DBTable getDBTable(String paramString);

  public abstract Set<String> getTableList(String paramString1, String paramString2);

  public abstract List<DBTable> getDBTables(String paramString1, String paramString2);
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.biz.db.DbEngineService
 * JD-Core Version:    0.6.0
 */