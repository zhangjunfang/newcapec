/*     */ package cn.newcapec.framework.base.exception;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ 
/*     */ public class BaseException extends SysException
/*     */ {
/*  19 */   private Collection exceptions = new ArrayList();
/*  20 */   private String messageKey = null;
/*  21 */   private Object[] messageArgs = null;
/*     */ 
/*     */   public BaseException()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BaseException(String msg)
/*     */   {
/*  37 */     super(msg);
/*     */   }
/*     */ 
/*     */   public BaseException(Throwable cause)
/*     */   {
/*  48 */     this.rootCause = cause;
/*     */   }
/*     */ 
/*     */   public BaseException(String msg, Throwable cause)
/*     */   {
/*  60 */     super(msg);
/*  61 */     this.rootCause = cause;
/*     */   }
/*     */ 
/*     */   public Collection getCollection()
/*     */   {
/*  70 */     return this.exceptions;
/*     */   }
/*     */ 
/*     */   public void addException(BaseException ex)
/*     */   {
/*  80 */     this.exceptions.add(ex);
/*     */   }
/*     */ 
/*     */   public void setMessageKey(String key)
/*     */   {
/*  90 */     this.messageKey = key;
/*     */   }
/*     */ 
/*     */   public String getMessageKey()
/*     */   {
/*  99 */     return this.messageKey;
/*     */   }
/*     */ 
/*     */   public void setMessageArgs(Object[] args)
/*     */   {
/* 109 */     this.messageArgs = args;
/*     */   }
/*     */ 
/*     */   public Object[] getMessageArgs()
/*     */   {
/* 118 */     return this.messageArgs;
/*     */   }
/*     */ 
/*     */   public void setRootCause(Throwable anException)
/*     */   {
/* 128 */     this.rootCause = anException;
/*     */   }
/*     */ 
/*     */   public Throwable getRootCause()
/*     */   {
/* 137 */     return this.rootCause;
/*     */   }
/*     */ 
/*     */   public void printStackTrace()
/*     */   {
/* 144 */     printStackTrace(System.err);
/*     */   }
/*     */ 
/*     */   public void printStackTrace(PrintStream outStream)
/*     */   {
/* 154 */     printStackTrace(new PrintWriter(outStream));
/*     */   }
/*     */ 
/*     */   public void printStackTrace(PrintWriter writer)
/*     */   {
/* 165 */     super.printStackTrace(writer);
/*     */ 
/* 167 */     if (getRootCause() != null)
/*     */     {
/* 169 */       getRootCause().printStackTrace(writer);
/*     */     }
/*     */ 
/* 173 */     writer.flush();
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.exception.BaseException
 * JD-Core Version:    0.6.0
 */