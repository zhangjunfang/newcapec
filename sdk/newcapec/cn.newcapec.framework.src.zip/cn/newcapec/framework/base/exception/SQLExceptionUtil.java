/*    */ package cn.newcapec.framework.base.exception;
/*    */ 
/*    */ import org.apache.commons.lang.exception.ExceptionUtils;
/*    */ 
/*    */ public class SQLExceptionUtil
/*    */ {
/*    */   public static void translateException(Throwable t)
/*    */   {
/* 23 */     Throwable t1 = null;
/* 24 */     Throwable t2 = null;
/*    */ 
/* 27 */     while (t != null) {
/* 28 */       t2 = t1;
/* 29 */       t1 = t;
/* 30 */       t = ExceptionUtils.getCause(t);
/*    */     }
/*    */ 
/* 33 */     throw new SysException(t2.getMessage(), t2);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.exception.SQLExceptionUtil
 * JD-Core Version:    0.6.0
 */