/*    */ package cn.newcapec.framework.base.exception;
/*    */ 
/*    */ public class DuplicateKeyException extends BaseException
/*    */ {
/*    */   public DuplicateKeyException(Object key)
/*    */   {
/* 18 */     super("Can not add a object with the duplicate key \"" + key + 
/* 18 */       "\"!");
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.exception.DuplicateKeyException
 * JD-Core Version:    0.6.0
 */