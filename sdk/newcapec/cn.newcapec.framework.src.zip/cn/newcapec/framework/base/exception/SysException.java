/*     */ package cn.newcapec.framework.base.exception;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ public class SysException extends RuntimeException
/*     */ {
/*     */   private static final long serialVersionUID = -5542169322764723764L;
/*  22 */   protected Throwable rootCause = null;
/*  23 */   private String messageKey = null;
/*  24 */   private Object[] messageArgs = null;
/*     */ 
/*     */   public SysException()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SysException(String msg)
/*     */   {
/*  40 */     super(msg);
/*     */   }
/*     */ 
/*     */   public SysException(Throwable cause)
/*     */   {
/*  50 */     this.rootCause = cause;
/*     */   }
/*     */ 
/*     */   public SysException(String msg, Throwable cause)
/*     */   {
/*  62 */     super(msg);
/*  63 */     this.rootCause = cause;
/*     */   }
/*     */ 
/*     */   public void setMessageKey(String key)
/*     */   {
/*  73 */     this.messageKey = key;
/*     */   }
/*     */ 
/*     */   public String getMessageKey()
/*     */   {
/*  82 */     return this.messageKey;
/*     */   }
/*     */ 
/*     */   public void setMessageArgs(Object[] args)
/*     */   {
/*  92 */     this.messageArgs = args;
/*     */   }
/*     */ 
/*     */   public Object[] getMessageArgs()
/*     */   {
/* 101 */     return this.messageArgs;
/*     */   }
/*     */ 
/*     */   public void setRootCause(Throwable anException)
/*     */   {
/* 111 */     this.rootCause = anException;
/*     */   }
/*     */ 
/*     */   public Throwable getRootCause()
/*     */   {
/* 120 */     return this.rootCause;
/*     */   }
/*     */ 
/*     */   public void printStackTrace()
/*     */   {
/* 127 */     printStackTrace(System.err);
/*     */   }
/*     */ 
/*     */   public void printStackTrace(PrintStream outStream)
/*     */   {
/* 137 */     printStackTrace(new PrintWriter(outStream));
/*     */   }
/*     */ 
/*     */   public void printStackTrace(PrintWriter writer)
/*     */   {
/* 147 */     super.printStackTrace(writer);
/*     */ 
/* 149 */     if (getRootCause() != null) {
/* 150 */       getRootCause().printStackTrace(writer);
/*     */     }
/* 152 */     writer.flush();
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.exception.SysException
 * JD-Core Version:    0.6.0
 */