/*     */ package cn.newcapec.framework.base.exception;
/*     */ 
/*     */ import cn.newcapec.framework.base.i18n.LocaleUtil;
/*     */ import cn.newcapec.framework.base.log.LogEnabled;
/*     */ import cn.newcapec.framework.utils.tools.BeanUtils;
/*     */ import cn.newcapec.framework.utils.tools.StringUtil;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Map;
/*     */ import java.util.ResourceBundle;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class Message
/*     */   implements LogEnabled
/*     */ {
/*     */   public static String getInfo(String infoCode, String lang)
/*     */   {
/*  32 */     return getInfo(infoCode, lang, null, null, null);
/*     */   }
/*     */ 
/*     */   public static String getInfo(String infoCode, String lang, String[] parms)
/*     */   {
/*  47 */     return getInfo(infoCode, lang, parms, null, null);
/*     */   }
/*     */ 
/*     */   public static String getInfo(String infoCode, String lang, String resName)
/*     */   {
/*  60 */     return getInfo(infoCode, lang, null, resName, null);
/*     */   }
/*     */ 
/*     */   private static String getInfoFromDB(String infoCode, String lang)
/*     */   {
/*  75 */     return null;
/*     */   }
/*     */ 
/*     */   private static String getInfoFromRes(String infoCode, String lang, String resName)
/*     */   {
/*  80 */     ResourceBundle res = ResourceBundle.getBundle(resName, 
/*  81 */       LocaleUtil.getLocale(lang));
/*  82 */     if (res != null)
/*  83 */       return res.getString(infoCode);
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */   public static String getInfo(String infoCode, String lang, Object[] parms, String resName, Object entityObject)
/*     */   {
/* 100 */     String s = null;
/* 101 */     infoCode = StringUtil.trim(infoCode);
/* 102 */     resName = StringUtil.trim(resName);
/*     */ 
/* 104 */     if (infoCode.length() < 1) {
/* 105 */       return s;
/*     */     }
/*     */ 
/* 108 */     if (resName.length() > 0)
/* 109 */       s = getInfoFromRes(infoCode, lang, resName);
/*     */     else {
/* 111 */       s = getInfoFromDB(infoCode, lang);
/*     */     }
/*     */ 
/* 114 */     if ((s == null) || (parms == null) || (parms.length < 1))
/* 115 */       return s;
/*     */     try
/*     */     {
/* 118 */       if (entityObject != null) {
/* 119 */         Map params = BeanUtils.describe(entityObject);
/* 120 */         if (params != null) params.isEmpty();
/*     */ 
/*     */       }
/*     */ 
/* 124 */       String msg = MessageFormat.format(s, parms);
/*     */ 
/* 126 */       return msg;
/*     */     } catch (Exception e) {
/*     */     }
/* 129 */     return s;
/*     */   }
/*     */ 
/*     */   private static void load(String lang)
/*     */   {
/*     */     try
/*     */     {
/* 142 */       sql = "select msg_id,msg_value from ctl_langmsg where lang_code='" + 
/* 143 */         lang + "' order by msg_id";
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       String sql;
/* 146 */       log.error("获取国际资源出错!!", e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.exception.Message
 * JD-Core Version:    0.6.0
 */