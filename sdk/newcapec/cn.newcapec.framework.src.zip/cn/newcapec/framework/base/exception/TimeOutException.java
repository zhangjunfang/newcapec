/*    */ package cn.newcapec.framework.base.exception;
/*    */ 
/*    */ public class TimeOutException extends BaseException
/*    */ {
/*    */   private static final long serialVersionUID = 3957340248111739698L;
/*    */ 
/*    */   public TimeOutException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TimeOutException(String message)
/*    */   {
/* 28 */     super(message);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.exception.TimeOutException
 * JD-Core Version:    0.6.0
 */