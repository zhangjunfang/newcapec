/*    */ package cn.newcapec.framework.base.exception;
/*    */ 
/*    */ public class ValidateException extends BaseException
/*    */ {
/*    */   private static final long serialVersionUID = -2441906100131506515L;
/*    */ 
/*    */   public ValidateException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ValidateException(String message)
/*    */   {
/* 18 */     super(message);
/*    */   }
/*    */ 
/*    */   public ValidateException(String message, Throwable cause) {
/* 22 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public ValidateException(Throwable cause) {
/* 26 */     super(cause);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.exception.ValidateException
 * JD-Core Version:    0.6.0
 */