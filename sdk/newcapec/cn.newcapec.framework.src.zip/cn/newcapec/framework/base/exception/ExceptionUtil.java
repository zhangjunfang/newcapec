/*     */ package cn.newcapec.framework.base.exception;
/*     */ 
/*     */ import cn.newcapec.framework.base.i18n.LangUtil;
/*     */ import cn.newcapec.framework.base.log.LogEnabled;
/*     */ import cn.newcapec.framework.utils.context.NewcapecContext;
/*     */ import cn.newcapec.framework.utils.tools.StringUtil;
/*     */ import java.sql.SQLException;
/*     */ import org.apache.commons.lang.exception.ExceptionUtils;
/*     */ 
/*     */ public class ExceptionUtil
/*     */   implements LogEnabled
/*     */ {
/*     */   private static final String ERROR_CODE = "err_code";
/*     */ 
/*     */   public static void extractException(Throwable t, String lang, Object[] messageArgs)
/*     */     throws RuntimeException
/*     */   {
/*  37 */     extractException(t, lang, messageArgs, null);
/*     */   }
/*     */ 
/*     */   public static void extractException(Throwable t, String lang, Object[] messageArgs, Object entityObject)
/*     */     throws RuntimeException
/*     */   {
/*  66 */     Throwable t1 = null;
/*     */ 
/*  68 */     if ((t instanceof SysException)) {
/*  69 */       t1 = t;
/*     */     }
/*     */     else {
/*  72 */       t1 = getTargetAppException(t);
/*     */     }
/*  74 */     if (t1 == null) {
/*  75 */       t1 = ExceptionUtils.getRootCause(t);
/*     */     }
/*  77 */     if (t1 == null) {
/*  78 */       t1 = t;
/*     */     }
/*     */ 
/*  82 */     String messageCode = StringUtil.trim(t1.getMessage());
/*  83 */     String errorMessage = null;
/*  84 */     if ((t1 instanceof SysException))
/*     */     {
/*  86 */       if (messageCode.indexOf("err_code") != -1) {
/*  87 */         errorMessage = Message.getInfo(messageCode, lang, messageArgs, null, entityObject);
/*  88 */         if (StringUtil.isValid(errorMessage)) {
/*  89 */           throw new SysException(errorMessage, t1);
/*     */         }
/*     */       }
/*  92 */       throw ((SysException)t1);
/*     */     }
/*  94 */     if ((t1 instanceof SysException)) {
/*  95 */       if (messageCode.indexOf("err_code") != -1) {
/*  96 */         errorMessage = Message.getInfo(messageCode, lang, messageArgs, null, entityObject);
/*  97 */         if (StringUtil.isValid(errorMessage)) {
/*  98 */           throw new SysException(errorMessage, t1);
/*     */         }
/*     */       }
/* 101 */       throw ((SysException)t);
/*     */     }
/* 103 */     if ((t1 instanceof SQLException))
/*     */     {
/* 106 */       SQLExceptionUtil.translateException(t);
/*     */     }
/*     */     else
/* 109 */       throw new SysException(t1.getMessage(), t1);
/*     */   }
/*     */ 
/*     */   private static Throwable getTargetAppException(Throwable t)
/*     */   {
/* 122 */     Throwable t1 = null;
/*     */     do {
/* 124 */       t1 = ExceptionUtils.getCause(t);
/* 125 */       if ((t1 instanceof SysException)) {
/* 126 */         return t1;
/*     */       }
/* 128 */       t = t1;
/* 129 */     }while (t1 != null);
/*     */ 
/* 131 */     return null;
/*     */   }
/*     */ 
/*     */   public static void extractException(Throwable t, String lang)
/*     */     throws RuntimeException
/*     */   {
/* 140 */     extractException(t, lang, null, null);
/*     */   }
/*     */ 
/*     */   public static void extractException(Throwable t)
/*     */     throws RuntimeException
/*     */   {
/* 150 */     String lang = LangUtil.getLang(NewcapecContext.getContext());
/* 151 */     extractException(t, lang);
/*     */   }
/*     */ 
/*     */   public static void extractException(Throwable t, Object[] messageArgs)
/*     */     throws RuntimeException
/*     */   {
/* 160 */     String lang = LangUtil.getLang(NewcapecContext.getContext());
/* 161 */     extractException(t, lang, messageArgs, null);
/*     */   }
/*     */ 
/*     */   public static void extractException(Throwable t, Object[] args, Object entityObject) {
/* 165 */     String lang = LangUtil.getLang(NewcapecContext.getContext());
/* 166 */     extractException(t, lang, args, entityObject);
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.exception.ExceptionUtil
 * JD-Core Version:    0.6.0
 */