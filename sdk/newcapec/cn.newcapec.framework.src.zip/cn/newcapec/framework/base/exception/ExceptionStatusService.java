/*    */ package cn.newcapec.framework.base.exception;
/*    */ 
/*    */ import cn.newcapec.framework.base.log.LogEnabled;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.restlet.data.CharacterSet;
/*    */ import org.restlet.data.Language;
/*    */ import org.restlet.data.MediaType;
/*    */ import org.restlet.data.Request;
/*    */ import org.restlet.data.Response;
/*    */ import org.restlet.data.Status;
/*    */ import org.restlet.resource.Representation;
/*    */ import org.restlet.resource.StringRepresentation;
/*    */ import org.restlet.service.StatusService;
/*    */ 
/*    */ public class ExceptionStatusService extends StatusService
/*    */   implements LogEnabled
/*    */ {
/*    */   public Representation getRepresentation(Status status, Request request, Response response)
/*    */   {
/* 26 */     if (status != null) {
/* 27 */       Throwable throwable = status.getThrowable();
/*    */ 
/* 29 */       if (throwable != null) {
/*    */         try {
/* 31 */           if ((throwable instanceof SysException)) {
/* 32 */             String message = throwable.getMessage();
/* 33 */             log.error(message);
/* 34 */             return new StringRepresentation(message, MediaType.APPLICATION_JSON, Language.ALL, 
/* 35 */               CharacterSet.UTF_8);
/*    */           }
/*    */ 
/* 38 */           String defautMessage = status.getDescription();
/* 39 */           log.error(defautMessage);
/* 40 */           return new StringRepresentation(defautMessage, MediaType.APPLICATION_JSON, 
/* 41 */             Language.ALL, CharacterSet.UTF_8);
/*    */         } catch (Exception localException) {
/*    */         }
/*    */       }
/* 45 */       else if (status.getCode() / 100 == 4) {
/* 46 */         String defautMessage = status.getDescription();
/* 47 */         log.error(defautMessage);
/* 48 */         return new StringRepresentation(defautMessage, MediaType.APPLICATION_JSON, Language.ALL, 
/* 49 */           CharacterSet.UTF_8);
/*    */       }
/*    */     }
/*    */ 
/* 53 */     return super.getRepresentation(status, request, response);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.exception.ExceptionStatusService
 * JD-Core Version:    0.6.0
 */