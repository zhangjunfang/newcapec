package cn.newcapec.framework.base.exception;

public abstract interface HttpStatusException
{
  public static final String BASE_HTTP = "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html";
  public static final String BASE_WEBDAV = "http://www.webdav.org/specs/rfc2518.html";
  public static final String BASE_RESTLET = "http://www.restlet.org/documentation/1.1/api/";

  public abstract int getCode();

  public abstract String getName();

  public abstract String getDescription();

  public abstract String getUri();
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.exception.HttpStatusException
 * JD-Core Version:    0.6.0
 */