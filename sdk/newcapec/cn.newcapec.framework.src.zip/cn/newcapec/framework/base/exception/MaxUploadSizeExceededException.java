/*    */ package cn.newcapec.framework.base.exception;
/*    */ 
/*    */ public class MaxUploadSizeExceededException extends BaseException
/*    */ {
/*    */   private long maxUploadSize;
/*    */   private String message;
/*    */   private String code;
/*    */ 
/*    */   public MaxUploadSizeExceededException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MaxUploadSizeExceededException(long maxUploadSize, String message)
/*    */   {
/* 19 */     this.maxUploadSize = maxUploadSize;
/* 20 */     this.message = message;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.exception.MaxUploadSizeExceededException
 * JD-Core Version:    0.6.0
 */