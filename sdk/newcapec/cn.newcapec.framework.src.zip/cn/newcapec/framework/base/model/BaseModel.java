/*     */ package cn.newcapec.framework.base.model;
/*     */ 
/*     */ import cn.newcapec.framework.base.datacontainer.DataContainer;
/*     */ import cn.newcapec.framework.base.datacontainer.DataObject;
/*     */ import cn.newcapec.framework.base.datacontainer.Property;
/*     */ import java.util.Date;
/*     */ import javax.persistence.Column;
/*     */ import javax.persistence.GeneratedValue;
/*     */ import javax.persistence.Id;
/*     */ import javax.persistence.MappedSuperclass;
/*     */ import javax.persistence.Temporal;
/*     */ import javax.persistence.TemporalType;
/*     */ import org.hibernate.annotations.GenericGenerator;
/*     */ 
/*     */ @MappedSuperclass
/*     */ public class BaseModel extends DataContainer
/*     */   implements DataObject
/*     */ {
/*     */   private static final long serialVersionUID = -602515871859035627L;
/*     */ 
/*     */   public BaseModel()
/*     */   {
/*  28 */     init(new Property[][] { AppBaseModelProperty.values() });
/*     */   }
/*     */ 
/*     */   @GenericGenerator(name="idGenerator", strategy="uuid")
/*     */   @Id
/*     */   @GeneratedValue(generator="idGenerator")
/*     */   @Column(name="id", unique=true, nullable=false, length=32)
/*     */   public String getId()
/*     */   {
/*  61 */     return (String)super.getValue(AppBaseModelProperty.id);
/*     */   }
/*     */ 
/*     */   public void setId(String id) {
/*  65 */     super.setValue(AppBaseModelProperty.id, id);
/*     */   }
/*     */ 
/*     */   @Column(name="create_date")
/*     */   @Temporal(TemporalType.TIMESTAMP)
/*     */   public Date getCreateDate()
/*     */   {
/*  74 */     return (Date)super.getValue(AppBaseModelProperty.createDate);
/*     */   }
/*     */ 
/*     */   public void setCreateDate(Date createDate)
/*     */   {
/*  82 */     super.setValue(AppBaseModelProperty.createDate, createDate);
/*     */   }
/*     */ 
/*     */   @Column(name="update_date")
/*     */   @Temporal(TemporalType.TIMESTAMP)
/*     */   public Date getUpdateDate()
/*     */   {
/*  91 */     return (Date)super.getValue(AppBaseModelProperty.updateDate);
/*     */   }
/*     */ 
/*     */   public void setUpdateDate(Date updateDate)
/*     */   {
/*  99 */     super.setValue(AppBaseModelProperty.updateDate, updateDate);
/*     */   }
/*     */ 
/*     */   @Column(name="create_by", length=32)
/*     */   public String getCreateBy()
/*     */   {
/* 107 */     return (String)super.getValue(AppBaseModelProperty.createBy);
/*     */   }
/*     */ 
/*     */   public void setCreateBy(String createBy)
/*     */   {
/* 115 */     super.setValue(AppBaseModelProperty.createBy, createBy);
/*     */   }
/*     */ 
/*     */   @Column(name="update_by", length=32)
/*     */   public String getUpdateBy()
/*     */   {
/* 123 */     return (String)super.getValue(AppBaseModelProperty.updateBy);
/*     */   }
/*     */ 
/*     */   public void setUpdateBy(String updateBy)
/*     */   {
/* 131 */     super.setValue(AppBaseModelProperty.updateBy, updateBy);
/*     */   }
/*     */ 
/*     */   @Column(name="version")
/*     */   public Integer getVersion()
/*     */   {
/* 139 */     return (Integer)super.getValue(AppBaseModelProperty.version);
/*     */   }
/*     */ 
/*     */   public void setVersion(Integer version)
/*     */   {
/* 146 */     super.setValue(AppBaseModelProperty.version, version);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 155 */     if ((obj != null) && ((obj instanceof BaseModel))) {
/* 156 */       String tempId = ((BaseModel)obj).getId();
/* 157 */       if (tempId == null) {
/* 158 */         return false;
/*     */       }
/* 160 */       return tempId.equals(getId());
/*     */     }
/* 162 */     return false;
/*     */   }
/*     */ 
/*     */   public static enum AppBaseModelProperty
/*     */     implements Property
/*     */   {
/*  32 */     id(String.class), 
/*  33 */     createDate(Date.class), 
/*  34 */     updateDate(Date.class), 
/*  35 */     createBy(String.class), 
/*  36 */     updateBy(String.class), 
/*  37 */     version(Integer.class);
/*     */ 
/*     */     Class<?> type;
/*     */ 
/*  42 */     private AppBaseModelProperty(Class<?> type) { this.type = type;
/*     */     }
/*     */ 
/*     */     public String getName()
/*     */     {
/*  47 */       return name();
/*     */     }
/*     */ 
/*     */     public Class<?> getType()
/*     */     {
/*  52 */       return this.type;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.model.BaseModel
 * JD-Core Version:    0.6.0
 */