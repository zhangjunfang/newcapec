/*    */ package cn.newcapec.framework.base.velocity;
/*    */ 
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.File;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.StringWriter;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.velocity.Template;
/*    */ import org.apache.velocity.app.Velocity;
/*    */ import org.apache.velocity.context.Context;
/*    */ 
/*    */ public class TemplateEngine
/*    */ {
/* 21 */   private static final Log log = LogFactory.getLog(TemplateEngine.class);
/*    */ 
/* 23 */   static { String templatePath = PathUtil.getRootPath();
/* 24 */     Velocity.setProperty("file.resource.loader.path", templatePath + ConfigUtil.getItem("file.resource.loader.path"));
/* 25 */     Velocity.setProperty("directive.set.null.allowed", "true");
/* 26 */     log.info("templatePath:" + templatePath);
/* 27 */     Velocity.init();
/*    */   }
/*    */ 
/*    */   public static String parse(String templatePath, Context context)
/*    */   {
/* 41 */     Template t = Velocity.getTemplate(templatePath, "utf-8");
/* 42 */     context.put("paging", "common/includePagination.vm");
/* 43 */     StringWriter sw = new StringWriter();
/* 44 */     t.merge(context, sw);
/* 45 */     return sw.toString();
/*    */   }
/*    */ 
/*    */   public static String parse(String templatePath, Context context, File saveDir)
/*    */     throws Exception
/*    */   {
/* 57 */     Template t = Velocity.getTemplate(templatePath, "utf-8");
/* 58 */     FileOutputStream outStream = new FileOutputStream(saveDir);
/* 59 */     OutputStreamWriter writer = new OutputStreamWriter(outStream, "UTF-8");
/* 60 */     BufferedWriter sw = new BufferedWriter(writer);
/* 61 */     t.merge(context, sw);
/* 62 */     sw.flush();
/* 63 */     sw.close();
/* 64 */     outStream.close();
/* 65 */     return sw.toString();
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.velocity.TemplateEngine
 * JD-Core Version:    0.6.0
 */