/*    */ package cn.newcapec.framework.base.velocity;
/*    */ 
/*    */ import java.net.URL;
/*    */ 
/*    */ public class PathUtil
/*    */ {
/*    */   private static String rootPath;
/*    */ 
/*    */   static
/*    */   {
/* 13 */     String classPath = PathUtil.class.getResource("/").getPath();
/*    */ 
/* 15 */     if (classPath.indexOf("/./") != -1) {
/* 16 */       classPath = classPath.replaceAll("/./", "/");
/*    */     }
/* 18 */     rootPath = classPath.substring(0, classPath.indexOf("WEB-INF"));
/*    */   }
/*    */ 
/*    */   public static String getRootPath()
/*    */   {
/* 26 */     return rootPath;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.velocity.PathUtil
 * JD-Core Version:    0.6.0
 */