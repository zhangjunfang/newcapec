/*    */ package cn.newcapec.framework.base.velocity;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ public class ConfigUtil
/*    */ {
/* 13 */   private static final String SYSTEM_CONFIG_PROPERTIY = "config" + File.separator + "velocity" + File.separator + "system_config";
/*    */ 
/*    */   public static String getItem(String key) {
/* 16 */     String result = "";
/*    */     try {
/* 18 */       ResourceBundle resourceBundle = ResourceBundle.getBundle(SYSTEM_CONFIG_PROPERTIY);
/* 19 */       result = resourceBundle.getString(key);
/*    */     } catch (Exception ex) {
/* 21 */       ex.printStackTrace();
/*    */     }
/* 23 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.velocity.ConfigUtil
 * JD-Core Version:    0.6.0
 */