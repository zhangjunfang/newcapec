/*    */ package cn.newcapec.framework.base.velocity;
/*    */ 
/*    */ import cn.newcapec.framework.utils.DateUtil;
/*    */ import java.io.PrintWriter;
/*    */ import java.io.StringWriter;
/*    */ import java.util.Map;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.velocity.Template;
/*    */ import org.apache.velocity.context.Context;
/*    */ import org.apache.velocity.exception.MethodInvocationException;
/*    */ import org.apache.velocity.tools.generic.DateTool;
/*    */ import org.springframework.web.util.NestedServletException;
/*    */ 
/*    */ public class VelocityView extends org.springframework.web.servlet.view.velocity.VelocityView
/*    */ {
/*    */   protected Context createVelocityContext(Map model, HttpServletRequest request, HttpServletResponse response)
/*    */     throws Exception
/*    */   {
/* 32 */     DateTool dateTool = new DateTool();
/* 33 */     model.put("dateTool", dateTool);
/*    */ 
/* 35 */     model.put("DATE_FORMAT_SHORT", DateUtil.DATE_FORMAT);
/* 36 */     model.put("DATE_FORMAT_LONG", DateUtil.DATETIME_FORMAT);
/* 37 */     return super.createVelocityContext(model, request, response);
/*    */   }
/*    */ 
/*    */   protected void mergeTemplate(Template template, Context context, HttpServletResponse response) throws Exception
/*    */   {
/* 42 */     StringWriter sw = new StringWriter();
/*    */     try
/*    */     {
/* 45 */       template.merge(context, sw);
/*    */ 
/* 47 */       response.getWriter().write(sw.toString());
/*    */     }
/*    */     catch (MethodInvocationException ex) {
/* 50 */       throw new NestedServletException(
/* 51 */         "Method invocation failed during rendering of Velocity view with name '" + 
/* 52 */         getBeanName() + "': " + ex.getMessage() + "; reference [" + ex.getReferenceName() + 
/* 53 */         "], method '" + ex.getMethodName() + "'", 
/* 54 */         ex.getWrappedThrowable());
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.velocity.VelocityView
 * JD-Core Version:    0.6.0
 */