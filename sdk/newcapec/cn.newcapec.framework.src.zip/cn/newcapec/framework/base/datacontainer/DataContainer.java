/*    */ package cn.newcapec.framework.base.datacontainer;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.persistence.MappedSuperclass;
/*    */ 
/*    */ @MappedSuperclass
/*    */ public abstract class DataContainer
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 14 */   private Map<String, Object> propertyValueMap = new HashMap();
/* 15 */   private Map<String, Property> propertyMap = new HashMap();
/*    */ 
/*    */   protected void init(Property[][] properties)
/*    */   {
/* 19 */     for (Property[] ps : properties)
/* 20 */       for (Property p : ps)
/* 21 */         this.propertyMap.put(p.getName(), p);
/*    */   }
/*    */ 
/*    */   public void setValue(Property property, Object obj)
/*    */   {
/* 27 */     if (!this.propertyMap.containsValue(property)) {
/* 28 */       throw new RuntimeException("DataContainer不包含此属性!");
/*    */     }
/* 30 */     if ((property.getType().isInstance(obj)) || (obj == null)) {
/* 31 */       this.propertyValueMap.put(property.getName(), obj);
/*    */     }
/*    */     else
/* 34 */       throw new RuntimeException("非法类型!");
/*    */   }
/*    */ 
/*    */   public Object getValue(Property property)
/*    */   {
/* 40 */     return this.propertyValueMap.get(property.getName());
/*    */   }
/*    */ 
/*    */   public Property getProperty(String propertyName)
/*    */   {
/* 45 */     Property result = (Property)this.propertyMap.get(propertyName);
/* 46 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.datacontainer.DataContainer
 * JD-Core Version:    0.6.0
 */