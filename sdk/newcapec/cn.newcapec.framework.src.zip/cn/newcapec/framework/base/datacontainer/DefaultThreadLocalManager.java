/*    */ package cn.newcapec.framework.base.datacontainer;
/*    */ 
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ public class DefaultThreadLocalManager
/*    */   implements ThreadLocalManager
/*    */ {
/*  7 */   private static ConcurrentHashMap<String, ThreadLocalContainer> allContainers = new ConcurrentHashMap();
/*  8 */   private static ThreadLocalContainer appContainer = new ThreadLocalContainer();
/*  9 */   private static ThreadLocalContainer appFrameworkContainer = new ThreadLocalContainer();
/* 10 */   private static ThreadLocalContainer frameworkContainer = new ThreadLocalContainer();
/*    */ 
/*    */   public ThreadLocalContainer getAppContainer()
/*    */   {
/* 14 */     return appContainer;
/*    */   }
/*    */ 
/*    */   public ThreadLocalContainer getAppFrameworkContainer()
/*    */   {
/* 19 */     return appFrameworkContainer;
/*    */   }
/*    */ 
/*    */   public ThreadLocalContainer getFrameworkContainer()
/*    */   {
/* 24 */     return frameworkContainer;
/*    */   }
/*    */ 
/*    */   public void registerContainer(String name, ThreadLocalContainer container)
/*    */   {
/* 29 */     if (allContainers.containsKey(name))
/*    */     {
/* 31 */       throw new RuntimeException("注册失败,线程变量容器已存在!");
/*    */     }
/* 33 */     allContainers.put(name, container);
/*    */   }
/*    */ 
/*    */   public void removeContainer(String name)
/*    */   {
/* 38 */     allContainers.remove(name);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.datacontainer.DefaultThreadLocalManager
 * JD-Core Version:    0.6.0
 */