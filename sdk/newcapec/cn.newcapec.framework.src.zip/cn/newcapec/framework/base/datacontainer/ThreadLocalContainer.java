/*    */ package cn.newcapec.framework.base.datacontainer;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ 
/*    */ public class ThreadLocalContainer
/*    */ {
/*  8 */   private ThreadLocal<HashMap<String, Object>> threadLocals = new ThreadLocal();
/*    */ 
/*    */   protected Map<String, Object> getThreadLocals() {
/* 11 */     if (this.threadLocals.get() == null) {
/* 12 */       this.threadLocals.set(new HashMap());
/*    */     }
/* 14 */     return (Map)this.threadLocals.get();
/*    */   }
/*    */ 
/*    */   public Object getValue(String name) {
/* 18 */     return getThreadLocals().get(name);
/*    */   }
/*    */ 
/*    */   public void setValue(String name, Object value) {
/* 22 */     getThreadLocals().put(name, value);
/*    */   }
/*    */ 
/*    */   public void clearAll() {
/* 26 */     for (Map.Entry entry : getThreadLocals().entrySet())
/* 27 */       entry.setValue(null);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.datacontainer.ThreadLocalContainer
 * JD-Core Version:    0.6.0
 */