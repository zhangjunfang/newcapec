package cn.newcapec.framework.base.datacontainer;

public abstract interface Condition
{
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.datacontainer.Condition
 * JD-Core Version:    0.6.0
 */