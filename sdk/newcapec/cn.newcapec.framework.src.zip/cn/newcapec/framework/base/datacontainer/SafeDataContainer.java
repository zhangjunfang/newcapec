/*    */ package cn.newcapec.framework.base.datacontainer;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public abstract class SafeDataContainer extends DataContainer
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 10 */   private Map<String, Boolean> readControlInfo = new HashMap();
/*    */ 
/* 12 */   private Map<String, Boolean> writeControlInfo = new HashMap();
/*    */ 
/*    */   public Object getSafeValue(Property property)
/*    */   {
/* 33 */     return super.getValue(property);
/*    */   }
/*    */ 
/*    */   public void setSafeValue(Property property, Object obj)
/*    */   {
/* 39 */     super.setValue(property, obj);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.datacontainer.SafeDataContainer
 * JD-Core Version:    0.6.0
 */