/*     */ package cn.newcapec.framework.base.i18n;
/*     */ 
/*     */ import cn.newcapec.framework.base.log.LogEnabled;
/*     */ import cn.newcapec.framework.utils.tools.BeanUtils;
/*     */ import cn.newcapec.framework.utils.tools.StringUtil;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Map;
/*     */ import java.util.ResourceBundle;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class Message
/*     */   implements LogEnabled
/*     */ {
/*     */   public static String getInfo(String infoCode, String lang)
/*     */   {
/*  31 */     return getInfo(infoCode, lang, null, null, null);
/*     */   }
/*     */ 
/*     */   public static String getInfo(String infoCode, String lang, String[] parms)
/*     */   {
/*  46 */     return getInfo(infoCode, lang, parms, null, null);
/*     */   }
/*     */ 
/*     */   public static String getInfo(String infoCode, String lang, String resName)
/*     */   {
/*  59 */     return getInfo(infoCode, lang, null, resName, null);
/*     */   }
/*     */ 
/*     */   private static String getInfoFromDB(String infoCode, String lang)
/*     */   {
/*  74 */     return null;
/*     */   }
/*     */ 
/*     */   private static String getInfoFromRes(String infoCode, String lang, String resName)
/*     */   {
/*  79 */     ResourceBundle res = ResourceBundle.getBundle(resName, 
/*  80 */       LocaleUtil.getLocale(lang));
/*  81 */     if (res != null)
/*  82 */       return res.getString(infoCode);
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */   public static String getInfo(String infoCode, String lang, Object[] parms, String resName, Object entityObject)
/*     */   {
/*  99 */     String s = null;
/* 100 */     infoCode = StringUtil.trim(infoCode);
/* 101 */     resName = StringUtil.trim(resName);
/*     */ 
/* 103 */     if (infoCode.length() < 1) {
/* 104 */       return s;
/*     */     }
/*     */ 
/* 107 */     if (resName.length() > 0)
/* 108 */       s = getInfoFromRes(infoCode, lang, resName);
/*     */     else {
/* 110 */       s = getInfoFromDB(infoCode, lang);
/*     */     }
/*     */ 
/* 113 */     if ((s == null) || (parms == null) || (parms.length < 1))
/* 114 */       return s;
/*     */     try
/*     */     {
/* 117 */       if (entityObject != null) {
/* 118 */         Map params = BeanUtils.describe(entityObject);
/* 119 */         if (params != null) params.isEmpty();
/*     */ 
/*     */       }
/*     */ 
/* 123 */       String msg = MessageFormat.format(s, parms);
/*     */ 
/* 125 */       return msg;
/*     */     } catch (Exception e) {
/*     */     }
/* 128 */     return s;
/*     */   }
/*     */ 
/*     */   private static void load(String lang)
/*     */   {
/*     */     try
/*     */     {
/* 141 */       sql = "select msg_id,msg_value from ctl_langmsg where lang_code='" + 
/* 142 */         lang + "' order by msg_id";
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       String sql;
/* 145 */       log.error("获取国际资源出错!!", e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.i18n.Message
 * JD-Core Version:    0.6.0
 */