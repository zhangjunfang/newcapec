package cn.newcapec.framework.base.i18n;

public abstract interface Lang
{
  public static final String ZH = "zh";
  public static final String EN = "en";
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.i18n.Lang
 * JD-Core Version:    0.6.0
 */