/*    */ package cn.newcapec.framework.base.i18n;
/*    */ 
/*    */ import cn.newcapec.framework.utils.context.NewcapecContext;
/*    */ import cn.newcapec.framework.utils.tools.GlobalVariant;
/*    */ import cn.newcapec.framework.utils.tools.StringUtil;
/*    */ 
/*    */ public class LangUtil
/*    */ {
/*    */   public static String getLang(NewcapecContext context)
/*    */   {
/* 26 */     String lang = null;
/*    */ 
/* 29 */     lang = context.getParameter("lang");
/* 30 */     lang = StringUtil.trim(lang);
/* 31 */     if (lang.length() > 0) {
/* 32 */       return lang;
/*    */     }
/*    */ 
/* 36 */     lang = (String)context.getAttribute("lang");
/* 37 */     lang = StringUtil.trim(lang);
/* 38 */     if (lang.length() > 0) {
/* 39 */       return lang;
/*    */     }
/*    */ 
/* 53 */     lang = GlobalVariant.getVariant("lang");
/* 54 */     lang = StringUtil.trim(lang);
/* 55 */     if (lang.length() > 0) {
/* 56 */       return "zh";
/*    */     }
/*    */ 
/* 59 */     return "zh";
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.i18n.LangUtil
 * JD-Core Version:    0.6.0
 */