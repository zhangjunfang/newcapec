/*    */ package cn.newcapec.framework.base.i18n;
/*    */ 
/*    */ import cn.newcapec.framework.utils.tools.GlobalVariant;
/*    */ import java.util.Locale;
/*    */ 
/*    */ public final class LocaleUtil
/*    */ {
/* 13 */   private static Locale loc = new Locale("zh", "", "");
/* 14 */   private static boolean inited = false;
/*    */ 
/*    */   static
/*    */   {
/* 51 */     init();
/*    */   }
/*    */ 
/*    */   public static Locale getLocale()
/*    */   {
/* 25 */     return loc;
/*    */   }
/*    */ 
/*    */   public static Locale getLocale(String lang)
/*    */   {
/* 36 */     return new Locale(lang, "", "");
/*    */   }
/*    */ 
/*    */   private static void init() {
/* 40 */     if (!inited) {
/* 41 */       String lang = GlobalVariant.getVariant("lang");
/*    */ 
/* 43 */       if (lang != null) {
/* 44 */         loc = new Locale(lang, "", "");
/*    */       }
/*    */     }
/* 47 */     inited = true;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.i18n.LocaleUtil
 * JD-Core Version:    0.6.0
 */