/*    */ package cn.newcapec.framework.base.dbmeta;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Properties;
/*    */ 
/*    */ public class Container
/*    */ {
/*    */   private String packageName;
/*    */   private Properties properties;
/*    */   private Map tables;
/*    */   boolean fullyLoaded;
/*    */ 
/*    */   public Properties getProperties()
/*    */   {
/* 26 */     return this.properties;
/*    */   }
/*    */ 
/*    */   public void setProperties(Properties properties) {
/* 30 */     this.properties = properties;
/*    */   }
/*    */ 
/*    */   public Map getTables() {
/* 34 */     return this.tables;
/*    */   }
/*    */ 
/*    */   public void setTables(Map tables) {
/* 38 */     this.tables = tables;
/*    */   }
/*    */ 
/*    */   public boolean isFullyLoaded() {
/* 42 */     return this.fullyLoaded;
/*    */   }
/*    */ 
/*    */   public String getProperty(String propertyName) {
/* 46 */     return this.properties.getProperty(propertyName);
/*    */   }
/*    */ 
/*    */   public String getPackageName() {
/* 50 */     return this.packageName;
/*    */   }
/*    */ 
/*    */   public void setPackageName(String packageName) {
/* 54 */     this.packageName = packageName;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dbmeta.Container
 * JD-Core Version:    0.6.0
 */