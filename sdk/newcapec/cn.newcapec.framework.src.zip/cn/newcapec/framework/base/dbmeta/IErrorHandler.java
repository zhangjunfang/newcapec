package cn.newcapec.framework.base.dbmeta;

public abstract interface IErrorHandler
{
  public abstract void onError(String paramString, Throwable paramThrowable);
}

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dbmeta.IErrorHandler
 * JD-Core Version:    0.6.0
 */