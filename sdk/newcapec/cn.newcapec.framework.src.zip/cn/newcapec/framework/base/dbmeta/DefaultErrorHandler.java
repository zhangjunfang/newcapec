/*    */ package cn.newcapec.framework.base.dbmeta;
/*    */ 
/*    */ import cn.newcapec.framework.base.log.LogEnabled;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class DefaultErrorHandler
/*    */   implements IErrorHandler, LogEnabled
/*    */ {
/*    */   public void onError(String s, Throwable throwable)
/*    */   {
/* 12 */     log.error(throwable);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dbmeta.DefaultErrorHandler
 * JD-Core Version:    0.6.0
 */