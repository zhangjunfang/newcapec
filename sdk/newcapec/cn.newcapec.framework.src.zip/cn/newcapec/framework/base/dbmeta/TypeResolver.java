/*    */ package cn.newcapec.framework.base.dbmeta;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.Properties;
/*    */ 
/*    */ public class TypeResolver
/*    */ {
/* 12 */   private static final Properties typeMap = new Properties();
/*    */ 
/*    */   static {
/* 15 */     typeMap.setProperty("float", "float");
/* 16 */     typeMap.setProperty("float unsigned zerofill", "float");
/* 17 */     typeMap.setProperty("double", "double");
/* 18 */     typeMap.setProperty("decimal", "bigdecimal");
/* 19 */     typeMap.setProperty("money", "bigdecimal");
/* 20 */     typeMap.setProperty("currency", "bigdecimal");
/* 21 */     typeMap.setProperty("int", "int");
/* 22 */     typeMap.setProperty("uniqueidentifier", "int");
/* 23 */     typeMap.setProperty("nvarchar", "string");
/* 24 */     typeMap.setProperty("tinyint", "byte");
/* 25 */     typeMap.setProperty("smallint", "short");
/* 26 */     typeMap.setProperty("mediumint", "int");
/* 27 */     typeMap.setProperty("int2", "int");
/* 28 */     typeMap.setProperty("int4", "long");
/* 29 */     typeMap.setProperty("int8", "long");
/* 30 */     typeMap.setProperty("int", "int");
/* 31 */     typeMap.setProperty("int identity", "int");
/* 32 */     typeMap.setProperty("bigint", "long");
/* 33 */     typeMap.setProperty("numeric", "int");
/* 34 */     typeMap.setProperty("number", "int");
/* 35 */     typeMap.setProperty("serial", "int");
/* 36 */     typeMap.setProperty("int unsigned", "int");
/* 37 */     typeMap.setProperty("smallint", "short");
/* 38 */     typeMap.setProperty("mediumint", "int");
/* 39 */     typeMap.setProperty("datetime", "datetime");
/* 40 */     typeMap.setProperty("datetime", "datetime");
/* 41 */     typeMap.setProperty("datetimetz", "datetime");
/* 42 */     typeMap.setProperty("typesysdatetime", "datetime");
/* 43 */     typeMap.setProperty("smalldatetime", "date");
/* 44 */     typeMap.setProperty("interval", "datetime");
/* 45 */     typeMap.setProperty("time", "time");
/* 46 */     typeMap.setProperty("date", "date");
/* 47 */     typeMap.setProperty("smalldate", "date");
/* 48 */     typeMap.setProperty("ntext", "string");
/* 49 */     typeMap.setProperty("text", "string");
/* 50 */     typeMap.setProperty("mediumtext", "string");
/* 51 */     typeMap.setProperty("mediumblob", "binary");
/* 52 */     typeMap.setProperty("longtext", "string");
/* 53 */     typeMap.setProperty("varchar", "string");
/* 54 */     typeMap.setProperty("varchar2", "string");
/* 55 */     typeMap.setProperty("char", "string");
/* 56 */     typeMap.setProperty("bpchar", "string");
/* 57 */     typeMap.setProperty("clob", "string");
/* 58 */     typeMap.setProperty("blob", "binary");
/* 59 */     typeMap.setProperty("bit", "boolean");
/* 60 */     typeMap.setProperty("bool", "boolean");
/* 61 */     typeMap.setProperty("varbinary", "binary");
/* 62 */     typeMap.setProperty("image", "binary");
/* 63 */     typeMap.setProperty("byte", "binary");
/*    */   }
/*    */ 
/*    */   public static String resolveType(String type, boolean useDefault) {
/* 67 */     if (type == null) return null;
/* 68 */     String s = typeMap.getProperty(type.toLowerCase());
/* 69 */     if (s == null) {
/* 70 */       if (useDefault) return "string";
/*    */ 
/* 72 */       for (Enumeration e = typeMap.keys(); e.hasMoreElements(); ) {
/* 73 */         String key = e.nextElement().toString();
/* 74 */         if (type.toLowerCase().startsWith(key.toLowerCase()))
/* 75 */           return typeMap.getProperty(key);
/*    */       }
/* 77 */       return null;
/*    */     }
/*    */ 
/* 81 */     return s;
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dbmeta.TypeResolver
 * JD-Core Version:    0.6.0
 */