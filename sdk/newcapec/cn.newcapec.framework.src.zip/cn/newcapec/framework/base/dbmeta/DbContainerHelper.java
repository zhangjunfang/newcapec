/*     */ package cn.newcapec.framework.base.dbmeta;
/*     */ 
/*     */ import cn.newcapec.framework.base.exception.BaseException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public final class DbContainerHelper
/*     */ {
/*     */   public static Container getDBContainer(String schemaPattern, String tablePattern, Connection conn)
/*     */   {
/*     */     try
/*     */     {
/*  39 */       Container container = new Container();
/*  40 */       DatabaseMetaData databaseMetaData = conn.getMetaData();
/*  41 */       MetaDataRetriever.getTables(container, databaseMetaData, 
/*  42 */         schemaPattern, tablePattern);
/*  43 */       MetaDataRetriever.populateTableData(databaseMetaData, schemaPattern, container);
/*  44 */       return container;
/*     */     }
/*     */     catch (Exception ex) {
/*     */     }
/*  48 */     throw new BaseException("读取数据库配置信息失败！", ex);
/*     */   }
/*     */ 
/*     */   public static List<DBTable> getDBTables(String schemaPattern, String tablePattern, Connection conn)
/*     */   {
/*     */     try
/*     */     {
/*  64 */       Container container = new Container();
/*  65 */       DatabaseMetaData databaseMetaData = conn.getMetaData();
/*  66 */       MetaDataRetriever.getTables(container, databaseMetaData, 
/*  67 */         schemaPattern, tablePattern);
/*  68 */       if ((container.getTables() == null) || 
/*  69 */         (container.getTables().isEmpty())) {
/*  70 */         return null;
/*     */       }
/*  72 */       MetaDataRetriever.populateTableData(databaseMetaData, schemaPattern, container);
/*  73 */       List tables = new ArrayList();
/*  74 */       for (Iterator iterator = container.getTables()
/*  75 */         .entrySet().iterator(); 
/*  75 */         iterator.hasNext(); )
/*     */       {
/*  76 */         tables.add((DBTable)((Map.Entry)iterator.next()).getValue());
/*     */       }
/*  78 */       return tables;
/*     */     } catch (Exception ex) {
/*     */     }
/*  81 */     throw new BaseException("读取数据库配置信息失败！", ex);
/*     */   }
/*     */ 
/*     */   public static DBTable getDBTable(String tableName, Connection conn)
/*     */   {
/*     */     try
/*     */     {
/*  95 */       Container container = new Container();
/*  96 */       DatabaseMetaData databaseMetaData = conn.getMetaData();
/*  97 */       MetaDataRetriever.getTables(container, databaseMetaData, null, 
/*  98 */         tableName);
/*  99 */       MetaDataRetriever.populateTableData(databaseMetaData, null, container);
/* 100 */       if ((container.getTables() == null) || 
/* 101 */         (container.getTables().isEmpty())) {
/* 102 */         return null;
/*     */       }
/* 104 */       return (DBTable)container.getTables().get(tableName);
/*     */     }
/*     */     catch (Exception ex) {
/*     */     }
/* 108 */     throw new BaseException("读取数据库配置信息失败！", ex);
/*     */   }
/*     */ 
/*     */   public static Set<String> getTableList(String schemaPattern, String tablePattern, Connection conn)
/*     */   {
/*     */     try
/*     */     {
/* 123 */       Container container = new Container();
/* 124 */       DatabaseMetaData databaseMetaData = conn.getMetaData();
/* 125 */       MetaDataRetriever.getTables(container, databaseMetaData, 
/* 126 */         schemaPattern, tablePattern);
/* 127 */       if ((container.getTables() == null) || 
/* 128 */         (container.getTables().isEmpty())) {
/* 129 */         return null;
/*     */       }
/*     */ 
/* 132 */       return container.getTables().keySet();
/*     */     }
/*     */     catch (Exception ex) {
/*     */     }
/* 136 */     throw new BaseException("读取数据库配置信息失败！", ex);
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dbmeta.DbContainerHelper
 * JD-Core Version:    0.6.0
 */