/*     */ package cn.newcapec.framework.base.dbmeta;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class MetaDataRetriever extends Thread
/*     */ {
/*     */   private Container container;
/*     */   private DatabaseMetaData metadata;
/*  21 */   private IErrorHandler errorHandler = new DefaultErrorHandler();
/*     */ 
/*     */   public MetaDataRetriever(Container container, DatabaseMetaData metadata, IErrorHandler errorHandler)
/*     */   {
/*  25 */     this.container = container;
/*  26 */     this.metadata = metadata;
/*  27 */     if (errorHandler != null)
/*  28 */       this.errorHandler = errorHandler;
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try {
/*  34 */       populateTableData(this.metadata, null, this.container);
/*     */     } catch (Exception e) {
/*  36 */       this.errorHandler.onError(null, e);
/*     */       try
/*     */       {
/*  39 */         if ((this.metadata != null) && (this.metadata.getConnection() != null))
/*  40 */           this.metadata.getConnection().close();
/*     */       }
/*     */       catch (SQLException localSQLException)
/*     */       {
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/*  39 */         if ((this.metadata != null) && (this.metadata.getConnection() != null))
/*  40 */           this.metadata.getConnection().close();
/*     */       }
/*     */       catch (SQLException localSQLException1)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int getTableCount(DatabaseMetaData metadata, String schemaPattern, String tablePattern)
/*     */     throws SQLException
/*     */   {
/*  58 */     String[] names = { "TABLE" };
/*  59 */     String _schema = null;
/*  60 */     String _table = null;
/*  61 */     if ((schemaPattern != null) && (schemaPattern.trim().length() > 0))
/*  62 */       _schema = schemaPattern.trim();
/*     */     else
/*  64 */       _schema = metadata.getUserName();
/*  65 */     if ((tablePattern != null) && (tablePattern.trim().length() > 0))
/*  66 */       _table = tablePattern.trim();
/*     */     else
/*  68 */       _table = null;
/*  69 */     ResultSet rs = null;
/*     */     try {
/*  71 */       int count = 0;
/*  72 */       rs = metadata.getTables(null, _schema, _table, names);
/*     */ 
/*  75 */       String TABLE_TYPE = "TABLE_TYPE";
/*  76 */       String SYSTEM = "SYSTEM";
/*  77 */       while (rs.next()) {
/*  78 */         String tableType = rs.getString(TABLE_TYPE);
/*  79 */         if ((tableType != null) && 
/*  80 */           (tableType.toUpperCase().indexOf(SYSTEM) >= 0)) continue;
/*  81 */         count++;
/*     */       }
/*     */ 
/*  84 */       int i = count;
/*     */       return i;
/*     */     } finally {
/*  86 */       if (rs != null)
/*  87 */         rs.close(); 
/*     */     }
/*  88 */     throw localObject;
/*     */   }
/*     */ 
/*     */   public static void getTables(Container container, DatabaseMetaData metadata, String schemaPattern, String tablePattern)
/*     */     throws SQLException
/*     */   {
/* 104 */     String[] names = { "TABLE" };
/* 105 */     String _schema = null;
/* 106 */     String _table = null;
/* 107 */     if ((schemaPattern != null) && (schemaPattern.trim().length() > 0))
/* 108 */       _schema = schemaPattern.trim();
/*     */     else {
/* 110 */       _schema = metadata.getUserName();
/*     */     }
/* 112 */     if ((tablePattern != null) && (tablePattern.trim().length() > 0))
/* 113 */       _table = tablePattern.trim();
/*     */     else
/* 115 */       _table = null;
/* 116 */     ResultSet rs = null;
/*     */     try {
/* 118 */       rs = metadata.getTables(null, _schema, _table, names);
/* 119 */       Map tables = new HashMap();
/* 120 */       String TABLE_NAME = "TABLE_NAME";
/* 121 */       String TABLE_TYPE = "TABLE_TYPE";
/* 122 */       String SYSTEM = "SYSTEM";
/* 123 */       while (rs.next()) {
/* 124 */         String tableName = rs.getString(TABLE_NAME);
/* 125 */         if (tableName.indexOf("$") != -1) {
/*     */           continue;
/*     */         }
/* 128 */         DBTable table = new DBTable(container, tableName);
/* 129 */         String tableType = rs.getString(TABLE_TYPE);
/* 130 */         if ((tableType != null) && 
/* 131 */           (tableType.toUpperCase().indexOf(SYSTEM) >= 0)) continue;
/* 132 */         tables.put(table.getName(), table);
/*     */       }
/*     */ 
/* 135 */       container.setTables(tables);
/*     */     } finally {
/* 137 */       if (rs != null)
/* 138 */         rs.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void populateTableData(DatabaseMetaData metadata, String schemaPattern, Container container)
/*     */     throws SQLException
/*     */   {
/* 152 */     Map tables = container.getTables();
/* 153 */     for (Iterator i = tables.values().iterator(); i.hasNext(); ) {
/* 154 */       DBTable table = (DBTable)i.next();
/* 155 */       readTableColumns(metadata, schemaPattern, table);
/*     */     }
/* 157 */     for (Iterator i = tables.values().iterator(); i.hasNext(); ) {
/* 158 */       DBTable table = (DBTable)i.next();
/* 159 */       readTableKeys(metadata, schemaPattern, table, tables);
/*     */     }
/* 161 */     for (Iterator i = tables.values().iterator(); i.hasNext(); ) {
/* 162 */       DBTable table = (DBTable)i.next();
/* 163 */       table.init();
/*     */     }
/* 165 */     container.fullyLoaded = true;
/*     */   }
/*     */ 
/*     */   private static void readTableColumns(DatabaseMetaData meta, String schemaPattern, DBTable table)
/*     */     throws SQLException
/*     */   {
/* 179 */     ResultSet columns = null;
/*     */     try {
/* 181 */       if ((schemaPattern != null) && (schemaPattern.trim().length() > 0))
/* 182 */         schemaPattern = schemaPattern.trim();
/*     */       else
/* 184 */         schemaPattern = meta.getUserName();
/* 185 */       columns = meta.getColumns(null, schemaPattern, table.getName(), "%");
/* 186 */       while (columns.next()) {
/* 187 */         String columnName = columns.getString("COLUMN_NAME");
/* 188 */         String datatype = columns.getString("TYPE_NAME");
/* 189 */         int datasize = columns.getInt("COLUMN_SIZE");
/* 190 */         int digits = columns.getInt("DECIMAL_DIGITS");
/* 191 */         int nullable = columns.getInt("NULLABLE");
/* 192 */         DBColumn newColumn = new DBColumn(table, columnName, datatype, 
/* 193 */           datasize, digits, nullable);
/* 194 */         table.notifyColumn(newColumn);
/*     */       }
/*     */     } finally {
/* 197 */       if (columns != null)
/* 198 */         columns.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void readTableKeys(DatabaseMetaData meta, String schemaPattern, DBTable table, Map tables)
/*     */     throws SQLException
/*     */   {
/* 213 */     ResultSet keys = null;
/*     */     try {
/* 215 */       if ((schemaPattern != null) && (schemaPattern.trim().length() > 0))
/* 216 */         schemaPattern = schemaPattern.trim();
/*     */       else {
/* 218 */         schemaPattern = meta.getUserName();
/*     */       }
/* 220 */       keys = meta.getPrimaryKeys(null, schemaPattern, table.getName());
/* 221 */       while (keys.next()) {
/* 222 */         String tableName = keys.getString("TABLE_NAME");
/* 223 */         String columnName = keys.getString("COLUMN_NAME");
/* 224 */         table = (DBTable)tables.get(checkName(tableName));
/* 225 */         table.notifyPrimaryKey(checkName(columnName));
/*     */       }
/*     */ 
/* 229 */       keys = meta.getImportedKeys(null, schemaPattern, table.getName());
/*     */ 
/* 231 */       while (keys.next()) {
/* 232 */         String pkTableName = keys.getString("PKTABLE_NAME");
/* 233 */         pkTableName = keys.getString("PKTABLE_NAME");
/* 234 */         String pkColumnName = keys.getString("PKCOLUMN_NAME");
/* 235 */         String fkTableName = keys.getString("FKTABLE_NAME");
/* 236 */         String fkColumnName = keys.getString("FKCOLUMN_NAME");
/* 237 */         DBTable pkTable = (DBTable)tables.get(checkName(pkTableName));
/* 238 */         DBTable fkTable = (DBTable)tables.get(checkName(fkTableName));
/* 239 */         if ((pkTable != null) && (fkTable != null)) {
/* 240 */           DBColumn pkColumn = pkTable
/* 241 */             .getColumn(checkName(pkColumnName));
/* 242 */           if (pkColumn != null)
/* 243 */             table.notifyForeignKey(checkName(fkColumnName), 
/* 244 */               pkColumn);
/*     */         }
/*     */       }
/*     */     } finally {
/* 248 */       if (keys != null)
/* 249 */         keys.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static String checkName(String s) {
/* 254 */     if (s == null)
/* 255 */       return null;
/* 256 */     s = stringReplace(s, "`", "");
/* 257 */     return s;
/*     */   }
/*     */ 
/*     */   public static String stringReplace(String base, String from, String to)
/*     */   {
/* 272 */     StringBuffer sb1 = new StringBuffer(base);
/* 273 */     StringBuffer sb2 = new StringBuffer(base.length() + 50);
/* 274 */     char[] f = from.toCharArray();
/* 275 */     char[] t = to.toCharArray();
/* 276 */     char[] test = new char[f.length];
/*     */ 
/* 278 */     for (int x = 0; x < sb1.length(); x++)
/*     */     {
/* 280 */       if (x + test.length > sb1.length()) {
/* 281 */         sb2.append(sb1.charAt(x));
/*     */       } else {
/* 283 */         sb1.getChars(x, x + test.length, test, 0);
/* 284 */         if (aEquals(test, f)) {
/* 285 */           sb2.append(t);
/* 286 */           x = x + test.length - 1;
/*     */         } else {
/* 288 */           sb2.append(sb1.charAt(x));
/*     */         }
/*     */       }
/*     */     }
/* 292 */     return sb2.toString();
/*     */   }
/*     */ 
/*     */   private static boolean aEquals(char[] a, char[] b) {
/* 296 */     if (a.length != b.length) {
/* 297 */       return false;
/*     */     }
/* 299 */     for (int x = 0; x < a.length; x++) {
/* 300 */       if (a[x] != b[x]) {
/* 301 */         return false;
/*     */       }
/*     */     }
/* 304 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dbmeta.MetaDataRetriever
 * JD-Core Version:    0.6.0
 */