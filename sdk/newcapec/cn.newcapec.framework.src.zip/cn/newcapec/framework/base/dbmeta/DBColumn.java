/*     */ package cn.newcapec.framework.base.dbmeta;
/*     */ 
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class DBColumn
/*     */ {
/*     */   private DBTable table;
/*     */   private String name;
/*     */   private String dataType;
/*     */   private int size;
/*     */   private int digits;
/*     */   private int nullable;
/*     */   private String metaData;
/*     */   boolean primaryKey;
/*     */   DBColumn fkParentKey;
/*     */   private String fkPropName;
/*     */   private String propName;
/*     */   private String javaType;
/*     */   private Integer hashCode;
/*     */ 
/*     */   public DBColumn()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DBColumn(DBTable table, String name, String dataType, int size, int digits, int nullable)
/*     */   {
/*  45 */     setName(name);
/*  46 */     setDataType(dataType);
/*  47 */     if (size <= 4096)
/*  48 */       setSize(size);
/*  49 */     setDigits(digits);
/*  50 */     setNullable(nullable);
/*     */   }
/*     */ 
/*     */   public boolean isPrimaryKey() {
/*  54 */     return this.primaryKey;
/*     */   }
/*     */ 
/*     */   public boolean isForeignKey() {
/*  58 */     return this.fkParentKey != null;
/*     */   }
/*     */ 
/*     */   public DBTable getParentTable() {
/*  62 */     if (this.fkParentKey == null) {
/*  63 */       return null;
/*     */     }
/*  65 */     return this.fkParentKey.getTable();
/*     */   }
/*     */ 
/*     */   protected Properties getProperties() {
/*  69 */     return this.table.getProperties();
/*     */   }
/*     */ 
/*     */   public void setPropName(String propName) {
/*  73 */     this.propName = propName;
/*  74 */     this.fkPropName = propName;
/*     */   }
/*     */ 
/*     */   public boolean isNull() {
/*  78 */     return this.nullable == 1;
/*     */   }
/*     */ 
/*     */   private boolean isInteger(String type)
/*     */   {
/*  86 */     if (type == null) return false;
/*  87 */     if (type.equals("int")) return true;
/*  88 */     if (type.equals("short")) return true;
/*  89 */     return type.equals("long");
/*     */   }
/*     */ 
/*     */   public boolean isTypeResolved()
/*     */   {
/*  97 */     return TypeResolver.resolveType(getDataType(), false) != null;
/*     */   }
/*     */ 
/*     */   public String getDataType() {
/* 101 */     return this.dataType;
/*     */   }
/*     */ 
/*     */   public void setDataType(String dataType) {
/* 105 */     this.dataType = dataType;
/*     */   }
/*     */ 
/*     */   public int getDigits() {
/* 109 */     return this.digits;
/*     */   }
/*     */ 
/*     */   public void setDigits(int digits) {
/* 113 */     this.digits = digits;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 117 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/* 121 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public void setNullable(int nullable) {
/* 125 */     this.nullable = nullable;
/*     */   }
/*     */ 
/*     */   public int getSize() {
/* 129 */     return this.size;
/*     */   }
/*     */ 
/*     */   public void setSize(int size) {
/* 133 */     this.size = size;
/*     */   }
/*     */ 
/*     */   public DBTable getTable() {
/* 137 */     return this.table;
/*     */   }
/*     */ 
/*     */   public void setTable(DBTable table) {
/* 141 */     this.table = table;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 145 */     return getName() + " (" + getDataType() + ")";
/*     */   }
/*     */ 
/*     */   public String getMetaData() {
/* 149 */     return this.metaData;
/*     */   }
/*     */ 
/*     */   public void setMetaData(String metaData) {
/* 153 */     this.metaData = metaData;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj) {
/* 157 */     if ((obj == null) || (!(obj instanceof DBColumn)))
/* 158 */       return false;
/* 159 */     if ((getTable().getName() == null) || (getName() == null))
/* 160 */       return false;
/* 161 */     DBColumn col = (DBColumn)obj;
/* 162 */     if ((col.getTable().getName() == null) || (col.getName() == null)) {
/* 163 */       return false;
/*     */     }
/* 165 */     return (col.getTable().getName().equals(getTable().getName())) && 
/* 165 */       (col.getName().equals(getName()));
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 169 */     if (this.hashCode == null) {
/* 170 */       if ((getTable().getName() == null) || (getName() == null))
/* 171 */         return super.hashCode();
/* 172 */       this.hashCode = 
/* 173 */         new Integer(new String(getTable().getName() + ":" + 
/* 173 */         getName()).hashCode());
/*     */     }
/* 175 */     return this.hashCode.intValue();
/*     */   }
/*     */ 
/*     */   public String getJavaType()
/*     */   {
/* 182 */     if (this.javaType == null) {
/* 183 */       this.javaType = TypeResolver.resolveType(getDataType(), true);
/* 184 */       if ((this.javaType != null) && 
/* 185 */         (isInteger(this.javaType)) && 
/* 186 */         (this.digits > 0)) this.javaType = "bigdecimal";
/*     */ 
/* 189 */       if (this.javaType == null) this.javaType = getDataType();
/*     */     }
/* 191 */     return this.javaType;
/*     */   }
/*     */ 
/*     */   public String getPropName()
/*     */   {
/* 198 */     return this.propName;
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dbmeta.DBColumn
 * JD-Core Version:    0.6.0
 */