/*     */ package cn.newcapec.framework.base.dbmeta;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class DBTable
/*     */   implements Comparable
/*     */ {
/*     */   private String name;
/*     */   private String metaData;
/*     */   private Container container;
/*     */   private List columns;
/*     */   private Map pKeys;
/*     */   private Map fKeys;
/*     */   private Map columnMap;
/*     */ 
/*     */   public void removeColumn(String columnName)
/*     */   {
/*  33 */     DBColumn column = getColumn(columnName);
/*  34 */     this.pKeys.remove(column);
/*  35 */     this.fKeys.remove(column);
/*  36 */     this.columnMap.remove(column.getName());
/*  37 */     this.columns.remove(column);
/*     */   }
/*     */ 
/*     */   public DBTable(Container container) {
/*  41 */     this.columns = new ArrayList();
/*     */ 
/*  43 */     this.columnMap = new HashMap();
/*  44 */     this.container = container;
/*     */   }
/*     */ 
/*     */   public DBTable(Container container, String name) {
/*  48 */     this.columns = new ArrayList();
/*     */ 
/*  50 */     this.columnMap = new HashMap();
/*  51 */     setName(name);
/*  52 */     this.container = container;
/*     */   }
/*     */ 
/*     */   public DBTable(String name, Container container) {
/*  56 */     this.columns = new ArrayList();
/*     */ 
/*  58 */     this.columnMap = new HashMap();
/*  59 */     setName(name);
/*  60 */     this.container = container;
/*     */   }
/*     */ 
/*     */   public void init() {
/*  64 */     if (this.pKeys == null)
/*  65 */       this.pKeys = new HashMap();
/*  66 */     if (this.fKeys == null)
/*  67 */       this.fKeys = new HashMap();
/*     */   }
/*     */ 
/*     */   public void setContainer(Container container)
/*     */   {
/*  72 */     this.container = container;
/*     */   }
/*     */ 
/*     */   public void notifyPrimaryKey(String columnName) {
/*  76 */     DBColumn column = (DBColumn)this.columnMap.get(columnName);
/*  77 */     if (column != null) {
/*  78 */       if (this.pKeys == null)
/*  79 */         this.pKeys = new HashMap();
/*  80 */       this.pKeys.put(column.getName(), column);
/*  81 */       column.primaryKey = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void notifyColumn(DBColumn column) {
/*  86 */     column.setTable(this);
/*  87 */     this.columns.add(column);
/*  88 */     this.columnMap.put(column.getName(), column);
/*     */   }
/*     */ 
/*     */   public void notifyForeignKey(String columnName, DBColumn parentKey) {
/*  92 */     DBColumn column = (DBColumn)this.columnMap.get(columnName);
/*  93 */     if (column != null) {
/*  94 */       column.fkParentKey = parentKey;
/*  95 */       if (this.fKeys == null)
/*  96 */         this.fKeys = new HashMap();
/*  97 */       this.fKeys.put(column.getName(), column);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Properties getProperties() {
/* 102 */     return this.container.getProperties();
/*     */   }
/*     */ 
/*     */   public boolean hasCompositeKey() {
/* 106 */     return getPkColumns().size() > 1;
/*     */   }
/*     */ 
/*     */   public boolean isCompositeKeyOnly()
/*     */   {
/* 111 */     return (getPkColumns().size() > 1) && 
/* 111 */       (getPkColumns().size() == getColumns().size());
/*     */   }
/*     */ 
/*     */   public boolean isForeignKey(DBColumn column) {
/* 115 */     if (this.fKeys == null)
/* 116 */       return false;
/* 117 */     return this.fKeys.get(column.getName()) != null;
/*     */   }
/*     */ 
/*     */   public Collection getFKColumns() {
/* 121 */     if (this.fKeys == null) {
/* 122 */       return new ArrayList(0);
/*     */     }
/* 124 */     return this.fKeys.values();
/*     */   }
/*     */ 
/*     */   public Collection getPkColumns() {
/* 128 */     if (this.pKeys == null) {
/* 129 */       return new ArrayList(0);
/*     */     }
/* 131 */     return this.pKeys.values();
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 135 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String getClassName() {
/* 139 */     return getName();
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/* 143 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public List getColumns() {
/* 147 */     return this.columns;
/*     */   }
/*     */ 
/*     */   public DBColumn getColumn(String columnName) {
/* 151 */     return (DBColumn)this.columnMap.get(columnName);
/*     */   }
/*     */ 
/*     */   public String getMetaData() {
/* 155 */     return this.metaData;
/*     */   }
/*     */ 
/*     */   public void setMetaData(String metaData) {
/* 159 */     this.metaData = metaData;
/*     */   }
/*     */ 
/*     */   public int compareTo(Object obj) {
/* 163 */     if ((obj == null) || (!(obj instanceof DBTable))) {
/* 164 */       return -1;
/*     */     }
/* 166 */     return getName().compareTo(((DBTable)obj).getName());
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.dbmeta.DBTable
 * JD-Core Version:    0.6.0
 */