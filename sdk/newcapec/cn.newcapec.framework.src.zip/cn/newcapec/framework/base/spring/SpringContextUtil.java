/*    */ package cn.newcapec.framework.base.spring;
/*    */ 
/*    */ import org.springframework.context.ApplicationContext;
/*    */ 
/*    */ public class SpringContextUtil
/*    */ {
/*    */   public static Object getBean(String beanName)
/*    */   {
/* 16 */     return ServiceLocator.instance().getContext().getBean(beanName);
/*    */   }
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.spring.SpringContextUtil
 * JD-Core Version:    0.6.0
 */