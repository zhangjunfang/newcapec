/*     */ package cn.newcapec.framework.base.spring;
/*     */ 
/*     */ import org.springframework.beans.factory.access.BeanFactoryLocator;
/*     */ import org.springframework.beans.factory.access.BeanFactoryReference;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.access.ContextSingletonBeanFactoryLocator;
/*     */ 
/*     */ public class ServiceLocator
/*     */ {
/*  15 */   private static final ServiceLocator instance = new ServiceLocator();
/*     */   private BeanFactoryReference beanFactoryReference;
/*     */   private String beanFactoryReferenceLocation;
/*     */   private String beanRefFactoryReferenceId;
/*  74 */   private final String DEFAULT_BEAN_REFERENCE_LOCATION = "classpath:com/newstar/cfg/newstar-core.xml";
/*     */ 
/*  79 */   private final String DEFAULT_BEAN_REFERENCE_ID = "newstar-core";
/*     */ 
/*     */   public static final ServiceLocator instance()
/*     */   {
/*  23 */     return instance;
/*     */   }
/*     */ 
/*     */   public synchronized void init(String beanFactoryReferenceLocation, String beanRefFactoryReferenceId)
/*     */   {
/*  52 */     this.beanFactoryReferenceLocation = beanFactoryReferenceLocation;
/*  53 */     this.beanRefFactoryReferenceId = beanRefFactoryReferenceId;
/*  54 */     this.beanFactoryReference = null;
/*     */   }
/*     */ 
/*     */   public synchronized void init(String beanFactoryReferenceLocation)
/*     */   {
/*  67 */     this.beanFactoryReferenceLocation = beanFactoryReferenceLocation;
/*  68 */     this.beanFactoryReference = null;
/*     */   }
/*     */ 
/*     */   public synchronized ApplicationContext getContext()
/*     */   {
/*  85 */     if (this.beanFactoryReference == null) {
/*  86 */       if (this.beanFactoryReferenceLocation == null) {
/*  87 */         this.beanFactoryReferenceLocation = "classpath:com/newstar/cfg/newstar-core.xml";
/*     */       }
/*  89 */       if (this.beanRefFactoryReferenceId == null) {
/*  90 */         this.beanRefFactoryReferenceId = "newstar-core";
/*     */       }
/*  92 */       BeanFactoryLocator beanFactoryLocator = 
/*  93 */         ContextSingletonBeanFactoryLocator.getInstance(this.beanFactoryReferenceLocation);
/*  94 */       this.beanFactoryReference = beanFactoryLocator
/*  95 */         .useBeanFactory(this.beanRefFactoryReferenceId);
/*     */     }
/*  97 */     return (ApplicationContext)this.beanFactoryReference
/*  98 */       .getFactory();
/*     */   }
/*     */ 
/*     */   public synchronized void shutdown()
/*     */   {
/* 105 */     if (this.beanFactoryReference != null) {
/* 106 */       this.beanFactoryReference.release();
/* 107 */       this.beanFactoryReference = null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.spring.ServiceLocator
 * JD-Core Version:    0.6.0
 */