/*    */ package cn.newcapec.framework.base.log;
/*    */ 
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public abstract interface LogEnabled
/*    */ {
/* 11 */   public static final Logger log = Logger.getLogger(LogEnabled.class);
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.base.log.LogEnabled
 * JD-Core Version:    0.6.0
 */