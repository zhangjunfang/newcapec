/*    */ package cn.newcapec.framework.constant;
/*    */ 
/*    */ public class SystemConstant
/*    */ {
/* 15 */   public static String IMG_EXT_NAME_PNG = "png";
/*    */ }

/* Location:           D:\eclipse4.2\NSP03\dist\cn.newcapec.framework.jar
 * Qualified Name:     cn.newcapec.framework.constant.SystemConstant
 * JD-Core Version:    0.6.0
 */