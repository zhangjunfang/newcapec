/**
 * @Title SystemConstant.java
 * @Description TODO
 * @author  andy.li
 */
package cn.newcapec.foundation.privilege.constant;

/**
 * @Title 系统常量类
 * @Description TODO
 * @author andy.li
 */
public class privilegeConstant {

	///////////////////////////////////角色状态//////////////////////////////////////////////////
	/* 角色停用 */
	public static String roleDisabled = "disabled";
	/* 角色启用 */
	public static String roleNormal = "normal";

}
