package cn.newcapec.framework.core.exception.asserts;

import cn.newcapec.framework.core.rest.Msg;

public interface AssertObject {

	
	void AssertMethod(Msg Msg);
}
