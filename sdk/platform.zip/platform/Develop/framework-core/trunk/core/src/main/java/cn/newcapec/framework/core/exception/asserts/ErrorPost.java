package cn.newcapec.framework.core.exception.asserts;

import cn.newcapec.framework.core.exception.BaseException;

public interface ErrorPost {

	
	Object doInstancePost() throws BaseException;
}
