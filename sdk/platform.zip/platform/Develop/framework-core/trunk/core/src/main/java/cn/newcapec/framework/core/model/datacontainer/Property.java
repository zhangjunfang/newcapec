package cn.newcapec.framework.core.model.datacontainer;

public interface Property {

	String getName();
	Class<?> getType();
}
