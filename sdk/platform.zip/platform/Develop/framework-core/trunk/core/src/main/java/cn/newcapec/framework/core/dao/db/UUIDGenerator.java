package cn.newcapec.framework.core.dao.db;

/**
 * 功能描述：UUID生成器接口
 * 
 */
public interface UUIDGenerator {

	public String generate();

}