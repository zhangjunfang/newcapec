package cn.newcapec.framework.core.i18n;

/**
 * 语种列举.
 * @author andy.li
 * 
 */
public interface Lang {
	String ZH = "zh";
	String EN = "en";
}
