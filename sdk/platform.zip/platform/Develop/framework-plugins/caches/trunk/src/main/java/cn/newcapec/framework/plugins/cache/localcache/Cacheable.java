package cn.newcapec.framework.plugins.cache.localcache;

public interface Cacheable {
    int getCachedSize();
}
