package cn.newcapec.framework.plugins.cache;

import java.io.Serializable;

public interface Cache extends Serializable {

}
